# Advanced GLM Residual Analysis Pipeline
### General Insurance — Pricing & Data Science

---

## Overview

This framework systematically detects **systematic mis-pricing patterns** that GLM-based
frequency/severity models miss — without touching the filed rating structure.

It is designed for use by pricing actuaries and data scientists in regulated general
insurance environments where:
- GLMs are filed with regulators and cannot be replaced mid-cycle
- Advanced ML must *complement*, not replace, the filed model
- All outputs must be explainable and defensible

---

## Architecture

```
glm_residual_analysis/
├── pipeline.py              ← Main orchestrator (run this)
├── utils/
│   ├── data_utils.py        ← Data simulation & preprocessing
│   └── visualisation.py    ← 9-chart publication-quality suite
├── models/
│   └── models.py            ← All 8 models + ensemble
└── outputs/
    ├── figures/             ← 9 PNG charts
    ├── model_comparison.csv
    ├── flagged_policies.csv
    ├── test_set_enriched.csv
    └── report_summary.json
```

---

## Models Implemented

| # | Model | Purpose | Key Strength |
|---|-------|---------|-------------|
| 1 | **Gradient Boosting** (Huber loss) | Non-linear residual capture | Interaction detection, robust to outliers |
| 2 | **Random Forest** | Ensemble benchmark + prediction intervals | Uncertainty quantification |
| 3 | **Neural Network** (MLP 128→64→32) | Deep feature interactions | Captures complex non-linearities |
| 4 | **Polynomial Ridge** (degree 2) | Explicit interaction surfacing | Names exact GLM interaction gaps |
| 5 | **KMeans + Ridge** Segmentation | Segment-level re-calibration | Identifies structured risk clusters |
| 6 | **Isolation Forest** | Anomaly / UW referral flagging | Structural outlier detection |
| 7 | **Gaussian Process** | Uncertainty-aware modelling | Confidence intervals on predictions |
| 8 | **Ensemble Meta-Learner** | Stacked combination | Best overall predictive accuracy |

---

## Pipeline Steps

| Step | Description | Output |
|------|-------------|--------|
| 1 | Data loading & validation | Console summary |
| 2 | Exploratory residual analysis | Zone/year/class breakdown |
| 3 | Feature preparation | 9-feature matrix |
| 4 | **Temporal train/test split** | 2018–2021 train / 2022–2023 test |
| 5 | Train all 7 base models | ModelResult objects |
| 6 | Ensemble meta-learner | Stacked predictions |
| 7 | Evaluation & comparison | `model_comparison.csv` |
| 8 | 9-chart visualisation suite | `outputs/figures/*.png` |
| 9 | Actionable risk reporting | `flagged_policies.csv` |
| 10 | Artefact export | All CSVs + JSON |

---

## Usage

### Run on synthetic data (default)
```bash
python pipeline.py
python pipeline.py --n 100000    # larger dataset
```

### Run on your own data
```bash
python pipeline.py --data your_portfolio.csv
```

**Required columns in your CSV:**
- `actual_pure_premium` — observed pure premium per policy
- `glm_pure_premium_pred` — your GLM's pure premium prediction
- `residual_pearson` — Pearson residual from GLM fit
- `driver_age`, `vehicle_age`, `vehicle_value`, `annual_mileage`
- `no_claims_discount`, `occupation_class`, `policy_year`, `exposure`
- `postcode_zone` (categorical)

---

## Output Charts

| Chart | Description |
|-------|-------------|
| `01_residual_overview.png` | 6-panel EDA dashboard |
| `02_feature_importance.png` | Feature importance comparison across models |
| `03_model_comparison.png` | RMSE / MAE / R² across all models |
| `04_interaction_heatmap.png` | Driver age × Vehicle age residual heatmap |
| `05_segment_analysis.png` | KMeans cluster analysis |
| `06_anomaly_detection.png` | Isolation Forest anomaly flags |
| `07_training_curves.png` | GB convergence + NN loss curve |
| `08_lift_chart.png` | Decile lift chart vs GLM |
| `09_ensemble_weights.png` | Meta-learner base model weights |

---

## Regulatory Positioning

All models in this pipeline are **internal diagnostic tools only**:
- They do NOT modify the filed rating structure
- They DO identify segments for future rate review filings
- The anomaly detector flags risks for **manual underwriting review**
- The temporal drift monitor provides evidence for **emergency rate revisions**
- All outputs are explainable via feature importance and SHAP-style decompositions

---

## Dependencies

```
numpy, pandas, scikit-learn, matplotlib, scipy
```
All available in standard Python 3.x environments. No external API calls required.

---

## Extending the Framework

To add your own model:

```python
# In models/models.py — add your class:
class MyCustomModel:
    def fit(self, X, y): ...
    def predict(self, X): ...
    def result(self, X, y) -> ModelResult: ...

# In pipeline.py step5_train_models — add:
my_model = MyCustomModel()
my_model.fit(X_train, y_train)
results['My Model'] = my_model.result(X_test, y_test)
```
