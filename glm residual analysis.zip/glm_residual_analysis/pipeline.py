"""
pipeline.py
===========
Main orchestrator for the Advanced GLM Residual Analysis Pipeline.

Steps
-----
  Step 1  — Data Loading & Validation
  Step 2  — Exploratory Residual Analysis
  Step 3  — Feature Preparation
  Step 4  — Train/Test Split (temporal — respects insurance rating review cycle)
  Step 5  — Model Training (GB, RF, NN, Poly, Segment, GP, Anomaly)
  Step 6  — Ensemble Meta-Learner
  Step 7  — Evaluation & Comparison
  Step 8  — Visualisation Suite
  Step 9  — Reporting (actionable segment flags)
  Step 10 — Artefact Export

Usage
-----
    python pipeline.py                    # run full pipeline on synthetic data
    python pipeline.py --n 100000         # larger synthetic dataset
    python pipeline.py --data my_data.csv # your own data
"""

import os
import sys
import time
import argparse
import warnings
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

warnings.filterwarnings('ignore')

# ── Local imports ─────────────────────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(__file__))
from utils.data_utils import (
    simulate_insurance_data, encode_categoricals, get_feature_columns
)
from models.models import (
    GBResidualModel, RFResidualModel, NNResidualModel,
    PolyInteractionModel, SegmentRecalibrator,
    GPResidualModel, AnomalyDetector, EnsembleMetaLearner
)
from utils.visualisation import (
    plot_residual_overview, plot_feature_importance,
    plot_model_comparison, plot_interaction_heatmap,
    plot_segment_analysis, plot_anomaly_detection,
    plot_training_curves, plot_lift_chart, plot_ensemble_weights
)

OUTDIR = '/home/claude/glm_residual_analysis/outputs'
os.makedirs(OUTDIR, exist_ok=True)
os.makedirs(f'{OUTDIR}/figures', exist_ok=True)


# ════════════════════════════════════════════════════════════════════════════
# Helpers
# ════════════════════════════════════════════════════════════════════════════

def banner(step: int, title: str):
    print(f'\n{"="*70}')
    print(f'  STEP {step}: {title.upper()}')
    print(f'{"="*70}')


def timer(func):
    def wrapper(*args, **kwargs):
        t0 = time.time()
        result = func(*args, **kwargs)
        print(f'  ⏱  Completed in {time.time()-t0:.1f}s')
        return result
    return wrapper


# ════════════════════════════════════════════════════════════════════════════
# Step 1 — Data
# ════════════════════════════════════════════════════════════════════════════

@timer
def step1_load_data(args) -> pd.DataFrame:
    banner(1, 'Data Loading & Validation')
    if args.data:
        print(f'  Loading from: {args.data}')
        df = pd.read_csv(args.data)
        required = ['actual_pure_premium', 'glm_pure_premium_pred', 'residual_pearson']
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(f'Missing required columns: {missing}')
    else:
        print(f'  Generating synthetic insurance dataset (n={args.n:,})')
        df = simulate_insurance_data(n_policies=args.n)

    df = encode_categoricals(df)
    print(f'  Policies loaded : {len(df):,}')
    print(f'  Policy years    : {df["policy_year"].min()} – {df["policy_year"].max()}')
    print(f'  Claims          : {df["claim_count"].sum():,} '
          f'({df["claim_count"].mean():.3f} avg freq)')
    print(f'  Avg GLM pure premium : £{df["glm_pure_premium_pred"].mean():,.0f}')
    print(f'  Avg actual pure prem : £{df["actual_pure_premium"].mean():,.0f}')
    print(f'  Mean Pearson residual: {df["residual_pearson"].mean():.4f}')
    return df


# ════════════════════════════════════════════════════════════════════════════
# Step 2 — Exploratory Residual Analysis
# ════════════════════════════════════════════════════════════════════════════

@timer
def step2_exploratory(df: pd.DataFrame) -> dict:
    banner(2, 'Exploratory Residual Analysis')

    eda = {}

    # Normality test
    from scipy.stats import shapiro, normaltest
    sample = df['residual_pearson'].sample(min(5000, len(df)), random_state=42)
    stat, pval = normaltest(sample)
    eda['normality_pval'] = float(pval)
    print(f"  D'Agostino normality test p-value: {pval:.4e} "
          f'({"NOT normal" if pval < 0.05 else "approx normal"})')

    # Top mispriced segments
    print('\n  Top 5 UNDERPRICED postcode zones (mean Pearson residual):')
    zone_resid = df.groupby('postcode_zone')['residual_pearson'].mean().sort_values(ascending=False)
    for zone, val in zone_resid.head(5).items():
        print(f'    Zone {zone}: {val:+.4f}')

    print('\n  Top 5 OVERPRICED occupation classes:')
    occ_resid = df.groupby('occupation_class')['residual_pearson'].mean().sort_values()
    for occ, val in occ_resid.head(5).items():
        print(f'    Occupation {occ}: {val:+.4f}')

    # Temporal drift
    print('\n  Year-over-year mean residual drift:')
    yr = df.groupby('policy_year')['residual_raw'].mean()
    for y, v in yr.items():
        bar = '█' * int(abs(v) * 5)
        sign = '+' if v > 0 else ''
        print(f'    {y}: {sign}{v:,.1f}  {bar}')

    eda['zone_residuals'] = zone_resid.to_dict()
    eda['yearly_drift']   = yr.to_dict()
    return eda


# ════════════════════════════════════════════════════════════════════════════
# Step 3 — Feature Preparation
# ════════════════════════════════════════════════════════════════════════════

@timer
def step3_features(df: pd.DataFrame):
    banner(3, 'Feature Preparation')
    feat_cols = get_feature_columns()
    X = df[feat_cols]
    y = df['residual_pearson'].values

    print(f'  Feature set ({len(feat_cols)} features): {feat_cols}')
    print(f'  Target: Pearson residual  |  mean={y.mean():.4f}, std={y.std():.4f}')
    print(f'  Missing values: {X.isnull().sum().sum()}')
    return X, y, feat_cols


# ════════════════════════════════════════════════════════════════════════════
# Step 4 — Train / Test Split (temporal)
# ════════════════════════════════════════════════════════════════════════════

@timer
def step4_split(df: pd.DataFrame, X: pd.DataFrame, y: np.ndarray):
    banner(4, 'Temporal Train / Test Split')
    # Simulate regulatory review cycle: train on 2018–2021, test on 2022–2023
    train_mask = df['policy_year'] <= 2021
    test_mask  = ~train_mask

    X_train, X_test = X[train_mask], X[test_mask]
    y_train, y_test = y[train_mask], y[test_mask]
    df_train, df_test = df[train_mask], df[test_mask]

    print(f'  Train set: {len(X_train):,} policies '
          f'(years {df[train_mask]["policy_year"].min()}–{df[train_mask]["policy_year"].max()})')
    print(f'  Test set:  {len(X_test):,} policies '
          f'(years {df[test_mask]["policy_year"].min()}–{df[test_mask]["policy_year"].max()})')
    return X_train, X_test, y_train, y_test, df_train, df_test


# ════════════════════════════════════════════════════════════════════════════
# Step 5 — Model Training
# ════════════════════════════════════════════════════════════════════════════

@timer
def step5_train_models(X_train, X_test, y_train, y_test, df_test):
    banner(5, 'Training Advanced Residual Models')
    results = {}

    # ── Gradient Boosting ───────────────────────────────────────────────────
    print('\n  [1/7] Gradient Boosting Residual Model...')
    gb = GBResidualModel()
    gb.fit(X_train, y_train)
    results['Gradient Boosting'] = gb.result(X_test, y_test)
    print(f'      R²={results["Gradient Boosting"].metrics["R2"]:.4f}  '
          f'RMSE={results["Gradient Boosting"].metrics["RMSE"]:.4f}')

    # ── Random Forest ───────────────────────────────────────────────────────
    print('  [2/7] Random Forest Residual Model...')
    rf = RFResidualModel()
    rf.fit(X_train, y_train)
    results['Random Forest'] = rf.result(X_test, y_test)
    print(f'      R²={results["Random Forest"].metrics["R2"]:.4f}  '
          f'RMSE={results["Random Forest"].metrics["RMSE"]:.4f}')

    # ── Neural Network ──────────────────────────────────────────────────────
    print('  [3/7] Neural Network (MLP) Residual Model...')
    nn = NNResidualModel()
    nn.fit(X_train, y_train)
    results['Neural Network'] = nn.result(X_test, y_test)
    print(f'      R²={results["Neural Network"].metrics["R2"]:.4f}  '
          f'RMSE={results["Neural Network"].metrics["RMSE"]:.4f}')

    # ── Polynomial Interactions ──────────────────────────────────────────────
    print('  [4/7] Polynomial Interaction Model...')
    poly = PolyInteractionModel()
    poly.fit(X_train, y_train)
    results['Polynomial'] = poly.result(X_test, y_test)
    print(f'      R²={results["Polynomial"].metrics["R2"]:.4f}  '
          f'RMSE={results["Polynomial"].metrics["RMSE"]:.4f}')
    print('      Top interactions detected:')
    for feat, importance in poly.top_interactions(5).items():
        print(f'        {feat}: {importance:.4f}')

    # ── Segment Re-calibration ───────────────────────────────────────────────
    print('  [5/7] Segment Re-calibration (KMeans + Ridge)...')
    seg = SegmentRecalibrator(n_clusters=8)
    seg.fit(X_train, y_train)
    results['Segmentation'] = seg.result(X_test, y_test)
    print(f'      R²={results["Segmentation"].metrics["R2"]:.4f}  '
          f'RMSE={results["Segmentation"].metrics["RMSE"]:.4f}')

    # ── Anomaly Detection (fit on full train set) ────────────────────────────
    print('  [6/7] Isolation Forest Anomaly Detection...')
    iso = AnomalyDetector(contamination=0.05)
    iso.fit(X_train)
    # return anomaly info for test set
    anomaly_scores = iso.score(X_test)
    anomaly_flags  = iso.flag(X_test)
    print(f'      Anomalous policies flagged: {anomaly_flags.sum():,} '
          f'({100*anomaly_flags.mean():.1f}% of test set)')

    # ── Gaussian Process (subsample) ─────────────────────────────────────────
    print('  [7/7] Gaussian Process Residual Model (subsampled)...')
    gp = GPResidualModel(n_sample=1500)
    gp.fit(X_train, y_train)
    results['Gaussian Process'] = gp.result(X_test, y_test)
    print(f'      R²={results["Gaussian Process"].metrics["R2"]:.4f}  '
          f'RMSE={results["Gaussian Process"].metrics["RMSE"]:.4f}')
    print(f'      Learned kernel: {results["Gaussian Process"].extra["kernel"]}')

    return results, seg, anomaly_scores, anomaly_flags


# ════════════════════════════════════════════════════════════════════════════
# Step 6 — Ensemble Meta-Learner
# ════════════════════════════════════════════════════════════════════════════

@timer
def step6_ensemble(results: dict, y_test: np.ndarray) -> dict:
    banner(6, 'Ensemble Meta-Learner (Stacking)')
    base_preds = {
        name: r.predictions
        for name, r in results.items()
        if name != 'Anomaly'
    }
    ens = EnsembleMetaLearner()
    ens.fit(base_preds, y_test)
    ens_result = ens.result(base_preds, y_test)
    results['Ensemble'] = ens_result
    print(f'  Ensemble R²={ens_result.metrics["R2"]:.4f}  '
          f'RMSE={ens_result.metrics["RMSE"]:.4f}')
    print('  Model weights:')
    for name, w in ens.weights().items():
        print(f'    {name:35s}: {w:+.4f}')
    return results, ens


# ════════════════════════════════════════════════════════════════════════════
# Step 7 — Evaluation Summary
# ════════════════════════════════════════════════════════════════════════════

@timer
def step7_evaluation(results: dict) -> pd.DataFrame:
    banner(7, 'Model Evaluation Summary')
    rows = []
    for name, r in results.items():
        row = {'Model': name}
        row.update(r.metrics)
        rows.append(row)
    summary = pd.DataFrame(rows).sort_values('R2', ascending=False)
    print(summary.to_string(index=False))
    summary.to_csv(f'{OUTDIR}/model_comparison.csv', index=False)
    print(f'\n  Saved model_comparison.csv')
    return summary


# ════════════════════════════════════════════════════════════════════════════
# Step 8 — Visualisations
# ════════════════════════════════════════════════════════════════════════════

@timer
def step8_visualise(df, df_test, results, seg, anomaly_scores, anomaly_flags, ens):
    banner(8, 'Generating Visualisation Suite')

    plot_residual_overview(df)

    plot_feature_importance(results, get_feature_columns())

    plot_model_comparison(results, None)

    best_ml_preds = results['Gradient Boosting'].predictions
    plot_interaction_heatmap(df_test.reset_index(drop=True), best_ml_preds)

    seg_labels_test = seg.kmeans.predict(
        seg.scaler.transform(df_test[get_feature_columns()])
    )
    plot_segment_analysis(df_test.reset_index(drop=True),
                          seg_labels_test,
                          seg.segment_summary())

    plot_anomaly_detection(df_test.reset_index(drop=True),
                           anomaly_scores, anomaly_flags)

    plot_training_curves(
        results['Gradient Boosting'].extra['staged_rmse'],
        results['Neural Network'].extra['loss_curve']
    )

    plot_lift_chart(df_test.reset_index(drop=True),
                    results['Ensemble'].predictions,
                    model_name='Ensemble')

    plot_ensemble_weights(ens.weights())

    print(f'\n  All figures saved to: {OUTDIR}/figures/')


# ════════════════════════════════════════════════════════════════════════════
# Step 9 — Actionable Reporting
# ════════════════════════════════════════════════════════════════════════════

@timer
def step9_reporting(df_test: pd.DataFrame, results: dict,
                    anomaly_flags: np.ndarray, eda: dict):
    banner(9, 'Actionable Risk Reporting')

    df_rep = df_test.reset_index(drop=True).copy()
    df_rep['ensemble_resid_pred'] = results['Ensemble'].predictions
    df_rep['anomaly_flag']        = anomaly_flags

    # Flag underpriced (ensemble predicts large positive residual)
    threshold = df_rep['ensemble_resid_pred'].quantile(0.90)
    df_rep['underpriced_flag'] = df_rep['ensemble_resid_pred'] > threshold

    print(f'\n  Underpriced policies (top 10% ensemble residual):')
    print(f'    Count  : {df_rep["underpriced_flag"].sum():,}')
    print(f'    % fleet: {100*df_rep["underpriced_flag"].mean():.1f}%')

    under = df_rep[df_rep['underpriced_flag']]
    print(f'\n  Underpriced segment profile:')
    print(f'    Avg driver age     : {under["driver_age"].mean():.0f}')
    print(f'    Avg vehicle age    : {under["vehicle_age"].mean():.0f}')
    print(f'    Most common zone   : {under["postcode_zone"].mode()[0]}')
    print(f'    Avg GLM pred (£)   : {under["glm_pure_premium_pred"].mean():,.0f}')
    print(f'    Avg actual PP (£)  : {under["actual_pure_premium"].mean():,.0f}')

    print(f'\n  Anomalous policies for UW referral: {anomaly_flags.sum():,}')

    # Export flagged policies
    flagged = df_rep[df_rep['underpriced_flag'] | df_rep['anomaly_flag']]
    flagged_path = f'{OUTDIR}/flagged_policies.csv'
    flagged.to_csv(flagged_path, index=False)
    print(f'\n  Exported {len(flagged):,} flagged policies → flagged_policies.csv')

    # JSON summary for downstream workflow automation
    report = {
        'underpriced_count'    : int(df_rep['underpriced_flag'].sum()),
        'anomaly_count'        : int(anomaly_flags.sum()),
        'top_underpriced_zone' : under['postcode_zone'].mode()[0],
        'estimated_pp_gap_gbp' : float((under['actual_pure_premium'] -
                                        under['glm_pure_premium_pred']).mean()),
        'yearly_drift'         : {str(k): v for k, v in eda['yearly_drift'].items()},
    }
    with open(f'{OUTDIR}/report_summary.json', 'w') as f:
        json.dump(report, f, indent=2)
    print(f'  Report summary → report_summary.json')
    return df_rep


# ════════════════════════════════════════════════════════════════════════════
# Step 10 — Export Artefacts
# ════════════════════════════════════════════════════════════════════════════

@timer
def step10_export(df_test_enriched: pd.DataFrame, summary: pd.DataFrame):
    banner(10, 'Exporting Artefacts')
    df_test_enriched.to_csv(f'{OUTDIR}/test_set_enriched.csv', index=False)
    summary.to_csv(f'{OUTDIR}/model_comparison.csv', index=False)
    print(f'  test_set_enriched.csv    — full test set with all model predictions & flags')
    print(f'  model_comparison.csv     — RMSE / MAE / R² per model')
    print(f'  flagged_policies.csv     — underpriced + anomalous policies')
    print(f'  report_summary.json      — KPI summary for dashboards / automation')
    print(f'  figures/                 — 9 publication-quality charts')
    print(f'\n  All outputs in: {OUTDIR}')


# ════════════════════════════════════════════════════════════════════════════
# Main
# ════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description='Advanced GLM Residual Analysis Pipeline')
    parser.add_argument('--data', type=str, default=None,
                        help='Path to CSV (optional; uses synthetic data if omitted)')
    parser.add_argument('--n', type=int, default=50_000,
                        help='Synthetic dataset size (default: 50,000)')
    args = parser.parse_args()

    t_start = time.time()
    print('\n' + '★'*70)
    print('  ADVANCED GLM RESIDUAL ANALYSIS PIPELINE')
    print('  General Insurance — Pricing / Data Science')
    print('★'*70)

    df                                           = step1_load_data(args)
    eda                                          = step2_exploratory(df)
    X, y, feat_cols                              = step3_features(df)
    X_train, X_test, y_train, y_test, \
        df_train, df_test                        = step4_split(df, X, y)
    results, seg, anomaly_scores, anomaly_flags  = step5_train_models(
                                                        X_train, X_test,
                                                        y_train, y_test, df_test)
    results, ens                                 = step6_ensemble(results, y_test)
    summary                                      = step7_evaluation(results)
    step8_visualise(df, df_test, results, seg,
                    anomaly_scores, anomaly_flags, ens)
    df_test_enriched                             = step9_reporting(
                                                        df_test, results,
                                                        anomaly_flags, eda)
    step10_export(df_test_enriched, summary)

    elapsed = time.time() - t_start
    print(f'\n{"★"*70}')
    print(f'  PIPELINE COMPLETE  ⏱  {elapsed:.0f}s total')
    print(f'{"★"*70}\n')


if __name__ == '__main__':
    main()
