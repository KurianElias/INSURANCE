"""
models.py
=========
Advanced residual modelling suite for GLM mis-pricing detection.

Models implemented
------------------
1. Gradient Boosting (sklearn GradientBoostingRegressor)  — captures non-linearities
2. Random Forest                                           — ensemble benchmark
3. Isotonic Regression on sorted residuals                 — monotone calibration check
4. Gaussian Process (RBF kernel)                           — uncertainty quantification
5. Polynomial Feature Regression                           — explicit interaction detection
6. K-Means + per-cluster linear model                      — segment-level re-calibration
7. Isolation Forest                                        — anomaly / outlier detection
8. Neural Network (MLPRegressor)                           — deep feature interactions

Each model exposes a unified .fit() / .predict() interface and
returns feature importance or equivalent interpretability artefacts.
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional

from sklearn.ensemble import (
    GradientBoostingRegressor, RandomForestRegressor, IsolationForest
)
from sklearn.neural_network import MLPRegressor
from sklearn.linear_model import Ridge
from sklearn.isotonic import IsotonicRegression
from sklearn.cluster import KMeans
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel
from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score


# ────────────────────────────────────────────────────────────────────────────
# Result container
# ────────────────────────────────────────────────────────────────────────────

@dataclass
class ModelResult:
    name: str
    predictions: np.ndarray
    feature_importances: Optional[pd.Series] = None
    cv_rmse: Optional[float] = None
    metrics: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)          # model-specific extras


def _regression_metrics(y_true, y_pred) -> dict:
    return {
        'RMSE' : float(np.sqrt(mean_squared_error(y_true, y_pred))),
        'MAE'  : float(mean_absolute_error(y_true, y_pred)),
        'R2'   : float(r2_score(y_true, y_pred)),
    }


# ────────────────────────────────────────────────────────────────────────────
# 1. Gradient Boosting Residual Model
# ────────────────────────────────────────────────────────────────────────────

class GBResidualModel:
    """
    Gradient Boosting on GLM residuals.
    Detects non-linearities and interaction effects the GLM missed.
    """

    def __init__(self, n_estimators=400, max_depth=4, learning_rate=0.05,
                 subsample=0.8, random_state=42):
        self.model = GradientBoostingRegressor(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            subsample=subsample,
            loss='huber',          # robust to large-loss outliers
            random_state=random_state
        )
        self.feature_names = None

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> 'GBResidualModel':
        self.feature_names = list(X.columns)
        self.model.fit(X, y)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        return self.model.predict(X)

    def result(self, X: pd.DataFrame, y: np.ndarray) -> ModelResult:
        preds = self.predict(X)
        fi = pd.Series(
            self.model.feature_importances_,
            index=self.feature_names
        ).sort_values(ascending=False)
        # staged deviance for convergence plot
        staged = list(self.model.staged_predict(X))
        staged_rmse = [np.sqrt(mean_squared_error(y, s)) for s in staged]
        return ModelResult(
            name='Gradient Boosting',
            predictions=preds,
            feature_importances=fi,
            metrics=_regression_metrics(y, preds),
            extra={'staged_rmse': staged_rmse}
        )


# ────────────────────────────────────────────────────────────────────────────
# 2. Random Forest Residual Model
# ────────────────────────────────────────────────────────────────────────────

class RFResidualModel:
    """
    Random Forest on GLM residuals.
    Also provides prediction intervals via quantile estimates across trees.
    """

    def __init__(self, n_estimators=300, max_depth=8, random_state=42):
        self.model = RandomForestRegressor(
            n_estimators=n_estimators,
            max_depth=max_depth,
            min_samples_leaf=30,
            random_state=random_state,
            n_jobs=-1
        )
        self.feature_names = None

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> 'RFResidualModel':
        self.feature_names = list(X.columns)
        self.model.fit(X, y)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        return self.model.predict(X)

    def predict_interval(self, X: pd.DataFrame, alpha=0.1):
        """Return (lower, upper) prediction interval from tree distribution."""
        tree_preds = np.stack(
            [t.predict(X) for t in self.model.estimators_], axis=1
        )
        lower = np.percentile(tree_preds, 100 * alpha / 2, axis=1)
        upper = np.percentile(tree_preds, 100 * (1 - alpha / 2), axis=1)
        return lower, upper

    def result(self, X: pd.DataFrame, y: np.ndarray) -> ModelResult:
        preds = self.predict(X)
        fi = pd.Series(
            self.model.feature_importances_,
            index=self.feature_names
        ).sort_values(ascending=False)
        lower, upper = self.predict_interval(X)
        return ModelResult(
            name='Random Forest',
            predictions=preds,
            feature_importances=fi,
            metrics=_regression_metrics(y, preds),
            extra={'pred_lower': lower, 'pred_upper': upper}
        )


# ────────────────────────────────────────────────────────────────────────────
# 3. Neural Network Residual Model
# ────────────────────────────────────────────────────────────────────────────

class NNResidualModel:
    """
    Multi-layer Perceptron on scaled residuals.
    Captures deep feature interactions without hand-crafting.
    """

    def __init__(self, hidden_layer_sizes=(128, 64, 32), random_state=42):
        self.pipeline = Pipeline([
            ('scaler', StandardScaler()),
            ('mlp', MLPRegressor(
                hidden_layer_sizes=hidden_layer_sizes,
                activation='relu',
                solver='adam',
                max_iter=500,
                learning_rate_init=0.001,
                early_stopping=True,
                validation_fraction=0.1,
                random_state=random_state,
                alpha=0.01            # L2 regularisation
            ))
        ])

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> 'NNResidualModel':
        self.pipeline.fit(X, y)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        return self.pipeline.predict(X)

    def result(self, X: pd.DataFrame, y: np.ndarray) -> ModelResult:
        preds = self.predict(X)
        mlp = self.pipeline.named_steps['mlp']
        return ModelResult(
            name='Neural Network (MLP)',
            predictions=preds,
            metrics=_regression_metrics(y, preds),
            extra={
                'n_iter'        : mlp.n_iter_,
                'best_val_score': mlp.best_validation_score_,
                'loss_curve'    : mlp.loss_curve_
            }
        )


# ────────────────────────────────────────────────────────────────────────────
# 4. Polynomial Interaction Detector
# ────────────────────────────────────────────────────────────────────────────

class PolyInteractionModel:
    """
    Ridge regression on degree-2 polynomial features.
    Surfaces specific interaction terms the GLM is missing.
    """

    def __init__(self, degree=2, alpha=10.0):
        self.pipeline = Pipeline([
            ('scaler', StandardScaler()),
            ('poly'  , PolynomialFeatures(degree=degree, include_bias=False)),
            ('ridge' , Ridge(alpha=alpha))
        ])
        self.poly_names = None

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> 'PolyInteractionModel':
        self.pipeline.fit(X, y)
        self.poly_names = self.pipeline.named_steps['poly'].get_feature_names_out(X.columns)
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        return self.pipeline.predict(X)

    def top_interactions(self, n=15) -> pd.Series:
        """Return top n interaction coefficients (excluding main effects)."""
        coefs = self.pipeline.named_steps['ridge'].coef_
        s = pd.Series(np.abs(coefs), index=self.poly_names)
        interactions = s[[' ' in nm for nm in s.index]]
        return interactions.sort_values(ascending=False).head(n)

    def result(self, X: pd.DataFrame, y: np.ndarray) -> ModelResult:
        preds = self.predict(X)
        return ModelResult(
            name='Polynomial Interactions (Ridge)',
            predictions=preds,
            metrics=_regression_metrics(y, preds),
            extra={'top_interactions': self.top_interactions()}
        )


# ────────────────────────────────────────────────────────────────────────────
# 5. Segment-Level Re-calibration (KMeans + per-cluster Ridge)
# ────────────────────────────────────────────────────────────────────────────

class SegmentRecalibrator:
    """
    Cluster policies into risk segments, then fit a local linear
    model per segment to detect systematic residual patterns.
    """

    def __init__(self, n_clusters=8, random_state=42):
        self.n_clusters = n_clusters
        self.scaler  = StandardScaler()
        self.kmeans  = KMeans(n_clusters=n_clusters, random_state=random_state, n_init=10)
        self.local_models = {}
        self.cluster_stats = {}

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> 'SegmentRecalibrator':
        Xs = self.scaler.fit_transform(X)
        labels = self.kmeans.fit_predict(Xs)
        for k in range(self.n_clusters):
            mask = labels == k
            Xk = X.values[mask]
            yk = y[mask]
            m = Ridge(alpha=5.0)
            m.fit(Xk, yk)
            self.local_models[k] = m
            self.cluster_stats[k] = {
                'n'          : int(mask.sum()),
                'mean_resid' : float(yk.mean()),
                'std_resid'  : float(yk.std()),
                'local_r2'   : float(r2_score(yk, m.predict(Xk)))
            }
        return self

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        Xs = self.scaler.transform(X)
        labels = self.kmeans.predict(Xs)
        preds = np.zeros(len(X))
        for k in range(self.n_clusters):
            mask = labels == k
            if mask.any():
                preds[mask] = self.local_models[k].predict(X.values[mask])
        return preds

    def segment_summary(self) -> pd.DataFrame:
        return pd.DataFrame(self.cluster_stats).T.sort_values('mean_resid', ascending=False)

    def result(self, X: pd.DataFrame, y: np.ndarray) -> ModelResult:
        preds = self.predict(X)
        return ModelResult(
            name='Segment Re-calibration (KMeans+Ridge)',
            predictions=preds,
            metrics=_regression_metrics(y, preds),
            extra={'segment_summary': self.segment_summary()}
        )


# ────────────────────────────────────────────────────────────────────────────
# 6. Isolation Forest — Anomaly Detection
# ────────────────────────────────────────────────────────────────────────────

class AnomalyDetector:
    """
    Isolation Forest to identify policies that are structural outliers
    in the feature space — candidates for manual underwriting review.
    """

    def __init__(self, contamination=0.05, random_state=42):
        self.scaler = StandardScaler()
        self.model  = IsolationForest(
            contamination=contamination,
            n_estimators=200,
            random_state=random_state
        )

    def fit(self, X: pd.DataFrame) -> 'AnomalyDetector':
        Xs = self.scaler.fit_transform(X)
        self.model.fit(Xs)
        return self

    def score(self, X: pd.DataFrame) -> np.ndarray:
        """Return anomaly scores (lower = more anomalous)."""
        Xs = self.scaler.transform(X)
        return self.model.decision_function(Xs)

    def flag(self, X: pd.DataFrame) -> np.ndarray:
        """Return boolean mask: True = anomalous policy."""
        Xs = self.scaler.transform(X)
        return self.model.predict(Xs) == -1


# ────────────────────────────────────────────────────────────────────────────
# 7. Gaussian Process (small sample — subsample for tractability)
# ────────────────────────────────────────────────────────────────────────────

class GPResidualModel:
    """
    Gaussian Process Regressor for uncertainty-aware residual modelling.
    Uses RBF + White noise kernel. Subsamples for tractability.
    """

    def __init__(self, n_sample=2000, random_state=42):
        self.n_sample = n_sample
        self.rng      = np.random.default_rng(random_state)
        self.scaler   = StandardScaler()
        kernel = ConstantKernel(1.0) * RBF(length_scale=1.0) + WhiteKernel(noise_level=0.1)
        self.model = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=3,
                                              normalize_y=True)
        self._fitted_X = None

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> 'GPResidualModel':
        idx = self.rng.choice(len(X), min(self.n_sample, len(X)), replace=False)
        Xs  = self.scaler.fit_transform(X)
        self._fitted_X = Xs[idx]
        self.model.fit(Xs[idx], y[idx])
        return self

    def predict(self, X: pd.DataFrame):
        Xs = self.scaler.transform(X)
        return self.model.predict(Xs, return_std=True)   # (mean, std)

    def result(self, X: pd.DataFrame, y: np.ndarray) -> ModelResult:
        mean, std = self.predict(X)
        return ModelResult(
            name='Gaussian Process',
            predictions=mean,
            metrics=_regression_metrics(y, mean),
            extra={'pred_std': std, 'kernel': str(self.model.kernel_)}
        )


# ────────────────────────────────────────────────────────────────────────────
# 8. Ensemble Meta-learner
# ────────────────────────────────────────────────────────────────────────────

class EnsembleMetaLearner:
    """
    Stack base model predictions using a Ridge meta-learner.
    Combines GB, RF, NN, Poly models for optimal residual capture.
    """

    def __init__(self, alpha=1.0):
        self.meta = Ridge(alpha=alpha)
        self.base_names = []

    def fit(self, base_preds: dict, y: np.ndarray) -> 'EnsembleMetaLearner':
        self.base_names = list(base_preds.keys())
        X_meta = np.column_stack(list(base_preds.values()))
        self.meta.fit(X_meta, y)
        return self

    def predict(self, base_preds: dict) -> np.ndarray:
        X_meta = np.column_stack(list(base_preds.values()))
        return self.meta.predict(X_meta)

    def weights(self) -> pd.Series:
        return pd.Series(self.meta.coef_, index=self.base_names)

    def result(self, base_preds: dict, y: np.ndarray) -> ModelResult:
        preds = self.predict(base_preds)
        return ModelResult(
            name='Ensemble Meta-Learner',
            predictions=preds,
            metrics=_regression_metrics(y, preds),
            extra={'weights': self.weights()}
        )
