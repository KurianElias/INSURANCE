"""
visualisation.py
================
Professional visualisation suite for GLM residual analysis.
Produces publication-quality charts suitable for actuarial/regulatory review.

All plots saved to outputs/figures/ as high-resolution PNGs.
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.colors import LinearSegmentedColormap
from scipy import stats
from scipy.stats import gaussian_kde

# ── Style ────────────────────────────────────────────────────────────────────
PALETTE = {
    'primary'  : '#1B4F72',
    'secondary': '#2980B9',
    'accent'   : '#E74C3C',
    'positive' : '#27AE60',
    'warning'  : '#F39C12',
    'light'    : '#EBF5FB',
    'grey'     : '#7F8C8D',
}

def _style():
    plt.rcParams.update({
        'figure.facecolor' : 'white',
        'axes.facecolor'   : '#FAFAFA',
        'axes.edgecolor'   : '#CCCCCC',
        'axes.grid'        : True,
        'grid.color'       : '#E5E5E5',
        'grid.linewidth'   : 0.7,
        'font.family'      : 'sans-serif',
        'font.size'        : 10,
        'axes.titlesize'   : 12,
        'axes.titleweight' : 'bold',
        'axes.labelsize'   : 10,
        'xtick.labelsize'  : 9,
        'ytick.labelsize'  : 9,
        'legend.fontsize'  : 9,
        'savefig.dpi'      : 150,
        'savefig.bbox'     : 'tight',
    })

OUTDIR = '/home/claude/glm_residual_analysis/outputs/figures'
os.makedirs(OUTDIR, exist_ok=True)


def _save(fig, name):
    path = os.path.join(OUTDIR, name)
    fig.savefig(path)
    plt.close(fig)
    print(f'  ✓ Saved {name}')
    return path


# ── 1. Residual Overview Dashboard ──────────────────────────────────────────

def plot_residual_overview(df: pd.DataFrame) -> str:
    _style()
    fig = plt.figure(figsize=(16, 10))
    fig.suptitle('GLM Residual Overview Dashboard', fontsize=16, fontweight='bold',
                 color=PALETTE['primary'], y=1.01)
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)

    # 1a. Distribution of Pearson residuals
    ax1 = fig.add_subplot(gs[0, 0])
    resid = df['residual_pearson'].clip(-3, 3)
    ax1.hist(resid, bins=60, color=PALETTE['secondary'], edgecolor='white', alpha=0.85)
    xr = np.linspace(resid.min(), resid.max(), 200)
    mu, sigma = resid.mean(), resid.std()
    ax1.plot(xr, stats.norm.pdf(xr, mu, sigma) * len(resid) * (resid.max()-resid.min())/60,
             color=PALETTE['accent'], lw=2, label='Normal fit')
    ax1.axvline(0, color=PALETTE['primary'], lw=1.5, ls='--')
    ax1.set_title('Pearson Residual Distribution')
    ax1.set_xlabel('Pearson Residual')
    ax1.legend()

    # 1b. Actual vs Predicted pure premium
    ax2 = fig.add_subplot(gs[0, 1])
    sample = df.sample(min(3000, len(df)), random_state=1)
    sc = ax2.scatter(sample['glm_pure_premium_pred'],
                     sample['actual_pure_premium'],
                     alpha=0.25, s=10, c=sample['residual_pearson'].clip(-2, 2),
                     cmap='RdYlBu_r')
    lim = max(sample['glm_pure_premium_pred'].max(), sample['actual_pure_premium'].max())
    ax2.plot([0, lim], [0, lim], 'k--', lw=1.5, label='45° line')
    plt.colorbar(sc, ax=ax2, label='Pearson Resid')
    ax2.set_title('Actual vs GLM Predicted\nPure Premium')
    ax2.set_xlabel('GLM Prediction')
    ax2.set_ylabel('Actual Pure Premium')
    ax2.legend()

    # 1c. Q-Q plot of deviance residuals
    ax3 = fig.add_subplot(gs[0, 2])
    dev_resid = df['residual_deviance'].dropna().clip(-4, 4)
    (osm, osr), (slope, intercept, r) = stats.probplot(dev_resid, fit=True)
    ax3.scatter(osm, osr, alpha=0.3, s=8, color=PALETTE['secondary'])
    ax3.plot(osm, slope * np.array(osm) + intercept, color=PALETTE['accent'], lw=2)
    ax3.set_title(f'Q-Q Plot: Deviance Residuals\n(R²={r**2:.3f})')
    ax3.set_xlabel('Theoretical Quantiles')
    ax3.set_ylabel('Sample Quantiles')

    # 1d. Residual by driver age (binned)
    ax4 = fig.add_subplot(gs[1, 0])
    bins = pd.cut(df['driver_age'], bins=15)
    grouped = df.groupby(bins)['residual_pearson'].agg(['mean', 'std']).reset_index()
    x = range(len(grouped))
    ax4.bar(x, grouped['mean'], color=PALETTE['secondary'], alpha=0.7, label='Mean resid')
    ax4.errorbar(x, grouped['mean'], yerr=grouped['std']/2, fmt='none',
                 color=PALETTE['accent'], capsize=3)
    ax4.axhline(0, color='black', lw=1)
    ax4.set_xticks(x)
    ax4.set_xticklabels([str(b) for b in grouped['driver_age']], rotation=55, ha='right', fontsize=7)
    ax4.set_title('Mean Pearson Residual\nby Driver Age Band')
    ax4.set_ylabel('Mean Residual')

    # 1e. Residual by postcode zone
    ax5 = fig.add_subplot(gs[1, 1])
    zone_resid = df.groupby('postcode_zone')['residual_pearson'].mean().sort_values()
    colors = [PALETTE['accent'] if v > 0 else PALETTE['positive'] for v in zone_resid]
    ax5.barh(zone_resid.index, zone_resid.values, color=colors)
    ax5.axvline(0, color='black', lw=1)
    ax5.set_title('Mean Pearson Residual\nby Postcode Zone')
    ax5.set_xlabel('Mean Pearson Residual')

    # 1f. Temporal trend
    ax6 = fig.add_subplot(gs[1, 2])
    yr_resid = df.groupby('policy_year')['residual_raw'].mean()
    ax6.plot(yr_resid.index, yr_resid.values, marker='o',
             color=PALETTE['primary'], lw=2.5, markersize=7)
    ax6.fill_between(yr_resid.index, yr_resid.values, alpha=0.15,
                     color=PALETTE['secondary'])
    ax6.axhline(0, color='black', lw=1, ls='--')
    ax6.set_title('Mean Raw Residual\nover Policy Years')
    ax6.set_xlabel('Policy Year')
    ax6.set_ylabel('Mean Raw Residual (£)')

    return _save(fig, '01_residual_overview.png')


# ── 2. Feature Importance Comparison ────────────────────────────────────────

def plot_feature_importance(results: dict, feature_names: list) -> str:
    _style()
    models_with_fi = {k: v for k, v in results.items() if v.feature_importances is not None}
    n = len(models_with_fi)
    fig, axes = plt.subplots(1, n, figsize=(6 * n, 6))
    if n == 1:
        axes = [axes]

    for ax, (name, result) in zip(axes, models_with_fi.items()):
        fi = result.feature_importances.head(9)
        colors = [PALETTE['primary'] if i == 0 else PALETTE['secondary']
                  for i in range(len(fi))]
        bars = ax.barh(fi.index[::-1], fi.values[::-1], color=colors[::-1], edgecolor='white')
        ax.set_title(name, fontweight='bold')
        ax.set_xlabel('Feature Importance')
        # Annotate values
        for bar, val in zip(bars, fi.values[::-1]):
            ax.text(bar.get_width() + 0.001, bar.get_y() + bar.get_height()/2,
                    f'{val:.3f}', va='center', fontsize=8)

    fig.suptitle('Feature Importance — Which Variables Drive GLM Mis-pricing?',
                 fontsize=14, fontweight='bold', color=PALETTE['primary'])
    plt.tight_layout()
    return _save(fig, '02_feature_importance.png')


# ── 3. Model Comparison ──────────────────────────────────────────────────────

def plot_model_comparison(results: dict, y_true: np.ndarray) -> str:
    _style()
    names, rmses, maes, r2s = [], [], [], []
    for name, r in results.items():
        names.append(name)
        rmses.append(r.metrics['RMSE'])
        maes.append(r.metrics['MAE'])
        r2s.append(r.metrics['R2'])

    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.suptitle('Model Performance Comparison on GLM Residuals',
                 fontsize=14, fontweight='bold', color=PALETTE['primary'])

    for ax, vals, title, good in zip(
        axes,
        [rmses, maes, r2s],
        ['RMSE (lower = better)', 'MAE (lower = better)', 'R² (higher = better)'],
        ['min', 'min', 'max']
    ):
        colors = []
        best = min(vals) if good == 'min' else max(vals)
        for v in vals:
            colors.append(PALETTE['accent'] if v == best else PALETTE['secondary'])
        bars = ax.barh(names, vals, color=colors, edgecolor='white')
        ax.set_title(title)
        for bar, val in zip(bars, vals):
            ax.text(bar.get_width() * 1.01, bar.get_y() + bar.get_height()/2,
                    f'{val:.4f}', va='center', fontsize=8)
        ax.invert_yaxis()

    plt.tight_layout()
    return _save(fig, '03_model_comparison.png')


# ── 4. Interaction Heatmap ───────────────────────────────────────────────────

def plot_interaction_heatmap(df: pd.DataFrame, model_preds: np.ndarray) -> str:
    _style()
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle('Residual Interaction Heatmaps\n(Driver Age × Vehicle Age)',
                 fontsize=13, fontweight='bold', color=PALETTE['primary'])

    for ax, vals, title in zip(
        axes,
        [df['residual_pearson'], model_preds],
        ['GLM Pearson Residual', 'ML-Predicted Residual']
    ):
        age_bins    = pd.cut(df['driver_age'],  bins=8)
        veh_bins    = pd.cut(df['vehicle_age'], bins=8)
        pivot = pd.DataFrame({'age': age_bins, 'veh': veh_bins, 'val': vals})
        hm = pivot.groupby(['age', 'veh'])['val'].mean().unstack()
        hm = hm.fillna(0)
        cmap = LinearSegmentedColormap.from_list('rg', ['#27AE60', 'white', '#E74C3C'])
        im = ax.imshow(hm.values, cmap=cmap, aspect='auto',
                       vmin=-abs(hm.values).max(), vmax=abs(hm.values).max())
        ax.set_xticks(range(len(hm.columns)))
        ax.set_xticklabels([str(c) for c in hm.columns], rotation=45, ha='right', fontsize=7)
        ax.set_yticks(range(len(hm.index)))
        ax.set_yticklabels([str(i) for i in hm.index], fontsize=7)
        ax.set_xlabel('Vehicle Age Band')
        ax.set_ylabel('Driver Age Band')
        ax.set_title(title)
        plt.colorbar(im, ax=ax, shrink=0.8)

    plt.tight_layout()
    return _save(fig, '04_interaction_heatmap.png')


# ── 5. Segment Analysis ───────────────────────────────────────────────────────

def plot_segment_analysis(df: pd.DataFrame, segment_labels: np.ndarray,
                          segment_summary: pd.DataFrame) -> str:
    _style()
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle('Risk Segment Analysis (KMeans Clustering)',
                 fontsize=13, fontweight='bold', color=PALETTE['primary'])

    # Segment mean residual
    ax1 = axes[0]
    seg_data = segment_summary.copy()
    seg_data.index = [f'Seg {int(i)}' for i in seg_data.index]
    colors = [PALETTE['accent'] if v > 0 else PALETTE['positive']
              for v in seg_data['mean_resid']]
    ax1.bar(seg_data.index, seg_data['mean_resid'], color=colors, edgecolor='white')
    ax1.axhline(0, color='black', lw=1)
    ax1.set_title('Mean Residual per Segment\n(Positive = Underpriced)')
    ax1.set_xlabel('Segment')
    ax1.set_ylabel('Mean Residual')
    ax1.tick_params(axis='x', rotation=30)

    # Segment size vs mean residual bubble chart
    ax2 = axes[1]
    scatter = ax2.scatter(
        seg_data['n'],
        seg_data['mean_resid'],
        s=seg_data['n'] / 30,
        c=seg_data['mean_resid'],
        cmap='RdYlGn_r',
        edgecolors='grey',
        linewidths=0.5,
        alpha=0.85
    )
    for idx, row in seg_data.iterrows():
        ax2.annotate(idx, (row['n'], row['mean_resid']),
                     textcoords='offset points', xytext=(5, 5), fontsize=8)
    ax2.axhline(0, color='black', lw=1, ls='--')
    ax2.set_title('Segment Size vs Mean Residual\n(Bubble = policy count)')
    ax2.set_xlabel('Number of Policies')
    ax2.set_ylabel('Mean Residual')
    plt.colorbar(scatter, ax=ax2, label='Mean Residual')

    plt.tight_layout()
    return _save(fig, '05_segment_analysis.png')


# ── 6. Anomaly Detection ─────────────────────────────────────────────────────

def plot_anomaly_detection(df: pd.DataFrame, anomaly_scores: np.ndarray,
                           anomaly_flags: np.ndarray) -> str:
    _style()
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    fig.suptitle('Isolation Forest — Anomalous Policy Detection',
                 fontsize=13, fontweight='bold', color=PALETTE['primary'])

    # Score distribution
    ax1 = axes[0]
    ax1.hist(anomaly_scores[~anomaly_flags], bins=50,
             color=PALETTE['positive'], alpha=0.7, label='Normal')
    ax1.hist(anomaly_scores[anomaly_flags], bins=30,
             color=PALETTE['accent'], alpha=0.8, label='Anomalous')
    ax1.set_title(f'Anomaly Score Distribution\n({anomaly_flags.sum()} anomalies flagged)')
    ax1.set_xlabel('Decision Score (lower = more anomalous)')
    ax1.set_ylabel('Count')
    ax1.legend()

    # Anomalies in feature space (driver age vs vehicle age)
    ax2 = axes[1]
    ax2.scatter(df['driver_age'][~anomaly_flags],
                df['vehicle_age'][~anomaly_flags],
                alpha=0.15, s=8, color=PALETTE['grey'], label='Normal')
    ax2.scatter(df['driver_age'][anomaly_flags],
                df['vehicle_age'][anomaly_flags],
                alpha=0.6, s=25, color=PALETTE['accent'],
                edgecolors='darkred', linewidths=0.5, label='Anomalous', zorder=5)
    ax2.set_title('Anomalous Policies in Feature Space\n(Driver Age vs Vehicle Age)')
    ax2.set_xlabel('Driver Age')
    ax2.set_ylabel('Vehicle Age')
    ax2.legend()

    plt.tight_layout()
    return _save(fig, '06_anomaly_detection.png')


# ── 7. GB Convergence & Neural Network Loss ──────────────────────────────────

def plot_training_curves(gb_staged_rmse: list, nn_loss_curve: list) -> str:
    _style()
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    fig.suptitle('Model Training Convergence',
                 fontsize=13, fontweight='bold', color=PALETTE['primary'])

    ax1 = axes[0]
    ax1.plot(gb_staged_rmse, color=PALETTE['primary'], lw=2)
    ax1.set_title('Gradient Boosting — RMSE vs Boosting Round')
    ax1.set_xlabel('Boosting Rounds')
    ax1.set_ylabel('RMSE')
    best_round = int(np.argmin(gb_staged_rmse))
    ax1.axvline(best_round, color=PALETTE['accent'], ls='--', lw=1.5,
                label=f'Best round: {best_round}')
    ax1.legend()

    ax2 = axes[1]
    ax2.plot(nn_loss_curve, color=PALETTE['secondary'], lw=2)
    ax2.set_title('Neural Network — Training Loss Curve')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('Loss (MSE)')

    plt.tight_layout()
    return _save(fig, '07_training_curves.png')


# ── 8. Lift Chart — Decile Analysis ─────────────────────────────────────────

def plot_lift_chart(df: pd.DataFrame, model_preds: np.ndarray,
                    model_name: str = 'Ensemble') -> str:
    _style()
    tmp = df[['actual_pure_premium', 'glm_pure_premium_pred']].copy()
    tmp['ml_pred'] = model_preds
    tmp['decile'] = pd.qcut(tmp['ml_pred'], 10, labels=False, duplicates='drop') + 1

    decs = tmp.groupby('decile').agg(
        actual=('actual_pure_premium', 'mean'),
        glm=('glm_pure_premium_pred', 'mean'),
        ml=('ml_pred', 'mean')
    ).reset_index()

    fig, ax = plt.subplots(figsize=(10, 5))
    x = decs['decile']
    ax.plot(x, decs['actual'], marker='o', color=PALETTE['primary'], lw=2.5,
            label='Actual Pure Premium', zorder=5)
    ax.plot(x, decs['glm'], marker='s', color=PALETTE['grey'], lw=2, ls='--',
            label='GLM Prediction')
    ax.plot(x, decs['ml'], marker='^', color=PALETTE['accent'], lw=2,
            label=f'{model_name} Prediction')
    ax.set_title('Lift Chart — Decile Analysis\nActual vs GLM vs ML-Corrected Prediction',
                 fontweight='bold', color=PALETTE['primary'])
    ax.set_xlabel('Risk Decile (1=Lowest ML Residual, 10=Highest)')
    ax.set_ylabel('Mean Pure Premium (£)')
    ax.legend()

    plt.tight_layout()
    return _save(fig, '08_lift_chart.png')


# ── 9. Ensemble Weight Summary ────────────────────────────────────────────────

def plot_ensemble_weights(weights: pd.Series) -> str:
    _style()
    fig, ax = plt.subplots(figsize=(8, 4))
    colors = [PALETTE['primary'] if w > 0 else PALETTE['accent'] for w in weights]
    ax.barh(weights.index, weights.values, color=colors, edgecolor='white')
    ax.axvline(0, color='black', lw=1)
    ax.set_title('Ensemble Meta-Learner — Base Model Weights',
                 fontweight='bold', color=PALETTE['primary'])
    ax.set_xlabel('Ridge Coefficient (meta-learner weight)')
    plt.tight_layout()
    return _save(fig, '09_ensemble_weights.png')
