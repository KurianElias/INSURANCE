"""
data_utils.py
=============
Synthetic insurance data generator and data loading utilities.
Simulates a realistic general insurance frequency/severity dataset
with hidden non-linearities and interactions — exactly what a GLM
would systematically mis-price.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder


def simulate_insurance_data(n_policies: int = 50_000, seed: int = 42) -> pd.DataFrame:
    """
    Generate synthetic multi-year insurance policy & claims data.

    Features engineered to contain:
    - Non-linear age effects (U-shaped)
    - Interaction between vehicle age and driver age
    - Hidden spatial clustering (postcode zones)
    - Temporal drift over policy years
    - A "dark segment" — high-risk cohort a GLM underestimates

    Returns
    -------
    pd.DataFrame with columns:
        policy_id, policy_year, driver_age, vehicle_age, vehicle_value,
        postcode_zone, annual_mileage, no_claims_discount, occupation_class,
        claim_count, claim_amount, exposure, glm_freq_pred, glm_sev_pred,
        glm_pure_premium_pred, actual_pure_premium, residual_pearson,
        residual_deviance, residual_raw
    """
    rng = np.random.default_rng(seed)

    # ── Feature Generation ────────────────────────────────────────────────────
    driver_age       = rng.integers(18, 85, n_policies)
    vehicle_age      = rng.integers(0, 20, n_policies)
    vehicle_value    = np.exp(rng.normal(9.5, 0.6, n_policies))          # log-normal
    annual_mileage   = rng.integers(3000, 35000, n_policies)
    no_claims_disc   = rng.integers(0, 6, n_policies)                     # 0–5 years NCD
    postcode_zone    = rng.choice(['A','B','C','D','E','F'], n_policies,
                                   p=[0.25, 0.20, 0.18, 0.15, 0.12, 0.10])
    occupation_class = rng.choice([1, 2, 3, 4], n_policies,
                                   p=[0.35, 0.30, 0.25, 0.10])
    policy_year      = rng.integers(2018, 2024, n_policies)
    exposure         = rng.uniform(0.1, 1.0, n_policies)                  # fraction of year

    # ── True Frequency (Poisson λ) — complex DGP ─────────────────────────────
    zone_effect = {'A': 0.08, 'B': 0.10, 'C': 0.13, 'D': 0.16, 'E': 0.20, 'F': 0.25}
    zone_factor = np.array([zone_effect[z] for z in postcode_zone])

    # Non-linear driver age: U-shaped (young + old risky)
    age_effect = 0.3 * np.exp(-0.05 * (driver_age - 30)**2 / 100) + \
                 0.002 * (driver_age - 50)**2 / 100

    # Vehicle age interaction with driver age (hidden from GLM)
    interaction = 0.015 * (vehicle_age > 10) * (driver_age < 25)

    # Mileage non-linearity (threshold at 20k)
    mileage_effect = 0.00001 * annual_mileage + \
                     0.00003 * np.maximum(annual_mileage - 20000, 0)

    # Temporal drift: frequency creeping up post-2021
    trend_effect = 0.02 * np.maximum(policy_year - 2020, 0)

    true_lambda = exposure * (
        zone_factor +
        age_effect +
        interaction +
        mileage_effect +
        trend_effect +
        0.05 * (occupation_class == 4) +        # high-risk occupation
        (-0.015 * no_claims_disc)                # NCD discount
    ).clip(0.01, 1.5)

    claim_count = rng.poisson(true_lambda)

    # ── True Severity (log-normal) ────────────────────────────────────────────
    mu_sev = np.log(2500) + \
             0.0015 * vehicle_value / 1000 + \
             0.01 * vehicle_age + \
             0.5 * (zone_factor - 0.10) + \
             0.3 * (claim_count > 1)             # large loss interaction

    true_severity = np.where(
        claim_count > 0,
        rng.lognormal(mu_sev, 0.8),
        0.0
    )
    claim_amount = true_severity * claim_count

    actual_pure_premium = claim_amount / exposure

    # ── Simulate GLM Predictions (correctly specified linear part only) ───────
    # GLM captures main effects but MISSES: interaction, non-linearity, trend
    glm_freq_pred = exposure * (
        zone_factor * 0.85 +                     # slight zone misfit
        0.0012 * annual_mileage / 1000 +
        0.0003 * np.abs(driver_age - 35) +       # linear proxy for U-shape
        (-0.012 * no_claims_disc) +
        0.04 * (occupation_class == 4)
    ).clip(0.005, 1.2)

    glm_sev_pred = np.exp(
        np.log(2500) +
        0.0012 * vehicle_value / 1000 +
        0.008 * vehicle_age
    )

    glm_pure_premium_pred = glm_freq_pred * glm_sev_pred

    # ── Residuals ────────────────────────────────────────────────────────────
    residual_raw      = actual_pure_premium - glm_pure_premium_pred
    residual_pearson  = residual_raw / (glm_pure_premium_pred + 1e-6)
    # Deviance residual (Tweedie approx)
    pp = actual_pure_premium + 1e-6
    pp_hat = glm_pure_premium_pred + 1e-6
    residual_deviance = np.sign(pp - pp_hat) * np.sqrt(
        2 * np.abs(pp * np.log(pp / pp_hat) - (pp - pp_hat))
    )

    df = pd.DataFrame({
        'policy_id'             : np.arange(1, n_policies + 1),
        'policy_year'           : policy_year,
        'driver_age'            : driver_age,
        'vehicle_age'           : vehicle_age,
        'vehicle_value'         : vehicle_value.round(0),
        'postcode_zone'         : postcode_zone,
        'annual_mileage'        : annual_mileage,
        'no_claims_discount'    : no_claims_disc,
        'occupation_class'      : occupation_class,
        'exposure'              : exposure.round(4),
        'claim_count'           : claim_count,
        'claim_amount'          : claim_amount.round(2),
        'actual_pure_premium'   : actual_pure_premium.round(2),
        'glm_freq_pred'         : glm_freq_pred.round(6),
        'glm_sev_pred'          : glm_sev_pred.round(2),
        'glm_pure_premium_pred' : glm_pure_premium_pred.round(2),
        'residual_raw'          : residual_raw.round(4),
        'residual_pearson'      : residual_pearson.round(6),
        'residual_deviance'     : residual_deviance.round(6),
    })

    return df


def encode_categoricals(df: pd.DataFrame) -> pd.DataFrame:
    """Label-encode categorical columns and return a copy."""
    df = df.copy()
    le = LabelEncoder()
    df['postcode_zone_enc'] = le.fit_transform(df['postcode_zone'])
    return df


def get_feature_columns() -> list:
    return [
        'driver_age', 'vehicle_age', 'vehicle_value',
        'annual_mileage', 'no_claims_discount', 'occupation_class',
        'policy_year', 'exposure', 'postcode_zone_enc'
    ]
