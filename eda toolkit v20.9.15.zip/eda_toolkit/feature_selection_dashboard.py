# -*- coding: utf-8 -*-
"""
feature_selection_dashboard.py -- Insurance EDA Toolkit v5

Fixes applied:
  1. White background removed -- transparent charts
  2. Controls stripped to minimum: only Count toggle + Sort + Group
  3. Group small bug fixed -- operates on fresh copy, not mutating allRaw
  4. Bins slider WORKS -- engine pre-computes [5,10,15,20,25,30] by default
     AND standalone run_target_analysis pre-computes same range
  5. Axis overlap fixed -- subplot layout with matched x-axis
  6. Chart design: large, clean, two-panel (bars top / mean line bottom)
  7. 96% zero target handled -- shows full + non-zero distributions side by side
  8. VS Code tip: always use output_path, never print the return value

Standalone usage:
    from eda_toolkit import run_target_analysis, generate_fs_report

    ta = run_target_analysis(df, "frequency", exposure_col="expo_amt")
    generate_fs_report(
        {"deep_target_analysis": ta, "target_col": "frequency", "n_rows": len(df)},
        output_path=r"C:\\path\\to\\output.html"
    )
"""
from __future__ import annotations
import json, time, webbrowser
from pathlib import Path
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

PLOTLY_CDN = "https://cdn.plot.ly/plotly-2.35.0.min.js"

# Pre-computed bin configs -- enough for smooth 1-30 slider
DEFAULT_BINS = [5, 10, 15, 20, 25, 30]


class _Enc(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, np.integer):  return int(o)
        if isinstance(o, np.floating): return float(o)
        if isinstance(o, np.ndarray):  return o.tolist()
        try:
            if pd.isna(o): return None
        except Exception:
            pass
        return super().default(o)

def _j(v):   return json.dumps(v, cls=_Enc, separators=(",", ":"))
def _esc(s): return (str(s).replace("&","&amp;").replace("<","&lt;")
                    .replace(">","&gt;").replace('"','&quot;').replace("'","&#39;"))
def _safe(v, d=6):
    try:
        f = float(v)
        return None if (np.isnan(f) or np.isinf(f)) else round(f, d)
    except Exception:
        return None


# ==============================================================
#  STANDALONE run_target_analysis()
# ==============================================================
def run_target_analysis(df: pd.DataFrame,
                         target_col: str,
                         exposure_col: str | None = None,
                         bin_by: str = "amount",
                         n_bins: int = 20,
                         dtype_map: dict | None = None) -> dict:
    """
    Run Target Analysis independently of run_eda().

    Parameters
    ----------
    df           : full DataFrame
    target_col   : target column name (numeric or coercible to numeric)
    exposure_col : exposure column for equal-exposure binning
    bin_by       : "amount" = equal SUM of exposure per bin (recommended)
    n_bins       : max bins; also pre-computes [5,10,15,20,25,30] up to n_bins+5
    dtype_map    : optional dict; auto-detected if None

    Returns
    -------
    dict  -- pass as {"deep_target_analysis": ta, ...} to generate_fs_report()

    Example
    -------
    ta = run_target_analysis(df, "frequency", exposure_col="expo_amt", n_bins=20)
    generate_fs_report(
        {"deep_target_analysis": ta, "target_col": "frequency", "n_rows": len(df)},
        output_path="feature_selection.html"
    )
    """
    try:
        from .target_analysis_engine import build_target_analysis
        from .eda_engine import detect_type
    except ImportError:
        from target_analysis_engine import build_target_analysis
        from eda_engine import detect_type

    if target_col not in df.columns:
        raise ValueError(f"target_col='{target_col}' not in DataFrame")

    if dtype_map is None:
        dtype_map = {}
        for col in df.columns:
            if col == target_col:
                continue
            try:
                dtype_map[col] = detect_type(df[col])
            except Exception:
                dtype_map[col] = "Unknown"

    # Pre-compute enough bin configs for smooth 1-30 slider
    bins_list = sorted(set([b for b in DEFAULT_BINS if b <= max(n_bins + 5, 10)]))
    if n_bins not in bins_list:
        bins_list.append(n_bins)
    bins_list = sorted(set(bins_list))

    bin_methods = ["exposure"] if exposure_col else ["equal"]

    return build_target_analysis(
        df=df, dtype_map=dtype_map, target=target_col,
        n_bins_list=bins_list,
        bin_methods=bin_methods,
        exposure_col=exposure_col,
        bin_by=bin_by,
    )


# ==============================================================
#  CSS
# ==============================================================
CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

:root {
  --bg:#EEF1F7; --surf:#fff; --bdr:#D4DCE8;
  --txt:#0D1B2E; --txt2:#4A5568; --txt3:#8A98AA;
  --acc:#C8922A; --acc-l:#FDF3E3;
  --navy:#002B5C; --navy2:#004A97;
  --r:10px;
  --sh:0 1px 4px rgba(0,43,92,.08);
  --sh2:0 4px 18px rgba(0,43,92,.14);
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);
     color:var(--txt);font-size:14px;line-height:1.6;min-height:100vh}

/* ── Header ── */
.hdr{background:linear-gradient(135deg,var(--navy) 0%,var(--navy2) 100%);
     box-shadow:0 3px 20px rgba(0,43,92,.35);position:sticky;top:0;z-index:100}
.hdr-row{display:flex;align-items:center;gap:14px;padding:12px 28px}
.logo{background:var(--acc);color:#fff;font-size:12px;font-weight:800;
      padding:5px 10px;border-radius:7px;white-space:nowrap}
.hdr-title{color:#fff;font-size:16px;font-weight:700;letter-spacing:-.3px}
.hdr-sub{color:rgba(255,255,255,.5);font-size:11px;margin-top:1px}
.hdr-meta{margin-left:auto;display:flex;gap:18px;font-size:12px;color:rgba(255,255,255,.6)}
.hdr-meta strong{color:#fff}
.nav{background:var(--navy);border-top:1px solid rgba(255,255,255,.1);
     display:flex;padding:0 20px;overflow-x:auto}
.nav-btn{padding:10px 22px;font-size:13px;font-weight:500;cursor:pointer;border:none;
         background:none;color:rgba(255,255,255,.45);border-bottom:3px solid transparent;
         margin-bottom:-1px;font-family:inherit;transition:all .13s;white-space:nowrap}
.nav-btn:hover{color:rgba(255,255,255,.85)}
.nav-btn.on{color:#fff;border-bottom-color:var(--acc);font-weight:600}
.tab{display:none}.tab.on{display:block}

/* ── Layout ── */
.page{max-width:1500px;margin:0 auto;padding:20px 26px 60px}

/* ── Controls bar (minimal) ── */
.cbar{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;
      background:var(--surf);border:1px solid var(--bdr);border-left:4px solid var(--acc);
      border-radius:var(--r);padding:11px 16px;margin-bottom:16px;box-shadow:var(--sh)}
.cg{display:flex;flex-direction:column;gap:4px}
.cl{font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--txt2)}
.br{display:flex;gap:3px;flex-wrap:wrap}
.cb{padding:5px 12px;border:1px solid var(--bdr);border-radius:6px;font-size:.80rem;
    font-weight:500;cursor:pointer;background:var(--surf);color:var(--txt2);
    font-family:inherit;transition:all .11s;white-space:nowrap}
.cb:hover{border-color:var(--navy2);color:var(--navy2)}
.cb.on{background:var(--navy);color:#fff;border-color:var(--navy);font-weight:600}
.tg{display:flex;align-items:center;gap:5px;font-size:.82rem;cursor:pointer;
    padding:5px 11px;border:1px solid var(--bdr);border-radius:6px;background:var(--surf);
    transition:all .11s;user-select:none;white-space:nowrap}
.tg input{accent-color:var(--acc);width:14px;height:14px}
.tg:hover{border-color:var(--acc);background:var(--acc-l)}
.csep{width:1px;background:var(--bdr);align-self:stretch;margin:0 3px}

/* ── Feature row ── */
.fr{display:flex;flex-wrap:wrap;gap:10px;align-items:center;background:var(--surf);
    border:1px solid var(--bdr);border-left:4px solid var(--navy2);border-radius:var(--r);
    padding:10px 16px;margin-bottom:14px;box-shadow:var(--sh)}
.fl{font-size:.82rem;font-weight:700;color:var(--navy);white-space:nowrap}
.fsel{padding:8px 12px;border:1px solid var(--bdr);border-radius:6px;font-size:.87rem;
      font-family:inherit;background:var(--surf);color:var(--txt);
      min-width:200px;flex:1;max-width:480px;outline:none;cursor:pointer}
.fsel:focus{border-color:var(--navy2)}
.bl{font-size:.85rem;color:var(--navy);font-weight:700;min-width:52px}
.rng{accent-color:var(--acc);cursor:pointer;width:130px}

/* ── Chart container ── */
.cc{background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);
    margin:10px 0;overflow:hidden;position:relative;box-shadow:var(--sh)}
.cl2{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
     gap:10px;background:rgba(255,255,255,.95);z-index:2;font-size:.82rem;color:var(--txt2);
     transition:opacity .35s}
.cl2.done{opacity:0;pointer-events:none}
.sp{width:22px;height:22px;border:2.5px solid var(--bdr);border-top-color:var(--acc);
    border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

/* ── Legend ── */
.leg{display:flex;flex-wrap:wrap;gap:14px;align-items:center;padding:7px 14px;
     background:#f5f8ff;border-radius:7px;border:1px solid var(--bdr);
     margin:8px 0 14px;font-size:.79rem;color:var(--txt2)}
.li{display:flex;align-items:center;gap:6px}
.ls{width:14px;height:14px;border-radius:3px;flex-shrink:0}
.lline{display:inline-block;width:24px;height:3px;background:#C8922A;
       vertical-align:middle;margin-right:5px;border-radius:2px}

/* ── Stat grid ── */
.sg{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:10px;margin:12px 0 18px}
.sc{background:var(--surf);border:1px solid var(--bdr);border-top:3px solid var(--acc);
    border-radius:var(--r);padding:.6rem 1rem .5rem;box-shadow:var(--sh)}
.sc.warn-card{border-top-color:#f59e0b}
.sv{font-size:1.05rem;font-weight:700;color:var(--navy);line-height:1.2}
.sl{font-size:.67rem;color:var(--txt2);text-transform:uppercase;letter-spacing:.05em;margin-top:2px}

/* ── Tables ── */
.tw{overflow-x:auto;margin:10px 0;border-radius:8px;box-shadow:var(--sh);border:1px solid var(--bdr)}
.dt{border-collapse:collapse;width:100%;font-size:.81rem;background:var(--surf)}
.dt th{background:#EEF3FA;padding:8px 12px;text-align:left;font-weight:600;font-size:.74rem;
       color:var(--navy2);border-bottom:2px solid var(--bdr);cursor:pointer;
       user-select:none;white-space:nowrap}
.dt th:hover{background:#E0E8F5}
.dt th.sa::after{content:" ^";color:var(--acc)}.dt th.sd::after{content:" v";color:var(--acc)}
.dt td{padding:7px 12px;border-bottom:1px solid #F0F4FA;vertical-align:middle}
.dt tr:last-child td{border-bottom:none}
.dt tbody tr:hover td{background:#F5F8FF}
.tc{display:flex;align-items:center;gap:8px;margin:5px 0 10px}
.dl{display:inline-flex;align-items:center;gap:4px;padding:6px 14px;background:var(--surf);
    border:1px solid var(--bdr);border-radius:6px;font-size:.78rem;font-weight:500;
    color:var(--txt2);text-decoration:none;transition:all .12s}
.dl:hover{background:var(--acc-l);color:var(--acc);border-color:var(--acc)}

/* ── Pagination ── */
.pgc{display:flex;align-items:center;gap:8px;margin:6px 0 10px;font-size:.81rem;color:var(--txt2)}
.pgb{padding:4px 12px;border:1px solid var(--bdr);border-radius:5px;font-size:.78rem;
     cursor:pointer;background:var(--surf);color:var(--navy2);transition:all .11s}
.pgb:hover:not(:disabled){background:var(--navy2);color:#fff;border-color:var(--navy2)}
.pgb:disabled{opacity:.38;cursor:not-allowed}
.pgi{font-weight:600;color:var(--navy)}

/* ── Section heading ── */
.sh{font-size:.95rem;font-weight:700;color:var(--navy);border-bottom:2px solid var(--acc);
    padding-bottom:4px;display:inline-block;margin:14px 0 10px}
.cap{font-size:.80rem;color:var(--txt2);margin:3px 0 7px}
.warn{padding:.5rem 1rem;border-radius:7px;font-size:.83rem;background:#fffbeb;
      color:#78350f;border-left:3px solid #f59e0b;margin:.5rem 0}
.zi-badge{display:inline-block;padding:.3rem .9rem;background:#fef3c7;color:#92400e;
          border:1px solid #fcd34d;border-radius:20px;font-size:.78rem;font-weight:600;
          margin-bottom:8px}
.tip-box{background:#f0fdf4;border:1px solid #86efac;border-left:4px solid #22c55e;
         border-radius:8px;padding:12px 16px;margin:10px 0;font-size:.83rem;color:#14532d}
.tip-box strong{color:#166534}

/* ── Fullscreen ── */
#fso{display:none;position:fixed;inset:0;background:rgba(0,0,0,.80);
     z-index:9999;align-items:center;justify-content:center}
#fso.on{display:flex}
#fsb{background:var(--surf);border-radius:12px;padding:8px;
     width:97vw;max-height:97vh;overflow:auto;position:relative}
#fsc{position:absolute;top:10px;right:14px;font-size:22px;cursor:pointer;
     color:#64748b;background:none;border:none;z-index:10;font-weight:bold}
#fsp{width:100%;height:86vh}

@media(max-width:768px){.hdr-meta{display:none}.page{padding:12px 10px 32px}}
"""


# ==============================================================
#  JavaScript
# ==============================================================
JS = r"""
// ============================================================
//  Feature Selection Dashboard JS
//  - Controls: Metric | Count toggle | Sort | Group small
//  - No LogY, no method toggle (exposure always used if available)
//  - Subplot layout: top panel = bars, bottom panel = mean line
//  - Group small: always operates on fresh copy of raw data
//  - Bins slider: finds closest pre-computed config, shows label
// ============================================================

var S = {
  metric:  'mean',
  showCnt: true,
  catSort: 'count',
  grp:     0,
  catPage: 0,
  catPgSz: 20,
  bins:    20,
};
var ACT = {type: null, col: null};
var FIGS = {};

// ── formatting ──────────────────────────────────────────────
function F(v, d) {
  if (v === null || v === undefined || v === '' || v !== v) return '--';
  var f = +v;
  if (!isFinite(f)) return '--';
  d = (d !== undefined) ? d : 4;
  if (Math.abs(f) >= 1e9)  return (f/1e9).toFixed(2) + 'B';
  if (Math.abs(f) >= 1e6)  return (f/1e6).toFixed(2) + 'M';
  if (Math.abs(f) >= 1e3)  return f.toLocaleString(undefined, {maximumFractionDigits: 2});
  if (Math.abs(f) < 0.0001 && f !== 0) return f.toExponential(3);
  return f.toFixed(d);
}
function trunc(s, n) {
  s = String(s || '');
  n = n || 20;
  return s.length > n ? s.slice(0, n-1) + '..' : s;
}

// ── tabs ─────────────────────────────────────────────────────
function showTab(id) {
  document.querySelectorAll('.tab').forEach(function(p) { p.classList.remove('on'); });
  document.querySelectorAll('.nav-btn').forEach(function(b) { b.classList.remove('on'); });
  var pane = document.getElementById(id);
  var btn  = document.querySelector('[data-tab="' + id + '"]');
  if (pane) pane.classList.add('on');
  if (btn)  btn.classList.add('on');
  window.scrollTo({top: 0, behavior: 'smooth'});
  setTimeout(function() {
    if (id === 'tab-u') renderUni();
    else if (id === 'tab-c' && ACT.col) renderCat(ACT.col);
    else if (id === 'tab-n' && ACT.col) renderNum(ACT.col);
  }, 80);
}

// ── controls ─────────────────────────────────────────────────
function setMetric(m) {
  S.metric = m;
  document.querySelectorAll('.mb2').forEach(function(b) {
    b.classList.toggle('on', b.getAttribute('data-m') === m);
  });
  refresh();
}
function togCnt(cb) {
  S.showCnt = cb.checked;
  refresh();
}
function setSort(s) {
  S.catSort = s;
  S.catPage = 0;
  document.querySelectorAll('.sb').forEach(function(b) {
    b.classList.toggle('on', b.getAttribute('data-s') === s);
  });
  refresh();
}
function setGrp(v) {
  S.grp = +v;
  S.catPage = 0;
  var el = document.getElementById('grp-lbl');
  if (el) el.textContent = v > 0 ? '< ' + v + '%' : 'Off';
  if (ACT.type === 'cat') renderCat(ACT.col);
}
function setBins(v) {
  S.bins = +v;
  var el = document.getElementById('bins-v');
  if (el) el.textContent = v + ' bins';
  if (ACT.type === 'num') renderNum(ACT.col);
}
function refresh() {
  if      (ACT.type === 'cat') renderCat(ACT.col);
  else if (ACT.type === 'num') renderNum(ACT.col);
  else if (ACT.type === 'uni') renderUni();
}

// ── chart renderer ───────────────────────────────────────────
function plotChart(id, traces, layout) {
  var el = document.getElementById(id);
  if (!el || !window.Plotly) return;
  var wrap = el.closest('.cc');
  if (wrap) {
    var ldr = wrap.querySelector('.cl2');
    if (ldr) {
      ldr.style.opacity = '0';
      setTimeout(function() { ldr.classList.add('done'); }, 350);
    }
  }
  var cfg = {
    responsive: true, displayModeBar: true, displaylogo: false,
    modeBarButtonsToRemove: ['sendDataToCloud', 'lasso2d', 'select2d'],
  };
  FIGS[id] = {data: traces, layout: layout};
  try {
    if (el._p) Plotly.react(id, traces, layout, cfg);
    else { Plotly.newPlot(id, traces, layout, cfg); el._p = true; }
  } catch(e) { console.warn('chart error', id, e); }
}

// ── fullscreen ───────────────────────────────────────────────
function openFS(id) {
  var fig = FIGS[id];
  if (!fig || !window.Plotly) return;
  var ov = document.getElementById('fso');
  var pl = document.getElementById('fsp');
  if (!ov || !pl) return;
  var lay = JSON.parse(JSON.stringify(fig.layout || {}));
  lay.height = Math.floor(window.innerHeight * 0.87);
  lay.autosize = true;
  Plotly.newPlot(pl, fig.data, lay, {responsive:true, displayModeBar:true, displaylogo:false});
  ov.classList.add('on');
}
function closeFS() {
  var ov = document.getElementById('fso');
  if (ov) ov.classList.remove('on');
  var pl = document.getElementById('fsp');
  if (pl && window.Plotly) Plotly.purge(pl);
}
document.addEventListener('click', function(e) {
  if (e.target === document.getElementById('fso')) closeFS();
});

// ── table sort ───────────────────────────────────────────────
document.addEventListener('click', function(e) {
  var th = e.target.closest('th');
  if (!th) return;
  var tbl = th.closest('table.srt');
  if (!tbl) return;
  var idx = Array.from(th.parentNode.children).indexOf(th);
  var tbody = tbl.querySelector('tbody');
  var rows = Array.from(tbody.querySelectorAll('tr'));
  var asc = th.classList.contains('sa');
  tbl.querySelectorAll('th').forEach(function(h) { h.classList.remove('sa', 'sd'); });
  rows.sort(function(a, b) {
    var av = a.cells[idx] ? a.cells[idx].textContent.trim() : '';
    var bv = b.cells[idx] ? b.cells[idx].textContent.trim() : '';
    var an = parseFloat(av.replace(/[,%MBk]/g, '')), bn = parseFloat(bv.replace(/[,%MBk]/g, ''));
    if (!isNaN(an) && !isNaN(bn)) return asc ? an - bn : bn - an;
    return asc ? av.localeCompare(bv) : bv.localeCompare(av);
  });
  rows.forEach(function(r) { tbody.appendChild(r); });
  th.classList.add(asc ? 'sd' : 'sa');
});

// ============================================================
//  SUBPLOT BUILDER
//  Two-panel layout using Plotly grid:
//    Panel 1 (top ~65%): exposure bars (gold) + count bars (navy)
//    Panel 2 (bottom ~35%): mean target line (gold) -- own independent scale
//
//  Key design rules:
//   - transparent backgrounds
//   - matched x-axes (same order top and bottom)
//   - auto-scaled y ranges with padding
//   - smart label truncation and angle
// ============================================================
function buildSubplot(id, xLabels, expos, cnts, mvals, expName, mLbl, title, totalH) {
  if (!window.Plotly || !xLabels || !xLabels.length) return;

  var ec = expName || '';
  var hasE = !!(ec && expos && expos.length && expos.some(function(v) { return v > 0; }));
  var n = xLabels.length;

  // Smart tick angle and bottom margin
  var maxLbl = xLabels.reduce(function(a, s) { return s && s.length > a ? s.length : a; }, 0);
  var angle = 0;
  if (n > 18 || maxLbl > 14) angle = -55;
  else if (n > 12 || maxLbl > 9)  angle = -40;
  else if (n > 7)                  angle = -28;

  var bMgn = angle < -45 ? 140 : angle < -20 ? 110 : 70;
  totalH = totalH || 560;

  // Row height split: bars 62%, line 38%
  var R1 = 0.62, R2 = 1 - R1;
  // Panel domains (with small gap)
  var GAP = 0.06;
  var top_lo = R2 + GAP/2, top_hi = 1.0;
  var bot_lo = 0.0,        bot_hi = R2 - GAP/2;

  var gridColor = 'rgba(212,220,232,0.6)';
  var traces = [];

  // Panel 1: Exposure bars (gold)
  if (hasE) {
    traces.push({
      type: 'bar', x: xLabels, y: expos, name: ec,
      xaxis: 'x', yaxis: 'y',
      marker: { color: 'rgba(200,146,42,0.60)', line: {color:'rgba(200,146,42,0.85)',width:0.5} },
      hovertemplate: '<b>%{x}</b><br>' + ec + ': %{y:,.2f}<extra></extra>',
    });
  }

  // Panel 1: Count bars (navy, toggleable)
  if (S.showCnt) {
    traces.push({
      type: 'bar', x: xLabels, y: cnts, name: 'Count',
      xaxis: 'x', yaxis: 'y2',
      marker: { color: 'rgba(0,43,92,0.32)', line: {color:'rgba(0,43,92,0.55)',width:0.5} },
      hovertemplate: '<b>%{x}</b><br>Count: %{y:,}<extra></extra>',
    });
  }

  // Panel 2: Mean line (gold)
  traces.push({
    type: 'scatter', mode: 'lines+markers',
    x: xLabels, y: mvals, name: mLbl,
    xaxis: 'x2', yaxis: 'y3',
    line: { color: '#C8922A', width: 3 },
    marker: { color: '#C8922A', size: 10, symbol: 'circle', line: {color:'#fff',width:2} },
    hovertemplate: '<b>%{x}</b><br>' + mLbl + ': %{y:.6g}<extra></extra>',
  });

  // Auto y-range for mean line with generous padding
  var validM = mvals.filter(function(v) { return v !== null && isFinite(+v); });
  var mMin = validM.length ? Math.min.apply(null, validM) : 0;
  var mMax = validM.length ? Math.max.apply(null, validM) : 1;
  var mSpan = mMax - mMin;
  var mPad = mSpan > 0 ? mSpan * 0.25 : Math.abs(mMax) * 0.25 || 0.001;
  var mR0 = mMin - mPad, mR1 = mMax + mPad;
  if (mR0 < 0 && mMin >= 0) mR0 = 0;  // don't go negative if all values >= 0

  var tickFont = { size: Math.max(9, 12 - Math.floor(n / 10)), color: '#4A5568' };

  var layout = {
    title: { text: title, font: {size:14,color:'#0D1B2E'}, x:0.01, xanchor:'left' },
    // Panel 1 axes
    xaxis: {
      domain: [0, 1], anchor: 'y',
      type: 'category',
      tickangle: angle, tickfont: tickFont,
      gridcolor: gridColor, zeroline: false, showgrid: false,
      automargin: true,
      // hide tick labels on top panel (shown on bottom panel)
      showticklabels: false,
    },
    yaxis: {  // exposure (gold, left)
      domain: [top_lo, top_hi], anchor: 'x',
      title: { text: hasE ? ec : '', font: {size:11,color:'rgba(200,146,42,0.9)'} },
      tickfont: { color:'rgba(200,146,42,0.9)', size:10 },
      gridcolor: gridColor, zeroline: true,
      zerolinecolor: 'rgba(200,146,42,0.3)', showgrid: true, side: 'left',
    },
    yaxis2: {  // count (navy, right, overlaying)
      overlaying: 'y', side: 'right',
      title: { text: S.showCnt ? 'Count' : '', font: {size:11,color:'rgba(0,43,92,0.60)'} },
      tickfont: { color:'rgba(0,43,92,0.60)', size:10 },
      zeroline: false, showgrid: false, visible: S.showCnt,
    },
    // Panel 2 axes
    xaxis2: {
      domain: [0, 1], anchor: 'y3',
      type: 'category',
      tickangle: angle, tickfont: tickFont,
      gridcolor: gridColor, zeroline: false, showgrid: false,
      automargin: true,
      matches: 'x',  // same category order as top panel
    },
    yaxis3: {  // mean line (gold, own scale)
      domain: [bot_lo, bot_hi], anchor: 'x2',
      title: { text: mLbl, font: {size:11,color:'#C8922A'} },
      tickfont: { color:'#C8922A', size:10 },
      range: [mR0, mR1],
      gridcolor: gridColor, zeroline: true,
      zerolinecolor: 'rgba(200,146,42,0.25)', showgrid: true, side: 'left',
    },
    // Transparent backgrounds
    paper_bgcolor: 'rgba(0,0,0,0)',
    plot_bgcolor:  'rgba(0,0,0,0)',
    font: { family: 'Inter,sans-serif', size: 11, color: '#0D1B2E' },
    height: totalH,
    margin: { l: 80, r: 80, t: 44, b: bMgn },
    barmode: 'group', bargap: 0.18, bargroupgap: 0.05,
    legend: {
      orientation: 'h', x: 0, y: 1.03,
      bgcolor: 'rgba(0,0,0,0)', font: {size:11},
      xanchor: 'left', yanchor: 'bottom',
    },
    hovermode: 'x unified',
    // Divider line between subplots
    shapes: [{
      type: 'line', xref: 'paper', yref: 'paper',
      x0: 0, x1: 1, y0: R2, y1: R2,
      line: { color: '#D4DCE8', width: 1.5, dash: 'dot' },
    }],
    // "Bars" annotation on top panel, "Mean" on bottom
    annotations: [
      { text: hasE ? ec + ' + Count' : 'Count',
        xref: 'paper', yref: 'paper', x: 1.0, y: top_hi - 0.01,
        showarrow: false, font: {size:9,color:'#8A98AA'},
        xanchor: 'right', yanchor: 'top' },
      { text: mLbl,
        xref: 'paper', yref: 'paper', x: 1.0, y: bot_hi,
        showarrow: false, font: {size:9,color:'#C8922A'},
        xanchor: 'right', yanchor: 'top' },
    ],
  };

  plotChart(id, traces, layout);
}

// ============================================================
//  UNIVARIATE
//  If >= 50% zeros: show two side-by-side panels
//    Left: full distribution, Right: non-zero (log1p)
//  Otherwise: single histogram
// ============================================================
function renderUni() {
  ACT.type = 'uni';
  var D = window.D_UNI;
  if (!D || !window.Plotly) return;

  var hist    = D.hist_clip;
  var histLog = D.hist_log;
  var stats   = D.stats || {};
  var zeroPct = +(stats.zero_pct || 0);
  var isZI    = zeroPct >= 50;

  if (!hist || !hist.counts || !hist.counts.length) return;

  var gridColor = 'rgba(212,220,232,0.6)';

  // Build main histogram trace
  var edges = hist.edges, counts = hist.counts;
  var mids = [], labs = [];
  for (var i = 0; i < counts.length; i++) {
    var lo = +edges[i], hi = +edges[i+1];
    mids.push((lo + hi) / 2);
    labs.push('[' + lo.toPrecision(4) + ', ' + hi.toPrecision(4) + ')');
  }

  var hasNZ = isZI && histLog && histLog.counts && histLog.counts.length > 0;

  if (hasNZ) {
    // Two side-by-side: full distribution | non-zero (log1p)
    var eL = histLog.edges, cL = histLog.counts;
    var mL = [], lL = [];
    for (var j = 0; j < cL.length; j++) {
      var lo2 = +eL[j], hi2 = +eL[j+1];
      mL.push((lo2+hi2)/2);
      lL.push('[' + lo2.toPrecision(3) + ', ' + hi2.toPrecision(3) + ')');
    }
    var traces = [
      { type:'bar', x:mids, y:counts, name:'All (incl. zeros)',
        xaxis:'x', yaxis:'y',
        marker:{color:'rgba(0,43,92,0.65)',line:{color:'rgba(0,43,92,0.85)',width:0.3}},
        hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>', text:labs },
      { type:'bar', x:mL, y:cL, name:'Non-zero (log1p)',
        xaxis:'x2', yaxis:'y2',
        marker:{color:'rgba(200,146,42,0.65)',line:{color:'rgba(200,146,42,0.9)',width:0.3}},
        hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>', text:lL },
    ];
    var layout = {
      title: { text: (window.D_TGT||'Target') + ' -- Distribution (' + zeroPct.toFixed(1) + '% zeros)',
               font:{size:14,color:'#0D1B2E'}, x:0.01, xanchor:'left' },
      grid: { rows:1, columns:2, pattern:'independent' },
      xaxis:  { domain:[0,0.46], anchor:'y',
                title:{text:'Value',font:{size:11}},
                gridcolor:gridColor, zeroline:false },
      yaxis:  { anchor:'x', title:{text:'Count',font:{size:11}}, gridcolor:gridColor },
      xaxis2: { domain:[0.54,1], anchor:'y2',
                title:{text:'log1p(non-zero values)',font:{size:11,color:'#C8922A'}},
                gridcolor:gridColor, zeroline:false },
      yaxis2: { anchor:'x2', title:{text:'Count',font:{size:11}}, gridcolor:gridColor },
      paper_bgcolor:'rgba(0,0,0,0)', plot_bgcolor:'rgba(0,0,0,0)',
      font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
      height:400, margin:{l:65,r:25,t:50,b:55}, bargap:0.04,
      legend:{orientation:'h',x:0,y:1.06,font:{size:11}},
      annotations:[
        {text:'Full distribution (incl. zeros)', xref:'paper',yref:'paper',
         x:0.23,y:1.04, showarrow:false, font:{size:10,color:'rgba(0,43,92,0.8)'}},
        {text:'Non-zero only (log1p scale)', xref:'paper',yref:'paper',
         x:0.77,y:1.04, showarrow:false, font:{size:10,color:'#C8922A'}},
      ],
    };
    plotChart('uni-ch', traces, layout);
  } else {
    // Single histogram
    var traces1 = [{
      type:'bar', x:mids, y:counts, name:'Count',
      marker:{color:'rgba(0,43,92,0.65)',line:{color:'rgba(0,43,92,0.85)',width:0.3}},
      hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>', text:labs,
    }];
    var layout1 = {
      title: { text: (window.D_TGT||'Target') + ' -- Distribution',
               font:{size:14,color:'#0D1B2E'}, x:0.01, xanchor:'left' },
      xaxis: { title:{text:window.D_TGT||'Target',font:{size:11}},
               gridcolor:gridColor, zeroline:false },
      yaxis: { title:{text:'Count',font:{size:11}}, gridcolor:gridColor },
      paper_bgcolor:'rgba(0,0,0,0)', plot_bgcolor:'rgba(0,0,0,0)',
      font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
      height:400, margin:{l:65,r:20,t:46,b:55}, bargap:0.04,
    };
    plotChart('uni-ch', traces1, layout1);
  }
  buildUniTbl();
}

function buildUniTbl() {
  var D = window.D_UNI;
  if (!D) return;
  var s = D.stats || {};
  var rows = [
    ['Count',    (s.count||0).toLocaleString()],
    ['Mean',     F(s.mean, 6)],
    ['Median',   F(s.median, 6)],
    ['Std Dev',  F(s.std, 4)],
    ['Min',      F(s.min, 6)],
    ['Max',      F(s.max, 4)],
    ['P25',      F(s.p25, 6)],
    ['P75',      F(s.p75, 4)],
    ['P95',      F(s.p95, 4)],
    ['P99',      F(s.p99, 4)],
    ['Skewness', F(s.skewness, 3)],
    ['Zero %',   F(s.zero_pct, 2) + '%'],
  ];
  var h = '<div class="tw" style="max-width:380px"><table class="dt">'
    + '<thead><tr><th>Statistic</th><th style="text-align:right">Value</th></tr></thead><tbody>';
  rows.forEach(function(r) {
    var hi = (r[0] === 'Zero %' && parseFloat(r[1]) >= 50)
           ? ' style="color:#b45309;font-weight:700"' : '';
    h += '<tr><td>' + r[0] + '</td>'
      + '<td style="text-align:right;font-weight:600;color:var(--navy)"' + hi + '>' + r[1] + '</td></tr>';
  });
  var el = document.getElementById('uni-tbl');
  if (el) el.innerHTML = h + '</tbody></table></div>';
}

// ============================================================
//  CATEGORICAL
// ============================================================
function selCat(col) { ACT = {type:'cat', col:col}; S.catPage = 0; renderCat(col); }
function catPg(d)    { S.catPage = Math.max(0, S.catPage + d); renderCat(ACT.col); }

function renderCat(col) {
  var rawData = window.D_CAT && window.D_CAT[col];
  if (!rawData || !rawData.length || !window.Plotly) return;

  var m   = S.metric;
  var ec  = window.D_EC || '';
  var hasE = !!(ec && rawData[0] && rawData[0].exposure_sum !== undefined);

  // IMPORTANT: always work on a FRESH COPY -- never mutate rawData
  var data = rawData.slice();

  // Group small categories
  if (S.grp > 0) {
    var kept = [], grp = [];
    data.forEach(function(r) { (+r.pct < S.grp ? grp : kept).push(r); });
    if (grp.length) {
      var gn  = grp.reduce(function(a, r) { return a + (+r.count||0); }, 0);
      var gws = grp.reduce(function(a, r) { return a + (+r.mean||0) * (+r.count||0); }, 0);
      var ges = grp.reduce(function(a, r) { return a + (+r.exposure_sum||0); }, 0);
      var gep = grp.reduce(function(a, r) { return a + (+r.exposure_pct||0); }, 0);
      kept.push({
        category: '(Other)',
        count:    gn,
        pct:      grp.reduce(function(a, r) { return a + (+r.pct||0); }, 0),
        mean:     gn > 0 ? gws / gn : 0,
        median:   0,
        sum:      grp.reduce(function(a, r) { return a + (+r.sum||0); }, 0),
        exposure_sum: ges,
        exposure_pct: gep,
      });
      data = kept;
    }
  }

  // Sort AFTER grouping
  if      (S.catSort === 'metric') data.sort(function(a,b) { return (+b[m]||0) - (+a[m]||0); });
  else if (S.catSort === 'alpha')  data.sort(function(a,b) { return String(a.category).localeCompare(String(b.category)); });
  else                              data.sort(function(a,b) { return (+b.count||0) - (+a.count||0); });

  // Paginate
  var ps  = S.catPgSz;
  var tot = Math.max(1, Math.ceil(data.length / ps));
  S.catPage = Math.min(S.catPage, tot - 1);
  var page = data.slice(S.catPage * ps, (S.catPage + 1) * ps);

  var pgEl = document.getElementById('cat-pi');
  if (pgEl) pgEl.textContent = (S.catPage*ps+1) + '-' + Math.min((S.catPage+1)*ps, data.length) + ' of ' + data.length;
  var prevB = document.getElementById('cat-prev'), nextB = document.getElementById('cat-next');
  if (prevB) prevB.disabled = (S.catPage === 0);
  if (nextB) nextB.disabled = (S.catPage >= tot - 1);
  var pgw = document.getElementById('cat-pg');
  if (pgw) pgw.style.display = data.length > ps ? 'flex' : 'none';

  var n = page.length;
  // Shorter labels when many categories
  var maxLen = n > 20 ? 10 : n > 14 ? 13 : n > 9 ? 17 : 22;
  var cats  = page.map(function(r) { return trunc(String(r.category), maxLen); });
  var expos = hasE ? page.map(function(r) { return +(r.exposure_sum)||0; }) : [];
  var cnts  = page.map(function(r) { return +(r.count)||0; });
  var mvals = page.map(function(r) { return +(r[m])||0; });
  var mLbl  = ({mean:'Mean',median:'Median',sum:'Sum'}[m]||m) + ' ' + window.D_TGT;

  var h = n > 20 ? 640 : n > 12 ? 580 : 520;
  var title = col + ' vs ' + window.D_TGT + (tot > 1 ? '  (pg ' + (S.catPage+1) + '/' + tot + ')' : '');

  buildSubplot('cat-ch', cats, expos, cnts, mvals, ec, mLbl, title, h);
  catTbl(page, data, m, mLbl, hasE, ec, col);
}

function catTbl(page, all, m, mLbl, hasE, ec, col) {
  var h = '<tr><th>Category</th><th>Count</th><th>%</th>'
    + (hasE ? '<th>' + ec + '</th><th>Exp%</th>' : '')
    + '<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows = page.map(function(r) {
    var it = r.category === '(Other)' ? ' style="font-style:italic;color:var(--txt2)"' : '';
    return '<tr' + it + '>'
      + '<td style="font-weight:500;max-width:220px;word-break:break-word">' + String(r.category) + '</td>'
      + '<td style="text-align:right">' + (+r.count||0).toLocaleString() + '</td>'
      + '<td style="text-align:right">' + F(r.pct,1) + '%</td>'
      + (hasE ? '<td style="text-align:right">' + F(r.exposure_sum,2) + '</td>'
             + '<td style="text-align:right">' + F(r.exposure_pct,1) + '%</td>' : '')
      + '<td style="text-align:right;color:var(--acc);font-weight:700">' + F(r.mean,6) + '</td>'
      + '<td style="text-align:right">' + F(r.median,6) + '</td>'
      + '<td style="text-align:right">' + F(r.sum,2) + '</td></tr>';
  }).join('');
  var csvH = 'Category,Count,Pct' + (hasE ? ',' + ec + ',ExpPct' : '') + ',Mean,Median,Sum';
  var csv = csvH + '\n' + all.map(function(r) {
    var b = ['"' + r.category + '"', r.count, r.pct];
    if (hasE) b = b.concat([r.exposure_sum, r.exposure_pct]);
    return b.concat([r.mean, r.median, r.sum]).join(',');
  }).join('\n');
  var b64 = btoa(unescape(encodeURIComponent(csv)));
  var tbl = '<div class="tw"><table class="dt srt"><thead>' + h + '</thead><tbody>' + rows + '</tbody></table></div>'
    + '<div class="tc"><a class="dl" href="data:text/csv;base64,' + b64
    + '" download="' + (col||'cat') + '_vs_target.csv">Download CSV (' + all.length + ' rows)</a></div>';
  var el = document.getElementById('cat-tbl');
  if (el) el.innerHTML = tbl;
}

// ============================================================
//  NUMERICAL
// ============================================================
function selNum(col) { ACT = {type:'num', col:col}; renderNum(col); }

function renderNum(col) {
  var all = window.D_NUM && window.D_NUM[col];
  if (!all || !window.Plotly) return;

  // Pick best available method
  var methData = null;
  if (window.D_EC) {
    methData = all['exposure'] || all['equal'] || null;
  }
  if (!methData) {
    var keys = Object.keys(all);
    for (var ki = 0; ki < keys.length; ki++) {
      if (Object.keys(all[keys[ki]] || {}).length) { methData = all[keys[ki]]; break; }
    }
  }
  if (!methData) {
    var el = document.getElementById('num-ch');
    if (el) el.innerHTML = '<p class="cap" style="padding:26px">No binned data available.</p>';
    return;
  }

  // Find closest pre-computed bin count to S.bins
  var avail = Object.keys(methData).map(Number).filter(function(n) { return n > 0; });
  if (!avail.length) {
    document.getElementById('num-ch').innerHTML = '<p class="cap" style="padding:26px">No bin configs.</p>';
    return;
  }
  avail.sort(function(a, b) { return a - b; });
  var target = S.bins;
  var closest = avail.reduce(function(best, k) {
    return Math.abs(k - target) < Math.abs(best - target) ? k : best;
  }, avail[0]);

  var bins = methData[closest];
  if (!bins || !bins.length) {
    document.getElementById('num-ch').innerHTML = '<p class="cap" style="padding:26px">No bins for ' + closest + '.</p>';
    return;
  }

  var m    = S.metric;
  var ec   = window.D_EC || '';
  var hasE = !!(ec && bins[0] && bins[0].exposure_sum !== undefined);

  // X-axis = bin range labels as categorical strings  e.g. "[25.0, 34.2)"
  var labs  = bins.map(function(b) { return b.bin; });
  var expos = hasE ? bins.map(function(b) { return +(b.exposure_sum)||0; }) : [];
  var cnts  = bins.map(function(b) { return +(b.count)||0; });
  var mvals = bins.map(function(b) { return +(b[m])||0; });
  var mLbl  = ({mean:'Mean',median:'Median',sum:'Sum'}[m]||m) + ' ' + window.D_TGT;

  var bNote = (window.D_EC && window.D_BY === 'amount') ? ' equal ' + ec + '/bin' : '';
  var closestNote = (closest !== target) ? '  (closest to ' + target + ')' : '';
  var title = col + ' vs ' + window.D_TGT + ' [' + closest + ' bins' + bNote + ']' + closestNote;

  // Update the bins label to show actual bins being displayed
  var bv = document.getElementById('bins-v');
  if (bv) bv.textContent = S.bins + ' bins' + (closest !== target ? ' -> ' + closest : '');

  var n = bins.length;
  var h = n > 20 ? 640 : n > 12 ? 580 : 520;
  buildSubplot('num-ch', labs, expos, cnts, mvals, ec, mLbl, title, h);
  numTbl(bins, m, mLbl, hasE, ec, col, closest);
}

function numTbl(bins, m, mLbl, hasE, ec, col, nb) {
  var h = '<tr><th>Bin Range</th><th>Count</th><th>%</th>'
    + (hasE ? '<th>' + ec + '</th><th>Exp%</th>' : '')
    + '<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows = bins.map(function(b) {
    return '<tr>'
      + '<td style="font-family:monospace;font-size:.78rem;white-space:nowrap">' + b.bin + '</td>'
      + '<td style="text-align:right">' + (+b.count||0).toLocaleString() + '</td>'
      + '<td style="text-align:right">' + F(b.pct,1) + '%</td>'
      + (hasE ? '<td style="text-align:right">' + F(b.exposure_sum,2) + '</td>'
             + '<td style="text-align:right">' + F(b.exposure_pct,1) + '%</td>' : '')
      + '<td style="text-align:right;color:var(--acc);font-weight:700">' + F(b.mean,6) + '</td>'
      + '<td style="text-align:right">' + F(b.median,6) + '</td>'
      + '<td style="text-align:right">' + F(b.sum,2) + '</td></tr>';
  }).join('');
  var csvH = 'Bin,Bin_Lo,Bin_Hi,Count,Pct' + (hasE ? ',' + ec + ',ExpPct' : '') + ',Mean,Median,Sum';
  var csv = csvH + '\n' + bins.map(function(b) {
    var base = ['"' + b.bin + '"', b.bin_lo, b.bin_hi, b.count, b.pct];
    if (hasE) base = base.concat([b.exposure_sum, b.exposure_pct]);
    return base.concat([b.mean, b.median, b.sum]).join(',');
  }).join('\n');
  var b64 = btoa(unescape(encodeURIComponent(csv)));
  var tbl = '<div class="tw"><table class="dt srt"><thead>' + h + '</thead><tbody>' + rows + '</tbody></table></div>'
    + '<div class="tc"><a class="dl" href="data:text/csv;base64,' + b64
    + '" download="' + (col||'num') + '_binned.csv">Download CSV (' + nb + ' bins)</a></div>';
  var el = document.getElementById('num-tbl');
  if (el) el.innerHTML = tbl;
}

// ── init ─────────────────────────────────────────────────────
window.addEventListener('load', function() {
  renderUni();
  var fc = window._FC, fn = window._FN;
  if (fc) selCat(fc);
  if (fn) selNum(fn);
  showTab('tab-u');
});
"""


# ==============================================================
#  generate_fs_report()
# ==============================================================
def generate_fs_report(results: dict,
                        output_path=None,
                        open_browser: bool = True,
                        offline: bool = False) -> str:
    """
    Generate the Feature Selection Dashboard.

    Parameters
    ----------
    results     : dict with "deep_target_analysis" key
                  (from run_eda() or run_target_analysis())
    output_path : file path to save  e.g. r"C:\\path\\output.html"
    open_browser: open in browser after saving
    offline     : embed Plotly.js (no internet needed)

    IMPORTANT for VS Code users:
        Always pass output_path. Never print the return value.
        The HTML is ~200KB and will freeze VS Code terminal/notebook output.

    Example
    -------
    ta = run_target_analysis(df, "frequency", exposure_col="expo_amt")
    generate_fs_report(
        {"deep_target_analysis": ta, "target_col": "frequency", "n_rows": len(df)},
        output_path=r"C:\\Users\\you\\Desktop\\output.html"
    )
    """
    target = results.get("target_col")
    dta    = results.get("deep_target_analysis", {})
    n_rows = results.get("n_rows", 0)

    if not target:
        return "<html><body><p>No target_col in results.</p></body></html>"
    if not dta:
        return ("<html><body><p>No deep_target_analysis found. "
                "Use run_target_analysis() or call plan.set_sections(target_analysis=True).</p></body></html>")

    cat_cols     = sorted(dta.get("categorical", {}).keys())
    num_cols     = sorted(dta.get("numeric",     {}).keys())
    uni          = dta.get("univariate",  {})
    n_bins_list  = dta.get("n_bins_list", DEFAULT_BINS)
    exposure_col = dta.get("exposure_col") or ""
    bin_by       = dta.get("bin_by", "amount")
    ta_elapsed   = dta.get("elapsed_sec", 0)

    n_bins_def = max(n_bins_list) if n_bins_list else 20

    # ── stat cards ─────────────────────────────────────────────
    stats    = uni.get("stats", {})
    zero_pct = float(stats.get("zero_pct") or 0)

    stat_cards = ""
    for lbl, key, fmt_s in [
        ("Count","count",",.0f"),("Mean","mean",".4g"),("Median","median",".4g"),
        ("Std Dev","std",".4g"),("P95","p95",".4g"),("P99","p99",".4g"),
        ("Skewness","skewness",".3f"),("Zero %","zero_pct",".2f"),
    ]:
        v = stats.get(key); disp = "--"
        if v is not None:
            try:
                fv = float(v)
                disp = (f"{int(fv):,}" if key == "count"
                        else f"{fv:.2f}%" if key == "zero_pct"
                        else format(fv, fmt_s))
            except Exception:
                disp = str(v)
        warn_cls = ' warn-card' if key == 'zero_pct' and zero_pct >= 50 else ''
        stat_cards += (f'<div class="sc{warn_cls}"><div class="sv">{disp}</div>'
                       f'<div class="sl">{lbl}</div></div>')

    # ── zero-inflation notice ──────────────────────────────────
    zi_notice = ""
    if zero_pct >= 50:
        zi_notice = f"""
<div class="zi-badge">Zero-inflated target: {zero_pct:.1f}% zeros</div>
<div class="tip-box">
  <strong>Why stats show 0 for Mean/Median/P95:</strong>
  {zero_pct:.0f}% of rows have frequency = 0. The mean across all rows
  is very close to zero, which is correct -- but not useful for feature selection.<br><br>
  <strong>What to do:</strong><br>
  1. Switch the metric to <strong>Sum</strong> -- shows total claims per category/bin<br>
  2. Use the <strong>non-zero distribution chart</strong> (right panel above) to see the claim severity shape<br>
  3. For modelling: use a <strong>Tweedie GLM</strong> or <strong>frequency x severity</strong>
     two-stage approach -- Tweedie handles zero-inflation natively<br>
  4. For feature selection: look at categories/bins where Sum is high relative to exposure
</div>"""

    # ── legend ─────────────────────────────────────────────────
    exp_item = (f'<span class="li"><span class="ls" style="background:rgba(200,146,42,.60)"></span>'
                f'{_esc(exposure_col)} (top panel, left axis)</span>'
                if exposure_col else "")
    legend = (f'<div class="leg">'
              f'{exp_item}'
              f'<span class="li"><span class="ls" style="background:rgba(0,43,92,.38)"></span>'
              f'Row Count (top panel, right axis)</span>'
              f'<span class="li"><span class="lline"></span>Mean {_esc(target)} (bottom panel -- own scale)</span>'
              f'</div>')

    # ── dropdowns ──────────────────────────────────────────────
    cat_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in cat_cols)
    num_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in num_cols)

    no_cat = '<div class="warn">No categorical features found.</div>' if not cat_cols else ""
    no_num = '<div class="warn">No numeric features found.</div>'     if not num_cols else ""

    # ── data script ────────────────────────────────────────────
    data_script = f"""<script>
window.D_TGT = {_j(target)};
window.D_UNI = {_j(uni)};
window.D_CAT = {_j(dta.get("categorical", {}))};
window.D_NUM = {_j(dta.get("numeric", {}))};
window.D_EC  = {_j(exposure_col)};
window.D_BY  = {_j(bin_by)};
window._FC   = {_j(cat_cols[0] if cat_cols else "")};
window._FN   = {_j(num_cols[0] if num_cols else "")};
</script>"""

    if offline:
        try:
            import plotly
            jp = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
            plotly_tag = (f"<script>{jp.read_text()}</script>"
                          if jp.exists() else f'<script src="{PLOTLY_CDN}"></script>')
        except Exception:
            plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'
    else:
        plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Feature Selection -- {_esc(target)} -- {n_rows:,} rows</title>
{plotly_tag}
<style>{CSS}</style>
</head>
<body>
{data_script}

<div id="fso"><div id="fsb">
  <button id="fsc" onclick="closeFS()">&#10005;</button>
  <div id="fsp"></div>
</div></div>

<div class="hdr">
  <div class="hdr-row">
    <div class="logo">RC</div>
    <div>
      <div class="hdr-title">Feature Selection Dashboard</div>
      <div class="hdr-sub">Chubb Risk Cohorts v5</div>
    </div>
    <div class="hdr-meta">
      <span>Rows <strong>{n_rows:,}</strong></span>
      <span>Target <strong>{_esc(target)}</strong></span>
      <span>Cat <strong>{len(cat_cols)}</strong></span>
      <span>Num <strong>{len(num_cols)}</strong></span>
      {"<span>Exposure <strong>" + _esc(exposure_col) + "</strong></span>" if exposure_col else ""}
      <span>Computed <strong>{ta_elapsed:.1f}s</strong></span>
    </div>
  </div>
  <div class="nav">
    <button class="nav-btn on" data-tab="tab-u" onclick="showTab('tab-u')">Target Overview</button>
    <button class="nav-btn"    data-tab="tab-c" onclick="showTab('tab-c')">Categorical vs Target</button>
    <button class="nav-btn"    data-tab="tab-n" onclick="showTab('tab-n')">Numerical vs Target</button>
  </div>
</div>

<div class="page">

<!-- Minimal controls: Metric | Count | Sort | Group -->
<div class="cbar">
  <div class="cg">
    <div class="cl">Metric (bottom panel)</div>
    <div class="br">
      <button class="cb mb2 on" data-m="mean"   onclick="setMetric('mean')">Mean</button>
      <button class="cb mb2"    data-m="median" onclick="setMetric('median')">Median</button>
      <button class="cb mb2"    data-m="sum"    onclick="setMetric('sum')">Sum</button>
    </div>
  </div>
  <div class="csep"></div>
  <div class="cg">
    <div class="cl">Count Bars</div>
    <label class="tg"><input type="checkbox" checked onchange="togCnt(this)"> Show Count</label>
  </div>
  <div class="csep"></div>
  <div class="cg">
    <div class="cl">Sort Categories</div>
    <div class="br">
      <button class="cb sb on" data-s="count"  onclick="setSort('count')">By Count</button>
      <button class="cb sb"    data-s="metric" onclick="setSort('metric')">By Metric</button>
      <button class="cb sb"    data-s="alpha"  onclick="setSort('alpha')">A-Z</button>
    </div>
  </div>
  <div class="csep"></div>
  <div class="cg">
    <div class="cl">Group Small &lt; <span id="grp-lbl" style="color:var(--acc);font-weight:700">Off</span></div>
    <input type="range" class="rng" min="0" max="5" step="0.5" value="0" oninput="setGrp(this.value)">
  </div>
  <div style="margin-left:auto;font-size:.71rem;color:var(--txt3);line-height:1.8;text-align:right">
    {n_rows:,} rows &bull; No sampling<br>Pre-computed in {ta_elapsed:.1f}s
  </div>
</div>

<!-- TARGET OVERVIEW -->
<div id="tab-u" class="tab on">
  <h3 class="sh">Target Overview -- {_esc(target)}</h3>
  <p class="cap">{n_rows:,} rows &bull; Full dataset &bull; No sampling</p>
  {zi_notice}
  <div class="sg">{stat_cards}</div>
  <div class="cc" style="padding:0">
    <div class="cl2"><div class="sp"></div><span>Rendering...</span></div>
    <div id="uni-ch" style="width:100%;min-height:400px"></div>
  </div>
  <div id="uni-tbl" style="margin-top:18px"></div>
</div>

<!-- CATEGORICAL -->
<div id="tab-c" class="tab">
  <h3 class="sh">Categorical vs {_esc(target)}</h3>
  {legend}
  {no_cat}
  {(f'<div class="fr"><label class="fl">Feature</label>'
    f'<select class="fsel" onchange="selCat(this.value)">{cat_opts}</select>'
    f'<span style="font-size:.77rem;color:var(--txt2)">{len(cat_cols)} features &bull; 20/page</span>'
    f'</div>') if cat_cols else ""}
  {('<div id="cat-pg" class="pgc" style="display:none">'
    '<button class="pgb" id="cat-prev" onclick="catPg(-1)">Prev</button>'
    '<span class="pgi" id="cat-pi"></span>'
    '<button class="pgb" id="cat-next" onclick="catPg(1)">Next</button>'
    '</div>') if cat_cols else ""}
  {('<div class="cc" style="padding:0"><div class="cl2"><div class="sp"></div><span>Rendering...</span></div>'
    '<div id="cat-ch" style="width:100%;min-height:520px"></div></div>'
    '<div id="cat-tbl" style="margin-top:14px"></div>') if cat_cols else ""}
</div>

<!-- NUMERICAL -->
<div id="tab-n" class="tab">
  <h3 class="sh">Numerical vs {_esc(target)}</h3>
  {legend}
  {no_num}
  {(f'<div class="fr"><label class="fl">Feature</label>'
    f'<select class="fsel" onchange="selNum(this.value)">{num_opts}</select>'
    f'<label class="fl" style="margin-left:12px">Bins</label>'
    f'<span class="bl" id="bins-v">{n_bins_def} bins</span>'
    f'<input type="range" class="rng" min="1" max="30" step="1"'
    f' value="{n_bins_def}" oninput="setBins(this.value)">'
    f'<span style="font-size:.74rem;color:var(--txt3)">1-30 (pre-computed: {", ".join(str(b) for b in sorted(n_bins_list))})</span>'
    f'</div>') if num_cols else ""}
  {('<div class="cc" style="padding:0"><div class="cl2"><div class="sp"></div><span>Rendering...</span></div>'
    '<div id="num-ch" style="width:100%;min-height:520px"></div></div>'
    '<div id="num-tbl" style="margin-top:14px"></div>') if num_cols else ""}
</div>

</div>

<script>
{JS}
S.bins = {n_bins_def};
</script>
</body>
</html>"""

    if output_path:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
        size = path.stat().st_size / 1024
        print(f"[FS] Saved -> {path}  ({size:.0f} KB)")
        if open_browser and not str(output_path).startswith("/dbfs"):
            try:
                webbrowser.open(path.resolve().as_uri())
            except Exception:
                pass

    return html
