"""
app.py — Insurance EDA Toolkit v5
Tabs: Overview · Variable Explorer · Hit Rate · Category Quality ·
      Outliers · Correlations · Data Comparison · Quality Scorecard
"""

import os
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

st.set_page_config(page_title="EDA Toolkit", page_icon="📊",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
  .block-container { padding: 1.1rem 2rem 1rem 2rem; }
  section[data-testid="stSidebar"] { background: #0f1117; }
  section[data-testid="stSidebar"] * { color: #e8eaf0 !important; }
  section[data-testid="stSidebar"] hr { border-color: #2d3145; }

  [data-testid="stMetricValue"]  { font-size: 1.3rem; font-weight: 700; color: #1a1d2e; }
  [data-testid="stMetricLabel"]  { font-size: 0.72rem; color: #6b7280; text-transform: uppercase; letter-spacing:.04em; }
  div[data-testid="metric-container"] {
    background:#f8f9fc; border:1px solid #e5e7ef; border-radius:10px; padding:.6rem 1rem .5rem 1rem;
  }
  .pill { display:inline-block; padding:2px 10px; border-radius:999px; font-size:.78rem; font-weight:600; margin:2px 3px; }
  .pill-red    { background:#fee2e2; color:#b91c1c; }
  .pill-yellow { background:#fef9c3; color:#a16207; }
  .pill-green  { background:#dcfce7; color:#166534; }
  .pill-blue   { background:#dbeafe; color:#1d4ed8; }
  .pill-purple { background:#ede9fe; color:#5b21b6; }

  .alert { padding:.45rem .85rem; border-radius:7px; margin:.25rem 0 .35rem 0; font-size:.85rem; line-height:1.45; }
  .alert-red    { background:#fef2f2; border-left:3px solid #ef4444; color:#7f1d1d; }
  .alert-yellow { background:#fffbeb; border-left:3px solid #f59e0b; color:#78350f; }
  .alert-blue   { background:#eff6ff; border-left:3px solid #3b82f6; color:#1e3a5f; }
  .alert-green  { background:#f0fdf4; border-left:3px solid #22c55e; color:#14532d; }
  .alert-purple { background:#f5f3ff; border-left:3px solid #7c3aed; color:#3b0764; }

  .sec-header { font-size:1.0rem; font-weight:700; color:#1a1d2e;
                border-bottom:2px solid #6366f1; padding-bottom:4px;
                margin:1.1rem 0 .6rem 0; display:inline-block; }

  button[data-baseweb="tab"] { font-size:.83rem; font-weight:600; }
  button[data-baseweb="tab"][aria-selected="true"] { color:#6366f1; border-color:#6366f1; }
  [data-testid="stDataFrame"] { border-radius:8px; overflow:hidden; }
  div[data-testid="stExpander"] summary { font-size:.88rem; }
  .stDownloadButton button { border-radius:6px; font-size:.78rem; padding:3px 12px; }
</style>
""", unsafe_allow_html=True)

PLOT_H  = 320
PLOT_BG = "rgba(0,0,0,0)"
GRID    = "#e5e7ef"
ACCENT  = "#6366f1"
CYAN    = "#06b6d4"
RED     = "#ef4444"
ORANGE  = "#f59e0b"
GREEN   = "#22c55e"
PURPLE  = "#7c3aed"


# ── helpers ───────────────────────────────────────────────────────────────────

def _R():
    return st.session_state.get("eda_results", {})

def _dl(df, label, fname):
    # Track usage count in session state so keys are unique but stable within a render
    counter_key = "__dl_counts__"
    if counter_key not in st.session_state:
        st.session_state[counter_key] = {}
    base = "dl_" + fname.replace(".", "_").replace("-", "_").replace(" ", "_")
    cnt = st.session_state[counter_key].get(base, 0) + 1
    st.session_state[counter_key][base] = cnt
    key = base if cnt == 1 else f"{base}_{cnt}"
    st.download_button(f"⬇ {label}", df.to_csv(index=False).encode(),
                       fname, "text/csv", use_container_width=True, key=key)

def _sec(t):
    st.markdown(f'<div class="sec-header">{t}</div>', unsafe_allow_html=True)

def _alert(msg, kind="yellow"):
    cls = {"red":"alert-red","yellow":"alert-yellow","blue":"alert-blue",
           "green":"alert-green","purple":"alert-purple"}.get(kind,"alert-yellow")
    st.markdown(f'<div class="alert {cls}">{msg}</div>', unsafe_allow_html=True)

def _chart(fig, h=PLOT_H):
    fig.update_layout(height=h, margin=dict(l=30,r=20,t=36,b=40),
                      paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
                      font=dict(family="Inter, sans-serif", size=11, color="#374151"),
                      legend=dict(bgcolor="rgba(0,0,0,0)", font_size=10))
    fig.update_xaxes(gridcolor=GRID, linecolor=GRID, zerolinecolor=GRID)
    fig.update_yaxes(gridcolor=GRID, linecolor=GRID, zerolinecolor=GRID)
    return fig

def _colour_status(val):
    if "Fix"    in str(val): return "color:#b91c1c; font-weight:700"
    if "Review" in str(val): return "color:#b45309; font-weight:700"
    if "Good"   in str(val): return "color:#166534; font-weight:700"
    return ""

def _df(df, height=None, extra_config=None):
    """
    st.dataframe wrapper that prevents number truncation.
    Auto-generates NumberColumn config for every numeric column so values
    always display in full instead of being cut off with '...'.
    """
    if df is None or not len(df):
        return
    col_cfg = {}
    for col in df.columns:
        try:
            s = df[col]
        except Exception:
            continue
        if pd.api.types.is_float_dtype(s):
            col_cfg[col] = st.column_config.NumberColumn(col, format="%.4g")
        elif pd.api.types.is_integer_dtype(s):
            col_cfg[col] = st.column_config.NumberColumn(col, format="%d")
    if extra_config:
        col_cfg.update(extra_config)
    kwargs = dict(use_container_width=True, column_config=col_cfg if col_cfg else None)
    if height:
        kwargs["height"] = height
    st.dataframe(df, **kwargs)


@st.cache_data(show_spinner=False)
def _build_feature_table(col_results_json):
    """
    Build the overview feature table. Cached so switching tabs / variables
    doesn't rebuild it on every Streamlit rerun.
    """
    import json
    col_results = json.loads(col_results_json)
    rows = []
    for col, r in col_results.items():
        rows.append({
            "Column":      col,
            "Type":        r.get("dtype","?"),
            "Missing %":   r.get("missing_pct", 0.0),
            "Hit Rate %":  r.get("hit_rate_pct", 100.0),
            "Unique":      r.get("n_unique", 0),
            "Zero %":      r.get("zero_pct", 0.0),
            "Inf %":       r.get("inf_pct", 0.0),
            "Skewness":    r.get("skewness") or r.get("dist", {}).get("skewness"),
        })
    return pd.DataFrame(rows)


# ── sidebar ───────────────────────────────────────────────────────────────────

def _sidebar(R):
    st.sidebar.markdown("## 📊 EDA Toolkit")
    st.sidebar.caption("100% local · no data leaves your machine")
    st.sidebar.markdown("---")

    # ── Stop Server button ────────────────────────────────────────────────────
    st.sidebar.markdown("**Server**")
    if st.sidebar.button("⏹ Stop Server", use_container_width=True,
                         help="Stop the Streamlit server (closes the app)"):
        st.sidebar.error("Stopping server…")
        os._exit(0)
    st.sidebar.markdown("---")

    dm    = R.get("dtype_map",{})
    n_num = sum(1 for t in dm.values() if t=="Numeric")
    n_cat = sum(1 for t in dm.values() if t=="Categorical")
    n_boo = sum(1 for t in dm.values() if t=="Boolean")
    n_dat = sum(1 for t in dm.values() if t=="Date")
    c1,c2 = st.sidebar.columns(2)
    c1.metric("Rows",    f"{R.get('n_rows',0):,}")
    c2.metric("Cols",    R.get("n_features",0))
    c1.metric("Numeric", n_num)
    c2.metric("Categ.",  n_cat)
    c1.metric("Bool",    n_boo)
    c2.metric("Date",    n_dat)
    st.sidebar.metric("Runtime", f"{R.get('elapsed_sec',0):.1f}s")
    if R.get("target_col"):
        st.sidebar.metric("Target", R["target_col"])

    sc = R.get("scorecard", pd.DataFrame())
    if len(sc):
        st.sidebar.markdown("---")
        st.sidebar.markdown("**Quality**")
        n_fix = int((sc["Status"]=="❌ Fix First").sum())
        n_rev = int((sc["Status"]=="⚠️ Review").sum())
        n_ok  = int((sc["Status"]=="✅ Good").sum())
        tot   = len(sc)
        bw    = 180
        wf,wr = round(n_fix/tot*bw) if tot else 0, round(n_rev/tot*bw) if tot else 0
        wo    = bw - wf - wr
        st.sidebar.markdown(f"""
<div style="display:flex;border-radius:5px;overflow:hidden;height:8px;margin:4px 0 10px 0">
  <div style="width:{wf}px;background:#ef4444"></div>
  <div style="width:{wr}px;background:#f59e0b"></div>
  <div style="width:{wo}px;background:#22c55e"></div>
</div>""", unsafe_allow_html=True)
        st.sidebar.write(f"🔴 Fix: **{n_fix}**   🟡 Review: **{n_rev}**   🟢 Good: **{n_ok}**")

    # ── Section toggles ───────────────────────────────────────────────────────
    st.sidebar.markdown("---")
    st.sidebar.markdown("**Active Tabs**")
    cfg_secs = R.get("config",{}).get("sections",{})
    def _on(k): return cfg_secs.get(k, True)

    # Store per-session tab visibility in session_state
    for k,label in [("hit_rate","Hit Rate"),("category_quality","Cat Quality"),
                    ("outliers","Outliers"),("correlations","Correlations"),
                    ("target_analysis","Target Analysis"),
                    ("comparison","Comparison"),("scorecard","Scorecard")]:
        default = _on(k) if k in cfg_secs else True
        # if section was disabled in config, default to off
        st.session_state.setdefault(f"tab_{k}", default)
        st.session_state[f"tab_{k}"] = st.sidebar.checkbox(label, value=st.session_state[f"tab_{k}"], key=f"chk_{k}")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════

def tab_overview(R):
    cfg    = R.get("config",{})
    cr     = R.get("col_results",{})
    dm     = R.get("dtype_map",{})
    df     = R.get("df", pd.DataFrame())
    n_rows = R["n_rows"]
    n_num  = sum(1 for t in dm.values() if t in ("Numeric","Boolean"))
    n_cat  = sum(1 for t in dm.values() if t=="Categorical")
    total_cells = n_rows * R["n_features"]
    total_miss  = sum(v["missing_count"] for v in cr.values())
    miss_pct    = round(total_miss/total_cells*100, 2) if total_cells else 0

    target = R.get("target_col")

    # ── KPI row ───────────────────────────────────────────────────────────────
    kpi_cols = st.columns(5)
    kpi_cols[0].metric("Total Rows",     f"{n_rows:,}")
    kpi_cols[1].metric("Columns",        R["n_features"])
    kpi_cols[2].metric("Numeric / Bool", n_num)
    kpi_cols[3].metric("Categorical",    n_cat)
    kpi_cols[4].metric("Overall Missing",f"{miss_pct:.1f}%")
    if target: st.caption(f"🎯 Target column: **{target}**  (excluded from feature analysis)")

    st.divider()

    # ── Key Stats Panel ───────────────────────────────────────────────────────
    ks = cfg.get("key_stats",{})
    key_cols_cfg   = ks.get("key_cols",[])
    composite_cfg  = ks.get("composite_keys",[])
    all_cols       = list(df.columns) if len(df) else []

    _sec("🔑 Key Column Statistics")
    # UI selector: user can add/change key cols interactively too
    ui_key_cols = st.multiselect(
        "Select key column(s) to analyse (pre-filled from config)",
        options=all_cols, default=[c for c in key_cols_cfg if c in all_cols],
        key="ov_key_sel"
    )

    if ui_key_cols and len(df):
        kcols = st.columns(min(len(ui_key_cols), 4))
        for i, col in enumerate(ui_key_cols[:4]):
            total  = len(df)
            unique = int(df[col].nunique())
            dups   = total - unique
            dup_pct= round(dups/total*100, 2) if total else 0
            with kcols[i]:
                st.metric(f"{col} — Count",  f"{total:,}")
                st.metric(f"{col} — Unique", f"{unique:,}")
                if dups > 0:
                    _alert(f"⚠️ {dups:,} duplicates ({dup_pct:.1f}%)", "yellow")
                else:
                    _alert(f"✅ All unique", "green")

    # ── Composite key builder ─────────────────────────────────────────────────
    st.markdown("**Composite Key Builder**")
    st.caption("Select multiple columns to concatenate and test as a composite key")
    comp_sel = st.multiselect("Select columns for composite key",
                               options=all_cols,
                               default=[c for c in (composite_cfg[0] if composite_cfg else []) if c in all_cols],
                               key="ov_comp_sel")
    if comp_sel and len(df) >= 2:
        composite = df[comp_sel].astype(str).agg("_".join, axis=1)
        total  = len(composite)
        unique = int(composite.nunique())
        dups   = total - unique
        dup_pct= round(dups/total*100, 2)
        c1,c2,c3 = st.columns(3)
        c1.metric("Composite rows",   f"{total:,}")
        c2.metric("Unique combos",    f"{unique:,}")
        c3.metric("Duplicates",       f"{dups:,}")
        if dups == 0:
            _alert(f"✅ <b>{'_'.join(comp_sel)}</b> is a perfect unique key", "green")
        else:
            _alert(f"⚠️ <b>{'_'.join(comp_sel)}</b> has {dups:,} duplicate combinations ({dup_pct:.1f}%)", "yellow")
            # show top dupes
            dup_df = (composite[composite.duplicated(keep=False)]
                      .value_counts().head(10).reset_index())
            dup_df.columns = ["Composite Key Value","Count"]
            with st.expander("Top duplicate values"):
                st.dataframe(dup_df, use_container_width=True, height=200)

    st.divider()

    # ── Type donut + Missing bar ──────────────────────────────────────────────
    left, right = st.columns(2)
    with left:
        _sec("Column Type Distribution")
        tc = pd.Series(dm).value_counts().reset_index()
        tc.columns = ["Type","Count"]
        colors = {"Numeric":ACCENT,"Categorical":CYAN,"Boolean":ORANGE,
                  "Date":"#10b981","ID-like":"#94a3b8","Unknown":"#e5e7ef","Constant":RED}
        fig = px.pie(tc, names="Type", values="Count", hole=0.55,
                     color="Type", color_discrete_map=colors)
        fig.update_traces(textposition="inside", textinfo="percent+label", textfont_size=11)
        _chart(fig, h=290); fig.update_layout(showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    with right:
        _sec("Missing Value Overview")
        miss_data = [(col, res["missing_pct"]) for col,res in cr.items() if res["missing_pct"]>0]
        if miss_data:
            mdf = pd.DataFrame(miss_data, columns=["Feature","Missing %"]).sort_values("Missing %")
            bar_colors = [RED if v>=30 else ORANGE if v>=10 else ACCENT for v in mdf["Missing %"]]
            fig2 = go.Figure(go.Bar(
                x=mdf["Missing %"], y=mdf["Feature"], orientation="h",
                marker_color=bar_colors,
                text=mdf["Missing %"].apply(lambda v: f"{v:.1f}%"),
                textposition="inside", textfont_color="white", textfont_size=9))
            _chart(fig2, h=290)
            fig2.update_layout(
                xaxis=dict(range=[0, 100], title="Missing %",
                           tickvals=[0,25,50,75,100], ticktext=["0%","25%","50%","75%","100%"]),
                yaxis_title="")
            st.plotly_chart(fig2, use_container_width=True)
        else:
            st.success("✅ No missing values")

    st.divider()

    # ── Feature table ─────────────────────────────────────────────────────────
    _sec("All Features at a Glance")
    rows = []
    for col, res in cr.items():
        dtype = res["dtype"]; dist = res.get("dist",{}); sk = res.get("skewness"); inf_p = res.get("inf_pct",0.0)
        rows.append({
            "Feature":    col, "Type": dtype,
            "Missing %":  res["missing_pct"], "Hit Rate %": res["hit_rate_pct"],
            "Unique":     res["n_unique"],
            "Mean / Top": (f"{dist['mean']:.4g}" if dist and dtype=="Numeric"
                           else (str(res.get("category_table",pd.DataFrame()).iloc[0]["Category"])[:20]
                                 if dtype=="Categorical" and len(res.get("category_table",pd.DataFrame()))
                                 else res.get("constant_value","—") if dtype=="Constant" else "—")),
            "Skewness":   round(sk,3) if sk is not None else "—",
            "Zero %":     res.get("zero_pct",0), "Inf %": round(inf_p,2),
        })
    feat_df = pd.DataFrame(rows)
    st.dataframe(feat_df, use_container_width=True, height=400,
                 column_config={
                     "Missing %":  st.column_config.ProgressColumn("Missing %",  min_value=0, max_value=100),
                     "Hit Rate %": st.column_config.ProgressColumn("Hit Rate %", min_value=0, max_value=100),
                     "Zero %":     st.column_config.ProgressColumn("Zero %",     min_value=0, max_value=100),
                     "Inf %":      st.column_config.NumberColumn("Inf %",     format="%.2f"),
                     "Skewness":   st.column_config.NumberColumn("Skewness",  format="%.3f"),
                 })
    _dl(feat_df, "Feature Overview CSV", "feature_overview.csv")

    det = R.get("grouped_report", pd.DataFrame())
    if len(det):
        st.divider(); _sec(f"Grouped Report — by {cfg.get('groupby_col','')}")
        _df(det); _dl(det, "Grouped Report CSV", "grouped_report.csv")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — VARIABLE EXPLORER
# ══════════════════════════════════════════════════════════════════════════════

def tab_variable_explorer(R):
    cr = R.get("col_results",{})
    if not cr: st.info("No features analysed."); return
    target = R.get("target_col")

    col_l, _ = st.columns([1,3])
    with col_l:
        # Use session_state key so Streamlit only rerenders THIS tab, not the whole app
        selected = st.selectbox(
            "Variable", list(cr.keys()),
            label_visibility="collapsed",
            key="vex_selected",
        )
    if not selected: return

    res = cr[selected]; dtype = res["dtype"]; dist = res.get("dist",{}); inf_p = res.get("inf_pct",0.0)
    st.divider()

    # ── NUMERIC ───────────────────────────────────────────────────────────────
    if dtype in ("Numeric","Boolean"):
        c1,c2,c3,c4,c5,c6,c7,c8 = st.columns(8)
        c1.metric("Mean",      f"{dist.get('mean',0):.4g}"    if dist else "—")
        c2.metric("Median",    f"{dist.get('median',0):.4g}"  if dist else "—")
        c3.metric("Std",       f"{dist.get('std',0):.4g}"     if dist else "—")
        c4.metric("Min",       f"{dist.get('min',0):.4g}"     if dist else "—")
        c5.metric("Max",       f"{dist.get('max',0):.4g}"     if dist else "—")
        c6.metric("Skewness",  f"{dist.get('skewness',0):.2f}" if dist else "—")
        c7.metric("Missing %", f"{res['missing_pct']:.1f}%")
        c8.metric("Zero %",    f"{res.get('zero_pct',0):.1f}%")
        sk = dist.get("skewness",0) if dist else 0
        if inf_p>0: _alert(f"🔴 {inf_p:.2f}% Inf values detected and excluded from stats","red")
        if abs(sk)>2: _alert(f"⚠️ Very high skewness ({sk:.2f}) — consider log1p transform","red")
        elif abs(sk)>1: _alert(f"⚠️ High skewness ({sk:.2f})","yellow")
        if res["missing_pct"]>20: _alert(f"⚠️ Sparse — {res['missing_pct']:.1f}% missing","red")
        elif res["missing_pct"]>5: _alert(f"ℹ️ {res['missing_pct']:.1f}% missing","yellow")
        if res.get("zero_inflated"): _alert("ℹ️ Zero-inflated: >30% zeros — consider two-part model","blue")
        if dist: st.caption(f"Shape: **{dist.get('shape','—')}**  ·  P25={dist.get('p25','—')}  P75={dist.get('p75','—')}  P95={dist.get('p95','—')}  P99={dist.get('p99','—')}")
        sample = res.get("plot_sample",[])
        if sample:
            scl = st.radio("Y-axis scale",["Linear","Log"],horizontal=True,key="vex_yscale")
            arr = np.array(sample); fig = go.Figure()
            fig.add_trace(go.Histogram(x=arr, nbinsx=60, name="Distribution",
                          marker_color=ACCENT, opacity=0.85, marker_line=dict(width=0.3,color="#fff")))
            if dist:
                fig.add_vline(x=dist["mean"],  line_dash="dash", line_color=ORANGE, annotation_text="Mean",   annotation_font_size=10)
                fig.add_vline(x=dist["median"],line_dash="dot",  line_color=GREEN,  annotation_text="Median", annotation_font_size=10)
            if scl=="Log": fig.update_yaxes(type="log")
            _chart(fig); fig.update_layout(title=dict(text=f"Distribution — {selected}",font_size=13),
                                            xaxis_title=selected, yaxis_title="Count", bargap=0.02)
            st.plotly_chart(fig, use_container_width=True)

    # ── CATEGORICAL ───────────────────────────────────────────────────────────
    elif dtype=="Categorical":
        nu = res["n_unique"]; rare = res.get("rare_count",0)
        c1,c2,c3 = st.columns(3)
        c1.metric("Unique",     nu); c2.metric("Rare (<1%)", rare); c3.metric("Missing %",f"{res['missing_pct']:.1f}%")
        if nu>100: _alert(f"⚠️ High cardinality — {nu} unique. Fuzzy matching skipped.","yellow")
        if rare>5: _alert(f"⚠️ {rare} rare categories","yellow")
        if res["missing_pct"]>10: _alert(f"⚠️ {res['missing_pct']:.1f}% missing","red")
        tbl = res.get("category_table", pd.DataFrame())
        if len(tbl):
            scl = st.radio("Y-axis scale",["Linear","Log"],horizontal=True,key="vex_cat_scale")
            bar_colors = [RED if f=="RARE" else CYAN if f=="DOMINANT" else ACCENT for f in tbl.head(25)["Flag"]]
            fig = go.Figure(go.Bar(x=tbl.head(25)["Category"], y=tbl.head(25)["Share %"],
                                   marker_color=bar_colors, text=tbl.head(25)["Count"],
                                   textposition="outside", textfont_size=9))
            if scl=="Log": fig.update_yaxes(type="log")
            _chart(fig); fig.update_layout(title=dict(text=f"Top Categories — {selected}",font_size=13),
                                            xaxis_title="", yaxis_title="Share %", bargap=0.15)
            fig.update_xaxes(tickangle=35); st.plotly_chart(fig, use_container_width=True)
            with st.expander("Full category table"): st.dataframe(tbl, use_container_width=True, height=240)

    elif dtype == "ID-like":
        nu = res["n_unique"]
        c1, c2, c3 = st.columns(3)
        c1.metric("Unique Values", f"{nu:,}")
        c2.metric("Missing %", f"{res['missing_pct']:.1f}%")
        c3.metric("Hit Rate %", f"{res['hit_rate_pct']:.1f}%")
        _alert("🔑 Identifier column — excluded from correlation and statistical analysis.", "blue")
        samples = res.get("sample_values", [])
        if samples:
            st.caption(f"**Sample values:** {', '.join(str(s) for s in samples)}")

    elif dtype == "Date":
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Min Date",   res.get("date_min", "—"))
        c2.metric("Max Date",   res.get("date_max", "—"))
        c3.metric("Unique",     f"{res['n_unique']:,}")
        c4.metric("Missing %",  f"{res['missing_pct']:.1f}%")
        year_counts = res.get("year_counts", {})
        month_counts = res.get("month_counts", {})
    elif dtype=="Constant":
        _alert(f"🔒 Constant column — value: <b>{res.get('constant_value','?')}</b>. Zero variance. Drop before modelling.","red")
        st.metric("Value", res.get("constant_value","?"))
    else:
        st.metric("Missing %", f"{res['missing_pct']:.1f}%"); st.info(f"Type: **{dtype}**")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — HIT RATE
# ══════════════════════════════════════════════════════════════════════════════

def tab_hit_rate(R):
    cr = R.get("col_results",{}); target = R.get("target_col")
    if not cr: st.info("No data."); return

    rows = [{"Feature":col,"Hit Rate %":res["hit_rate_pct"],"Missing %":res["missing_pct"],"Type":res["dtype"]}
            for col,res in cr.items()]
    if target and target in R.get("df",pd.DataFrame()).columns:
        df = R["df"]; t_miss = round(df[target].isna().mean()*100,1); t_hr = round(100-t_miss,1)
        rows.insert(0, {"Feature":f"🎯 {target} (target)","Hit Rate %":t_hr,"Missing %":t_miss,"Type":"Target"})

    df_hr = pd.DataFrame(rows).sort_values("Hit Rate %", ascending=True)
    colors = [PURPLE if "target" in str(r).lower() else
              GREEN if h>=95 else ORANGE if h>=75 else RED
              for h,r in zip(df_hr["Hit Rate %"], df_hr["Feature"])]

    fig = go.Figure(go.Bar(x=df_hr["Hit Rate %"], y=df_hr["Feature"], orientation="h",
                            marker_color=colors,
                            text=df_hr["Hit Rate %"].apply(lambda v:f"{v:.1f}%"),
                            textposition="inside", textfont_size=9,
                            textfont_color="white"))
    _chart(fig, h=max(350, len(df_hr)*22))
    fig.update_layout(title=dict(text="Hit Rate per Feature (% non-null)",font_size=13),
                      xaxis=dict(range=[0, 100], title="Hit Rate %",
                                 tickvals=[0,25,50,75,100], ticktext=["0%","25%","50%","75%","100%"]),
                      yaxis_title="")
    st.plotly_chart(fig, use_container_width=True)
    st.markdown('<span class="pill pill-green">● ≥95% Good</span>'
                '<span class="pill pill-yellow">● 75–94% Review</span>'
                '<span class="pill pill-red">● <75% Problem</span>'
                '<span class="pill pill-purple">● Target col</span>', unsafe_allow_html=True)
    st.divider(); _sec("Hit Rate Table")
    st.dataframe(df_hr.sort_values("Hit Rate %").reset_index(drop=True), use_container_width=True, height=300,
                 column_config={
                     "Hit Rate %": st.column_config.ProgressColumn("Hit Rate %", min_value=0, max_value=100),
                     "Missing %":  st.column_config.ProgressColumn("Missing %",  min_value=0, max_value=100),
                 })
    _dl(df_hr, "Hit Rate CSV", "hit_rate.csv")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — CATEGORY QUALITY
# ══════════════════════════════════════════════════════════════════════════════

def tab_category_quality(R):
    fuzzy = R.get("fuzzy_categories",{}); cr = R.get("col_results",{})
    cat_cols = [c for c,r in cr.items() if r["dtype"]=="Categorical"]
    if not cat_cols: st.info("No categorical columns."); return

    with_matches = {c:v for c,v in fuzzy.items() if isinstance(v,list) and len(v)>0}
    skipped      = {c for c,v in fuzzy.items() if isinstance(v,list) and len(v)==0}
    c1,c2,c3 = st.columns(3)
    c1.metric("Cols with similar cats",  len(with_matches))
    c2.metric("Total similar pairs",     sum(len(v) for v in with_matches.values()))
    c3.metric("Skipped (high-card)",     len(skipped))

    st.divider(); _sec("Similar / Duplicate Category Pairs")
    if not with_matches:
        _alert("✅ No similar or duplicate categories detected.","green")
    else:
        for col, matches in with_matches.items():
            nu = cr[col].get("n_unique",0); rare = cr[col].get("rare_count",0)
            with st.expander(f"🏷️ **{col}** — {len(matches)} pair(s)  ({nu} cats, {rare} rare)", expanded=True):
                mdf = pd.DataFrame(matches)
                def _sc(val):
                    if val==1.0: return "background-color:#fee2e2; color:#991b1b; font-weight:700"
                    if val>=0.95: return "background-color:#fef9c3"
                    return ""
                st.dataframe(mdf.style.map(_sc, subset=["Similarity"]),
                             use_container_width=True, height=min(300,40+len(mdf)*38))
    if skipped:
        with st.expander(f"ℹ️ {len(skipped)} high-cardinality cols skipped"):
            for c in sorted(skipped): st.write(f"  • {c} ({cr[c].get('n_unique',0)} cats)")

    st.divider(); _sec("Rare Categories Explorer")
    sel = st.selectbox("Column", cat_cols, key="cq_sel")
    if sel:
        tbl = cr[sel].get("category_table",pd.DataFrame())
        rare_df = tbl[tbl["Flag"]=="RARE"] if len(tbl) else pd.DataFrame()
        dom_df  = tbl[tbl["Flag"]=="DOMINANT"] if len(tbl) else pd.DataFrame()
        ca,cb = st.columns(2)
        with ca:
            if len(rare_df): _alert(f"⚠️ {len(rare_df)} rare cats","yellow"); st.dataframe(rare_df, use_container_width=True, height=200)
            else: _alert(f"✅ No rare cats in <b>{sel}</b>","green")
        with cb:
            if len(dom_df): _alert(f"⚠️ Dominant category detected","yellow"); st.dataframe(dom_df, use_container_width=True, height=200)
            else: st.caption("No dominant category.")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — OUTLIERS
# ══════════════════════════════════════════════════════════════════════════════

def tab_outliers(R):
    cr = R.get("col_results",{})
    num_cols = [c for c,r in cr.items() if r["dtype"] in ("Numeric","Boolean") and r.get("plot_sample")]
    if not num_cols: st.info("No numeric columns with data."); return

    col_l,_ = st.columns([1,3])
    with col_l: selected = st.selectbox("Variable", num_cols, label_visibility="collapsed", key="ol_sel")
    if not selected: return

    res = cr[selected]; outl = res.get("outlier",{}); dist = res.get("dist",{}); inf_p = res.get("inf_pct",0.0)
    if inf_p>0: _alert(f"🔴 {inf_p:.2f}% Inf values excluded before stats","red")

    # FIX: use selected in key so sliders reset when column changes
    sl1,sl2 = st.columns(2)
    pct_lo = sl1.slider("Lower percentile cutoff", 0, 20, 5, key=f"ol_lo_{selected}")
    pct_hi = sl2.slider("Upper percentile cutoff", 80, 100, 95, key=f"ol_hi_{selected}")

    sample = np.array(res.get("plot_sample",[]))
    if len(sample)==0: st.warning("No sample data."); return

    lo_val  = float(np.percentile(sample, pct_lo))
    hi_val  = float(np.percentile(sample, pct_hi))
    n_out   = int(((sample<lo_val)|(sample>hi_val)).sum())
    out_pct = round(n_out/len(sample)*100, 2)

    c1,c2,c3,c4 = st.columns(4)
    c1.metric(f"P{pct_lo}",              f"{lo_val:.4g}")
    c2.metric(f"P{pct_hi}",              f"{hi_val:.4g}")
    c3.metric("Outside range (sample)", n_out)
    c4.metric("% outside",               f"{out_pct:.2f}%")

    if outl.get("note"): _alert(f"ℹ️ {outl['note']}","blue")
    if outl: st.caption(f"**IQR fences:** lo={outl.get('fence_lo','—')}  hi={outl.get('fence_hi','—')}  |  {outl.get('iqr_pct',0):.1f}% outside IQR")

    # Boxplot
    fig_box = go.Figure()
    fig_box.add_trace(go.Box(x=sample, name=selected, marker_color=ACCENT, boxmean="sd",
                              fillcolor="rgba(99,102,241,0.15)", line_color=ACCENT))
    fig_box.add_vline(x=lo_val, line_dash="dash", line_color=ORANGE, annotation_text=f"P{pct_lo}", annotation_font_size=10)
    fig_box.add_vline(x=hi_val, line_dash="dash", line_color=RED,    annotation_text=f"P{pct_hi}", annotation_font_size=10)
    _chart(fig_box, h=200); fig_box.update_layout(title=dict(text=f"Boxplot — {selected}",font_size=13))
    st.plotly_chart(fig_box, use_container_width=True)

    # Histogram with outlier zones — clip display range to P1–P99 to avoid squashing
    p1_disp  = float(np.percentile(sample, 1))
    p99_disp = float(np.percentile(sample, 99))
    x_pad    = (p99_disp - p1_disp) * 0.05
    x_lo_disp = p1_disp  - x_pad
    x_hi_disp = p99_disp + x_pad

    # Auto bin width: divide visible range into ~60 bins
    bin_w = (p99_disp - p1_disp) / 60 if p99_disp > p1_disp else None

    fig_h = go.Figure()
    fig_h.add_trace(go.Histogram(
        x=sample, xbins=dict(size=bin_w) if bin_w else {},
        marker_color=ACCENT, opacity=0.82,
        marker_line=dict(width=0.2, color="#fff")))
    # shade outlier zones only within visible range
    if lo_val > x_lo_disp:
        fig_h.add_vrect(x0=x_lo_disp, x1=lo_val, fillcolor=ORANGE, opacity=0.12, line_width=0,
                         annotation_text="Low tail", annotation_font_size=9, annotation_position="top left")
    if hi_val < x_hi_disp:
        fig_h.add_vrect(x0=hi_val, x1=x_hi_disp, fillcolor=RED, opacity=0.12, line_width=0,
                         annotation_text="High tail", annotation_font_size=9, annotation_position="top right")
    _chart(fig_h)
    fig_h.update_layout(
        title=dict(text=f"Distribution — {selected}  (display: P1–P99)", font_size=13),
        xaxis=dict(title=selected, range=[x_lo_disp, x_hi_disp]),
        yaxis_title="Count", bargap=0.02)
    st.plotly_chart(fig_h, use_container_width=True)
    if p1_disp > float(sample.min()) or p99_disp < float(sample.max()):
        st.caption(f"ℹ️ X-axis clipped to P1–P99 range [{p1_disp:.4g}, {p99_disp:.4g}] for readability. "
                   f"Full range: [{float(sample.min()):.4g}, {float(sample.max()):.4g}]")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 6 — CORRELATIONS
# ══════════════════════════════════════════════════════════════════════════════

def tab_correlations(R):
    corr = R.get("correlations", {}); cfg = R.get("config", {}); target = R.get("target_col")
    if not corr:
        _alert("Correlations section was disabled. Re-run with set_sections(correlations=True).", "yellow")
        return

    thresh = cfg.get("corr_threshold", 0.75)

    # ── number column config helpers ──────────────────────────────────────────
    def _r4(col):   return st.column_config.NumberColumn(col, format="%.4f")
    def _r3(col):   return st.column_config.NumberColumn(col, format="%.3f")
    def _r2(col):   return st.column_config.NumberColumn(col, format="%.2f")
    def _r6(col):   return st.column_config.NumberColumn(col, format="%.6f")
    def _int(col):  return st.column_config.NumberColumn(col, format="%d")

    # ── Section tabs ──────────────────────────────────────────────────────────
    sec1, sec2, sec3 = st.tabs([
        "🔢 Numeric — Pearson",
        "🏷️ Categorical — Chi-Square",
        "🎯 Target Correlation",
    ])

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 1 — NUMERIC PEARSON
    # ══════════════════════════════════════════════════════════════════════════
    with sec1:
        hm = corr.get("pearson", pd.DataFrame())
        total  = corr.get("total_rows", 0)
        sn     = corr.get("sample_size", total)
        n_vars = corr.get("n_vars", 0)

        with st.expander("ℹ️ About Pearson correlation", expanded=False):
            st.markdown("""
**Pearson r** measures the *linear* relationship between two numeric variables.
- Range: **−1 to +1** · |r| ≥ 0.7 = **strong** · 0.4–0.7 = **moderate** · < 0.4 = **weak**
- Sensitive to outliers. Best for normally distributed data.
- Target column is included so you can see each feature's linear relationship with your outcome.

**VIF (Variance Inflation Factor)** detects multicollinearity.
- VIF > 10 = severe (drop one feature) · 5–10 = moderate · < 5 = OK
            """)

        if len(hm) < 2:
            _alert("Need ≥ 2 numeric features to compute Pearson correlation.", "yellow")
        else:
            pct = round(sn / total * 100, 1) if total else 100
            st.caption(f"**{n_vars} numeric features** (all, no cap) · {sn:,} of {total:,} rows ({pct}%)"
                       + (" — sampled for speed" if corr.get("sampled") else ""))

            _sec("Pearson Correlation Heatmap  (all numeric features + target)")

            # ── Target-only bar chart shown FIRST so target is always visible ──
            if target and target in hm.columns:
                tc_quick = hm[target].drop(target, errors="ignore").dropna().sort_values(key=abs, ascending=True)
                if len(tc_quick):
                    bar_c = [PURPLE if abs(v) >= 0.5 else ACCENT if abs(v) >= 0.3
                             else GREEN if abs(v) >= 0.1 else CYAN for v in tc_quick]
                    fig_quick = go.Figure(go.Bar(
                        x=tc_quick.values, y=tc_quick.index.tolist(), orientation="h",
                        marker_color=bar_c,
                        text=[f"{v:+.3f}" for v in tc_quick.values],
                        textposition="auto", textfont_size=9,
                    ))
                    _chart(fig_quick, h=max(300, len(tc_quick) * 22))
                    fig_quick.update_layout(
                        title=dict(text=f"🎯 All features vs Target: {target}  (Pearson r)", font_size=13),
                        xaxis=dict(range=[-1, 1], title="Pearson r",
                                   zeroline=True, zerolinecolor="#374151", zerolinewidth=1.5),
                        yaxis_title="",
                    )
                    st.plotly_chart(fig_quick, use_container_width=True)
                    st.markdown(
                        '<span class="pill pill-purple">● |r|≥0.5 Strong</span>'
                        '<span class="pill pill-blue">● 0.3–0.5 Moderate</span>'
                        '<span class="pill pill-green">● 0.1–0.3 Weak</span>'
                        '<span class="pill" style="background:#e0f2fe;color:#0369a1">● <0.1 Negligible</span>',
                        unsafe_allow_html=True)
                    st.divider()

            # ── Full feature-vs-feature heatmap ───────────────────────────────
            st.caption("💡 Scroll right/left inside the chart if columns are cut off. "
                       "Use the Plotly toolbar (top-right of chart) to zoom and pan.")
            fig = px.imshow(hm, text_auto=".2f", aspect="auto",
                            color_continuous_scale="RdBu_r", zmin=-1, zmax=1)
            fig.update_layout(
                height=max(420, len(hm) * 38),
                margin=dict(l=10, r=10, t=20, b=10),
                paper_bgcolor=PLOT_BG,
                font=dict(family="Inter, sans-serif", size=9),
                coloraxis_colorbar=dict(thickness=12, len=0.7,
                                        tickvals=[-1,-0.5,0,0.5,1],
                                        ticktext=["-1","-0.5","0","0.5","1"]),
            )
            fig.update_traces(textfont_size=8)
            # Mark target axis labels with 🎯
            if target and target in hm.columns:
                xticks = ["🎯 " + c if c == target else c for c in hm.columns]
                yticks = ["🎯 " + c if c == target else c for c in hm.index]
                fig.update_xaxes(ticktext=xticks, tickvals=list(range(len(hm.columns))))
                fig.update_yaxes(ticktext=yticks, tickvals=list(range(len(hm.index))))
            st.plotly_chart(fig, use_container_width=True)

            # ── High-corr pairs ───────────────────────────────────────────────
            st.divider()
            _sec(f"⚠️ High Correlation Pairs  |r| ≥ {thresh}")
            hcp = corr.get("high_corr", [])
            if hcp:
                _alert("Highly correlated features → multicollinearity risk. Consider dropping one.", "yellow")
                hcp_df = pd.DataFrame(hcp).drop(columns=["Abs r"], errors="ignore")
                def _r_color(v):
                    try:
                        f = abs(float(v))
                        if f >= 0.9: return "background-color:#fee2e2;color:#991b1b;font-weight:700"
                        if f >= 0.75: return "background-color:#fef9c3;color:#a16207;font-weight:600"
                        return ""
                    except: return ""
                st.dataframe(
                    hcp_df.style.map(_r_color, subset=["Pearson r"]),
                    use_container_width=True,
                    column_config={"Pearson r": _r4("Pearson r")},
                )
                _dl(hcp_df, "High Corr Pairs CSV", "high_corr_pairs.csv")
            else:
                _alert(f"✅ No numeric feature pairs with |r| ≥ {thresh}", "green")

            # ── All pairs table ───────────────────────────────────────────────
            st.divider()
            _sec("All Numeric Pairs")
            pt = corr.get("pair_table", pd.DataFrame())
            if len(pt):
                _df(pt, height=300, extra_config={
                    "Pearson r": _r4("Pearson r"),
                    "Abs r":     _r4("Abs r"),
                })
                _dl(pt, "All Pairs CSV", "correlation_pairs.csv")

            # ── VIF ───────────────────────────────────────────────────────────
            st.divider()
            _sec("VIF — Variance Inflation Factor")
            vif = corr.get("vif", pd.DataFrame())
            if len(vif):
                st.caption("VIF > 10 = severe multicollinearity · 5–10 = moderate · < 5 = OK")
                def _vif_c(v):
                    try:
                        f = float(v)
                        if f > 10: return "background-color:#fee2e2;color:#991b1b;font-weight:700"
                        if f > 5:  return "background-color:#fef9c3;color:#a16207"
                        return "background-color:#dcfce7;color:#166534"
                    except: return ""
                st.dataframe(
                    vif.style.map(_vif_c, subset=["VIF"]),
                    use_container_width=True,
                    column_config={"VIF": st.column_config.NumberColumn("VIF", format="%.2f")},
                )
            else:
                st.info("VIF not computed (need ≥ 2 non-target numeric features).")

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 2 — CATEGORICAL CRAMÉR'S V
    # ══════════════════════════════════════════════════════════════════════════
    with sec2:
        chi_df = corr.get("cat_chi2", pd.DataFrame())
        skipped    = corr.get("chi_skipped", [])
        chi_cap    = corr.get("chi_max_cardinality", 10_000)
        total_rows = corr.get("total_rows", 0)

        with st.expander("ℹ️ About Cramér's V", expanded=False):
            st.markdown("""
**Cramér's V** measures association strength between two categorical variables.
- Ranges 0 to 1, independent of sample size.
- V ≥ 0.3 = **Strong** · 0.1–0.3 = **Moderate** · < 0.1 = **Weak**
- Computed on the **full dataset** (no sampling) using exact contingency tables.

**🎯** marks pairs involving the target variable.
            """)

        st.caption(
            f"Computed on full {total_rows:,} rows · "
            f"Columns with >{chi_cap:,} unique values skipped"
            + (f" · **{len(skipped)} column(s) skipped**" if skipped else "")
        )

        if not len(chi_df):
            _alert("No categorical column pairs found (need ≥ 2 categorical columns).", "yellow")
        else:
            n_strong = int((chi_df["Cramér's V"].fillna(0) >= 0.3).sum())
            n_mod    = int(((chi_df["Cramér's V"].fillna(0) >= 0.1) & (chi_df["Cramér's V"].fillna(0) < 0.3)).sum())
            n_target = int((chi_df["vs Target"] == "🎯").sum())
            c1,c2,c3,c4 = st.columns(4)
            c1.metric("Total pairs",      len(chi_df))
            c2.metric("Strong (V ≥ 0.3)", n_strong)
            c3.metric("Moderate",         n_mod)
            c4.metric("vs Target pairs",  n_target)

            st.divider()
            show_target = st.checkbox("Target pairs only", value=False, key="cv_tgt")
            disp = chi_df[chi_df["vs Target"] == "🎯"].copy() if show_target else chi_df.copy()

            _sec(f"Cramér's V  ({len(disp)} pairs)")

            def _cv_style(row):
                styles = [""] * len(row)
                idx = list(disp.columns)
                v = float(row.get("Cramér's V") or 0)
                cv_i = idx.index("Cramér's V") if "Cramér's V" in idx else -1
                st_i = idx.index("Strength")   if "Strength"   in idx else -1
                clr = ""
                if   v >= 0.3: clr = "background-color:#ede9fe;color:#5b21b6;font-weight:700"
                elif v >= 0.1: clr = "background-color:#dbeafe;color:#1e3a5f;font-weight:600"
                if cv_i >= 0: styles[cv_i] = clr
                if st_i >= 0: styles[st_i] = clr
                if "vs Target" in idx and row.get("vs Target") == "🎯":
                    styles[idx.index("vs Target")] = "background-color:#f5f3ff;font-weight:700"
                return styles

            st.dataframe(
                disp.reset_index(drop=True).style.apply(_cv_style, axis=1),
                use_container_width=True,
                height=min(600, 80 + len(disp) * 36),
                column_config={"Cramér's V": st.column_config.NumberColumn("Cramér's V", format="%.4f")},
            )
            _dl(disp, "Cramér's V CSV", "cramers_v.csv")

            # Cramér's V bar chart — top 20
            top = disp[disp["Cramér's V"].notna()].head(20).copy()
            if len(top):
                st.divider()
                _sec("Top Pairs by Cramér's V")
                top["pair"] = top["Variable A"] + "  ×  " + top["Variable B"]
                top = top.sort_values("Cramér's V", ascending=True)
                bar_c = [PURPLE if v >= 0.3 else ACCENT if v >= 0.1 else CYAN
                         for v in top["Cramér's V"]]
                fig_chi = go.Figure(go.Bar(
                    x=top["Cramér's V"], y=top["pair"], orientation="h",
                    marker_color=bar_c,
                    text=top.apply(lambda r: f"V={r[\"Cramér's V\"]:.4f}  {r['Significance']}", axis=1),
                    textposition="outside", textfont_size=9,
                ))
                _chart(fig_chi, h=max(300, len(top) * 26))
                fig_chi.update_layout(
                    title=dict(text="Categorical Association Strength (Cramér's V)", font_size=13),
                    xaxis=dict(range=[0, min(top["Cramér's V"].max() * 1.35, 1.05)], title="Cramér's V"),
                    yaxis_title="",
                )
                st.plotly_chart(fig_chi, use_container_width=True)
                st.markdown(
                    '<span class="pill pill-purple">● V≥0.3 Strong</span>'
                    '<span class="pill pill-blue">● 0.1–0.3 Moderate</span>'
                    '<span class="pill pill-blue" style="background:#e0f2fe;color:#0369a1">● <0.1 Weak</span>',
                    unsafe_allow_html=True,
                )

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 3 — TARGET CORRELATION
    # ══════════════════════════════════════════════════════════════════════════
    with sec3:
        if not target:
            _alert("No target column defined. Pass target_col= to inspect() or run_eda().", "yellow")
        else:
            st.caption(f"Target: **{target}** — association strength of every feature with your outcome.")

            # ── COMBINED SUMMARY TABLE (numeric + categorical together) ──────
            ts = corr.get("target_summary", pd.DataFrame())
            if len(ts):
                _sec(f"📋 All Features vs Target: {target}  (ranked by strength)")
                st.caption(
                    "Numeric features → **Pearson r** (linear correlation).  "
                    "Categorical features → **Cramér's V** (chi-square effect size).  "
                    "Both metrics range −1/0 to +1 — higher absolute value = stronger association."
                )

                def _ts_style(row):
                    styles = [""] * len(row)
                    idx    = list(ts.columns)
                    v      = abs(float(row.get("Value") or 0))
                    s      = row.get("Strength", "")
                    col_i  = idx.index("Value") if "Value" in idx else -1
                    str_i  = idx.index("Strength") if "Strength" in idx else -1
                    clr = ""
                    if   s == "Strong":     clr = "background-color:#ede9fe;color:#5b21b6;font-weight:700"
                    elif s == "Moderate":   clr = "background-color:#dbeafe;color:#1e3a5f;font-weight:600"
                    elif s == "Weak":       clr = "background-color:#dcfce7;color:#166534"
                    if col_i >= 0:  styles[col_i]  = clr
                    if str_i >= 0:  styles[str_i]  = clr
                    # Type badge colour
                    typ_i = idx.index("Type") if "Type" in idx else -1
                    if typ_i >= 0:
                        styles[typ_i] = ("background-color:#fef9c3;color:#78350f"
                                         if row.get("Type") == "Categorical"
                                         else "background-color:#e0f2fe;color:#0369a1")
                    return styles

                st.dataframe(
                    ts.style.apply(_ts_style, axis=1),
                    use_container_width=True,
                    height=min(600, 60 + len(ts) * 36),
                    column_config={
                        "Value": st.column_config.NumberColumn("Value", format="%.4f"),
                    },
                )
                _dl(ts, "All Features vs Target CSV", "target_summary.csv")

                # Combined bar chart
                ts_plot = ts.dropna(subset=["Value"]).copy()
                ts_plot = ts_plot.sort_values("Value", key=abs, ascending=True).tail(40)
                bar_c = []
                for _, row in ts_plot.iterrows():
                    v = abs(float(row["Value"]))
                    if row["Type"] == "Categorical":
                        bar_c.append(PURPLE if v >= 0.3 else ACCENT if v >= 0.1 else CYAN)
                    else:
                        bar_c.append("#7c3aed" if v >= 0.5 else ACCENT if v >= 0.3
                                     else GREEN if v >= 0.1 else CYAN)
                fig_ts = go.Figure(go.Bar(
                    x=ts_plot["Value"].abs(), y=ts_plot["Feature"], orientation="h",
                    marker_color=bar_c,
                    text=ts_plot.apply(
                        lambda r: f"{r['Metric']}: {abs(r['Value']):.4f}", axis=1),
                    textposition="auto", textfont_size=9,
                ))
                _chart(fig_ts, h=max(320, len(ts_plot) * 24))
                fig_ts.update_layout(
                    title=dict(text=f"Feature Association with {target}  (top 40, abs value)", font_size=12),
                    xaxis=dict(range=[0, 1.05], title="Association Strength (absolute)"),
                    yaxis_title="",
                )
                st.plotly_chart(fig_ts, use_container_width=True)
                st.markdown(
                    '<span class="pill pill-purple">● Strong</span>'
                    '<span class="pill pill-blue">● Moderate</span>'
                    '<span class="pill pill-green">● Weak</span>'
                    '<span class="pill" style="background:#e0f2fe;color:#0369a1">● Negligible</span>'
                    '&nbsp;&nbsp;'
                    '<span class="pill" style="background:#fef9c3;color:#78350f">🏷️ Categorical (Cramér\'s V)</span>'
                    '<span class="pill" style="background:#e0f2fe;color:#0369a1">🔢 Numeric (Pearson r)</span>',
                    unsafe_allow_html=True,
                )

            st.divider()

            # ── Numeric vs target detail ──────────────────────────────────────
            tc = corr.get("target_corr", pd.DataFrame())
            if len(tc):
                with st.expander(f"🔢 Numeric detail — Pearson r with {target}", expanded=False):
                    def _tc_color(val):
                        try:
                            v = abs(float(val))
                            if v >= 0.5: return "background-color:#ede9fe;color:#5b21b6;font-weight:700"
                            if v >= 0.3: return "background-color:#dbeafe;color:#1e3a5f;font-weight:600"
                            if v >= 0.1: return "background-color:#dcfce7;color:#166534"
                            return ""
                        except: return ""
                    st.dataframe(
                        tc.style.map(_tc_color, subset=["Pearson r"]),
                        use_container_width=True,
                        height=min(500, 60 + len(tc) * 36),
                        column_config={"Pearson r": st.column_config.NumberColumn("Pearson r", format="%.4f")},
                    )
                    _dl(tc, "Numeric–Target Correlation CSV", "target_correlation_numeric.csv")
            else:
                _alert(f"Target '{target}' is not numeric — no Pearson r available. "
                       "See chi-square results above.", "blue")

            # ── Categorical vs target detail ──────────────────────────────────
            chi_df = corr.get("cat_chi2", pd.DataFrame())
            if len(chi_df):
                tgt_chi = chi_df[chi_df["vs Target"] == "🎯"].copy()
                if len(tgt_chi):
                    with st.expander(f"🏷️ Categorical detail — Chi-Square / Cramér's V vs {target}",
                                     expanded=False):
                        def _tchi_style(row):
                            styles = [""] * len(row)
                            idx = list(tgt_chi.columns)
                            v = float(row.get("Cramér's V") or 0)
                            p = float(row.get("p-value")    or 1)
                            if "Cramér's V" in idx:
                                if v >= 0.3:   styles[idx.index("Cramér's V")] = "background-color:#ede9fe;color:#5b21b6;font-weight:700"
                                elif v >= 0.1: styles[idx.index("Cramér's V")] = "background-color:#dbeafe;color:#1e3a5f"
                            if "p-value" in idx:
                                if p < 0.001:  styles[idx.index("p-value")] = "background-color:#fee2e2;color:#991b1b;font-weight:700"
                                elif p < 0.05: styles[idx.index("p-value")] = "background-color:#fef9c3;color:#a16207"
                            return styles
                        st.dataframe(
                            tgt_chi.reset_index(drop=True).style.apply(_tchi_style, axis=1),
                            use_container_width=True,
                            height=min(420, 60 + len(tgt_chi) * 36),
                            column_config={
                                "Chi²":       st.column_config.NumberColumn("Chi²",       format="%.4f"),
                                "p-value":    st.column_config.NumberColumn("p-value",    format="%.6f"),
                                "Cramér's V": st.column_config.NumberColumn("Cramér's V", format="%.4f"),
                                "DoF":        _int("DoF"),
                            },
                        )
                        _dl(tgt_chi, "Categorical–Target Chi-Square CSV", "target_correlation_categorical.csv")

            # ── Skipped columns notice ────────────────────────────────────────
            skipped = corr.get("chi_skipped", [])
            chi_cap = corr.get("chi_max_cardinality", 10_000)
            if skipped:
                with st.expander(f"ℹ️ {len(skipped)} column(s) skipped in chi-square "
                                 f"(>{chi_cap:,} unique values)", expanded=False):
                    st.caption(
                        f"Columns with more than **{chi_cap:,}** unique values are skipped to prevent "
                        "enormous contingency tables that would slow computation significantly. "
                        "To change this threshold: `plan.set_corr_options(chi_max_cardinality=20_000)`"
                    )
                    _df(pd.DataFrame(skipped))


# ══════════════════════════════════════════════════════════════════════════════
# TAB 7 — TARGET ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════

def tab_target_analysis(R):
    target = R.get("target_col")
    ta     = R.get("target_analysis",{})

    if not target:
        _alert("No target column was defined. Set target_col in your config or plan.set('target_col', 'ColName').","yellow")
        return
    if not ta:
        _alert("Target analysis section was disabled or target_col not set. Re-run with target_analysis=True.","yellow")
        return

    df = R.get("df", pd.DataFrame())
    if target in (df.columns if len(df) else []):
        t_series = pd.to_numeric(df[target], errors="coerce")
        t_nu = int(t_series.dropna().nunique())
        t_flavour = ta[list(ta.keys())[0]].get("t_flavour","?") if ta else "?"

        c1,c2,c3 = st.columns(3)
        c1.metric("Target column",  target)
        c2.metric("Unique values",  t_nu)
        c3.metric("Flavour",        t_flavour.title())

        if t_nu<=2 and len(df):
            vc = df[target].value_counts()
            st.caption(f"Target distribution: {dict(vc.head(5))}")

    st.divider()

    # ── Summary ranking bar chart ─────────────────────────────────────────────
    rows = []
    for col, entry in ta.items():
        if entry.get("abs_stat",0) > 0:
            rows.append({"Feature":col, "Association":entry["abs_stat"],
                         "Label":entry["label"], "Method":entry["method"]})
    if not rows:
        _alert("No computable associations found (need ≥30 overlapping non-null rows per feature).","yellow")
        return

    rank_df = pd.DataFrame(rows).sort_values("Association", ascending=True)
    bar_colors = [PURPLE if v>=0.3 else ACCENT if v>=0.1 else CYAN for v in rank_df["Association"]]
    fig_rank = go.Figure(go.Bar(
        x=rank_df["Association"], y=rank_df["Feature"], orientation="h",
        marker_color=bar_colors,
        text=rank_df["Label"], textposition="outside", textfont_size=9,
    ))
    _chart(fig_rank, h=max(350, len(rank_df)*22))
    fig_rank.update_layout(
        title=dict(text=f"Feature Association with Target: {target}", font_size=13),
        xaxis=dict(range=[0, min(rank_df["Association"].max()*1.25, 1.05)], title="Association (|r| or Cramér's V)"),
        yaxis_title="",
    )
    st.plotly_chart(fig_rank, use_container_width=True)

    st.markdown(
        '<span class="pill pill-purple">● ≥0.3 Strong</span>'
        '<span class="pill pill-blue">● 0.1–0.3 Moderate</span>'
        '<span class="pill pill-blue" style="background:#e0f2fe;color:#0369a1">● <0.1 Weak</span>',
        unsafe_allow_html=True,
    )
    st.divider()

    # ── Per-feature detail ────────────────────────────────────────────────────
    _sec("Feature Detail")
    sel_feat = st.selectbox("Select feature", rank_df.sort_values("Association",ascending=False)["Feature"].tolist(), key="ta_sel")
    if sel_feat:
        entry = ta[sel_feat]
        c1,c2,c3 = st.columns(3)
        c1.metric("Method",      entry.get("method","—"))
        c2.metric("Association", entry.get("label","—"))
        c3.metric("p-value",     f"{entry['pvalue']:.4g}" if entry.get("pvalue") is not None else "—")

        if entry.get("bar_data") is not None:
            bd = entry["bar_data"]
            col_colors = [GREEN if v >= bd["Mean Target"].median() else RED for v in bd["Mean Target"]]
            fig_bar = go.Figure(go.Bar(
                x=bd["Category"], y=bd["Mean Target"],
                marker_color=col_colors,
                text=bd.apply(lambda r: f"{r['Mean Target']:.4f}\n(n={r['Count']:,})", axis=1),
                textposition="outside", textfont_size=9,
            ))
            _chart(fig_bar, h=300)
            fig_bar.update_layout(
                title=dict(text=f"Mean {target} by {sel_feat}", font_size=13),
                xaxis_title=sel_feat, yaxis_title=f"Mean {target}", bargap=0.15)
            fig_bar.update_xaxes(tickangle=35)
            st.plotly_chart(fig_bar, use_container_width=True)

        elif entry.get("scatter_x") is not None:
            fig_sc = go.Figure(go.Scatter(
                x=entry["scatter_x"], y=entry["scatter_y"], mode="markers",
                marker=dict(color=ACCENT, opacity=0.3, size=4),
            ))
            _chart(fig_sc, h=300)
            fig_sc.update_layout(title=dict(text=f"{sel_feat} vs {target}",font_size=13),
                                  xaxis_title=sel_feat, yaxis_title=target)
            st.plotly_chart(fig_sc, use_container_width=True)

    # ── Full table ────────────────────────────────────────────────────────────
    st.divider(); _sec("Full Association Table")
    tbl_rows = []
    for col, entry in ta.items():
        tbl_rows.append({"Feature":col, "Method":entry.get("method","—"),
                          "Stat":entry.get("stat"), "Association":entry.get("abs_stat",0),
                          "Label":entry.get("label","—")})
    tbl_df = pd.DataFrame(tbl_rows).sort_values("Association",ascending=False).reset_index(drop=True)

    def _asc_color(val):
        try:
            v = float(val)
            if v>=0.3: return "background-color:#ede9fe; color:#5b21b6; font-weight:700"
            if v>=0.1: return "background-color:#dbeafe; color:#1e3a5f"
            return ""
        except: return ""
    st.dataframe(tbl_df.style.map(_asc_color, subset=["Association"]),
                 use_container_width=True, height=400)
    _dl(tbl_df, "Target Association CSV", "target_analysis.csv")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 8 — DATA COMPARISON
# ══════════════════════════════════════════════════════════════════════════════

def _match_color(match_pct, is_total=False):
    """Return CSS background+text style based on Match %."""
    v = float(match_pct)
    bold = "font-weight:700;" if is_total else "font-weight:600;"
    if v >= 100:  return f"background-color:#dcfce7; color:#166534; {bold}"
    if v >= 95:   return f"background-color:#bbf7d0; color:#14532d; {bold}"
    if v >= 85:   return f"background-color:#fef9c3; color:#a16207; {bold}"
    if v >= 70:   return f"background-color:#fed7aa; color:#9a3412; {bold}"
    return              f"background-color:#fee2e2; color:#991b1b; {bold}"

def _diff_color(val):
    """Red if negative, green if positive, grey if zero."""
    try:
        v = float(val)
        if v > 0:  return "color:#166534; font-weight:600"
        if v < 0:  return "color:#b91c1c; font-weight:600"
        return "color:#6b7280"
    except: return ""

def _fmt(v):
    """Format a number nicely."""
    try:
        f = float(v)
        if abs(f) >= 1_000_000: return f"{f/1_000_000:.3f}M"
        if abs(f) >= 1_000:     return f"{f:,.2f}"
        return f"{f:.4g}"
    except: return str(v)


def tab_comparison(R):
    cmp = R.get("comparison", {})

    # ── No-data state ─────────────────────────────────────────────────────────
    if not cmp or not isinstance(cmp, dict) or not cmp.get("per_col_tables"):
        _alert("No comparison data configured. Set it up in your notebook before running:", "blue")
        st.code("""\
# Simple — same agg for all columns
plan.set_comparison(
    df          = df_renewals,
    label_a     = "New Business",
    label_b     = "Renewals",
    groupby_col = "Policy_Year",          # or list: ["Region","Policy_Year"]
    agg_cols    = ["Premium","Claim_Flag","Exposure"],
)

# Advanced — per-column aggregation
plan.set_comparison(
    df          = df_renewals,
    label_a     = "New Business",
    label_b     = "Renewals",
    groupby_col = "Policy_Year",
    agg_config  = {
        "Premium":       ["sum", "mean"],
        "Policy_Number": ["count", "nunique"],
        "Claim_Flag":    ["sum", "mean"],
        "Exposure":      ["sum"],
    },
)
results = run_eda(df_clean, plan)
""", language="python")
        return

    la  = cmp["label_a"]; lb = cmp["label_b"]
    ra  = cmp.get("rows_a", 0); rb = cmp.get("rows_b", 0)
    gb  = cmp.get("groupby_col", [])
    gb_str = ", ".join(gb) if isinstance(gb, list) else str(gb or "—")

    sum_a = cmp.get("summary_a", pd.DataFrame())
    sum_b = cmp.get("summary_b", pd.DataFrame())
    per_col = cmp.get("per_col_tables", {})

    # ── Header KPIs ───────────────────────────────────────────────────────────
    c1,c2,c3,c4 = st.columns(4)
    c1.metric(f"📁 {la} — Rows",  f"{ra:,}")
    c2.metric(f"📁 {lb} — Rows",  f"{rb:,}")
    c3.metric("Row Δ",            f"{rb-ra:+,}")
    c4.metric("Grouped by",       gb_str)

    st.divider()

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 1 & 2 — DF Summaries side by side
    # ══════════════════════════════════════════════════════════════════════════
    _sec("📋 Dataset Summaries")
    st.caption("Descriptive statistics for each configured column in both DataFrames.")

    col_sa, col_sb = st.columns(2)

    def _render_summary(df_sum, label, col_widget):
        with col_widget:
            st.markdown(f"**{label}**")
            if not len(df_sum):
                st.info("No summary data."); return
            # Style the summary table
            def _miss_color(v):
                try:
                    f = float(v)
                    if f >= 30: return "background-color:#fee2e2; color:#991b1b"
                    if f >= 10: return "background-color:#fef9c3; color:#a16207"
                    if f > 0:   return "background-color:#fffbeb; color:#78350f"
                    return "background-color:#dcfce7; color:#166534"
                except: return ""
            styled = df_sum.style.map(_miss_color, subset=["Missing %"])
            st.dataframe(styled, use_container_width=True,
                         height=min(500, 60 + len(df_sum) * 38),
                         column_config={
                             "Count":     st.column_config.NumberColumn("Count",     format="%d"),
                             "Missing %": st.column_config.NumberColumn("Missing %", format="%.2f"),
                             "Sum":       st.column_config.NumberColumn("Sum",       format="%.4f"),
                             "Mean":      st.column_config.NumberColumn("Mean",      format="%.4f"),
                             "Median":    st.column_config.NumberColumn("Median",    format="%.4f"),
                             "Min":       st.column_config.NumberColumn("Min",       format="%.4f"),
                             "Max":       st.column_config.NumberColumn("Max",       format="%.4f"),
                         })
            _dl(df_sum, f"{label} Summary CSV", f"{label.replace(' ','_')}_summary.csv")

    _render_summary(sum_a, la, col_sa)
    _render_summary(sum_b, lb, col_sb)

    st.divider()

    # ══════════════════════════════════════════════════════════════════════════
    # SECTION 3 — Comparison tables (one per column+function combo)
    # ══════════════════════════════════════════════════════════════════════════
    _sec("⚖️ Comparison by Group")
    st.caption(
        f"For each group value of **{gb_str}**, shows {la} value, {lb} value, "
        "Diff (A−B), Diff %, and Match %. "
        "🟢 100% match · 🟡 95–99% · 🟠 85–94% · 🔴 <85%  ·  **TOTAL row** = sum across all groups."
    )

    if not per_col:
        _alert("No grouped comparison tables — check that groupby_col exists in both DataFrames.", "yellow")
        return

    # Selector if multiple column+fn combos
    keys = list(per_col.keys())
    if len(keys) > 1:
        sel_key = st.selectbox(
            "Column / Aggregation",
            keys,
            format_func=lambda k: f"{per_col[k]['col']}  ({per_col[k]['fn']})",
            key="cmp_sel",
        )
    else:
        sel_key = keys[0]

    entry = per_col[sel_key]
    tbl   = entry["table"].copy()
    grp_label = entry["grp_label"]
    col_name  = entry["col"]
    fn_name   = entry["fn"]

    # ── Color-coded dataframe ──────────────────────────────────────────────
    is_total_mask = tbl[grp_label] == "TOTAL"

    def _style_row(row):
        styles = [""] * len(row)
        idx    = tbl.columns.tolist()
        is_tot = row[grp_label] == "TOTAL"
        bold   = "font-weight:700; " if is_tot else ""

        # Match % cell
        if "Match %" in idx:
            mp = row["Match %"]
            styles[idx.index("Match %")] = _match_color(mp, is_total=is_tot)

        # Diff (A−B) cell
        if "Diff (A−B)" in idx:
            d = row["Diff (A−B)"]
            styles[idx.index("Diff (A−B)")] = _diff_color(d) + ("; font-weight:700" if is_tot else "")

        # Diff % cell — same RAG as match but inverted
        if "Diff %" in idx:
            dp = abs(float(row["Diff %"])) if row["Diff %"] is not None else 0
            if dp == 0:   dc = f"background-color:#dcfce7; color:#166534; {bold}"
            elif dp < 5:  dc = f"background-color:#bbf7d0; color:#14532d; {bold}"
            elif dp < 15: dc = f"background-color:#fef9c3; color:#a16207; {bold}"
            elif dp < 30: dc = f"background-color:#fed7aa; color:#9a3412; {bold}"
            else:         dc = f"background-color:#fee2e2; color:#991b1b; {bold}"
            styles[idx.index("Diff %")] = dc

        # Total row — bold all cells
        if is_tot:
            styles = [s + " font-weight:700; border-top:2px solid #374151;" for s in styles]

        return styles

    styled_tbl = tbl.style.apply(_style_row, axis=1)

    # Format numeric columns
    num_cols = [la, lb, "Diff (A−B)"]
    for nc in num_cols:
        if nc in tbl.columns:
            styled_tbl = styled_tbl.format({nc: lambda v: _fmt(v)})
    if "Diff %" in tbl.columns:
        styled_tbl = styled_tbl.format({"Diff %": lambda v: f"{v:.2f}%"})
    if "Match %" in tbl.columns:
        styled_tbl = styled_tbl.format({"Match %": lambda v: f"{v:.1f}%"})

    st.dataframe(styled_tbl, use_container_width=True,
                 height=min(600, 80 + len(tbl) * 38),
                 column_config={
                     "Diff %":  st.column_config.TextColumn("Diff %"),
                     "Match %": st.column_config.TextColumn("Match %"),
                     la:        st.column_config.TextColumn(la),
                     lb:        st.column_config.TextColumn(lb),
                     "Diff (A−B)": st.column_config.TextColumn("Diff (A−B)"),
                 })
    _dl(tbl, f"{col_name} ({fn_name}) Comparison CSV",
        f"comparison_{col_name}_{fn_name}.csv")

    # ── Bar chart: A vs B per group (excl. TOTAL row) ─────────────────────
    plot_tbl = tbl[~is_total_mask].copy()
    if len(plot_tbl):
        st.divider()
        fig = go.Figure()
        fig.add_trace(go.Bar(
            name=la, x=plot_tbl[grp_label].astype(str), y=plot_tbl[la],
            marker_color=ACCENT,
            text=plot_tbl[la].apply(_fmt), textposition="outside", textfont_size=9,
        ))
        fig.add_trace(go.Bar(
            name=lb, x=plot_tbl[grp_label].astype(str), y=plot_tbl[lb],
            marker_color=CYAN,
            text=plot_tbl[lb].apply(_fmt), textposition="outside", textfont_size=9,
        ))
        _chart(fig, h=340)
        fig.update_layout(
            barmode="group",
            title=dict(text=f"{col_name} ({fn_name}) — {la} vs {lb} by {gb_str}", font_size=13),
            xaxis_title=gb_str, yaxis_title=f"{col_name} ({fn_name})", bargap=0.12,
        )
        st.plotly_chart(fig, use_container_width=True)

    # ── Match % chart ─────────────────────────────────────────────────────
    if len(plot_tbl) and "Match %" in plot_tbl.columns:
        bar_colors = []
        for v in plot_tbl["Match %"]:
            fv = float(v)
            if fv >= 100:   bar_colors.append(GREEN)
            elif fv >= 95:  bar_colors.append("#86efac")
            elif fv >= 85:  bar_colors.append(ORANGE)
            elif fv >= 70:  bar_colors.append("#f97316")
            else:           bar_colors.append(RED)

        fig_m = go.Figure(go.Bar(
            x=plot_tbl[grp_label].astype(str),
            y=plot_tbl["Match %"],
            marker_color=bar_colors,
            text=plot_tbl["Match %"].apply(lambda v: f"{v:.1f}%"),
            textposition="inside", textfont_color="white", textfont_size=10,
        ))
        _chart(fig_m, h=260)
        fig_m.add_hline(y=95, line_dash="dash", line_color=ORANGE,
                         annotation_text="95% threshold", annotation_font_size=9)
        fig_m.update_layout(
            title=dict(text=f"Match % by {gb_str}  ({col_name} {fn_name})", font_size=13),
            xaxis_title=gb_str,
            yaxis=dict(title="Match %", range=[0, 105]),
        )
        st.plotly_chart(fig_m, use_container_width=True)
        st.markdown(
            '<span class="pill pill-green">● 100% Exact match</span>'
            '<span class="pill pill-green" style="background:#bbf7d0;color:#14532d">● ≥95%</span>'
            '<span class="pill pill-yellow">● 85–94%</span>'
            '<span class="pill" style="background:#fed7aa;color:#9a3412">● 70–84%</span>'
            '<span class="pill pill-red">● <70%</span>',
            unsafe_allow_html=True,
        )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 9 — QUALITY SCORECARD
# ══════════════════════════════════════════════════════════════════════════════

def tab_quality(R):
    sc = R.get("scorecard", pd.DataFrame())
    if not len(sc):
        _alert("Scorecard section was disabled. Re-run with sections(scorecard=True).","yellow"); return

    n_fix = int((sc["Status"]=="❌ Fix First").sum())
    n_rev = int((sc["Status"]=="⚠️ Review").sum())
    n_ok  = int((sc["Status"]=="✅ Good").sum())
    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Total",      len(sc))
    c2.metric("🔴 Fix",     n_fix)
    c3.metric("🟡 Review",  n_rev)
    c4.metric("🟢 Good",    n_ok)

    st.divider(); _sec("Score Distribution")
    score_col = "Overall (0-100)"
    fig_h = go.Figure()
    fig_h.add_trace(go.Histogram(x=sc[score_col], xbins=dict(start=0,end=100,size=5),
                                  marker_color=[RED if x<55 else ORANGE if x<80 else GREEN for x in sc[score_col]],
                                  opacity=0.88))
    _chart(fig_h, h=200)
    fig_h.update_layout(xaxis=dict(title="Score (0–100)",range=[0,103]), yaxis_title="# Features", bargap=0.05,
                         shapes=[dict(type="line",x0=55,x1=55,y0=0,y1=1,yref="paper",
                                       line=dict(color=ORANGE,dash="dash",width=1.5)),
                                  dict(type="line",x0=80,x1=80,y0=0,y1=1,yref="paper",
                                       line=dict(color=GREEN,dash="dash",width=1.5))])
    st.plotly_chart(fig_h, use_container_width=True)
    st.markdown('<span class="pill pill-red">● <55 Fix</span>'
                '<span class="pill pill-yellow">● 55–79 Review</span>'
                '<span class="pill pill-green">● ≥80 Good</span>', unsafe_allow_html=True)

    st.divider(); _sec("Feature Scorecard")
    st.caption("Weights: Hit Rate 30% · Valid Values 20% · Skewness 15% · Cat Consistency 15% · Outliers 20%")
    filt = st.multiselect("Filter status",["❌ Fix First","⚠️ Review","✅ Good"],
                           default=["❌ Fix First","⚠️ Review","✅ Good"])
    df_show = sc[sc["Status"].isin(filt)] if filt else sc

    def _score_color(val):
        try:
            v = float(val)
            if v>=80: return "background-color:#dcfce7; color:#166534; font-weight:600"
            if v>=55: return "background-color:#fef9c3; color:#a16207; font-weight:600"
            return "background-color:#fee2e2; color:#991b1b; font-weight:700"
        except: return ""

    st.dataframe(df_show.style.map(_colour_status,subset=["Status"]).map(_score_color,subset=[score_col]),
                 use_container_width=True, height=460)
    _dl(sc, "Scorecard CSV", "scorecard.csv")

    recs = R.get("recommendations",[])
    if recs:
        st.divider(); _sec("Recommended Actions")
        pf = st.multiselect("Filter",["❌ Fix First","⚠️ Review","✅ Good"],default=["❌ Fix First","⚠️ Review"])
        filtered = [r for r in recs if r["Priority"] in pf]
        st.caption(f"Showing {len(filtered)} of {len(recs)} features")
        for rec in filtered:
            icon = "🔴" if "Fix" in rec["Priority"] else "🟡" if "Review" in rec["Priority"] else "🟢"
            with st.expander(f"{icon} **{rec['Feature']}**  ({rec['Type']})"):
                for finding,action in rec["Items"]:
                    a,b = st.columns(2)
                    a.markdown(f"**Finding:** {finding}")
                    b.markdown(f"**Action:** `{action}`")
        rows_flat = [{"Feature":r["Feature"],"Type":r["Type"],"Priority":r["Priority"],
                       "Finding":f,"Action":a} for r in recs for f,a in r["Items"]]
        if rows_flat: _dl(pd.DataFrame(rows_flat),"Recommendations CSV","recommendations.csv")
    else:
        _alert("✅ No significant issues found.","green")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    # Reset download button counter at the start of every render
    st.session_state["__dl_counts__"] = {}

    R = _R()
    if not R:
        st.warning("No EDA results loaded.")
        st.code("""\
from eda_toolkit import inspect, run_eda, launch_app

plan = inspect(df, target_col="Claim_Flag")
plan.fix(Policy_Year="Categorical")
plan.confirm()
df_clean = plan.apply_to_df()

# Optional config
plan.set_sections(correlations=True, category_quality=True,
                  scorecard=True, target_analysis=True)
plan.set_key_stats(key_cols=["Policy_Number"],
                   composite_keys=[["Policy_Number","Eff_Date"]])
plan.set_comparison(df=df2, label_a="NB", label_b="Renewals",
                    groupby_col="Region", agg_cols=["Premium","Claim_Flag"])

results = run_eda(df_clean, plan)
launch_app(results)
""", language="python")
        return

    _sidebar(R)

    def _tab_on(k): return st.session_state.get(f"tab_{k}", True)

    # Build dynamic tab list
    TAB_DEFS = [
        ("📋 Overview",           "overview",          True),
        ("🔬 Variable Explorer",  "variable_explorer", True),
        ("📊 Hit Rate",           "hit_rate",          True),
        ("🏷️ Category Quality",  "category_quality",  True),
        ("⚡ Outliers",           "outliers",          True),
        ("🔗 Correlations",       "correlations",      True),
        ("⚖️ Data Comparison",   "comparison",        True),
        ("🏆 Quality Scorecard",  "scorecard",         True),
    ]
    active = [(label, key, fn) for label,key,_ in TAB_DEFS
              for fn in [{"overview":tab_overview,"variable_explorer":tab_variable_explorer,
                           "hit_rate":tab_hit_rate,"category_quality":tab_category_quality,
                           "outliers":tab_outliers,"correlations":tab_correlations,
                           "comparison":tab_comparison,
                           "scorecard":tab_quality}.get(key)]
              if _tab_on(key) and fn]

    if not active:
        st.info("All tabs disabled. Enable some in the sidebar."); return

    tabs = st.tabs([label for label,_,_ in active])
    for tab, (label, key, fn) in zip(tabs, active):
        with tab: fn(R)


if __name__ == "__main__":
    main()
