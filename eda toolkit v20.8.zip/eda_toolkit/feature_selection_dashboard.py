# -*- coding: utf-8 -*-
"""
feature_selection_dashboard.py -- Insurance EDA Toolkit v5
Feature Selection Dashboard.

Key design decisions:
  - Exposure bars (gold)  on LEFT  axis y  -- always shown, fixed
  - Count bars   (navy)   on RIGHT axis y2 -- toggleable
  - Mean line    (gold)   on RIGHT axis y3 -- always shown, separate scale
  THREE axes so toggling count never distorts the mean line scale.

  Numerical binning: equal-exposure by default (1-30 bins slider).
  Bin x-axis uses range labels like [25.0, 34.2) not midpoints.
  Categories: paginated 30/page, angle labels when >8.

  run_target_analysis() is a standalone function -- can be called
  independently of run_eda().

Usage:
    from eda_toolkit import inspect, run_eda, generate_fs_report
    from eda_toolkit import run_target_analysis   # standalone

    # Option A: via run_eda (target analysis runs inside)
    plan.set_sections(target_analysis=True)
    plan.set_target_analysis(n_bins=[10,20], exposure_col="expo_amt", bin_by="amount")
    results = run_eda(df, plan)
    generate_fs_report(results, "feature_selection.html")

    # Option B: standalone (faster, skips all EDA sections)
    ta = run_target_analysis(
        df, target_col="frequency",
        exposure_col="expo_amt", bin_by="amount",
        n_bins=20,
    )
    generate_fs_report({"deep_target_analysis": ta, "target_col": "frequency",
                         "n_rows": len(df)},
                        "feature_selection.html")
"""
from __future__ import annotations
import json, time, webbrowser
from pathlib import Path
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")

PLOTLY_CDN = "https://cdn.plot.ly/plotly-2.35.0.min.js"


# ==============================================================
#  HELPERS
# ==============================================================
class _Enc(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, np.integer):  return int(o)
        if isinstance(o, np.floating): return float(o)
        if isinstance(o, np.ndarray):  return o.tolist()
        try:
            if pd.isna(o): return None
        except Exception:
            pass
        return super().default(o)

def _j(v):   return json.dumps(v, cls=_Enc, separators=(",", ":"))
def _esc(s): return (str(s).replace("&","&amp;").replace("<","&lt;")
                    .replace(">","&gt;").replace('"','&quot;').replace("'","&#39;"))
def _safe(v, d=6):
    try:
        f = float(v)
        return None if (np.isnan(f) or np.isinf(f)) else round(f, d)
    except Exception:
        return None


# ==============================================================
#  STANDALONE run_target_analysis()
# ==============================================================
def run_target_analysis(df: pd.DataFrame,
                         target_col: str,
                         exposure_col: str | None = None,
                         bin_by: str = "amount",
                         n_bins: int = 20,
                         dtype_map: dict | None = None) -> dict:
    """
    Run Target Analysis independently of run_eda().

    Parameters
    ----------
    df           : DataFrame (full, no sampling)
    target_col   : name of the target column (must be numeric or coercible)
    exposure_col : exposure column (required for equal-exposure binning)
    bin_by       : "amount" = equal SUM of exposure_col per bin (recommended)
                   "count"  = equal row count per bin
    n_bins       : number of bins for numeric features (1-30)
    dtype_map    : optional {col: type} dict; auto-detected if None

    Returns
    -------
    dict  compatible with generate_fs_report()

    Example
    -------
    from eda_toolkit import run_target_analysis, generate_fs_report

    ta = run_target_analysis(df, "frequency", exposure_col="expo_amt", n_bins=20)
    generate_fs_report(
        {"deep_target_analysis": ta, "target_col": "frequency", "n_rows": len(df)},
        output_path="feature_selection.html"
    )
    """
    from target_analysis_engine import (
        build_target_analysis, _edges_exposure_amount, _edges_equal
    )
    from eda_engine import detect_type

    if target_col not in df.columns:
        raise ValueError(f"target_col='{target_col}' not found in DataFrame")

    # Auto-detect dtypes if not provided
    if dtype_map is None:
        dtype_map = {}
        for col in df.columns:
            if col == target_col:
                continue
            try:
                dtype_map[col] = detect_type(df[col])
            except Exception:
                dtype_map[col] = "Unknown"

    # Build bin configs list: always pre-compute multiple for good slider coverage
    # Even if n_bins=20 is requested, we compute nearby configs too
    if n_bins <= 5:
        bins_list = [n_bins]
    elif n_bins <= 10:
        bins_list = [5, n_bins]
    else:
        # Always include [5,10,n_bins] plus a few steps up to 30
        core = sorted(set([5, 10, n_bins, min(n_bins+5, 30)]))
        bins_list = [b for b in [5, 10, 15, 20, 25, 30] if b <= n_bins+5] or core
        bins_list = sorted(set(bins_list + [n_bins]))

    bin_methods = ["exposure"] if exposure_col else ["equal"]

    return build_target_analysis(
        df           = df,
        dtype_map    = dtype_map,
        target       = target_col,
        n_bins_list  = [n_bins],
        bin_methods  = bin_methods,
        exposure_col = exposure_col,
        bin_by       = bin_by,
    )


# ==============================================================
#  ENGINE HELPERS  (used by both standalone and via run_eda)
# ==============================================================
def _compute_bins_on_demand(df, col, target, exposure_col, bin_by, n_bins):
    """
    Compute bins for a single numeric column on demand (for slider).
    Returns list of bin dicts.
    """
    from target_analysis_engine import _aggregate_numeric_bins
    method = "exposure" if exposure_col else "equal"
    return _aggregate_numeric_bins(
        df, col, target, n_bins,
        method=method,
        exposure_col=exposure_col,
        bin_by=bin_by,
    )


# ==============================================================
#  CSS
# ==============================================================
CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
:root{--bg:#EEF1F7;--surf:#fff;--bdr:#D4DCE8;--txt:#0D1B2E;--txt2:#4A5568;
      --txt3:#8A98AA;--acc:#C8922A;--acc-l:#FDF3E3;--navy:#002B5C;--navy2:#004A97;
      --r:10px;--sh:0 1px 4px rgba(0,43,92,.08);--sh2:0 4px 16px rgba(0,43,92,.14)}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--txt);
     font-size:14px;line-height:1.6;min-height:100vh}
.hdr{background:linear-gradient(135deg,var(--navy) 0%,var(--navy2) 100%);
     box-shadow:0 3px 16px rgba(0,43,92,.3);position:sticky;top:0;z-index:100}
.hdr-row{display:flex;align-items:center;gap:14px;padding:11px 26px}
.logo{background:var(--acc);color:#fff;font-size:12px;font-weight:800;
      padding:5px 10px;border-radius:7px;white-space:nowrap}
.hdr-title{color:#fff;font-size:16px;font-weight:700;letter-spacing:-.3px}
.hdr-sub{color:rgba(255,255,255,.5);font-size:11px;margin-top:1px}
.hdr-meta{margin-left:auto;display:flex;gap:16px;font-size:12px;color:rgba(255,255,255,.6)}
.hdr-meta strong{color:#fff}
.nav{background:var(--navy);border-top:1px solid rgba(255,255,255,.1);
     display:flex;padding:0 18px;overflow-x:auto}
.nav-btn{padding:10px 20px;font-size:13px;font-weight:500;cursor:pointer;border:none;
         background:none;color:rgba(255,255,255,.45);border-bottom:3px solid transparent;
         margin-bottom:-1px;font-family:inherit;transition:all .13s;white-space:nowrap}
.nav-btn:hover{color:rgba(255,255,255,.85)}
.nav-btn.on{color:#fff;border-bottom-color:var(--acc);font-weight:600}
.tab{display:none}.tab.on{display:block}
.page{max-width:1360px;margin:0 auto;padding:20px 24px 48px}
/* slim controls */
.ctrls{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;
       background:var(--surf);border:1px solid var(--bdr);border-left:4px solid var(--acc);
       border-radius:var(--r);padding:11px 16px;margin-bottom:16px;box-shadow:var(--sh)}
.cg{display:flex;flex-direction:column;gap:4px}
.cl{font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--txt2)}
.br{display:flex;gap:3px;flex-wrap:wrap}
.cb{padding:5px 11px;border:1px solid var(--bdr);border-radius:6px;font-size:.79rem;
    font-weight:500;cursor:pointer;background:var(--surf);color:var(--txt2);
    font-family:inherit;transition:all .11s;white-space:nowrap}
.cb:hover{border-color:var(--navy2);color:var(--navy2)}
.cb.on{background:var(--navy);color:#fff;border-color:var(--navy);font-weight:600}
.tg{display:flex;align-items:center;gap:5px;font-size:.80rem;cursor:pointer;
    padding:5px 10px;border:1px solid var(--bdr);border-radius:6px;background:var(--surf);
    transition:all .11s;user-select:none;white-space:nowrap}
.tg input{accent-color:var(--acc);width:13px;height:13px}
.tg:hover{border-color:var(--acc);background:var(--acc-l)}
.csep{width:1px;background:var(--bdr);align-self:stretch;margin:0 2px}
/* feature row */
.fr{display:flex;flex-wrap:wrap;gap:8px;align-items:center;background:var(--surf);
    border:1px solid var(--bdr);border-left:4px solid var(--navy2);border-radius:var(--r);
    padding:9px 14px;margin-bottom:12px;box-shadow:var(--sh)}
.fl{font-size:.82rem;font-weight:700;color:var(--navy);white-space:nowrap}
.fs{padding:7px 10px;border:1px solid var(--bdr);border-radius:6px;font-size:.86rem;
    font-family:inherit;background:var(--surf);color:var(--txt);
    min-width:180px;flex:1;max-width:420px;outline:none}
.fs:focus{border-color:var(--navy2)}
.bl{font-size:.82rem;color:var(--navy);font-weight:700;min-width:44px}
.rng{accent-color:var(--acc);cursor:pointer;width:110px}
/* chart */
.cw{background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);
    margin:10px 0;overflow:hidden;position:relative;box-shadow:var(--sh)}
.cl2{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
     gap:10px;background:var(--surf);z-index:2;font-size:.82rem;color:var(--txt2);
     transition:opacity .3s}
.cl2.done{opacity:0;pointer-events:none}
.sp{width:20px;height:20px;border:2.5px solid var(--bdr);border-top-color:var(--acc);
    border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.cd{width:100%;min-height:360px}
/* legend */
.leg{display:flex;flex-wrap:wrap;gap:12px;align-items:center;padding:6px 12px;
     background:#f5f8ff;border-radius:6px;border:1px solid var(--bdr);
     margin:7px 0 12px;font-size:.77rem;color:var(--txt2)}
.li{display:flex;align-items:center;gap:5px}
.ls{width:13px;height:13px;border-radius:3px;flex-shrink:0}
.lline{display:inline-block;width:22px;height:3px;background:#C8922A;
       vertical-align:middle;margin-right:4px;border-radius:2px}
/* stat grid */
.sg{display:grid;grid-template-columns:repeat(auto-fill,minmax(108px,1fr));gap:9px;margin:12px 0 18px}
.sc{background:var(--surf);border:1px solid var(--bdr);border-top:3px solid var(--acc);
    border-radius:var(--r);padding:.55rem .9rem .45rem;box-shadow:var(--sh)}
.sv{font-size:1.0rem;font-weight:700;color:var(--navy);line-height:1.2}
.sl{font-size:.66rem;color:var(--txt2);text-transform:uppercase;letter-spacing:.05em;margin-top:2px}
/* tables */
.tw{overflow-x:auto;margin:10px 0;border-radius:8px;box-shadow:var(--sh);border:1px solid var(--bdr)}
.dt{border-collapse:collapse;width:100%;font-size:.80rem;background:var(--surf)}
.dt th{background:#EEF3FA;padding:7px 10px;text-align:left;font-weight:600;font-size:.73rem;
       color:var(--navy2);border-bottom:2px solid var(--bdr);cursor:pointer;
       user-select:none;white-space:nowrap}
.dt th:hover{background:#E0E8F5}
.dt th.sa::after{content:" ^";color:var(--acc)}.dt th.sd::after{content:" v";color:var(--acc)}
.dt td{padding:6px 10px;border-bottom:1px solid #F0F4FA;vertical-align:middle}
.dt tr:last-child td{border-bottom:none}.dt tbody tr:hover td{background:#F5F8FF}
.tc{display:flex;align-items:center;gap:8px;margin:5px 0 10px}
.dl{display:inline-flex;align-items:center;gap:4px;padding:5px 12px;background:var(--surf);
    border:1px solid var(--bdr);border-radius:6px;font-size:.77rem;font-weight:500;
    color:var(--txt2);text-decoration:none;transition:all .12s}
.dl:hover{background:var(--acc-l);color:var(--acc);border-color:var(--acc)}
.pgc{display:flex;align-items:center;gap:7px;margin:5px 0 10px;font-size:.80rem;color:var(--txt2)}
.pgb{padding:4px 11px;border:1px solid var(--bdr);border-radius:5px;font-size:.77rem;
     cursor:pointer;background:var(--surf);color:var(--navy2);transition:all .11s}
.pgb:hover:not(:disabled){background:var(--navy2);color:#fff;border-color:var(--navy2)}
.pgb:disabled{opacity:.38;cursor:not-allowed}
.pgi{font-weight:600;color:var(--navy)}
.sh{font-size:.9rem;font-weight:700;color:var(--navy);border-bottom:2px solid var(--acc);
    padding-bottom:3px;display:inline-block;margin:14px 0 8px}
.cap{font-size:.79rem;color:var(--txt2);margin:3px 0 7px}
.warn{padding:.45rem .85rem;border-radius:6px;font-size:.82rem;background:#fffbeb;
      color:#78350f;border-left:3px solid #f59e0b;margin:.3rem 0}
#fso{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:9999;
     align-items:center;justify-content:center}
#fso.on{display:flex}
#fsb{background:#fff;border-radius:12px;padding:8px;width:96vw;max-height:96vh;
     overflow:auto;position:relative}
#fsc{position:absolute;top:10px;right:12px;font-size:20px;cursor:pointer;
     color:#64748b;background:none;border:none;z-index:10}
#fsp{width:100%;height:82vh}
@media(max-width:760px){.hdr-meta{display:none}.page{padding:12px 10px 32px}}
"""


# ==============================================================
#  JavaScript
# ==============================================================
JS = r"""
// Feature Selection Dashboard -- fixed axis scaling
// THREE-AXIS CHART:
//   yaxis  (left)   = exposure bars  -- gold, always shown
//   yaxis2 (right)  = count bars     -- navy, toggleable
//   yaxis3 (right2) = mean line      -- gold, OWN scale, never distorted by count toggle
//
// X-AXIS: category strings (bin range labels) NOT midpoints
// BINS: slider 1-30, finds closest pre-computed config

var S={metric:'mean',logY:false,showCnt:true,catSort:'count',grpSmall:0,
       catPage:0,catPgSz:30,bins:20};
var ACT={type:null,col:null};
var FIGS={};

function F(v,d){
  if(v===null||v===undefined||v==='')return '-';
  var f=+v;if(isNaN(f))return '-';
  d=d!==undefined?d:4;
  if(Math.abs(f)>=1e9)return(f/1e9).toFixed(2)+'B';
  if(Math.abs(f)>=1e6)return(f/1e6).toFixed(2)+'M';
  if(Math.abs(f)>=1e3)return f.toLocaleString(undefined,{maximumFractionDigits:2});
  return f.toFixed(d);
}
function trunc(s,n){n=n||22;return(s&&s.length>n)?s.slice(0,n-1)+'...':(s||'');}

function showTab(id){
  document.querySelectorAll('.tab').forEach(function(p){p.classList.remove('on');});
  document.querySelectorAll('.nav-btn').forEach(function(b){b.classList.remove('on');});
  var pane=document.getElementById(id);
  var btn=document.querySelector('[data-tab="'+id+'"]');
  if(pane)pane.classList.add('on');
  if(btn)btn.classList.add('on');
  window.scrollTo({top:0,behavior:'smooth'});
  setTimeout(function(){
    if(id==='tab-u')renderUni();
    else if(id==='tab-c'&&ACT.col)renderCat(ACT.col);
    else if(id==='tab-n'&&ACT.col)renderNum(ACT.col);
  },80);
}

function setMetric(m){
  S.metric=m;
  document.querySelectorAll('.mb2').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-m')===m);});
  refresh();
}
function togLog(cb){S.logY=cb.checked;refresh();}
function togCnt(cb){S.showCnt=cb.checked;refresh();}
function setSort(s){
  S.catSort=s;S.catPage=0;
  document.querySelectorAll('.sb').forEach(function(b){b.classList.toggle('on',b.getAttribute('data-s')===s);});
  refresh();
}
function setGrp(v){
  S.grpSmall=+v;S.catPage=0;
  var el=document.getElementById('grp-lbl');
  if(el)el.textContent=v>0?'< '+v+'%':'Off';
  refresh();
}
function setBins(v){
  S.bins=+v;
  var el=document.getElementById('bins-v');
  if(el)el.textContent=v+' bins';
  if(ACT.type==='num')renderNum(ACT.col);
}
function refresh(){
  if(ACT.type==='cat')renderCat(ACT.col);
  else if(ACT.type==='num')renderNum(ACT.col);
  else if(ACT.type==='uni')renderUni();
}

function plot(id,traces,layout){
  var el=document.getElementById(id);
  if(!el||!window.Plotly)return;
  var wrap=el.closest('.cw');
  if(wrap){
    var ldr=wrap.querySelector('.cl2');
    if(ldr){ldr.style.opacity='0';setTimeout(function(){ldr.classList.add('done');},350);}
  }
  var cfg={responsive:true,displayModeBar:true,displaylogo:false,
           modeBarButtonsToRemove:['sendDataToCloud','lasso2d','select2d']};
  FIGS[id]={data:traces,layout:layout};
  try{
    if(el._p)Plotly.react(id,traces,layout,cfg);
    else{Plotly.newPlot(id,traces,layout,cfg);el._p=true;}
  }catch(e){console.warn('chart error',id,e);}
}

function openFS(id){
  var fig=FIGS[id];if(!fig||!window.Plotly)return;
  var ov=document.getElementById('fso'),pl=document.getElementById('fsp');
  if(!ov||!pl)return;
  var lay=JSON.parse(JSON.stringify(fig.layout||{}));
  lay.height=Math.floor(window.innerHeight*.83);lay.autosize=true;
  Plotly.newPlot(pl,fig.data,lay,{responsive:true,displayModeBar:true,displaylogo:false});
  ov.classList.add('on');
}
function closeFS(){
  var ov=document.getElementById('fso');if(ov)ov.classList.remove('on');
  var pl=document.getElementById('fsp');if(pl&&window.Plotly)Plotly.purge(pl);
}
document.addEventListener('click',function(e){if(e.target===document.getElementById('fso'))closeFS();});

document.addEventListener('click',function(e){
  var th=e.target.closest('th');if(!th)return;
  var tbl=th.closest('table.srt');if(!tbl)return;
  var idx=Array.from(th.parentNode.children).indexOf(th);
  var tbody=tbl.querySelector('tbody');
  var rows=Array.from(tbody.querySelectorAll('tr'));
  var asc=th.classList.contains('sa');
  tbl.querySelectorAll('th').forEach(function(h){h.classList.remove('sa','sd');});
  rows.sort(function(a,b){
    var av=a.cells[idx]?a.cells[idx].textContent.trim():'';
    var bv=b.cells[idx]?b.cells[idx].textContent.trim():'';
    var an=parseFloat(av.replace(/[,%MBk]/g,'')),bn=parseFloat(bv.replace(/[,%MBk]/g,''));
    if(!isNaN(an)&&!isNaN(bn))return asc?an-bn:bn-an;
    return asc?av.localeCompare(bv):bv.localeCompare(av);
  });
  rows.forEach(function(r){tbody.appendChild(r);});
  th.classList.add(asc?'sd':'sa');
});

// UNIVARIATE
function renderUni(){
  ACT.type='uni';
  var D=window.D_UNI;
  if(!D||!window.Plotly)return;
  var hist=S.logY?D.hist_log:D.hist_clip;
  if(!hist||!hist.counts||!hist.counts.length)return;
  var edges=hist.edges,counts=hist.counts,mids=[],labs=[];
  for(var i=0;i<counts.length;i++){
    var lo=+edges[i],hi=+edges[i+1];
    mids.push((lo+hi)/2);
    labs.push('['+lo.toPrecision(4)+', '+hi.toPrecision(4)+')');
  }
  plot('uni-ch',[{
    type:'bar',x:mids,y:counts,name:'Count',
    marker:{color:'rgba(0,43,92,0.65)',line:{color:'rgba(0,43,92,0.85)',width:0.4}},
    hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>',text:labs
  }],{
    title:{text:(window.D_TGT||'Target')+' -- Distribution'+(S.logY?' (log1p)':''),
           font:{size:14,color:'#0D1B2E'}},
    xaxis:{title:window.D_TGT||'Target',gridcolor:'#D4DCE8',zeroline:false},
    yaxis:{title:'Count',type:S.logY?'log':'linear',gridcolor:'#D4DCE8'},
    paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
    font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
    height:380,margin:{l:65,r:20,t:48,b:54},bargap:0.04
  });
  buildUniTbl();
}
function buildUniTbl(){
  var D=window.D_UNI;if(!D)return;
  var s=D.stats;
  var rows=[['Count',(s.count||0).toLocaleString()],
    ['Mean',F(s.mean)],['Median',F(s.median)],['Std Dev',F(s.std)],
    ['Min',F(s.min)],['Max',F(s.max)],
    ['P25',F(s.p25)],['P75',F(s.p75)],['P95',F(s.p95)],['P99',F(s.p99)],
    ['Skewness',F(s.skewness,3)],['Zero %',F(s.zero_pct,2)+'%']];
  var h='<div class="tw" style="max-width:360px"><table class="dt">'
    +'<thead><tr><th>Statistic</th><th style="text-align:right">Value</th></tr></thead><tbody>';
  rows.forEach(function(r){
    h+='<tr><td>'+r[0]+'</td><td style="text-align:right;font-weight:600;color:var(--navy)">'+r[1]+'</td></tr>';
  });
  var el=document.getElementById('uni-tbl');
  if(el)el.innerHTML=h+'</tbody></table></div>';
}

// THREE-AXIS CHART BUILDER (shared by cat and num)
// yaxis  = exposure bars (gold, left)   -- always
// yaxis2 = count bars    (navy, right)  -- toggleable, own scale
// yaxis3 = mean line     (gold, right2) -- OWN scale, never affected by count toggle
function build3Axis(id,xLabels,expos,cnts,mvals,expName,mLbl,titleText,h,bMgn,angle){
  var ec=expName||'';
  var hasE=!!(ec&&expos&&expos.length);
  var traces=[];

  if(hasE){
    traces.push({
      type:'bar',x:xLabels,y:expos,name:ec,yaxis:'y',
      marker:{color:'rgba(200,146,42,0.55)',line:{color:'rgba(200,146,42,0.80)',width:0.5}},
      hovertemplate:'<b>%{x}</b><br>'+ec+': %{y:,.2f}<extra></extra>',
    });
  }

  if(S.showCnt){
    traces.push({
      type:'bar',x:xLabels,y:cnts,name:'Count',yaxis:'y2',
      marker:{color:'rgba(0,43,92,0.38)',line:{color:'rgba(0,43,92,0.60)',width:0.5}},
      hovertemplate:'<b>%{x}</b><br>Count: %{y:,}<extra></extra>',
    });
  }

  traces.push({
    type:'scatter',mode:'lines+markers',x:xLabels,y:mvals,
    name:mLbl,yaxis:'y3',
    line:{color:'#C8922A',width:2.5},
    marker:{color:'#C8922A',size:8,symbol:'circle',line:{color:'#fff',width:1.5}},
    hovertemplate:'<b>%{x}</b><br>'+mLbl+': %{y:.6g}<extra></extra>',
  });

  var layout={
    title:{text:titleText,font:{size:14,color:'#0D1B2E'}},
    xaxis:{
      type:'category',
      tickangle:angle,
      tickfont:{size:10},
      gridcolor:'#D4DCE8',
      zeroline:false,
      automargin:true,
    },
    yaxis:{
      title:hasE?ec:'',
      side:'left',
      color:'rgba(200,146,42,0.85)',
      gridcolor:'rgba(200,146,42,0.12)',
      zeroline:false,
      showgrid:hasE,
      titlefont:{color:'rgba(200,146,42,0.9)',size:11},
      tickfont:{color:'rgba(200,146,42,0.9)'},
    },
    yaxis2:{
      title:S.showCnt?'Count':'',
      overlaying:'y',
      side:'right',
      showgrid:false,
      color:'rgba(0,43,92,0.65)',
      visible:S.showCnt,
      titlefont:{color:'rgba(0,43,92,0.65)',size:11},
      tickfont:{color:'rgba(0,43,92,0.65)'},
    },
    yaxis3:{
      title:mLbl,
      overlaying:'y',
      side:'right',
      showgrid:false,
      anchor:'free',
      position:1.0,
      color:'#C8922A',
      titlefont:{color:'#C8922A',size:10},
      tickfont:{color:'#C8922A',size:9},
    },
    paper_bgcolor:'rgba(0,0,0,0)',
    plot_bgcolor:'rgba(0,0,0,0)',
    font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
    height:h,
    margin:{l:75,r:130,t:48,b:bMgn},
    legend:{orientation:'h',x:0,y:-0.30,bgcolor:'rgba(0,0,0,0)',font:{size:11}},
    barmode:'group',
    bargap:0.22,
    bargroupgap:0.06,
  };

  plot(id,traces,layout);
}

// CATEGORICAL
function selCat(col){ACT={type:'cat',col:col};S.catPage=0;renderCat(col);}
function catPg(d){S.catPage=Math.max(0,S.catPage+d);renderCat(ACT.col);}

function renderCat(col){
  var all=window.D_CAT&&window.D_CAT[col];
  if(!all||!all.length||!window.Plotly)return;
  var m=S.metric;
  var ec=window.D_EC||'';
  var hasE=!!(ec&&all.length&&all[0].exposure_sum!==undefined);

  var data=all.slice();
  if(S.grpSmall>0){
    var kept=[],grp=[];
    data.forEach(function(r){(+r.pct<S.grpSmall?grp:kept).push(r);});
    if(grp.length){
      var n=grp.reduce(function(a,r){return a+(+r.count||0);},0);
      var ws=grp.reduce(function(a,r){return a+(+r.mean||0)*(+r.count||0);},0);
      var es=grp.reduce(function(a,r){return a+(+r.exposure_sum||0);},0);
      kept.push({category:'(Other)',count:n,
        pct:grp.reduce(function(a,r){return a+(+r.pct||0);},0),
        mean:n>0?ws/n:0,median:0,
        sum:grp.reduce(function(a,r){return a+(+r.sum||0);},0),
        exposure_sum:es,exposure_pct:grp.reduce(function(a,r){return a+(+r.exposure_pct||0);},0)});
    }
    data=kept;
  }

  if(S.catSort==='metric')data.sort(function(a,b){return(+b[m]||0)-(+a[m]||0);});
  else if(S.catSort==='alpha')data.sort(function(a,b){return a.category.localeCompare(b.category);});
  else data.sort(function(a,b){return(+b.count||0)-(+a.count||0);});

  var ps=S.catPgSz,tot=Math.max(1,Math.ceil(data.length/ps));
  S.catPage=Math.min(S.catPage,tot-1);
  var page=data.slice(S.catPage*ps,(S.catPage+1)*ps);

  var pgEl=document.getElementById('cat-pi');
  if(pgEl)pgEl.textContent=(S.catPage*ps+1)+'-'+Math.min((S.catPage+1)*ps,data.length)+' of '+data.length;
  var prevB=document.getElementById('cat-prev'),nextB=document.getElementById('cat-next');
  if(prevB)prevB.disabled=S.catPage===0;
  if(nextB)nextB.disabled=S.catPage>=tot-1;
  var pgw=document.getElementById('cat-pg');
  if(pgw)pgw.style.display=data.length>ps?'flex':'none';

  var n=page.length;
  var maxLen=n>15?13:n>8?17:22;
  var cats=page.map(function(r){return trunc(r.category,maxLen);});
  var expos=hasE?page.map(function(r){return+r.exposure_sum||0;}):[]; 
  var cnts=page.map(function(r){return+r.count||0;});
  var mvals=page.map(function(r){return+r[m]||0;});
  var mLbl=({mean:'Mean',median:'Median',sum:'Sum'}[m]||m)+' '+window.D_TGT;

  var angle=n>8?-45:(n>5?-30:0);
  var bMgn=n>12?145:n>7?105:65;
  var h=n>20?520:n>12?460:400;
  var title=col+' vs '+window.D_TGT+(tot>1?' (pg '+(S.catPage+1)+'/'+tot+')':'');

  build3Axis('cat-ch',cats,expos,cnts,mvals,ec,mLbl,title,h,bMgn,angle);
  catTbl(page,data,m,mLbl,hasE,ec,col);
}

function catTbl(page,all,m,mLbl,hasE,ec,col){
  var h='<tr><th>Category</th><th>Count</th><th>%</th>'
    +(hasE?'<th>'+ec+'</th><th>Exp%</th>':'')
    +'<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows=page.map(function(r){
    var it=r.category==='(Other)'?' style="font-style:italic;color:var(--txt2)"':'';
    return '<tr'+it+'><td style="font-weight:500;max-width:200px;word-break:break-word">'+r.category+'</td>'
      +'<td style="text-align:right">'+(+r.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+F(r.pct,1)+'%</td>'
      +(hasE?'<td style="text-align:right">'+F(r.exposure_sum,2)+'</td>'
            +'<td style="text-align:right">'+F(r.exposure_pct,1)+'%</td>':'')
      +'<td style="text-align:right;color:var(--acc);font-weight:700">'+F(r.mean,4)+'</td>'
      +'<td style="text-align:right">'+F(r.median,4)+'</td>'
      +'<td style="text-align:right">'+F(r.sum,2)+'</td></tr>';
  }).join('');
  var csvH='Category,Count,Pct'+(hasE?','+ec+',ExpPct':'')+',Mean,Median,Sum';
  var csv=csvH+'\n'+all.map(function(r){
    var b=['"'+r.category+'"',r.count,r.pct];
    if(hasE)b=b.concat([r.exposure_sum,r.exposure_pct]);
    return b.concat([r.mean,r.median,r.sum]).join(',');
  }).join('\n');
  var b64=btoa(unescape(encodeURIComponent(csv)));
  var tbl='<div class="tw"><table class="dt srt"><thead>'+h+'</thead><tbody>'+rows+'</tbody></table></div>'
    +'<div class="tc"><a class="dl" href="data:text/csv;base64,'+b64
    +'" download="'+(col||'cat')+'_vs_target.csv">DL Download CSV ('+all.length+' rows)</a></div>';
  var el=document.getElementById('cat-tbl');if(el)el.innerHTML=tbl;
}

// NUMERICAL -- x-axis bin range labels, finds closest pre-computed bins
function selNum(col){ACT={type:'num',col:col};renderNum(col);}

function renderNum(col){
  var all=window.D_NUM&&window.D_NUM[col];
  if(!all||!window.Plotly)return;

  var methData=null;
  if(window.D_EC){methData=all['exposure']||all['equal']||null;}
  if(!methData){var keys=Object.keys(all);if(keys.length)methData=all[keys[0]];}
  if(!methData){
    document.getElementById('num-ch').innerHTML='<p class="cap" style="padding:22px">No data.</p>';
    return;
  }

  var avail=Object.keys(methData).map(Number).sort(function(a,b){return a-b;});
  if(!avail.length)return;
  var closest=avail[0];
  avail.forEach(function(k){if(Math.abs(k-S.bins)<=Math.abs(closest-S.bins))closest=k;});
  var bins=methData[closest]||[];

  if(!bins||!bins.length){
    document.getElementById('num-ch').innerHTML='<p class="cap" style="padding:22px">No bins.</p>';
    return;
  }

  var m=S.metric;
  var ec=window.D_EC||'';
  var hasE=!!(ec&&bins.length&&bins[0].exposure_sum!==undefined);

  var labs=bins.map(function(b){return b.bin;});
  var expos=hasE?bins.map(function(b){return+b.exposure_sum||0;}):[]; 
  var cnts=bins.map(function(b){return+b.count||0;});
  var mvals=bins.map(function(b){return+b[m]||0;});
  var mLbl=({mean:'Mean',median:'Median',sum:'Sum'}[m]||m)+' '+window.D_TGT;

  var n=labs.length;
  var angle=n>12?-45:n>7?-30:0;
  var bMgn=n>12?125:n>7?85:60;
  var bNote=(window.D_EC&&window.D_BY==='amount')?' equal '+ec+'/bin':'';
  var closestNote=(closest!==S.bins)?' (closest to '+S.bins+')':'';
  var title=col+' vs '+window.D_TGT+' ['+closest+' bins'+bNote+']'+closestNote;

  build3Axis('num-ch',labs,expos,cnts,mvals,ec,mLbl,title,420,bMgn,angle);
  numTbl(bins,m,mLbl,hasE,ec,col,closest);
}

function numTbl(bins,m,mLbl,hasE,ec,col,nb){
  var h='<tr><th>Bin Range</th><th>Count</th><th>%</th>'
    +(hasE?'<th>'+ec+'</th><th>Exp%</th>':'')
    +'<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows=bins.map(function(b){
    return '<tr><td style="font-family:monospace;font-size:.77rem;white-space:nowrap">'+b.bin+'</td>'
      +'<td style="text-align:right">'+(+b.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+F(b.pct,1)+'%</td>'
      +(hasE?'<td style="text-align:right">'+F(b.exposure_sum,2)+'</td>'
            +'<td style="text-align:right">'+F(b.exposure_pct,1)+'%</td>':'')
      +'<td style="text-align:right;color:var(--acc);font-weight:700">'+F(b.mean,4)+'</td>'
      +'<td style="text-align:right">'+F(b.median,4)+'</td>'
      +'<td style="text-align:right">'+F(b.sum,2)+'</td></tr>';
  }).join('');
  var csvH='Bin,Bin_Lo,Bin_Hi,Count,Pct'+(hasE?','+ec+',ExpPct':'')+',Mean,Median,Sum';
  var csv=csvH+'\n'+bins.map(function(b){
    var base=['"'+b.bin+'"',b.bin_lo,b.bin_hi,b.count,b.pct];
    if(hasE)base=base.concat([b.exposure_sum,b.exposure_pct]);
    return base.concat([b.mean,b.median,b.sum]).join(',');
  }).join('\n');
  var b64=btoa(unescape(encodeURIComponent(csv)));
  var tbl='<div class="tw"><table class="dt srt"><thead>'+h+'</thead><tbody>'+rows+'</tbody></table></div>'
    +'<div class="tc"><a class="dl" href="data:text/csv;base64,'+b64
    +'" download="'+(col||'num')+'_binned.csv">DL Download CSV ('+nb+' bins)</a></div>';
  var el=document.getElementById('num-tbl');if(el)el.innerHTML=tbl;
}

window.addEventListener('load',function(){
  renderUni();
  var fc=window._FC,fn=window._FN;
  if(fc)selCat(fc);
  if(fn)selNum(fn);
  showTab('tab-u');
});
"""



# ==============================================================
#  generate_fs_report()
# ==============================================================
def generate_fs_report(results: dict,
                        output_path=None,
                        open_browser: bool = True,
                        offline: bool = False) -> str:
    """
    Generate the Feature Selection Dashboard HTML.

    Works with results from either run_eda() or run_target_analysis().

    Parameters
    ----------
    results     : dict with key "deep_target_analysis" (from run_eda or run_target_analysis)
    output_path : e.g. "feature_selection.html"
    open_browser: auto-open after saving
    offline     : embed Plotly.js (no internet)
    """
    target = results.get("target_col")
    dta    = results.get("deep_target_analysis", {})
    n_rows = results.get("n_rows", 0)

    if not target:
        return "<html><body><p>No target_col in results.</p></body></html>"
    if not dta:
        return ("<html><body><p>No deep_target_analysis found. "
                "Call plan.set_sections(target_analysis=True) or use run_target_analysis().</p></body></html>")

    cat_cols    = sorted(dta.get("categorical", {}).keys())
    num_cols    = sorted(dta.get("numeric",     {}).keys())
    uni         = dta.get("univariate",  {})
    n_bins_list = dta.get("n_bins_list", [10, 20])
    exposure_col= dta.get("exposure_col") or ""
    bin_by      = dta.get("bin_by", "amount")
    ta_elapsed  = dta.get("elapsed_sec", 0)

    # Default number of bins shown on slider = largest pre-computed
    n_bins_def = max(n_bins_list) if n_bins_list else 20
    # Slider range: always 1-30 regardless of what was pre-computed
    # JS finds the closest pre-computed config

    # ── stat cards ─────────────────────────────────────────────────────────
    stats = uni.get("stats", {})
    stat_cards = ""
    for lbl, key, fmt_s in [
        ("Count","count",",.0f"),("Mean","mean",".4g"),("Median","median",".4g"),
        ("Std Dev","std",".4g"),("P95","p95",".4g"),("P99","p99",".4g"),
        ("Skewness","skewness",".3f"),("Zero %","zero_pct",".2f"),
    ]:
        v = stats.get(key); disp = "—"
        if v is not None:
            try:
                fv = float(v)
                disp = (f"{int(fv):,}" if key=="count"
                        else f"{fv:.2f}%" if key=="zero_pct"
                        else format(fv, fmt_s))
            except Exception:
                disp = str(v)
        stat_cards += (f'<div class="sc"><div class="sv">{disp}</div>'
                       f'<div class="sl">{lbl}</div></div>')

    cat_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in cat_cols)
    num_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in num_cols)

    # ── legend ─────────────────────────────────────────────────────────────
    exp_item = (f'<span class="li">'
                f'<span class="ls" style="background:rgba(200,146,42,.50)"></span>'
                f'{_esc(exposure_col)} (exposure, left axis)</span>'
                if exposure_col else "")
    legend = (f'<div class="leg">'
              f'{exp_item}'
              f'<span class="li"><span class="ls" style="background:rgba(0,43,92,.40)"></span>'
              f'Count (right axis, toggleable)</span>'
              f'<span class="li"><span class="lline"></span>Mean {_esc(target)} (right axis, own scale)</span>'
              f'</div>')

    # ── display toggles ─────────────────────────────────────────────────
    expo_tog = (f'<label class="tg"><input type="checkbox" checked onchange="togExp(this)"> '
                f'{_esc(exposure_col)}</label>'
                if exposure_col else "")

    # ── data script ─────────────────────────────────────────────────────
    data_script = f"""<script>
window.D_TGT={_j(target)};
window.D_UNI={_j(uni)};
window.D_CAT={_j(dta.get("categorical",{}))};
window.D_NUM={_j(dta.get("numeric",{}))};
window.D_EC={_j(exposure_col)};
window.D_BY={_j(bin_by)};
window._FC={_j(cat_cols[0] if cat_cols else "")};
window._FN={_j(num_cols[0] if num_cols else "")};
</script>"""

    if offline:
        try:
            import plotly
            jp = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
            plotly_tag = (f"<script>{jp.read_text()}</script>"
                          if jp.exists() else f'<script src="{PLOTLY_CDN}"></script>')
        except Exception:
            plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'
    else:
        plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'

    no_cat = '<div class="warn">No categorical features found.</div>' if not cat_cols else ""
    no_num = '<div class="warn">No numeric features found.</div>'     if not num_cols else ""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Feature Selection -- {_esc(target)} -- {n_rows:,} rows</title>
{plotly_tag}
<style>{CSS}</style>
</head>
<body>
{data_script}

<div id="fso"><div id="fsb"><button id="fsc" onclick="closeFS()">&#10005;</button><div id="fsp"></div></div></div>

<div class="hdr">
  <div class="hdr-row">
    <div class="logo">RC</div>
    <div><div class="hdr-title">Feature Selection Dashboard</div>
         <div class="hdr-sub">Chubb Risk Cohorts v5</div></div>
    <div class="hdr-meta">
      <span>Rows <strong>{n_rows:,}</strong></span>
      <span>Target <strong>{_esc(target)}</strong></span>
      <span>Cat <strong>{len(cat_cols)}</strong></span>
      <span>Num <strong>{len(num_cols)}</strong></span>
      {"<span>Exposure <strong>" + _esc(exposure_col) + "</strong></span>" if exposure_col else ""}
      <span>Computed <strong>{ta_elapsed:.1f}s</strong></span>
    </div>
  </div>
  <div class="nav">
    <button class="nav-btn on" data-tab="tab-u" onclick="showTab('tab-u')">Target Overview</button>
    <button class="nav-btn"    data-tab="tab-c" onclick="showTab('tab-c')">Categorical vs Target</button>
    <button class="nav-btn"    data-tab="tab-n" onclick="showTab('tab-n')">Numerical vs Target</button>
  </div>
</div>

<div class="page">

<!-- controls: only essentials -->
<div class="ctrls">
  <div class="cg">
    <div class="cl">Metric</div>
    <div class="br">
      <button class="cb mb2 on" data-m="mean"   onclick="setMetric('mean')">Mean</button>
      <button class="cb mb2"    data-m="median" onclick="setMetric('median')">Median</button>
      <button class="cb mb2"    data-m="sum"    onclick="setMetric('sum')">Sum</button>
    </div>
  </div>
  <div class="csep"></div>
  <div class="cg">
    <div class="cl">Options</div>
    <div class="br">
      <label class="tg"><input type="checkbox" onchange="togLog(this)"> Log Y</label>
      <label class="tg"><input type="checkbox" checked onchange="togCnt(this)"> Count bars</label>
    </div>
  </div>
  <div class="csep"></div>
  <div class="cg">
    <div class="cl">Sort (categorical)</div>
    <div class="br">
      <button class="cb sb on" data-s="count"  onclick="setSort('count')">By Count</button>
      <button class="cb sb"    data-s="metric" onclick="setSort('metric')">By Metric</button>
      <button class="cb sb"    data-s="alpha"  onclick="setSort('alpha')">A-Z</button>
    </div>
  </div>
  <div class="csep"></div>
  <div class="cg">
    <div class="cl">Group small &lt;<span id="grp-lbl" style="color:var(--acc)">Off</span></div>
    <input type="range" class="rng" min="0" max="5" step="0.5" value="0" oninput="setGrp(this.value)">
  </div>
  <div class="cg" style="margin-left:auto;font-size:.72rem;color:var(--txt3);line-height:1.75;text-align:right">
    {n_rows:,} rows No sampling<br>Pre-computed {ta_elapsed:.1f}s
  </div>
</div>

<!-- UNIVARIATE -->
<div id="tab-u" class="tab on">
  <h3 class="sh">Target Overview -- {_esc(target)}</h3>
  <p class="cap">{n_rows:,} rows full dataset no sampling</p>
  <div class="sg">{stat_cards}</div>
  <div class="cw">
    <div class="cl2"><div class="sp"></div><span>Rendering...</span></div>
    <div id="uni-ch" class="cd"></div>
  </div>
  <div id="uni-tbl" style="margin-top:16px"></div>
</div>

<!-- CATEGORICAL -->
<div id="tab-c" class="tab">
  <h3 class="sh">Categorical vs {_esc(target)}</h3>
  {legend}
  {no_cat}
  {(f'<div class="fr">'
    f'<label class="fl">Feature</label>'
    f'<select class="fs" onchange="selCat(this.value)">{cat_opts}</select>'
    f'<span style="font-size:.77rem;color:var(--txt2)">{len(cat_cols)} features 30/page</span>'
    f'</div>') if cat_cols else ""}
  {('<div id="cat-pg" class="pgc" style="display:none">'
    '<button class="pgb" id="cat-prev" onclick="catPg(-1)">Prev</button>'
    '<span class="pgi" id="cat-pi"></span>'
    '<button class="pgb" id="cat-next" onclick="catPg(1)">Next</button>'
    '</div>') if cat_cols else ""}
  {('<div class="cw"><div class="cl2"><div class="sp"></div><span>Rendering...</span></div>'
    '<div id="cat-ch" class="cd"></div></div>'
    '<div id="cat-tbl" style="margin-top:12px"></div>') if cat_cols else ""}
</div>

<!-- NUMERICAL -->
<div id="tab-n" class="tab">
  <h3 class="sh">Numerical vs {_esc(target)}</h3>
  {legend}
  {no_num}
  {(f'<div class="fr">'
    f'<label class="fl">Feature</label>'
    f'<select class="fs" onchange="selNum(this.value)">{num_opts}</select>'
    f'<label class="fl" style="margin-left:8px">Bins</label>'
    f'<span class="bl" id="bins-v">{n_bins_def}</span>'
    f'<input type="range" class="rng" min="1" max="30" step="1"'
    f' value="{n_bins_def}" oninput="setBins(this.value)">'
    f'<span style="font-size:.75rem;color:var(--txt2)">1-30</span>'
    f'</div>') if num_cols else ""}
  {('<div class="cw"><div class="cl2"><div class="sp"></div><span>Rendering...</span></div>'
    '<div id="num-ch" class="cd"></div></div>'
    '<div id="num-tbl" style="margin-top:12px"></div>') if num_cols else ""}
</div>

</div>
<script>
{JS}
S.bins={n_bins_def};
</script>
</body>
</html>"""

    if output_path:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
        size = path.stat().st_size / 1024
        print(f"[FS] Saved -> {path}  ({size:.0f} KB)")
        if open_browser and not str(output_path).startswith("/dbfs"):
            try:
                webbrowser.open(path.resolve().as_uri())
            except Exception:
                pass

    return html
