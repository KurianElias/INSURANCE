"""
app.py — Insurance EDA Toolkit v3
Clean, minimal, dark-accent UI.
Tabs: Overview · Variable Explorer · Hit Rate · Category Quality ·
      Outliers · Correlations · Quality Scorecard
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

st.set_page_config(
    page_title="EDA Toolkit",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── global style ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
  /* Layout */
  .block-container { padding: 1.1rem 2rem 1rem 2rem; }
  section[data-testid="stSidebar"] { background: #0f1117; }
  section[data-testid="stSidebar"] * { color: #e8eaf0 !important; }
  section[data-testid="stSidebar"] hr { border-color: #2d3145; }

  /* Metrics */
  [data-testid="stMetricValue"]  { font-size: 1.35rem; font-weight: 700; color: #1a1d2e; }
  [data-testid="stMetricLabel"]  { font-size: 0.72rem; color: #6b7280; text-transform: uppercase; letter-spacing: .04em; }
  [data-testid="stMetricDelta"]  { font-size: 0.78rem; }
  div[data-testid="metric-container"] {
    background: #f8f9fc;
    border: 1px solid #e5e7ef;
    border-radius: 10px;
    padding: .6rem 1rem .5rem 1rem;
  }

  /* Alert pills */
  .pill { display:inline-block; padding:2px 10px; border-radius:999px; font-size:.78rem; font-weight:600; margin:2px 3px; }
  .pill-red    { background:#fee2e2; color:#b91c1c; }
  .pill-yellow { background:#fef9c3; color:#a16207; }
  .pill-green  { background:#dcfce7; color:#166534; }
  .pill-blue   { background:#dbeafe; color:#1d4ed8; }

  /* Alert banners */
  .alert { padding:.45rem .85rem; border-radius:7px; margin:.25rem 0 .35rem 0; font-size:.85rem; line-height:1.45; }
  .alert-red    { background:#fef2f2; border-left:3px solid #ef4444; color:#7f1d1d; }
  .alert-yellow { background:#fffbeb; border-left:3px solid #f59e0b; color:#78350f; }
  .alert-blue   { background:#eff6ff; border-left:3px solid #3b82f6; color:#1e3a5f; }
  .alert-green  { background:#f0fdf4; border-left:3px solid #22c55e; color:#14532d; }

  /* Section headers */
  .sec-header { font-size:1.0rem; font-weight:700; color:#1a1d2e;
                border-bottom:2px solid #6366f1; padding-bottom:4px;
                margin:1.1rem 0 .6rem 0; display:inline-block; }

  /* Tab strip */
  button[data-baseweb="tab"] { font-size:.83rem; font-weight:600; }
  button[data-baseweb="tab"][aria-selected="true"] { color:#6366f1; border-color:#6366f1; }

  /* Dataframe */
  [data-testid="stDataFrame"] { border-radius:8px; overflow:hidden; }

  /* Misc */
  div[data-testid="stExpander"] summary { font-size:.88rem; }
  .stDownloadButton button { border-radius:6px; font-size:.78rem; padding:3px 12px; }
</style>
""", unsafe_allow_html=True)

PLOT_H    = 320
PLOT_BG   = "rgba(0,0,0,0)"
GRID_CLR  = "#e5e7ef"
ACCENT    = "#6366f1"
ACCENT2   = "#06b6d4"
RED       = "#ef4444"
ORANGE    = "#f59e0b"
GREEN     = "#22c55e"


# ── helpers ───────────────────────────────────────────────────────────────────

def _R():
    return st.session_state.get("eda_results", {})

def _dl(df, label, fname):
    st.download_button(f"⬇ {label}", df.to_csv(index=False).encode(),
                       fname, "text/csv", use_container_width=True)

def _sec(title):
    st.markdown(f'<div class="sec-header">{title}</div>', unsafe_allow_html=True)

def _pill(text, kind="blue"):
    st.markdown(f'<span class="pill pill-{kind}">{text}</span>', unsafe_allow_html=True)

def _alert(msg, kind="yellow"):
    cls = {"red":"alert-red","yellow":"alert-yellow","blue":"alert-blue","green":"alert-green"}.get(kind,"alert-yellow")
    st.markdown(f'<div class="alert {cls}">{msg}</div>', unsafe_allow_html=True)

def _chart(fig, h=PLOT_H):
    fig.update_layout(
        height=h,
        margin=dict(l=30, r=20, t=36, b=40),
        paper_bgcolor=PLOT_BG, plot_bgcolor=PLOT_BG,
        font=dict(family="Inter, sans-serif", size=11, color="#374151"),
        legend=dict(bgcolor="rgba(0,0,0,0)", font_size=10),
    )
    fig.update_xaxes(gridcolor=GRID_CLR, linecolor=GRID_CLR, zerolinecolor=GRID_CLR)
    fig.update_yaxes(gridcolor=GRID_CLR, linecolor=GRID_CLR, zerolinecolor=GRID_CLR)
    return fig

def _blank_fig(msg="No data"):
    fig = go.Figure()
    fig.add_annotation(text=msg, xref="paper", yref="paper",
                       x=0.5, y=0.5, showarrow=False, font_size=13, font_color="#9ca3af")
    return _chart(fig)


# ── sidebar ───────────────────────────────────────────────────────────────────

def _sidebar(R):
    st.sidebar.markdown("## 📊 EDA Toolkit")
    st.sidebar.caption("100% local · no data leaves your machine")
    st.sidebar.markdown("---")

    dm     = R.get("dtype_map", {})
    n_num  = sum(1 for t in dm.values() if t == "Numeric")
    n_cat  = sum(1 for t in dm.values() if t == "Categorical")
    n_bool = sum(1 for t in dm.values() if t == "Boolean")
    n_date = sum(1 for t in dm.values() if t == "Date")

    c1, c2 = st.sidebar.columns(2)
    c1.metric("Rows",    f"{R.get('n_rows',0):,}")
    c2.metric("Cols",    R.get("n_features", 0))
    c1.metric("Numeric", n_num)
    c2.metric("Categ.",  n_cat)
    c1.metric("Bool",    n_bool)
    c2.metric("Date",    n_date)

    st.sidebar.metric("Runtime", f"{R.get('elapsed_sec',0):.1f}s")

    sc = R.get("scorecard", pd.DataFrame())
    if len(sc):
        st.sidebar.markdown("---")
        st.sidebar.markdown("**Quality Summary**")
        n_fix = int((sc["Status"] == "❌ Fix First").sum())
        n_rev = int((sc["Status"] == "⚠️ Review").sum())
        n_ok  = int((sc["Status"] == "✅ Good").sum())
        total = len(sc)
        # mini progress bar
        bar_w = 180
        w_fix = round(n_fix/total*bar_w) if total else 0
        w_rev = round(n_rev/total*bar_w) if total else 0
        w_ok  = bar_w - w_fix - w_rev
        st.sidebar.markdown(f"""
<div style="display:flex;border-radius:5px;overflow:hidden;height:8px;margin:4px 0 10px 0">
  <div style="width:{w_fix}px;background:#ef4444"></div>
  <div style="width:{w_rev}px;background:#f59e0b"></div>
  <div style="width:{w_ok}px;background:#22c55e"></div>
</div>
""", unsafe_allow_html=True)
        st.sidebar.write(f"🔴 Fix First: **{n_fix}**")
        st.sidebar.write(f"🟡 Review:    **{n_rev}**")
        st.sidebar.write(f"🟢 Good:      **{n_ok}**")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════

def tab_overview(R):
    cfg = R.get("config", {})
    cr  = R.get("col_results", {})
    dm  = R.get("dtype_map", {})

    n_rows = R["n_rows"]
    n_num  = sum(1 for t in dm.values() if t in ("Numeric","Boolean"))
    n_cat  = sum(1 for t in dm.values() if t == "Categorical")
    total_cells  = n_rows * R["n_features"]
    total_miss   = sum(v["missing_count"] for v in cr.values())
    miss_pct_tot = round(total_miss / total_cells * 100, 2) if total_cells else 0

    # KPI row
    cols = st.columns(5)
    cols[0].metric("Total Rows",    f"{n_rows:,}")
    cols[1].metric("Columns",       R["n_features"])
    cols[2].metric("Numeric / Bool",n_num)
    cols[3].metric("Categorical",   n_cat)
    cols[4].metric("Overall Missing",f"{miss_pct_tot:.1f}%")

    st.divider()

    left, right = st.columns(2)

    with left:
        _sec("Column Type Distribution")
        type_counts = pd.Series(dm).value_counts().reset_index()
        type_counts.columns = ["Type", "Count"]
        colors = {"Numeric":"#6366f1","Categorical":"#06b6d4","Boolean":"#f59e0b",
                  "Date":"#10b981","ID-like":"#94a3b8","Unknown":"#e5e7ef","Constant":"#ef4444"}
        fig = px.pie(type_counts, names="Type", values="Count", hole=0.55,
                     color="Type", color_discrete_map=colors)
        fig.update_traces(textposition="inside", textinfo="percent+label",
                          textfont_size=11)
        _chart(fig, h=290)
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    with right:
        _sec("Missing Value Overview")
        miss_data = [(col, res["missing_pct"]) for col, res in cr.items()
                     if res["missing_pct"] > 0]
        if miss_data:
            mdf = (pd.DataFrame(miss_data, columns=["Feature","Missing %"])
                   .sort_values("Missing %", ascending=True))
            colors_bar = [RED if v >= 30 else ORANGE if v >= 10 else ACCENT
                          for v in mdf["Missing %"]]
            fig2 = go.Figure(go.Bar(
                x=mdf["Missing %"], y=mdf["Feature"], orientation="h",
                marker_color=colors_bar,
                text=mdf["Missing %"].apply(lambda v: f"{v:.1f}%"),
                textposition="outside",
            ))
            _chart(fig2, h=290)
            fig2.update_layout(xaxis=dict(range=[0,115], title="Missing %"),
                                yaxis_title="")
            st.plotly_chart(fig2, use_container_width=True)
        else:
            st.success("✅ No missing values in any feature")

    st.divider()

    # Feature table
    _sec("All Features at a Glance")
    rows = []
    for col, res in cr.items():
        dtype = res["dtype"]
        dist  = res.get("dist", {})
        sk    = res.get("skewness")
        inf_p = res.get("inf_pct", 0.0)
        rows.append({
            "Feature":    col,
            "Type":       dtype,
            "Missing %":  res["missing_pct"],
            "Hit Rate %": res["hit_rate_pct"],
            "Unique":     res["n_unique"],
            "Mean / Top": (f"{dist['mean']:.4g}" if dist and dtype == "Numeric"
                           else (str(res.get("category_table",pd.DataFrame()).iloc[0]["Category"])[:20]
                                 if dtype == "Categorical" and len(res.get("category_table",pd.DataFrame()))
                                 else res.get("constant_value","—") if dtype == "Constant" else "—")),
            "Skewness":   round(sk, 3) if sk is not None else "—",
            "Zero %":     res.get("zero_pct", 0),
            "Inf %":      round(inf_p, 2),
        })
    feat_df = pd.DataFrame(rows)
    st.dataframe(feat_df, use_container_width=True, height=400,
                 column_config={
                     "Missing %":  st.column_config.ProgressColumn("Missing %",  min_value=0, max_value=100),
                     "Hit Rate %": st.column_config.ProgressColumn("Hit Rate %", min_value=0, max_value=100),
                     "Zero %":     st.column_config.ProgressColumn("Zero %",     min_value=0, max_value=100),
                 })
    _dl(feat_df, "Feature Overview CSV", "feature_overview.csv")

    # Grouped report
    det = R.get("grouped_report", pd.DataFrame())
    if len(det):
        st.divider()
        _sec(f"Grouped Report — by {cfg.get('groupby_col','')}")
        st.dataframe(det, use_container_width=True)
        _dl(det, "Grouped Report CSV", "grouped_report.csv")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — VARIABLE EXPLORER
# ══════════════════════════════════════════════════════════════════════════════

def tab_variable_explorer(R):
    cr = R.get("col_results", {})
    if not cr:
        st.info("No features analysed.")
        return

    col_l, col_r = st.columns([1, 3])
    with col_l:
        selected = st.selectbox("Select variable", list(cr.keys()), label_visibility="collapsed")

    if not selected:
        return

    res   = cr[selected]
    dtype = res["dtype"]
    dist  = res.get("dist", {})
    outl  = res.get("outlier", {})
    inf_p = res.get("inf_pct", 0.0)

    st.divider()

    # ── NUMERIC ───────────────────────────────────────────────────────────────
    if dtype in ("Numeric", "Boolean"):
        c1,c2,c3,c4,c5,c6,c7,c8 = st.columns(8)
        c1.metric("Mean",      f"{dist.get('mean',0):.4g}"    if dist else "—")
        c2.metric("Median",    f"{dist.get('median',0):.4g}"  if dist else "—")
        c3.metric("Std",       f"{dist.get('std',0):.4g}"     if dist else "—")
        c4.metric("Min",       f"{dist.get('min',0):.4g}"     if dist else "—")
        c5.metric("Max",       f"{dist.get('max',0):.4g}"     if dist else "—")
        c6.metric("Skewness",  f"{dist.get('skewness',0):.2f}" if dist else "—")
        c7.metric("Missing %", f"{res['missing_pct']:.1f}%")
        c8.metric("Zero %",    f"{res.get('zero_pct',0):.1f}%")

        # Alerts
        sk = dist.get("skewness", 0) if dist else 0
        if inf_p > 0:
            _alert(f"🔴 {inf_p:.2f}% Inf values detected and excluded from stats — investigate source", "red")
        if abs(sk) > 2:
            _alert(f"⚠️ Very high skewness ({sk:.2f}) — consider log1p transform", "red")
        elif abs(sk) > 1:
            _alert(f"⚠️ High skewness ({sk:.2f})", "yellow")
        if res["missing_pct"] > 20:
            _alert(f"⚠️ Sparse variable — {res['missing_pct']:.1f}% missing", "red")
        elif res["missing_pct"] > 5:
            _alert(f"ℹ️ {res['missing_pct']:.1f}% missing values", "yellow")
        if res.get("zero_inflated"):
            _alert("ℹ️ Zero-inflated: >30% of values are zero — consider two-part model", "blue")
        if dist:
            st.caption(f"Shape: **{dist.get('shape','—')}**  ·  "
                       f"P25={dist.get('p25','—')}  P75={dist.get('p75','—')}  "
                       f"P95={dist.get('p95','—')}  P99={dist.get('p99','—')}")

        # Histogram
        sample = res.get("plot_sample", [])
        if sample:
            scl = st.radio("Y-axis scale", ["Linear","Log"], horizontal=True, key="vex_scale")
            arr = np.array(sample)
            fig = go.Figure()
            fig.add_trace(go.Histogram(
                x=arr, nbinsx=60, name="Distribution",
                marker_color=ACCENT, opacity=0.85,
                marker_line=dict(width=0.3, color="#fff"),
            ))
            if dist:
                fig.add_vline(x=dist["mean"],   line_dash="dash",
                              line_color=ORANGE, annotation_text="Mean",
                              annotation_font_size=10)
                fig.add_vline(x=dist["median"], line_dash="dot",
                              line_color=GREEN, annotation_text="Median",
                              annotation_font_size=10)
            if scl == "Log":
                fig.update_yaxes(type="log")
            _chart(fig)
            fig.update_layout(title=dict(text=f"Distribution — {selected}", font_size=13),
                              xaxis_title=selected, yaxis_title="Count",
                              bargap=0.02)
            st.plotly_chart(fig, use_container_width=True)

    # ── CATEGORICAL ───────────────────────────────────────────────────────────
    elif dtype == "Categorical":
        nu   = res["n_unique"]
        rare = res.get("rare_count", 0)
        c1,c2,c3 = st.columns(3)
        c1.metric("Unique Categories", nu)
        c2.metric("Rare (<1%)",        rare)
        c3.metric("Missing %",         f"{res['missing_pct']:.1f}%")

        if nu > 100:
            _alert(f"⚠️ High cardinality — {nu} unique categories. Fuzzy matching skipped.", "yellow")
        if rare > 5:
            _alert(f"⚠️ {rare} rare categories (<1% share) — consider grouping into 'Other'", "yellow")
        if res["missing_pct"] > 10:
            _alert(f"⚠️ {res['missing_pct']:.1f}% missing", "red")

        tbl = res.get("category_table", pd.DataFrame())
        if len(tbl):
            scl = st.radio("Y-axis scale", ["Linear","Log"], horizontal=True, key="vex_cat_scale")
            # colour bars by flag
            bar_colors = [RED if f == "RARE" else ACCENT2 if f == "DOMINANT" else ACCENT
                          for f in tbl.head(25)["Flag"]]
            fig = go.Figure(go.Bar(
                x=tbl.head(25)["Category"],
                y=tbl.head(25)["Share %"],
                marker_color=bar_colors,
                text=tbl.head(25)["Count"],
                textposition="outside",
                textfont_size=9,
            ))
            if scl == "Log":
                fig.update_yaxes(type="log")
            _chart(fig)
            fig.update_layout(title=dict(text=f"Top Categories — {selected}", font_size=13),
                              xaxis_title="", yaxis_title="Share %",
                              bargap=0.15)
            fig.update_xaxes(tickangle=35)
            st.plotly_chart(fig, use_container_width=True)
            with st.expander("Full category table"):
                st.dataframe(tbl, use_container_width=True, height=240)

    # ── CONSTANT ──────────────────────────────────────────────────────────────
    elif dtype == "Constant":
        _alert(f"🔒 Constant column — single unique value: <b>{res.get('constant_value','?')}</b>. "
               f"Zero variance, no information for modelling. Consider dropping.", "red")
        st.metric("Value", res.get("constant_value","?"))

    else:
        st.metric("Missing %",  f"{res['missing_pct']:.1f}%")
        st.metric("Hit Rate %", f"{res['hit_rate_pct']:.1f}%")
        st.info(f"Type: **{dtype}**")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — HIT RATE
# ══════════════════════════════════════════════════════════════════════════════

def tab_hit_rate(R):
    cr = R.get("col_results", {})
    if not cr:
        st.info("No data available.")
        return

    rows = [{"Feature": col, "Hit Rate %": res["hit_rate_pct"],
             "Missing %": res["missing_pct"], "Type": res["dtype"]}
            for col, res in cr.items()]
    df_hr = pd.DataFrame(rows).sort_values("Hit Rate %", ascending=True)

    colors = [GREEN if h >= 95 else ORANGE if h >= 75 else RED
              for h in df_hr["Hit Rate %"]]

    fig = go.Figure(go.Bar(
        x=df_hr["Hit Rate %"], y=df_hr["Feature"],
        orientation="h", marker_color=colors,
        text=df_hr["Hit Rate %"].apply(lambda v: f"{v:.1f}%"),
        textposition="outside", textfont_size=9,
    ))
    _chart(fig, h=max(350, len(df_hr) * 22))
    fig.update_layout(
        title=dict(text="Hit Rate per Feature (% non-null)", font_size=13),
        xaxis=dict(range=[0,110], title="Hit Rate %"),
        yaxis_title="",
    )
    st.plotly_chart(fig, use_container_width=True)

    # Legend pills
    st.markdown(
        '<span class="pill pill-green">● ≥95% Good</span>'
        '<span class="pill pill-yellow">● 75–94% Review</span>'
        '<span class="pill pill-red">● <75% Problem</span>',
        unsafe_allow_html=True,
    )

    st.divider()
    _sec("Hit Rate Table")
    st.dataframe(
        df_hr.sort_values("Hit Rate %").reset_index(drop=True),
        use_container_width=True, height=300,
        column_config={
            "Hit Rate %": st.column_config.ProgressColumn("Hit Rate %", min_value=0, max_value=100),
            "Missing %":  st.column_config.ProgressColumn("Missing %",  min_value=0, max_value=100),
        }
    )
    _dl(df_hr, "Hit Rate CSV", "hit_rate.csv")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — CATEGORY QUALITY
# ══════════════════════════════════════════════════════════════════════════════

def tab_category_quality(R):
    fuzzy = R.get("fuzzy_categories", {})
    cr    = R.get("col_results", {})
    cat_cols = [c for c, r in cr.items() if r["dtype"] == "Categorical"]

    if not cat_cols:
        st.info("No categorical columns found.")
        return

    # Summary KPIs
    # fuzzy dict: col -> list of matches (empty list = skipped)
    cols_with_matches = {c: v for c, v in fuzzy.items() if isinstance(v, list) and len(v) > 0}
    cols_skipped      = {c for c, v in fuzzy.items() if isinstance(v, list) and len(v) == 0}
    total_pairs       = sum(len(v) for v in cols_with_matches.values())

    c1,c2,c3 = st.columns(3)
    c1.metric("Cols with similar categories", len(cols_with_matches))
    c2.metric("Total similar pairs",          total_pairs)
    c3.metric("Skipped (high-cardinality)",   len(cols_skipped))

    st.divider()

    # ── Fuzzy match results ───────────────────────────────────────────────────
    _sec("Similar / Duplicate Category Pairs")
    if not cols_with_matches:
        _alert("✅ No similar or duplicate categories detected.", "green")
    else:
        for col, matches in cols_with_matches.items():
            nu   = cr[col].get("n_unique", 0)
            rare = cr[col].get("rare_count", 0)
            with st.expander(
                f"🏷️ **{col}** — {len(matches)} similar pair(s)  "
                f"({nu} categories, {rare} rare)", expanded=len(matches) > 0
            ):
                mdf = pd.DataFrame(matches)
                # colour similarity
                def _sim_color(val):
                    if val == 1.0: return "background-color:#fee2e2; color:#991b1b; font-weight:700"
                    if val >= 0.95: return "background-color:#fef9c3; color:#92400e"
                    return ""
                st.dataframe(
                    mdf.style.map(_sim_color, subset=["Similarity"]),
                    use_container_width=True, height=min(300, 40+len(mdf)*38)
                )

    if cols_skipped:
        with st.expander(f"ℹ️ {len(cols_skipped)} columns skipped (>50 categories)"):
            for c in sorted(cols_skipped):
                st.write(f"  • {c} ({cr[c].get('n_unique',0)} categories)")

    st.divider()

    # ── Rare categories explorer ──────────────────────────────────────────────
    _sec("Rare Categories Explorer")
    sel = st.selectbox("Select categorical column", cat_cols, key="cq_sel")
    if sel:
        tbl      = cr[sel].get("category_table", pd.DataFrame())
        rare_df  = tbl[tbl["Flag"] == "RARE"] if len(tbl) else pd.DataFrame()
        dom_df   = tbl[tbl["Flag"] == "DOMINANT"] if len(tbl) else pd.DataFrame()

        col_a, col_b = st.columns(2)
        with col_a:
            if len(rare_df):
                _alert(f"⚠️ {len(rare_df)} rare categories (< 1% share) in <b>{sel}</b>", "yellow")
                st.dataframe(rare_df, use_container_width=True, height=200)
            else:
                _alert(f"✅ No rare categories in <b>{sel}</b>", "green")
        with col_b:
            if len(dom_df):
                _alert(f"⚠️ Dominant category detected (>80% share) in <b>{sel}</b>", "yellow")
                st.dataframe(dom_df, use_container_width=True, height=200)
            else:
                st.caption("No dominant category.")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — OUTLIERS
# ══════════════════════════════════════════════════════════════════════════════

def tab_outliers(R):
    cr = R.get("col_results", {})
    num_cols = [c for c, r in cr.items()
                if r["dtype"] in ("Numeric","Boolean") and r.get("plot_sample")]
    if not num_cols:
        st.info("No numeric columns with data available.")
        return

    col_l, col_r = st.columns([1,3])
    with col_l:
        selected = st.selectbox("Select numeric variable", num_cols,
                                label_visibility="collapsed")
    if not selected:
        return

    res  = cr[selected]
    outl = res.get("outlier", {})
    dist = res.get("dist", {})
    inf_p = res.get("inf_pct", 0.0)

    if inf_p > 0:
        _alert(f"🔴 {inf_p:.2f}% Inf values were excluded before computing these stats", "red")

    # Threshold sliders
    sl1, sl2 = st.columns(2)
    pct_lo = sl1.slider("Lower percentile cutoff", 0, 20, 5, key="ol_lo")
    pct_hi = sl2.slider("Upper percentile cutoff", 80, 100, 95, key="ol_hi")

    sample = np.array(res.get("plot_sample", []))
    if len(sample) == 0:
        st.warning("No sample data."); return

    lo_val  = float(np.percentile(sample, pct_lo))
    hi_val  = float(np.percentile(sample, pct_hi))
    n_out   = int(((sample < lo_val) | (sample > hi_val)).sum())
    out_pct = round(n_out / len(sample) * 100, 2)

    c1,c2,c3,c4 = st.columns(4)
    c1.metric(f"P{pct_lo}",             f"{lo_val:.4g}")
    c2.metric(f"P{pct_hi}",             f"{hi_val:.4g}")
    c3.metric("Outside range (sample)", n_out)
    c4.metric("% outside",              f"{out_pct:.2f}%")

    if outl.get("note"):
        _alert(f"ℹ️ {outl['note']}", "blue")
    if outl:
        st.caption(f"**IQR fences (engine):** lower = {outl.get('fence_lo','—')}  "
                   f"upper = {outl.get('fence_hi','—')}  |  "
                   f"{outl.get('iqr_pct',0):.1f}% outside IQR")

    # Boxplot
    fig_box = go.Figure()
    fig_box.add_trace(go.Box(
        x=sample, name=selected,
        marker_color=ACCENT, boxmean="sd",
        fillcolor=f"rgba(99,102,241,0.15)",
        line_color=ACCENT,
    ))
    fig_box.add_vline(x=lo_val, line_dash="dash", line_color=ORANGE,
                      annotation_text=f"P{pct_lo}", annotation_font_size=10)
    fig_box.add_vline(x=hi_val, line_dash="dash", line_color=RED,
                      annotation_text=f"P{pct_hi}", annotation_font_size=10)
    _chart(fig_box, h=200)
    fig_box.update_layout(title=dict(text=f"Boxplot — {selected}", font_size=13))
    st.plotly_chart(fig_box, use_container_width=True)

    # Histogram with outlier zones
    fig_hist = go.Figure()
    fig_hist.add_trace(go.Histogram(
        x=sample, nbinsx=60,
        marker_color=ACCENT, opacity=0.82, name="All",
        marker_line=dict(width=0.2, color="#fff"),
    ))
    fig_hist.add_vrect(
        x0=float(sample.min()), x1=lo_val,
        fillcolor=ORANGE, opacity=0.10, line_width=0,
        annotation_text="Low tail", annotation_font_size=9,
        annotation_position="top left",
    )
    fig_hist.add_vrect(
        x0=hi_val, x1=float(sample.max()),
        fillcolor=RED, opacity=0.10, line_width=0,
        annotation_text="High tail", annotation_font_size=9,
        annotation_position="top right",
    )
    _chart(fig_hist)
    fig_hist.update_layout(
        title=dict(text=f"Distribution with outlier zones — {selected}", font_size=13),
        xaxis_title=selected, yaxis_title="Count", bargap=0.02,
    )
    st.plotly_chart(fig_hist, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 6 — CORRELATIONS
# ══════════════════════════════════════════════════════════════════════════════

def tab_correlations(R):
    corr = R.get("correlations", {})
    cfg  = R.get("config", {})

    method = st.radio(
        "Method",
        ["Pearson (full data)", "Spearman (sampled)", "Kendall (sampled)"],
        horizontal=True,
    )
    mat_key = {"Pearson (full data)":"pearson",
               "Spearman (sampled)":"spearman",
               "Kendall (sampled)":"kendall"}[method]
    hm = corr.get(mat_key, pd.DataFrame())

    if len(hm) < 2:
        st.info("Need ≥ 2 numeric features for correlation analysis.")
        return

    # IMP-7: show % of data used
    total_rows  = corr.get("total_rows", 0)
    n_vars      = corr.get("n_vars", 0)
    if mat_key == "pearson":
        sn  = corr.get("sample_size", total_rows)
        pct = round(sn/total_rows*100, 1) if total_rows else 100
        caption = (f"Pearson — pairwise (min 30 obs). "
                   f"Sample: {sn:,} of {total_rows:,} rows ({pct}%). "
                   f"Top {n_vars} numeric variables by variance. "
                   f"Threshold |r| ≥ {cfg.get('corr_threshold',0.75)}")
    elif mat_key == "spearman":
        sn  = corr.get("spearman_sample_n", 0)
        pct = corr.get("spearman_sample_pct", 0)
        caption = f"Spearman — pairwise (min 30 obs). Sample: {sn:,} of {total_rows:,} rows ({pct}%)."
    else:
        sn  = corr.get("kendall_sample_n", 0)
        pct = corr.get("kendall_sample_pct", 0)
        caption = f"Kendall — pairwise (min 30 obs). Sample: {sn:,} of {total_rows:,} rows ({pct}%)."
    st.caption(caption)

    # Heatmap
    _sec(f"{method.split()[0]} Correlation Heatmap")
    fig = px.imshow(
        hm, text_auto=".2f", aspect="auto",
        color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
    )
    fig.update_layout(
        height=max(380, len(hm) * 38),
        margin=dict(l=10, r=10, t=20, b=10),
        paper_bgcolor=PLOT_BG,
        font=dict(family="Inter, sans-serif", size=10),
        coloraxis_colorbar=dict(thickness=12, len=0.8),
    )
    fig.update_traces(textfont_size=9)
    st.plotly_chart(fig, use_container_width=True)

    st.divider()

    # Sortable pair table
    pt = corr.get("pair_table", pd.DataFrame())
    if len(pt):
        _sec("All Correlation Pairs  (click column header to sort)")
        st.dataframe(pt, use_container_width=True, height=300)
        _dl(pt, "Correlation Pairs CSV", "correlation_pairs.csv")

    st.divider()

    # High-corr pairs
    hcp    = corr.get("high_corr", [])
    thresh = cfg.get("corr_threshold", 0.75)
    if hcp:
        _sec(f"⚠️ High Pearson Pairs  |r| ≥ {thresh}")
        _alert("Highly correlated features → multicollinearity risk in models. Consider dropping one.", "yellow")
        hcp_df = pd.DataFrame(hcp).drop(columns=["Abs r"], errors="ignore")
        st.dataframe(hcp_df, use_container_width=True)
    else:
        _alert(f"✅ No feature pairs with |r| ≥ {thresh}", "green")

    st.divider()

    # VIF
    vif = corr.get("vif", pd.DataFrame())
    if len(vif):
        _sec("VIF — Variance Inflation Factor")
        st.caption("VIF > 10 = severe multicollinearity  |  VIF 5–10 = moderate  |  < 5 = OK")

        def _vif_color(val):
            try:
                v = float(val)
                if v > 10: return "background-color:#fee2e2; color:#991b1b; font-weight:700"
                if v > 5:  return "background-color:#fef9c3; color:#92400e"
                return "background-color:#f0fdf4; color:#166534"
            except Exception:
                return ""
        st.dataframe(
            vif.style.map(_vif_color, subset=["VIF"]),
            use_container_width=True,
        )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 7 — QUALITY SCORECARD
# ══════════════════════════════════════════════════════════════════════════════

def tab_quality(R):
    sc = R.get("scorecard", pd.DataFrame())
    if not len(sc):
        st.info("Scorecard not available.")
        return

    n_fix = int((sc["Status"] == "❌ Fix First").sum())
    n_rev = int((sc["Status"] == "⚠️ Review").sum())
    n_ok  = int((sc["Status"] == "✅ Good").sum())
    total = len(sc)

    c1,c2,c3,c4 = st.columns(4)
    c1.metric("Total Features",  total)
    c2.metric("🔴 Fix First",    n_fix)
    c3.metric("🟡 Review",       n_rev)
    c4.metric("🟢 Good",         n_ok)

    st.divider()

    # Score distribution
    _sec("Score Distribution")
    fig_hist = go.Figure()
    score_col = "Overall (0-100)"
    bins = [0,10,20,30,40,50,55,60,65,70,75,80,85,90,95,100]
    fig_hist.add_trace(go.Histogram(
        x=sc[score_col], xbins=dict(start=0, end=100, size=5),
        marker_color=[RED if x < 55 else ORANGE if x < 80 else GREEN
                      for x in sc[score_col]],
        opacity=0.88, name="Features",
    ))
    _chart(fig_hist, h=200)
    fig_hist.update_layout(
        xaxis=dict(title="Overall Score (0–100)", range=[0,103]),
        yaxis_title="# Features",
        bargap=0.05,
        shapes=[
            dict(type="line", x0=55, x1=55, y0=0, y1=1, yref="paper",
                 line=dict(color=ORANGE, dash="dash", width=1.5)),
            dict(type="line", x0=80, x1=80, y0=0, y1=1, yref="paper",
                 line=dict(color=GREEN, dash="dash", width=1.5)),
        ],
    )
    st.plotly_chart(fig_hist, use_container_width=True)
    st.markdown(
        '<span class="pill pill-red">● <55 Fix First</span>'
        '<span class="pill pill-yellow">● 55–79 Review</span>'
        '<span class="pill pill-green">● ≥80 Good</span>',
        unsafe_allow_html=True,
    )

    st.divider()

    # Scorecard table
    _sec("Feature Scorecard")
    st.caption(
        "**Weights:** Hit Rate 30% · Valid Values 20% · "
        "Skewness 15% · Category Consistency 15% · Outliers 20%"
    )

    filter_opts = st.multiselect(
        "Filter by status",
        ["❌ Fix First","⚠️ Review","✅ Good"],
        default=["❌ Fix First","⚠️ Review","✅ Good"],
    )
    df_show = sc[sc["Status"].isin(filter_opts)] if filter_opts else sc

    def _colour_status(val):
        if "Fix"    in str(val): return "color:#b91c1c; font-weight:700"
        if "Review" in str(val): return "color:#b45309; font-weight:700"
        if "Good"   in str(val): return "color:#166534; font-weight:700"
        return ""

    def _colour_score(val):
        try:
            v = float(val)
            if v >= 80: return "background-color:#dcfce7; color:#166534; font-weight:600"
            if v >= 55: return "background-color:#fef9c3; color:#a16207; font-weight:600"
            return "background-color:#fee2e2; color:#991b1b; font-weight:700"
        except Exception:
            return ""

    styled = (df_show.style
              .map(_colour_status, subset=["Status"])
              .map(_colour_score,  subset=[score_col]))
    st.dataframe(styled, use_container_width=True, height=460)
    _dl(sc, "Scorecard CSV", "scorecard.csv")

    st.divider()

    # Recommendations
    recs = R.get("recommendations", [])
    if recs:
        _sec("Recommended Actions")
        pf = st.multiselect(
            "Filter priority",
            ["❌ Fix First","⚠️ Review","✅ Good"],
            default=["❌ Fix First","⚠️ Review"],
        )
        filtered = [r for r in recs if r["Priority"] in pf]
        st.caption(f"Showing {len(filtered)} of {len(recs)} features with actions")

        for rec in filtered:
            icon = ("🔴" if "Fix" in rec["Priority"]
                    else "🟡" if "Review" in rec["Priority"] else "🟢")
            with st.expander(f"{icon} **{rec['Feature']}**  ({rec['Type']})"):
                for finding, action in rec["Items"]:
                    a, b = st.columns(2)
                    a.markdown(f"**Finding:** {finding}")
                    b.markdown(f"**Action:** `{action}`")

        rows_flat = []
        for r in recs:
            for finding, action in r["Items"]:
                rows_flat.append({"Feature":r["Feature"],"Type":r["Type"],
                                  "Priority":r["Priority"],
                                  "Finding":finding,"Action":action})
        if rows_flat:
            _dl(pd.DataFrame(rows_flat), "Recommendations CSV", "recommendations.csv")
    else:
        _alert("✅ No significant issues found.", "green")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    R = _R()
    if not R:
        st.warning("No EDA results loaded.")
        st.code("""\
from eda_toolkit import inspect, run_eda, launch_app

# Recommended 2-step workflow:
plan     = inspect(df, target_col=None)
plan.fix(SomeCol="Categorical")         # optional overrides
plan.confirm()
df_clean = plan.apply_to_df()           # cast + drop constants/unknowns
results  = run_eda(df_clean, plan)
launch_app(results)

# One-shot:
results = run_eda(df, {"target_col": None})
launch_app(results)
        """, language="python")
        return

    _sidebar(R)

    tabs = st.tabs([
        "📋 Overview",
        "🔬 Variable Explorer",
        "📊 Hit Rate",
        "🏷️ Category Quality",
        "⚡ Outliers",
        "🔗 Correlations",
        "🎯 Quality Scorecard",
    ])
    with tabs[0]: tab_overview(R)
    with tabs[1]: tab_variable_explorer(R)
    with tabs[2]: tab_hit_rate(R)
    with tabs[3]: tab_category_quality(R)
    with tabs[4]: tab_outliers(R)
    with tabs[5]: tab_correlations(R)
    with tabs[6]: tab_quality(R)


if __name__ == "__main__":
    main()
