"""
eda_engine.py — Insurance EDA Toolkit (v3)
Pure computation. No Streamlit. No external calls. 100% local.

Fixes in v3:
  BUG-1: Inf values now stripped before stats in _analyse_numeric
  BUG-2: _is_bool_strings now checks raw nunique BEFORE lowercasing
  BUG-3: Correlations now use pairwise min_periods=30 (no listwise dropna)
  BUG-4: Misleading comment removed from app.py

Improvements in v3:
  IMP-1: "Constant" type for zero-variance columns
  IMP-2: Pairwise correlation min_periods=30
  IMP-3: inf_count / inf_pct surfaced in col_results
  IMP-4: _is_bool_strings guarded on raw nunique
  IMP-5: Fuzzy matching skipped for cols with >50 unique categories
  IMP-7: Spearman/Kendall captions show % of data used
"""

import time, warnings
import numpy as np
import pandas as pd
from scipy.stats import skew as _skew, normaltest

warnings.filterwarnings("ignore")

# optional fuzzy match
try:
    from rapidfuzz import fuzz as _fuzz
    def _similarity(a, b):
        return _fuzz.token_sort_ratio(a, b) / 100.0
    _FUZZY_LIB = "rapidfuzz"
except ImportError:
    from difflib import SequenceMatcher
    def _similarity(a, b):
        return SequenceMatcher(None, a.lower(), b.lower()).ratio()
    _FUZZY_LIB = "difflib"


# ── helpers ───────────────────────────────────────────────────────────────────

def _samp(arr, n):
    if len(arr) == 0: return arr
    if len(arr) <= n: return arr
    return arr[np.random.choice(len(arr), n, replace=False)]

def _log(msg, pct=0):
    print(f"[EDA {pct:3d}%] {msg}")

def _nunique(s):
    clean = s.dropna()
    n = len(clean)
    if n == 0: return 0
    if n <= 50_000: return int(clean.nunique())
    return int(clean.sample(50_000, random_state=42).nunique())


# ── type detection ────────────────────────────────────────────────────────────

_BOOL_STRINGS = [
    {"0","1"}, {"y","n"}, {"yes","no"}, {"true","false"}, {"t","f"},
    {"1.0","0.0"}, {"male","female"}, {"m","f"},
]

def _try_parse_date(s) -> bool:
    sample = s.dropna().astype(str).head(300)
    if len(sample) < 5:
        return False
    has_sep   = sample.str.contains(r'[-/: ]', regex=True)
    has_digit = sample.str.contains(r'\d', regex=True)
    if (has_sep & has_digit).mean() < 0.7:
        return False
    try:
        p1 = pd.to_datetime(sample, errors="coerce")
        if float(p1.notna().mean()) >= 0.80:
            return True
        p2 = pd.to_datetime(sample, errors="coerce", dayfirst=True)
        return float(p2.notna().mean()) >= 0.80
    except Exception:
        return False


def _is_bool_strings(s) -> bool:
    # IMP-4 / BUG-2: check RAW unique count BEFORE lowercasing
    # Prevents Male/male/MALE/Female/female from collapsing to {male,female}
    raw_unique = s.dropna().astype(str).str.strip().unique()
    if len(raw_unique) == 0 or len(raw_unique) > 2:
        return False
    # Only lowercase-compare when there are exactly 1 or 2 raw unique values
    lower_unique = set(v.lower() for v in raw_unique)
    return lower_unique in _BOOL_STRINGS


def detect_type(s, id_ratio=0.8) -> str:
    n = len(s)
    if n == 0 or s.isna().all():
        return "Unknown"
    if pd.api.types.is_bool_dtype(s):
        return "Boolean"
    if pd.api.types.is_datetime64_any_dtype(s):
        return "Date"
    if pd.api.types.is_numeric_dtype(s):
        nu = _nunique(s)
        if nu == 0: return "Unknown"
        # IMP-1: single unique value = Constant (not Boolean)
        if nu == 1: return "Constant"
        if nu == 2: return "Boolean"
        clean = s.dropna()
        if nu <= 150:
            try:
                vals = clean.astype(float)
                if ((vals >= 1900) & (vals <= 2100)).mean() > 0.95 and \
                   (vals == vals.round(0)).mean() > 0.99:
                    return "Date"
            except Exception:
                pass
        if nu / n > id_ratio:
            try:
                if (clean.head(200) == clean.head(200).round(0)).mean() > 0.99:
                    return "ID-like"
            except Exception:
                pass
        return "Numeric"
    # IMP-4 / BUG-2 fix applied inside _is_bool_strings
    if _is_bool_strings(s):
        return "Boolean"
    nu = _nunique(s)
    if nu == 0: return "Unknown"
    if nu == 1: return "Constant"
    if _try_parse_date(s):
        return "Date"
    if nu / n > id_ratio:
        return "ID-like"
    return "Categorical"


# ── per-column analysis ───────────────────────────────────────────────────────

def _analyse_numeric(col, s, n_total, plot_n=20_000, norm_n=5_000):
    if s.dtype == object:
        _TRUE = {"1","y","yes","true","t","1.0","male","m"}
        s = pd.to_numeric(
            s.map(lambda v: 1.0 if str(v).strip().lower() in _TRUE
                  else (0.0 if pd.notna(v) else np.nan)),
            errors="coerce")
    arr = pd.to_numeric(s, errors="coerce").to_numpy(dtype=float, na_value=np.nan)
    missing  = int(np.isnan(arr).sum())
    # BUG-1 FIX: strip Inf values separately, track count
    inf_mask = np.isinf(arr)
    inf_count = int(inf_mask.sum())
    # clean = non-NaN AND non-Inf
    clean = arr[~np.isnan(arr) & ~np.isinf(arr)]
    nc    = len(clean)

    base = dict(
        dtype="Numeric",
        missing_count=missing,
        missing_pct=round(missing / n_total * 100, 1),
        hit_rate_pct=round((n_total - missing) / n_total * 100, 1),
        # IMP-3: surface Inf count
        inf_count=inf_count,
        inf_pct=round(inf_count / n_total * 100, 2),
        n_unique=0, zero_pct=0.0, dist={}, outlier={},
        plot_sample=[], zero_inflated=False, skewness=None,
    )
    if nc == 0:
        return base

    pcts = np.percentile(clean, [1, 5, 10, 25, 50, 75, 90, 95, 99])
    mean = float(clean.mean())
    std  = float(clean.std()) if nc > 1 else 0.0
    zero_pct = round(float((clean == 0).mean()) * 100, 1)
    zero_inf = zero_pct > 30
    nu = int(pd.Series(_samp(clean, 50_000)).nunique())
    base.update(n_unique=nu, zero_pct=zero_pct, zero_inflated=zero_inf)

    sk = round(float(_skew(clean)), 3) if nc > 3 else 0.0
    if not np.isfinite(sk): sk = 0.0
    base["skewness"] = sk

    pos = clean[clean > 0]
    is_ln = False
    if len(pos) > 50:
        try:
            _, lp = normaltest(np.log(_samp(pos, norm_n)))
            is_ln = bool(lp > 0.05)
        except Exception:
            pass

    tags = []
    if zero_inf:             tags.append("Zero-Inflated")
    if is_ln and sk > 0.5:  tags.append("Log-Normal")
    elif sk > 1.0:           tags.append("Right-Skewed")
    elif sk < -1.0:          tags.append("Left-Skewed")
    if not tags:             tags.append("Near-Normal")

    base["dist"] = dict(
        mean=round(mean, 4), median=round(float(pcts[4]), 4),
        std=round(std, 4),
        min=round(float(clean.min()), 4), max=round(float(clean.max()), 4),
        p25=round(float(pcts[3]), 4), p75=round(float(pcts[5]), 4),
        p95=round(float(pcts[7]), 4), p99=round(float(pcts[8]), 4),
        skewness=sk, is_lognormal=is_ln, shape=", ".join(tags),
    )

    k = 1.5
    if zero_inf:
        nz = clean[clean > 0]
        q1 = float(np.percentile(nz, 25)) if len(nz) else 0.0
        q3 = float(np.percentile(nz, 75)) if len(nz) else 0.0
        iqr      = q3 - q1
        fence_lo = 0.0
        fence_hi = round(q3 + k * iqr, 4)
        iqr_cnt  = int((clean > fence_hi).sum())
        note     = "IQR on non-zero values (zero-inflated)"
    else:
        q1, q3  = float(pcts[3]), float(pcts[5])
        iqr     = q3 - q1
        fence_lo = round(q1 - k * iqr, 4)
        fence_hi = round(q3 + k * iqr, 4)
        iqr_cnt  = int(((clean < fence_lo) | (clean > fence_hi)).sum())
        note     = ""

    base["outlier"] = dict(
        q1=round(q1, 4), q3=round(q3, 4), iqr=round(iqr, 4),
        fence_lo=fence_lo, fence_hi=fence_hi,
        iqr_count=iqr_cnt, iqr_pct=round(iqr_cnt / nc * 100, 1),
        p99_cap=round(float(pcts[8]), 4), note=note,
    )
    base["plot_sample"] = _samp(clean, plot_n).tolist()
    return base


def _analyse_categorical(col, s, n_total, rare_pct=1.0):
    missing = int(s.isna().sum())
    vc  = s.value_counts(dropna=True)
    nu  = len(vc)
    top = round(float(vc.iloc[0]) / n_total * 100, 1) if nu else 0.0

    hr = pd.DataFrame({
        "Category":   vc.index.astype(str),
        "Count":      vc.values,
        "Share %":    (vc.values / n_total * 100).round(1),
    }).head(30)
    hr["Flag"] = hr["Share %"].apply(
        lambda x: "RARE" if x < rare_pct else ("DOMINANT" if x > 80 else ""))

    return dict(
        dtype="Categorical",
        missing_count=missing,
        missing_pct=round(missing / n_total * 100, 1),
        hit_rate_pct=round((n_total - missing) / n_total * 100, 1),
        inf_count=0, inf_pct=0.0,
        n_unique=nu, top_val_pct=top,
        category_table=hr,
        rare_count=int((hr["Flag"] == "RARE").sum()),
        dist={}, outlier={}, plot_sample=[], zero_inflated=False,
        skewness=None,
    )


# ── correlations (large-data optimised) ───────────────────────────────────────

def _correlations(df, corr_sample=100_000, threshold=0.75, max_vars=30):
    num = df.select_dtypes(include=[np.number]).columns.tolist()
    out = dict(
        pearson=pd.DataFrame(), spearman=pd.DataFrame(), kendall=pd.DataFrame(),
        high_corr=[], pair_table=pd.DataFrame(), vif=pd.DataFrame(),
        n_vars=0, sampled=False, sample_size=0,
        total_rows=len(df),
    )
    if len(num) < 2:
        return out

    # Limit to top-variance variables
    if len(num) > max_vars:
        var_series = df[num].var().sort_values(ascending=False)
        num_top = var_series.head(max_vars).index.tolist()
    else:
        num_top = num

    out["n_vars"] = len(num_top)

    # BUG-3 / IMP-2 FIX: pairwise correlation with min_periods=30
    # Sample for speed on large data, but compute pairwise (not listwise)
    df_num = df[num_top]
    if len(df_num) > corr_sample:
        df_samp = df_num.sample(corr_sample, random_state=42)
        out["sampled"] = True
    else:
        df_samp = df_num
        out["sampled"] = False
    out["sample_size"] = len(df_samp)

    # Pearson pairwise
    try:
        pearson_mat = df_samp.corr(method="pearson", min_periods=30).round(3)
    except Exception:
        pearson_mat = df_samp.corr(method="pearson").round(3)
    out["pearson"] = pearson_mat

    # high-corr pairs
    C    = pearson_mat.values
    cols = pearson_mat.columns.tolist()
    pairs = []
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            v = C[i, j]
            if np.isnan(v): continue
            r = round(float(v), 3)
            if abs(r) >= threshold:
                pairs.append({"Feature A": cols[i], "Feature B": cols[j],
                              "Pearson r": r, "Abs r": abs(r)})
    out["high_corr"] = sorted(pairs, key=lambda x: x["Abs r"], reverse=True)

    # Spearman on sample (same sample as pearson for consistency)
    spear_n  = min(50_000, len(df_samp))
    df_sp    = df_samp.sample(spear_n, random_state=42) if len(df_samp) > spear_n else df_samp
    k_n      = min(10_000, len(df_sp))
    df_kd    = df_sp.head(k_n)

    # IMP-7: store raw counts and pct for UI display
    out["spearman_sample_n"]  = len(df_sp)
    out["kendall_sample_n"]   = len(df_kd)
    out["spearman_sample_pct"] = round(len(df_sp) / len(df_num) * 100, 1)
    out["kendall_sample_pct"]  = round(len(df_kd) / len(df_num) * 100, 1)

    try:
        out["spearman"] = df_sp.corr(method="spearman", min_periods=30).round(3)
    except Exception:
        try:
            out["spearman"] = df_sp.corr(method="spearman").round(3)
        except Exception:
            pass

    try:
        out["kendall"] = df_kd.corr(method="kendall", min_periods=30).round(3)
    except Exception:
        try:
            out["kendall"] = df_kd.corr(method="kendall").round(3)
        except Exception:
            pass

    # Sortable pair table
    pair_rows = []
    spear_mat = out["spearman"]
    kend_mat  = out["kendall"]
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            pv = pearson_mat.iloc[i, j]
            if np.isnan(pv): continue
            row = {"Variable A": cols[i], "Variable B": cols[j],
                   "Pearson": round(float(pv), 3)}
            if len(spear_mat):
                sv = spear_mat.iloc[i, j]
                row["Spearman"] = round(float(sv), 3) if not np.isnan(sv) else None
            if len(kend_mat):
                kv = kend_mat.iloc[i, j]
                row["Kendall"] = round(float(kv), 3) if not np.isnan(kv) else None
            row["_abs"] = abs(row["Pearson"])
            pair_rows.append(row)
    if pair_rows:
        out["pair_table"] = (pd.DataFrame(pair_rows)
                             .sort_values("_abs", ascending=False)
                             .drop(columns=["_abs"])
                             .reset_index(drop=True))

    # VIF
    try:
        from sklearn.linear_model import LinearRegression
        vcols = num_top[:15]
        X = df[vcols].fillna(df[vcols].median()).values[:20_000].astype(float)
        vifs = []
        for i in range(len(vcols)):
            yi = X[:, i]
            Xi = np.delete(X, i, axis=1)
            r2 = LinearRegression().fit(Xi, yi).score(Xi, yi)
            vifs.append(round(1 / (1 - r2) if r2 < 0.9999 else 999.0, 1))
        vdf = pd.DataFrame({"Feature": vcols, "VIF": vifs}).sort_values("VIF", ascending=False)
        vdf["Flag"] = vdf["VIF"].apply(
            lambda v: "HIGH>10" if v > 10 else ("MOD 5-10" if v > 5 else "OK"))
        out["vif"] = vdf
    except Exception:
        pass

    return out


# ── fuzzy category matching ───────────────────────────────────────────────────

def _fuzzy_categories(col_results, threshold=0.85, max_categories=50):
    # IMP-5: skip columns with >50 unique categories (high-cardinality not actionable)
    results = {}
    for col, res in col_results.items():
        if res["dtype"] != "Categorical":
            continue
        tbl = res.get("category_table", pd.DataFrame())
        nu  = res.get("n_unique", 0)
        if len(tbl) < 2:
            continue
        # IMP-5: skip high-cardinality columns
        if nu > max_categories:
            results[col] = []   # empty list = skipped, UI can show note
            continue
        cats = tbl["Category"].astype(str).tolist()[:max_categories]
        matches = []
        for i in range(len(cats)):
            for j in range(i + 1, len(cats)):
                # exact case duplicate
                if cats[i].lower() == cats[j].lower():
                    matches.append({"Category A": cats[i], "Category B": cats[j],
                                    "Similarity": 1.0})
                else:
                    sim = _similarity(cats[i], cats[j])
                    if sim >= threshold:
                        matches.append({"Category A": cats[i], "Category B": cats[j],
                                        "Similarity": round(sim, 3)})
        if matches:
            results[col] = sorted(matches, key=lambda x: -x["Similarity"])
    return results


# ── scorecard (enhanced numeric 0-100) ───────────────────────────────────────

def _scorecard(col_results, corr, fuzzy):
    hm = corr.get("pearson", pd.DataFrame())
    max_r = {}
    if len(hm):
        for c in hm.columns:
            vals = hm[c].drop(c, errors="ignore").abs()
            max_r[c] = round(float(vals.max()), 3) if len(vals) else 0.0

    rows = []
    for col, res in col_results.items():
        dtype = res["dtype"]
        mp    = res["missing_pct"]
        dist  = res.get("dist", {})
        outl  = res.get("outlier", {})
        zi    = res.get("zero_inflated", False)
        nu    = res.get("n_unique", 0)

        # Hit Rate
        hit_rate = res["hit_rate_pct"]
        if hit_rate >= 99:    hr_score = 100
        elif hit_rate >= 90:  hr_score = 80
        elif hit_rate >= 75:  hr_score = 55
        elif hit_rate >= 50:  hr_score = 30
        else:                 hr_score = 5
        hr_label = f"{hit_rate:.1f}%"

        # Valid Values — IMP-3: penalise Inf values too
        inf_pct = res.get("inf_pct", 0.0)
        if dtype in ("Numeric", "Boolean"):
            zero_pct = res.get("zero_pct", 0)
            if zero_pct >= 99 or inf_pct > 5:  vv_score = 10
            elif zero_pct >= 50:               vv_score = 60
            elif zero_pct >= 30:               vv_score = 75
            else:                              vv_score = 100
            if inf_pct > 0:
                vv_label = f"{inf_pct:.1f}% Inf" if zero_pct == 0 else f"{zero_pct:.0f}% zeros, {inf_pct:.1f}% Inf"
            else:
                vv_label = f"{zero_pct:.0f}% zeros" if zero_pct > 0 else "OK"
        elif dtype == "Categorical":
            rare = res.get("rare_count", 0)
            tbl  = res.get("category_table", pd.DataFrame())
            dom  = float(tbl["Share %"].max()) if len(tbl) else 0
            if dom >= 99:    vv_score = 20
            elif dom >= 90:  vv_score = 60
            elif rare > 5:   vv_score = 70
            elif rare > 0:   vv_score = 85
            else:            vv_score = 100
            vv_label = f"Dom {dom:.0f}%" if dom >= 80 else (f"{rare} rare cats" if rare else "OK")
        elif dtype == "Constant":
            vv_score = 0; vv_label = "Constant — zero variance"
        else:
            vv_score = 80; vv_label = "—"

        # Skewness
        sk = dist.get("skewness", 0) if dist else 0
        sk = float(sk) if sk is not None and np.isfinite(float(sk if sk is not None else 0)) else 0.0
        if dtype == "Numeric":
            ask = abs(sk)
            if ask < 0.5:    sk_score = 100; sk_label = f"Low ({sk:.2f})"
            elif ask < 1.0:  sk_score = 80;  sk_label = f"Mod ({sk:.2f})"
            elif ask < 2.0:  sk_score = 55;  sk_label = f"High ({sk:.2f})"
            else:            sk_score = 25;  sk_label = f"V.High ({sk:.2f})"
        else:
            sk_score = 100; sk_label = "—"

        # Category Consistency
        if dtype == "Categorical":
            fuzzy_matches = fuzzy.get(col, [])
            n_matches = len(fuzzy_matches)
            # IMP-5: empty list means skipped (high cardinality)
            if nu > 50:
                cc_score = 100; cc_label = "Skipped (high-card)"
            elif n_matches == 0:   cc_score = 100; cc_label = "Clean"
            elif n_matches <= 2:   cc_score = 70;  cc_label = f"{n_matches} similar"
            elif n_matches <= 5:   cc_score = 45;  cc_label = f"{n_matches} similar"
            else:                  cc_score = 20;  cc_label = f"{n_matches} similar"
        else:
            cc_score = 100; cc_label = "—"

        # Outlier Score
        iqr_p = outl.get("iqr_pct", 0) if dtype in ("Numeric", "Boolean") else None
        if iqr_p is None:
            ol_score = 100; ol_label = "—"
        elif dtype == "Constant":
            ol_score = 0; ol_label = "Constant"
        elif zi:
            ol_score = 50; ol_label = "Zero-Inf"
        elif iqr_p < 1:    ol_score = 100; ol_label = f"Low ({iqr_p:.1f}%)"
        elif iqr_p < 3:    ol_score = 80;  ol_label = f"Med ({iqr_p:.1f}%)"
        elif iqr_p < 8:    ol_score = 55;  ol_label = f"High ({iqr_p:.1f}%)"
        else:              ol_score = 25;  ol_label = f"V.High ({iqr_p:.1f}%)"

        # Constant override — always red
        if dtype == "Constant":
            hr_score = 100; vv_score = 0; sk_score = 0; cc_score = 0; ol_score = 0

        # Overall (weighted)
        overall = round(
            0.30 * hr_score +
            0.20 * vv_score +
            0.15 * sk_score +
            0.15 * cc_score +
            0.20 * ol_score, 1)

        if overall >= 80:   rag = "✅ Good";      pri = 2
        elif overall >= 55: rag = "⚠️ Review";    pri = 1
        else:               rag = "❌ Fix First"; pri = 0

        type_icon = {
            "Numeric":"🔢","Categorical":"🏷️","Boolean":"☑️",
            "Date":"📅","ID-like":"🔑","Unknown":"❓","Constant":"🔒",
        }.get(dtype, "❓")

        rows.append({
            "Feature": col,
            "Type": f"{type_icon} {dtype}",
            "Hit Rate": hr_label,
            "Valid Values": vv_label,
            "Skewness": sk_label,
            "Cat Consistency": cc_label,
            "Outlier Score": ol_label,
            "Overall (0-100)": overall,
            "Status": rag,
            "_hr": hr_score, "_vv": vv_score, "_sk": sk_score,
            "_cc": cc_score, "_ol": ol_score, "_p": pri,
        })

    df_sc = pd.DataFrame(rows)
    if len(df_sc):
        df_sc = (df_sc.sort_values(["_p", "Overall (0-100)"])
                      .drop(columns=["_hr","_vv","_sk","_cc","_ol","_p"])
                      .reset_index(drop=True))
    return df_sc


# ── recommendations ───────────────────────────────────────────────────────────

def _recommendations(col_results, scorecard):
    score_map = {r["Feature"]: r["Status"] for _, r in scorecard.iterrows()} if len(scorecard) else {}
    recs = []

    for col, res in col_results.items():
        dtype = res["dtype"]
        mp    = res["missing_pct"]
        dist  = res.get("dist", {})
        outl  = res.get("outlier", {})
        zi    = res.get("zero_inflated", False)
        nu    = res.get("n_unique", 0)
        inf_p = res.get("inf_pct", 0.0)
        items = []

        if mp >= 100 or dtype == "Unknown":
            items.append(("Column entirely null", "Drop or investigate data pipeline"))
        elif dtype == "Constant":
            items.append(("Zero-variance constant column", "Drop before modelling — carries no information"))
        elif dtype == "Numeric":
            sk = dist.get("skewness", 0) if dist else 0
            if inf_p > 0:
                items.append((f"{inf_p:.2f}% Inf values detected",
                               "Investigate source; replace or cap Inf before modelling"))
            if zi:
                items.append((f"Zero-inflated ({res.get('zero_pct',0):.0f}% zeros)",
                               "Two-part model (logistic + Gamma) or Tweedie GLM"))
            if dist.get("is_lognormal") and sk > 0.5:
                items.append(("Log-normal distribution", "Apply log1p transform before modelling"))
            elif abs(sk) > 1.5 and not zi:
                items.append((f"Highly skewed (skew={sk:.1f})", "Apply log1p transform"))
            if not zi and outl.get("iqr_pct", 0) > 5:
                p99 = outl.get("p99_cap", "?")
                items.append((f"{outl['iqr_pct']:.1f}% outliers by IQR", f"Cap at P99 = {p99}"))
            if mp > 20:
                items.append((f"High missing ({mp:.0f}%)", f"Add {col}_missing flag + median impute"))
            elif mp > 0:
                items.append((f"Missing {mp:.0f}%", "Median imputation"))
            if nu <= 5 and nu > 0:
                items.append(("Very few unique values", "Treat as categorical / ordinal"))
        elif dtype == "Categorical":
            if res.get("rare_count", 0) > 0:
                items.append((f"{res['rare_count']} rare categories (<1%)", "Group into 'Other'"))
            if nu > 50:
                items.append((f"High cardinality ({nu} categories)", "Target encode or frequency encode"))
            if mp > 0:
                items.append((f"Missing {mp:.0f}%", "Create 'Unknown' category, do not drop"))
        elif dtype == "ID-like":
            items.append(("ID column — unique per row", "Exclude from modelling entirely"))
        elif dtype == "Date":
            items.append(("Date column", "Extract year, month, quarter, day-of-week"))

        if not items:
            continue
        recs.append(dict(Feature=col, Type=dtype,
                         Priority=score_map.get(col, "✅ Good"),
                         Items=items))

    order = {"❌ Fix First": 0, "⚠️ Review": 1, "✅ Good": 2}
    recs.sort(key=lambda r: order.get(r["Priority"], 3))
    return recs


# ── master ────────────────────────────────────────────────────────────────────

def run_eda(df, config):
    t0          = time.time()
    n           = len(df)
    target      = config.get("target_col")
    feats       = [c for c in df.columns if c != target]
    corr_sample = config.get("corr_sample", 100_000)
    corr_thresh = config.get("corr_threshold", 0.75)
    rare_pct    = config.get("rare_cat_pct", 1.0)
    plot_n      = config.get("plot_sample", 20_000)
    norm_n      = config.get("norm_sample", 5_000)
    id_ratio    = config.get("id_ratio", 0.8)
    max_corr    = config.get("max_corr_vars", 30)

    _log(f"EDA — {len(feats)} features × {n:,} rows", 0)

    _log("Detecting types...", 5)
    dtype_map = {c: detect_type(df[c], id_ratio) for c in feats}

    overrides = config.get("dtype_overrides", {})
    for col, forced_type in overrides.items():
        if col in dtype_map:
            dtype_map[col] = forced_type

    _log("Analysing columns...", 15)
    col_results = {}
    for i, col in enumerate(feats):
        dtype = dtype_map[col]
        try:
            if dtype in ("Numeric", "Boolean"):
                s = df[col]
                if dtype == "Boolean" and s.dtype == object:
                    s = s.map(lambda v: 1.0 if str(v).strip().lower() in
                              {"1","y","yes","true","t","1.0","male","m"} else
                              (0.0 if pd.notna(v) else np.nan))
                col_results[col] = _analyse_numeric(col, s, n, plot_n, norm_n)
            elif dtype == "Unknown":
                col_results[col] = dict(
                    dtype="Unknown",
                    missing_count=int(df[col].isna().sum()),
                    missing_pct=round(df[col].isna().mean()*100, 1),
                    hit_rate_pct=round((1-df[col].isna().mean())*100, 1),
                    inf_count=0, inf_pct=0.0,
                    n_unique=0, zero_pct=0, dist={}, outlier={},
                    plot_sample=[], zero_inflated=False, skewness=None)
            elif dtype == "Constant":
                col_results[col] = dict(
                    dtype="Constant",
                    missing_count=int(df[col].isna().sum()),
                    missing_pct=round(df[col].isna().mean()*100, 1),
                    hit_rate_pct=round((1-df[col].isna().mean())*100, 1),
                    inf_count=0, inf_pct=0.0,
                    n_unique=1,
                    constant_value=str(df[col].dropna().iloc[0]) if df[col].notna().any() else "NaN",
                    zero_pct=0, dist={}, outlier={},
                    plot_sample=[], zero_inflated=False, skewness=None)
            else:
                col_results[col] = _analyse_categorical(col, df[col], n, rare_pct)
        except Exception as e:
            print(f"  [WARN] {col}: {e}")
            col_results[col] = dict(dtype=dtype, missing_count=0, missing_pct=0,
                hit_rate_pct=100, inf_count=0, inf_pct=0.0,
                n_unique=0, zero_pct=0, dist={}, outlier={},
                plot_sample=[], zero_inflated=False, skewness=None)
        pct = 15 + int((i + 1) / len(feats) * 35)
        if (i + 1) % max(1, len(feats) // 8) == 0 or i + 1 == len(feats):
            _log(f"Features {i+1}/{len(feats)}", pct)

    _log("Correlations...", 52)
    corr = _correlations(df[feats], corr_sample, corr_thresh, max_corr)

    _log("Fuzzy category matching...", 62)
    fuzzy = _fuzzy_categories(col_results)

    _log("Scorecard...", 72)
    sc = _scorecard(col_results, corr, fuzzy)

    _log("Recommendations...", 82)
    recs = _recommendations(col_results, sc)

    # Grouped report
    det = pd.DataFrame()
    if config.get("groupby_col") and config.get("agg_config"):
        _log("Grouped report...", 90)
        gb  = config["groupby_col"]
        agg = {c: f for c, f in config["agg_config"].items() if c in df.columns}
        if gb in df.columns and agg:
            try:
                r = df.groupby(gb).agg(agg)
                r.columns = ["_".join(c) for c in r.columns]
                det = r.reset_index().sort_values(gb)
            except Exception as e:
                print(f"  [WARN] Grouped report: {e}")

    elapsed = round(time.time() - t0, 1)
    _log(f"Done in {elapsed}s", 100)

    return dict(
        df=df, config=config, feature_cols=feats, dtype_map=dtype_map,
        n_rows=n, n_features=len(feats), elapsed_sec=elapsed, target_col=target,
        col_results=col_results, correlations=corr,
        fuzzy_categories=fuzzy, scorecard=sc,
        recommendations=recs, grouped_report=det,
    )
