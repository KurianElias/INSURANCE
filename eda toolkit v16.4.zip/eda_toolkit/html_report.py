"""
html_report.py — Insurance EDA Toolkit
Generates a fully self-contained interactive HTML dashboard from run_eda() results.
No server, no Streamlit, no ports. Works in Databricks via displayHTML(), offline,
or as a standalone .html file.

Usage:
    from eda_toolkit import generate_report

    results = run_eda(df_clean, plan)

    # Render inline (Databricks / Jupyter)
    html = generate_report(results)
    displayHTML(html)                          # Databricks
    # or: from IPython.display import HTML, display; display(HTML(html))

    # Save to file (opens in browser automatically)
    generate_report(results, output_path="eda_report.html")

    # Save only, don't open browser
    generate_report(results, output_path="eda_report.html", open_browser=False)
"""

from __future__ import annotations
import json, os, math, webbrowser
from pathlib import Path
import numpy as np
import pandas as pd

# ─────────────────────────────────────────────────────────────────────────────
# Colour palette  (matches Streamlit app)
# ─────────────────────────────────────────────────────────────────────────────
_C = dict(
    accent="#6366f1", cyan="#06b6d4", red="#ef4444",
    orange="#f59e0b", green="#22c55e", purple="#7c3aed",
    grid="#e5e7ef",
)

def _jc(v):
    """Safe JSON colour."""
    return v

# ─────────────────────────────────────────────────────────────────────────────
# Tiny JSON helpers
# ─────────────────────────────────────────────────────────────────────────────

class _NpEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (np.integer,)):   return int(o)
        if isinstance(o, (np.floating,)):  return float(o)
        if isinstance(o, np.ndarray):      return o.tolist()
        if isinstance(o, pd.Timestamp):    return str(o)
        if pd.isna(o):                     return None
        return super().default(o)

def _j(obj):
    return json.dumps(obj, cls=_NpEncoder, separators=(",", ":"))

def _safe_float(v, default=0.0):
    try:    return float(v)
    except: return default

def _fmt_num(v):
    """Format a number nicely for display."""
    try:
        f = float(v)
        if abs(f) >= 1_000_000: return f"{f/1_000_000:.3f}M"
        if abs(f) >= 1_000:     return f"{f:,.2f}"
        return f"{f:.4g}"
    except: return str(v)

# ─────────────────────────────────────────────────────────────────────────────
# Plotly figure → JSON (self-contained, no CDN data)
# ─────────────────────────────────────────────────────────────────────────────

def _fig_json(fig, height=320):
    """Return the Plotly figure as a compact JSON string for embedding."""
    try:
        import plotly.graph_objects as go
        fig.update_layout(
            height=height,
            margin=dict(l=30, r=20, t=36, b=40),
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(family="'DM Sans', sans-serif", size=11, color="#374151"),
            legend=dict(bgcolor="rgba(0,0,0,0)", font_size=10),
        )
        fig.update_xaxes(gridcolor=_C["grid"], linecolor=_C["grid"], zerolinecolor=_C["grid"])
        fig.update_yaxes(gridcolor=_C["grid"], linecolor=_C["grid"], zerolinecolor=_C["grid"])
        return fig.to_json()
    except Exception as e:
        return "{}"

# ─────────────────────────────────────────────────────────────────────────────
# HTML helpers
# ─────────────────────────────────────────────────────────────────────────────

def _esc(s):
    """HTML-escape a string."""
    return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"','&quot;')

def _badge(text, kind="blue"):
    colours = {
        "red":    ("fee2e2","991b1b"),
        "orange": ("fef3c7","b45309"),
        "green":  ("dcfce7","166534"),
        "blue":   ("dbeafe","1d4ed8"),
        "purple": ("ede9fe","5b21b6"),
        "cyan":   ("cffafe","0e7490"),
        "grey":   ("f1f5f9","475569"),
    }
    bg, fg = colours.get(kind, colours["blue"])
    return f'<span class="badge" style="background:#{bg};color:#{fg}">{_esc(text)}</span>'

def _pill(label, colour):
    return f'<span class="pill" style="background:{colour}20;color:{colour}">{_esc(label)}</span>'

def _metric(label, value, sub=""):
    sub_html = f'<div class="metric-sub">{_esc(str(sub))}</div>' if sub else ""
    return f'''<div class="metric-card">
  <div class="metric-val">{_esc(str(value))}</div>
  <div class="metric-label">{_esc(label)}</div>
  {sub_html}
</div>'''

def _table(df, row_fn=None, id_="", cls=""):
    """Render a DataFrame as a styled HTML table with optional per-row styling."""
    if df is None or not len(df):
        return '<p class="empty">No data.</p>'
    tid = f' id="{id_}"' if id_ else ""
    tcls = f'data-table{(" " + cls) if cls else ""}'
    rows = []
    for _, row in df.iterrows():
        cells = []
        for col in df.columns:
            val = row[col]
            style = ""
            if row_fn:
                style = row_fn(col, val, row)
            disp = _esc(str(val)) if not pd.isna(val) else "—"
            cells.append(f'<td style="{style}">{disp}</td>')
        rows.append(f'<tr>{"".join(cells)}</tr>')
    headers = "".join(f'<th data-col="{_esc(c)}">{_esc(c)}</th>' for c in df.columns)
    return f'''<div class="table-wrap">
<table{tid} class="{tcls}">
  <thead><tr>{headers}</tr></thead>
  <tbody>{"".join(rows)}</tbody>
</table></div>'''

def _alert(msg, kind="yellow"):
    colours = {"red":"#fee2e2:#b91c1c:#ef4444","yellow":"#fffbeb:#78350f:#f59e0b",
               "blue":"#eff6ff:#1e3a5f:#3b82f6","green":"#f0fdf4:#14532d:#22c55e",
               "purple":"#f5f3ff:#3b0764:#7c3aed"}
    parts = colours.get(kind,"#fffbeb:#78350f:#f59e0b").split(":")
    bg,fg,bd = parts[0], parts[1], parts[2]
    return f'<div class="alert" style="background:{bg};color:{fg};border-left:3px solid {bd}">{msg}</div>'

def _sec(title):
    return f'<h3 class="sec-head">{_esc(title)}</h3>'

def _divider():
    return '<hr class="divider">'

def _chart_div(fig_json, div_id, height=320):
    """Emit a <div> that Plotly will render into, plus a data attribute with the figure JSON."""
    return (f'<div id="{div_id}" class="plotly-chart" data-height="{height}" '
            f'data-fig=\'{fig_json}\'></div>')

def _collapsible(title, content, open_=False):
    attr = " open" if open_ else ""
    return f'<details class="collapsible"{attr}><summary>{_esc(title)}</summary><div class="collapsible-body">{content}</div></details>'

# ─────────────────────────────────────────────────────────────────────────────
# Per-section generators
# ─────────────────────────────────────────────────────────────────────────────

def _sec_overview(R):
    cr    = R.get("col_results", {})
    dm    = R.get("dtype_map", {})
    n_rows= R.get("n_rows", 0)
    n_feat= R.get("n_features", 0)
    target= R.get("target_col")
    cfg   = R.get("config", {})

    n_num   = sum(1 for t in dm.values() if t in ("Numeric","Boolean"))
    n_cat   = sum(1 for t in dm.values() if t == "Categorical")
    t_cells = n_rows * n_feat
    t_miss  = sum(v["missing_count"] for v in cr.values())
    miss_pct= round(t_miss / t_cells * 100, 2) if t_cells else 0

    html = '<div class="metrics-row">'
    html += _metric("Total Rows",      f"{n_rows:,}")
    html += _metric("Columns",         n_feat)
    html += _metric("Numeric / Bool",  n_num)
    html += _metric("Categorical",     n_cat)
    html += _metric("Overall Missing", f"{miss_pct:.1f}%")
    html += '</div>'

    if target:
        html += f'<p class="caption">🎯 Target column: <strong>{_esc(target)}</strong> (excluded from feature analysis)</p>'

    html += _divider()

    # ── Type donut + Missing bar ──────────────────────────────────────────────
    try:
        import plotly.graph_objects as go
        import plotly.express as px

        html += '<div class="two-col">'

        # Donut
        tc = pd.Series(dm).value_counts().reset_index()
        tc.columns = ["Type","Count"]
        col_map = {"Numeric":_C["accent"],"Categorical":_C["cyan"],"Boolean":_C["orange"],
                   "Date":"#10b981","ID-like":"#94a3b8","Unknown":"#e5e7ef","Constant":_C["red"]}
        colors = [col_map.get(t,"#94a3b8") for t in tc["Type"]]
        fig_donut = go.Figure(go.Pie(
            labels=tc["Type"], values=tc["Count"], hole=0.55,
            marker=dict(colors=colors),
            textposition="inside", textinfo="percent+label", textfont_size=10,
        ))
        fig_donut.update_layout(showlegend=False)
        html += f'<div><h3 class="sec-head">Column Type Distribution</h3>{_chart_div(_fig_json(fig_donut, 280), "ov-donut", 280)}</div>'

        # Missing bar
        miss_data = [(col, res["missing_pct"]) for col, res in cr.items() if res["missing_pct"] > 0]
        if miss_data:
            mdf = pd.DataFrame(miss_data, columns=["Feature","Missing %"]).sort_values("Missing %")
            bar_c = [_C["red"] if v >= 30 else _C["orange"] if v >= 10 else _C["accent"] for v in mdf["Missing %"]]
            fig_miss = go.Figure(go.Bar(
                x=mdf["Missing %"], y=mdf["Feature"], orientation="h",
                marker_color=bar_c,
                text=mdf["Missing %"].apply(lambda v: f"{v:.1f}%"),
                textposition="inside", textfont_color="white", textfont_size=9,
            ))
            fig_miss.update_layout(
                xaxis=dict(range=[0,100], title="Missing %"),
                yaxis_title="",
            )
            html += f'<div><h3 class="sec-head">Missing Value Overview</h3>{_chart_div(_fig_json(fig_miss, max(280, len(mdf)*22)), "ov-miss", max(280, len(mdf)*22))}</div>'
        else:
            html += f'<div><h3 class="sec-head">Missing Value Overview</h3>{_alert("✅ No missing values in any column.", "green")}</div>'

        html += '</div>'  # two-col

    except ImportError:
        html += _alert("Install plotly for charts: pip install plotly", "yellow")

    html += _divider()

    # ── Feature table ─────────────────────────────────────────────────────────
    html += _sec("All Features at a Glance")
    rows = []
    for col, res in cr.items():
        dtype = res["dtype"]
        dist  = res.get("dist", {})
        sk    = res.get("skewness")
        inf_p = res.get("inf_pct", 0.0)
        mean_top = (f"{dist['mean']:.4g}" if dist and dtype == "Numeric"
                    else (str(res.get("category_table", pd.DataFrame()).iloc[0]["Category"])[:20]
                          if dtype == "Categorical" and len(res.get("category_table", pd.DataFrame()))
                          else res.get("constant_value", "—") if dtype == "Constant" else "—"))
        rows.append({
            "Feature":    col,
            "Type":       dtype,
            "Missing %":  res["missing_pct"],
            "Hit Rate %": res["hit_rate_pct"],
            "Unique":     res["n_unique"],
            "Mean / Top": mean_top,
            "Skewness":   round(sk, 3) if sk is not None else "—",
            "Zero %":     res.get("zero_pct", 0),
            "Inf %":      round(inf_p, 2),
        })
    feat_df = pd.DataFrame(rows)

    def _feat_row_style(col, val, row):
        if col == "Missing %":
            v = _safe_float(val)
            if v >= 30:  return "background:#fee2e2;color:#991b1b"
            if v >= 10:  return "background:#fef9c3;color:#a16207"
            if v > 0:    return "background:#fffbeb;color:#78350f"
            return "background:#dcfce7;color:#166534"
        if col == "Hit Rate %":
            v = _safe_float(val)
            if v >= 95:  return "background:#dcfce7;color:#166534;font-weight:600"
            if v >= 75:  return "background:#fef9c3;color:#a16207"
            return "background:#fee2e2;color:#991b1b"
        if col == "Type":
            dtype_colors = {"Numeric":_C["accent"],"Categorical":_C["cyan"],"Boolean":_C["orange"],
                            "Date":"#10b981","ID-like":"#94a3b8","Constant":_C["red"],"Unknown":"#94a3b8"}
            c = dtype_colors.get(str(val), "#94a3b8")
            return f"color:{c};font-weight:600"
        return ""

    html += _table(feat_df, _feat_row_style, id_="feat-table", cls="searchable sortable")
    html += '''<div class="table-controls">
  <input type="text" class="table-search" data-target="feat-table" placeholder="🔍 Search features…">
</div>'''

    return html


def _sec_variable_explorer(R):
    cr     = R.get("col_results", {})
    target = R.get("target_col")
    if not cr:
        return _alert("No features analysed.", "yellow")

    try:
        import plotly.graph_objects as go
    except ImportError:
        return _alert("Install plotly for Variable Explorer charts.", "yellow")

    # Build all variable panels upfront; JS shows/hides on select
    options_html = "".join(f'<option value="var_{i}">{_esc(col)}</option>'
                           for i, col in enumerate(cr.keys()))

    panels = []
    for i, (col, res) in enumerate(cr.items()):
        dtype  = res["dtype"]
        dist   = res.get("dist", {})
        inf_p  = res.get("inf_pct", 0.0)
        sample = res.get("plot_sample", [])
        outl   = res.get("outlier", {})

        p = f'<div id="var_{i}" class="var-panel" style="display:none">'
        p += f'<h3 class="var-title">{_esc(col)} <span class="var-dtype">{_esc(dtype)}</span></h3>'

        # ── NUMERIC / BOOLEAN ──────────────────────────────────────────────────
        if dtype in ("Numeric", "Boolean") and dist:
            p += '<div class="metrics-row">'
            for label, key in [("Mean","mean"),("Median","median"),("Std","std"),
                                ("Min","min"),("Max","max"),("Skewness","skewness")]:
                val = dist.get(key)
                p += _metric(label, f"{val:.4g}" if val is not None else "—")
            p += _metric("Missing %", f"{res['missing_pct']:.1f}%")
            p += _metric("Zero %",    f"{res.get('zero_pct',0):.1f}%")
            p += '</div>'

            sk = dist.get("skewness", 0) or 0
            if inf_p > 0:    p += _alert(f"🔴 {inf_p:.2f}% Inf values detected and excluded from stats", "red")
            if abs(sk) > 2:  p += _alert(f"⚠️ Very high skewness ({sk:.2f}) — consider log1p transform", "red")
            elif abs(sk) > 1:p += _alert(f"⚠️ High skewness ({sk:.2f})", "yellow")
            if res["missing_pct"] > 20: p += _alert(f"⚠️ Sparse — {res['missing_pct']:.1f}% missing", "red")
            elif res["missing_pct"] > 5: p += _alert(f"ℹ️ {res['missing_pct']:.1f}% missing", "yellow")
            if res.get("zero_inflated"): p += _alert("ℹ️ Zero-inflated: >30% zeros — consider two-part model", "blue")
            if dist:
                p += f'<p class="caption">Shape: <strong>{_esc(dist.get("shape","—"))}</strong> · P25={dist.get("p25","—")} P75={dist.get("p75","—")} P95={dist.get("p95","—")} P99={dist.get("p99","—")}</p>'

            if sample:
                arr = [x for x in sample if x is not None and not (isinstance(x, float) and math.isnan(x))]
                arr_sorted = sorted(arr)

                # Linear histogram
                fig_lin = go.Figure()
                fig_lin.add_trace(go.Histogram(x=arr, nbinsx=60, name="Distribution",
                    marker_color=_C["accent"], opacity=0.85,
                    marker_line=dict(width=0.3, color="#fff")))
                if dist:
                    fig_lin.add_vline(x=dist["mean"],   line_dash="dash", line_color=_C["orange"],
                                      annotation_text="Mean",   annotation_font_size=10)
                    fig_lin.add_vline(x=dist["median"], line_dash="dot",  line_color=_C["green"],
                                      annotation_text="Median", annotation_font_size=10)
                fig_lin.update_layout(title=dict(text=f"Distribution — {col}", font_size=13),
                                      xaxis_title=col, yaxis_title="Count", bargap=0.02)

                # Log histogram (pre-computed, toggled by JS)
                fig_log = go.Figure()
                fig_log.add_trace(go.Histogram(x=arr, nbinsx=60, name="Distribution",
                    marker_color=_C["accent"], opacity=0.85,
                    marker_line=dict(width=0.3, color="#fff")))
                if dist:
                    fig_log.add_vline(x=dist["mean"],   line_dash="dash", line_color=_C["orange"])
                    fig_log.add_vline(x=dist["median"], line_dash="dot",  line_color=_C["green"])
                fig_log.update_layout(yaxis_type="log", title=dict(text=f"Distribution (Log Y) — {col}", font_size=13),
                                      xaxis_title=col, yaxis_title="Count (log)", bargap=0.02)

                p += f'''<div class="scale-toggle">
  <button class="scale-btn active" onclick="toggleScale(this,'vex_lin_{i}','vex_log_{i}')">Linear</button>
  <button class="scale-btn" onclick="toggleScale(this,'vex_log_{i}','vex_lin_{i}')">Log</button>
</div>'''
                p += f'<div id="vex_lin_{i}">{_chart_div(_fig_json(fig_lin), f"vchart_lin_{i}")}</div>'
                p += f'<div id="vex_log_{i}" style="display:none">{_chart_div(_fig_json(fig_log), f"vchart_log_{i}")}</div>'

                # Embed raw percentile data for the JS outlier slider
                p99s = [float(np.percentile(arr_sorted, p)) for p in range(101)] if arr_sorted else []
                p += f'<div id="pct_data_{i}" style="display:none" data-pct=\'{_j(p99s)}\'></div>'

        # ── CATEGORICAL ────────────────────────────────────────────────────────
        elif dtype == "Categorical":
            nu   = res["n_unique"]
            rare = res.get("rare_count", 0)
            p += '<div class="metrics-row">'
            p += _metric("Unique",      nu)
            p += _metric("Rare (<1%)",  rare)
            p += _metric("Missing %",   f"{res['missing_pct']:.1f}%")
            p += _metric("Top Value %", f"{res.get('top_val_pct',0):.1f}%")
            p += '</div>'

            if nu > 100: p += _alert(f"⚠️ High cardinality — {nu} unique. Fuzzy matching skipped.", "yellow")
            if rare > 5: p += _alert(f"⚠️ {rare} rare categories detected.", "yellow")
            if res["missing_pct"] > 10: p += _alert(f"⚠️ {res['missing_pct']:.1f}% missing", "red")

            tbl = res.get("category_table", pd.DataFrame())
            if len(tbl):
                top25 = tbl.head(25)
                bar_c = [_C["red"] if f == "RARE" else _C["cyan"] if f == "DOMINANT" else _C["accent"]
                         for f in top25["Flag"]]

                fig_lin = go.Figure(go.Bar(
                    x=top25["Category"].astype(str), y=top25["Share %"],
                    marker_color=bar_c,
                    text=top25["Count"], textposition="outside", textfont_size=9,
                ))
                fig_lin.update_layout(title=dict(text=f"Top Categories — {col}", font_size=13),
                                      xaxis_title="", yaxis_title="Share %", bargap=0.15)
                fig_lin.update_xaxes(tickangle=35)

                fig_log = go.Figure(go.Bar(
                    x=top25["Category"].astype(str), y=top25["Share %"],
                    marker_color=bar_c,
                    text=top25["Count"], textposition="outside", textfont_size=9,
                ))
                fig_log.update_layout(yaxis_type="log",
                                      title=dict(text=f"Top Categories (Log Y) — {col}", font_size=13),
                                      xaxis_title="", yaxis_title="Share % (log)", bargap=0.15)
                fig_log.update_xaxes(tickangle=35)

                p += f'''<div class="scale-toggle">
  <button class="scale-btn active" onclick="toggleScale(this,'cat_lin_{i}','cat_log_{i}')">Linear</button>
  <button class="scale-btn" onclick="toggleScale(this,'cat_log_{i}','cat_lin_{i}')">Log</button>
</div>'''
                p += f'<div id="cat_lin_{i}">{_chart_div(_fig_json(fig_lin), f"cchart_lin_{i}")}</div>'
                p += f'<div id="cat_log_{i}" style="display:none">{_chart_div(_fig_json(fig_log), f"cchart_log_{i}")}</div>'

                p += _collapsible("Full category table", _table(tbl, id_=f"cattbl_{i}"))

        # ── ID-LIKE ────────────────────────────────────────────────────────────
        elif dtype == "ID-like":
            p += '<div class="metrics-row">'
            p += _metric("Unique Values", f"{res['n_unique']:,}")
            p += _metric("Missing %",     f"{res['missing_pct']:.1f}%")
            p += _metric("Hit Rate %",    f"{res['hit_rate_pct']:.1f}%")
            p += '</div>'
            p += _alert("🔑 Identifier column — excluded from correlation and statistical analysis.", "blue")
            samples = res.get("sample_values", [])
            if samples:
                p += f'<p class="caption"><strong>Sample values:</strong> {", ".join(_esc(str(s)) for s in samples)}</p>'

        # ── DATE ───────────────────────────────────────────────────────────────
        elif dtype == "Date":
            p += '<div class="metrics-row">'
            p += _metric("Min Date",  res.get("date_min", "—"))
            p += _metric("Max Date",  res.get("date_max", "—"))
            p += _metric("Unique",    f"{res['n_unique']:,}")
            p += _metric("Missing %", f"{res['missing_pct']:.1f}%")
            p += '</div>'
            yc = res.get("year_counts",  {})
            mc = res.get("month_counts", {})
            if yc or mc:
                p += '<div class="two-col">'
                if yc:
                    yr = sorted(yc.keys())
                    fig_yr = go.Figure(go.Bar(x=yr, y=[yc[y] for y in yr], marker_color=_C["accent"]))
                    fig_yr.update_layout(title=dict(text=f"{col} — Records by Year", font_size=12),
                                         xaxis_title="Year", yaxis_title="Count")
                    p += f'<div>{_chart_div(_fig_json(fig_yr, 250), f"yr_{i}", 250)}</div>'
                if mc:
                    MN = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
                    mo = sorted(mc.keys())
                    fig_mo = go.Figure(go.Bar(x=[MN[m-1] for m in mo], y=[mc[m] for m in mo],
                                             marker_color=_C["purple"]))
                    fig_mo.update_layout(title=dict(text=f"{col} — Records by Month", font_size=12),
                                          xaxis_title="Month", yaxis_title="Count")
                    p += f'<div>{_chart_div(_fig_json(fig_mo, 250), f"mo_{i}", 250)}</div>'
                p += '</div>'

        # ── CONSTANT ───────────────────────────────────────────────────────────
        elif dtype == "Constant":
            p += _alert(f"🔒 Constant column — value: <strong>{_esc(str(res.get('constant_value','?')))}</strong>. Zero variance. Drop before modelling.", "red")

        else:
            p += _metric("Missing %", f"{res['missing_pct']:.1f}%")
            p += _alert(f"Type: {_esc(dtype)}", "blue")

        p += '</div>'  # var-panel
        panels.append(p)

    html = f'''<div class="vex-controls">
  <select id="vex-select" onchange="showVar(this.value)" class="var-select">
    {options_html}
  </select>
</div>
<div id="vex-panels">{"".join(panels)}</div>
<script>
(function(){{
  function showVar(id){{
    document.querySelectorAll(".var-panel").forEach(p=>p.style.display="none");
    var el=document.getElementById(id);
    if(el){{el.style.display="block"; renderPendingCharts(el);}}
  }}
  window.showVar=showVar;
  // Show first panel on load
  var first=document.querySelector(".var-panel");
  if(first){{first.style.display="block"; renderPendingCharts(first);}}
}})();
</script>'''
    return html


def _sec_hit_rate(R):
    cr     = R.get("col_results", {})
    target = R.get("target_col")
    if not cr:
        return _alert("No data.", "yellow")

    rows = [{"Feature": col, "Hit Rate %": res["hit_rate_pct"],
             "Missing %": res["missing_pct"], "Type": res["dtype"]}
            for col, res in cr.items()]
    df_hr = pd.DataFrame(rows).sort_values("Hit Rate %", ascending=True)

    try:
        import plotly.graph_objects as go
        colors = [_C["green"] if h >= 95 else _C["orange"] if h >= 75 else _C["red"]
                  for h in df_hr["Hit Rate %"]]
        fig = go.Figure(go.Bar(
            x=df_hr["Hit Rate %"], y=df_hr["Feature"], orientation="h",
            marker_color=colors,
            text=df_hr["Hit Rate %"].apply(lambda v: f"{v:.1f}%"),
            textposition="inside", textfont_size=9, textfont_color="white",
        ))
        fig.update_layout(
            title=dict(text="Hit Rate per Feature (% non-null)", font_size=13),
            xaxis=dict(range=[0,100], title="Hit Rate %"),
            yaxis_title="",
        )
        h = max(350, len(df_hr) * 22)
        html = _chart_div(_fig_json(fig, h), "hr-chart", h)
    except ImportError:
        html = ""

    html += '<div class="pills">'
    html += _pill("● ≥95% Good",        _C["green"])
    html += _pill("● 75–94% Review",    _C["orange"])
    html += _pill("● <75% Problem",     _C["red"])
    html += '</div>'

    html += _divider() + _sec("Hit Rate Table")

    def _hr_style(col, val, row):
        if col == "Hit Rate %":
            v = _safe_float(val)
            if v >= 95:  return "background:#dcfce7;color:#166534;font-weight:600"
            if v >= 75:  return "background:#fef9c3;color:#a16207"
            return "background:#fee2e2;color:#991b1b;font-weight:600"
        if col == "Missing %":
            v = _safe_float(val)
            if v >= 30: return "background:#fee2e2;color:#991b1b"
            if v > 0:   return "background:#fef9c3;color:#a16207"
            return "background:#dcfce7;color:#166534"
        return ""

    html += _table(df_hr.reset_index(drop=True), _hr_style, id_="hr-table", cls="sortable")
    html += '''<div class="table-controls">
  <input type="text" class="table-search" data-target="hr-table" placeholder="🔍 Search…">
</div>'''
    return html


def _sec_category_quality(R):
    cr    = R.get("col_results", {})
    fuzzy = R.get("fuzzy_categories", {})
    cat_cols = [c for c, r in cr.items() if r["dtype"] == "Categorical"]
    if not cat_cols:
        return _alert("No categorical columns.", "yellow")

    with_matches = {c: v for c, v in fuzzy.items() if isinstance(v, list) and len(v) > 0}
    skipped      = [c for c, v in fuzzy.items() if isinstance(v, list) and len(v) == 0]

    html = '<div class="metrics-row">'
    html += _metric("Cols with similar cats", len(with_matches))
    html += _metric("Total similar pairs",    sum(len(v) for v in with_matches.values()))
    html += _metric("Skipped (high-card)",    len(skipped))
    html += '</div>'

    html += _divider() + _sec("Similar / Duplicate Category Pairs")

    if not with_matches:
        html += _alert("✅ No similar or duplicate categories detected.", "green")
    else:
        for col, matches in with_matches.items():
            nu   = cr[col].get("n_unique", 0)
            rare = cr[col].get("rare_count", 0)
            mdf  = pd.DataFrame(matches)

            def _sim_style(c, val, row):
                if c == "Similarity":
                    v = _safe_float(val)
                    if v == 1.0:  return "background:#fee2e2;color:#991b1b;font-weight:700"
                    if v >= 0.95: return "background:#fef9c3;color:#a16207"
                return ""

            inner = _table(mdf, _sim_style)
            html += _collapsible(
                f"🏷️ {col} — {len(matches)} pair(s)  ({nu} cats, {rare} rare)",
                inner, open_=True
            )

    if skipped:
        skip_html = "".join(f'<li>{_esc(c)} ({cr[c].get("n_unique",0)} cats)</li>' for c in sorted(skipped))
        html += _collapsible(f"ℹ️ {len(skipped)} high-cardinality cols skipped", f"<ul>{skip_html}</ul>")

    # ── Rare Categories Explorer ──────────────────────────────────────────────
    html += _divider() + _sec("Rare Categories Explorer")
    opts = "".join(f'<option value="rcat_{i}">{_esc(c)}</option>' for i, c in enumerate(cat_cols))

    panels = []
    for i, col in enumerate(cat_cols):
        tbl     = cr[col].get("category_table", pd.DataFrame())
        rare_df = tbl[tbl["Flag"] == "RARE"]   if len(tbl) else pd.DataFrame()
        dom_df  = tbl[tbl["Flag"] == "DOMINANT"] if len(tbl) else pd.DataFrame()
        p = f'<div id="rcat_{i}" class="var-panel" style="display:none"><div class="two-col">'
        p += '<div>'
        if len(rare_df):
            p += _alert(f"⚠️ {len(rare_df)} rare categories", "yellow")
            p += _table(rare_df.reset_index(drop=True))
        else:
            p += _alert(f"✅ No rare categories in {_esc(col)}", "green")
        p += '</div><div>'
        if len(dom_df):
            p += _alert("⚠️ Dominant category detected", "yellow")
            p += _table(dom_df.reset_index(drop=True))
        else:
            p += '<p class="caption">No dominant category.</p>'
        p += '</div></div></div>'
        panels.append(p)

    html += f'''<select id="rcat-select" onchange="showRcat(this.value)" class="var-select">{opts}</select>
<div id="rcat-panels">{"".join(panels)}</div>
<script>
(function(){{
  function showRcat(id){{
    document.querySelectorAll("#rcat-panels .var-panel").forEach(p=>p.style.display="none");
    var el=document.getElementById(id); if(el) el.style.display="block";
  }}
  window.showRcat=showRcat;
  var first=document.querySelector("#rcat-panels .var-panel");
  if(first) first.style.display="block";
}})();
</script>'''
    return html


def _sec_outliers(R):
    cr = R.get("col_results", {})
    num_cols = [c for c, r in cr.items()
                if r["dtype"] in ("Numeric","Boolean") and r.get("plot_sample")]
    if not num_cols:
        return _alert("No numeric columns with data.", "yellow")

    try:
        import plotly.graph_objects as go
    except ImportError:
        return _alert("Install plotly for outlier charts.", "yellow")

    # ── Pre-compute per-column stats used by both the summary table and panels ─
    col_stats = {}   # col → dict of precomputed values
    for col in num_cols:
        res    = cr[col]
        outl   = res.get("outlier", {})
        dist   = res.get("dist", {})
        sample = res.get("plot_sample", [])
        arr    = sorted([x for x in sample
                         if x is not None and not (isinstance(x, float) and math.isnan(x))])
        if not arr:
            col_stats[col] = None
            continue

        pcts      = [float(np.percentile(arr, p)) for p in range(101)]
        p1        = pcts[1];  p99 = pcts[99]
        lo_def    = pcts[5];  hi_def = pcts[95]
        n_total   = len(arr)
        n_out_def = sum(1 for v in arr if v < lo_def or v > hi_def)
        iqr_pct   = outl.get("iqr_pct", 0.0)
        iqr_count = outl.get("iqr_count", outl.get("count", 0))
        skewness  = dist.get("skewness", 0) or 0
        inf_p     = res.get("inf_pct", 0.0)
        zero_inf  = res.get("zero_inflated", False)

        # Severity classification based on IQR outlier %
        if iqr_pct >= 10:   sev = ("🔴 High",    "fee2e2", "991b1b")
        elif iqr_pct >= 5:  sev = ("🟡 Moderate", "fef9c3", "a16207")
        elif iqr_pct >= 1:  sev = ("🟢 Low",      "dcfce7", "166534")
        else:               sev = ("✅ Clean",     "f0fdf4", "166534")

        col_stats[col] = dict(
            arr=arr, pcts=pcts, p1=p1, p99=p99,
            lo_def=lo_def, hi_def=hi_def,
            n_total=n_total, n_out_def=n_out_def,
            iqr_pct=iqr_pct, iqr_count=iqr_count,
            skewness=skewness, inf_p=inf_p, zero_inf=zero_inf,
            fence_lo=outl.get("fence_lo", "—"),
            fence_hi=outl.get("fence_hi", "—"),
            note=outl.get("note", ""),
            sev=sev,
        )

    # ── SECTION 1: Summary table ──────────────────────────────────────────────
    html = _sec("Outlier Summary — All Variables")
    html += '<p class="caption">IQR method (1.5×IQR fences) · Click a row to jump to that variable\'s detail below</p>'

    # Build summary DataFrame
    sum_rows = []
    for col in num_cols:
        s = col_stats.get(col)
        if not s:
            sum_rows.append({
                "Variable": col, "IQR Outliers": "—", "IQR %": "—",
                "P5": "—", "P95": "—", "Fence Lo": "—", "Fence Hi": "—",
                "Skewness": "—", "Inf %": "—", "Severity": "—",
            })
            continue
        sum_rows.append({
            "Variable":    col,
            "IQR Outliers":s["iqr_count"],
            "IQR %":       round(s["iqr_pct"], 2),
            "P5":          round(s["lo_def"], 4),
            "P95":         round(s["hi_def"], 4),
            "Fence Lo":    s["fence_lo"],
            "Fence Hi":    s["fence_hi"],
            "Skewness":    round(s["skewness"], 3),
            "Inf %":       round(s["inf_p"], 2),
            "Severity":    s["sev"][0],
        })

    sum_df = pd.DataFrame(sum_rows)

    def _sum_row_style(col_name, val, row):
        if col_name == "IQR %":
            v = _safe_float(val)
            if v >= 10:  return "background:#fee2e2;color:#991b1b;font-weight:700"
            if v >= 5:   return "background:#fef9c3;color:#a16207;font-weight:600"
            if v >= 1:   return "background:#dcfce7;color:#166534"
            return "background:#f0fdf4;color:#166534"
        if col_name == "Severity":
            s = str(val)
            if "High"     in s: return "background:#fee2e2;color:#991b1b;font-weight:700"
            if "Moderate" in s: return "background:#fef9c3;color:#a16207;font-weight:600"
            if "Low"      in s: return "background:#dcfce7;color:#166534"
            return "color:#166534"
        if col_name == "Skewness":
            v = abs(_safe_float(val))
            if v > 2:   return "color:#b91c1c;font-weight:600"
            if v > 1:   return "color:#b45309;font-weight:600"
            return ""
        if col_name == "Inf %":
            v = _safe_float(val)
            if v > 0:   return "background:#fee2e2;color:#991b1b"
            return ""
        return ""

    # Make Variable column clickable to jump to drill-down
    # We inject a custom table with onclick on each row
    thead = "".join(f'<th data-col="{_esc(c)}">{_esc(c)}</th>' for c in sum_df.columns)
    tbody_rows = []
    for idx, row in sum_df.iterrows():
        col_name = str(row["Variable"])
        # find index in num_cols for this variable
        try:
            vi = num_cols.index(col_name)
        except ValueError:
            vi = 0
        cells = []
        for c in sum_df.columns:
            val = row[c]
            style = _sum_row_style(c, val, row)
            disp  = _esc(str(val)) if not (isinstance(val, float) and math.isnan(val)) else "—"
            cells.append(f'<td style="{style}">{disp}</td>')
        tbody_rows.append(
            f'<tr class="ol-sum-row" data-var-idx="{vi}" '
            f'style="cursor:pointer" '
            f'title="Click to drill into {_esc(col_name)}">'
            + "".join(cells) + "</tr>"
        )

    html += f'''<div class="table-wrap" style="margin-bottom:8px">
<table id="ol-summary-table" class="data-table sortable">
  <thead><tr>{thead}</tr></thead>
  <tbody>{"".join(tbody_rows)}</tbody>
</table></div>
<div class="table-controls">
  <input type="text" class="table-search" data-target="ol-summary-table" placeholder="🔍 Search variables…">
</div>
<p class="caption" style="margin-top:4px">
  {_pill("🔴 IQR% ≥10% High",    _C["red"])}
  {_pill("🟡 IQR% 5–9% Moderate", _C["orange"])}
  {_pill("🟢 IQR% 1–4% Low",      _C["green"])}
  {_pill("✅ IQR% <1% Clean",      "#16a34a")}
  &nbsp;· Click any row to drill into that variable below.
</p>'''

    html += _divider()

    # ── SECTION 2: Variable drill-down with sliders and plots ─────────────────
    html += _sec("Variable Detail")

    opts = "".join(f'<option value="ol_{i}">{_esc(c)}</option>'
                   for i, c in enumerate(num_cols))

    panels = []
    for i, col in enumerate(num_cols):
        s = col_stats.get(col)
        p = f'<div id="ol_{i}" class="var-panel" style="display:none">'

        if not s:
            p += _alert("No sample data.", "yellow")
            p += '</div>'
            panels.append(p)
            continue

        arr      = s["arr"]
        pcts     = s["pcts"]
        p1       = s["p1"];     p99     = s["p99"]
        lo_def   = s["lo_def"]; hi_def  = s["hi_def"]
        n_out_def= s["n_out_def"]
        inf_p    = s["inf_p"]
        pad      = (p99 - p1) * 0.05

        if inf_p > 0:
            p += _alert(f"🔴 {inf_p:.2f}% Inf values excluded before stats", "red")
        if s["note"]:
            p += _alert(f"ℹ️ {_esc(s['note'])}", "blue")
        if s["zero_inf"]:
            p += _alert("ℹ️ Zero-inflated column — IQR computed on non-zero values", "blue")

        # Sliders (lo: 0..20 default 5, hi: 80..100 default 95)
        p += f'''<div class="outlier-controls">
  <div class="slider-group">
    <label>Lower percentile cutoff: <strong id="lo_val_{i}">P5 = {lo_def:.4g}</strong></label>
    <input type="range" id="lo_sl_{i}" min="0" max="20" value="5" step="1"
           oninput="updateOutlier({i},this.value,null)">
  </div>
  <div class="slider-group">
    <label>Upper percentile cutoff: <strong id="hi_val_{i}">P95 = {hi_def:.4g}</strong></label>
    <input type="range" id="hi_sl_{i}" min="80" max="100" value="95" step="1"
           oninput="updateOutlier({i},null,this.value)">
  </div>
</div>'''

        # Metrics row (updated live by JS)
        p += f'''<div class="metrics-row" id="ol_metrics_{i}">
  <div class="metric-card"><div class="metric-val" id="ol_p_lo_{i}">{lo_def:.4g}</div><div class="metric-label" id="ol_lab_lo_{i}">P5</div></div>
  <div class="metric-card"><div class="metric-val" id="ol_p_hi_{i}">{hi_def:.4g}</div><div class="metric-label" id="ol_lab_hi_{i}">P95</div></div>
  <div class="metric-card"><div class="metric-val" id="ol_count_{i}">{n_out_def:,}</div><div class="metric-label">Outside range</div></div>
  <div class="metric-card"><div class="metric-val" id="ol_pct_{i}">{round(n_out_def/len(arr)*100,2):.2f}%</div><div class="metric-label">% outside</div></div>
  <div class="metric-card"><div class="metric-val">{s["iqr_count"]:,}</div><div class="metric-label">IQR outliers</div></div>
  <div class="metric-card"><div class="metric-val">{s["iqr_pct"]:.1f}%</div><div class="metric-label">IQR %</div></div>
</div>'''

        p += f'<p class="caption"><strong>IQR fences:</strong> lo={s["fence_lo"]}  hi={s["fence_hi"]}</p>'

        # Boxplot
        fig_box = go.Figure()
        fig_box.add_trace(go.Box(
            x=arr, name=col, marker_color=_C["accent"], boxmean="sd",
            fillcolor="rgba(99,102,241,0.15)", line_color=_C["accent"],
        ))
        fig_box.add_vline(x=lo_def, line_dash="dash", line_color=_C["orange"],
                          annotation_text="P5", annotation_font_size=10)
        fig_box.add_vline(x=hi_def, line_dash="dash", line_color=_C["red"],
                          annotation_text="P95", annotation_font_size=10)
        fig_box.update_layout(title=dict(text=f"Boxplot — {col}", font_size=13))

        # Histogram with outlier shading
        bin_w = (p99 - p1) / 60 if p99 > p1 else None
        fig_h = go.Figure()
        fig_h.add_trace(go.Histogram(
            x=arr,
            xbins=dict(size=bin_w, start=p1-pad, end=p99+pad) if bin_w else {},
            marker_color=_C["accent"], opacity=0.82,
            marker_line=dict(width=0.2, color="#fff"),
        ))
        if lo_def > p1 - pad:
            fig_h.add_vrect(x0=p1-pad, x1=lo_def, fillcolor=_C["orange"], opacity=0.12,
                             line_width=0, annotation_text="Low tail",
                             annotation_font_size=9, annotation_position="top left")
        if hi_def < p99 + pad:
            fig_h.add_vrect(x0=hi_def, x1=p99+pad, fillcolor=_C["red"], opacity=0.12,
                             line_width=0, annotation_text="High tail",
                             annotation_font_size=9, annotation_position="top right")
        fig_h.update_layout(
            title=dict(text=f"Distribution — {col}  (display: P1–P99)", font_size=13),
            xaxis=dict(title=col, range=[p1-pad, p99+pad]),
            yaxis_title="Count", bargap=0.02,
        )

        p += _chart_div(_fig_json(fig_box, 200), f"ol_box_{i}", 200)
        p += _chart_div(_fig_json(fig_h),        f"ol_hist_{i}")

        if p1 > float(min(arr)) or p99 < float(max(arr)):
            p += (f'<p class="caption">ℹ️ X-axis clipped to P1–P99 [{p1:.4g}, {p99:.4g}] '
                  f'for readability. Full range: [{float(min(arr)):.4g}, {float(max(arr)):.4g}]</p>')

        # Embed percentile table + sampled array for JS slider updates
        arr_store = arr[::max(1, len(arr)//10000)]
        p += (f'<div id="ol_data_{i}" style="display:none" '
              f'data-pct=\'{_j(pcts)}\' data-arr=\'{_j(arr_store)}\' '
              f'data-total="{len(arr)}"></div>')

        p += '</div>'  # var-panel
        panels.append(p)

    html += f'''<div class="vex-controls">
  <select id="ol-select" onchange="showOl(this.value)" class="var-select">{opts}</select>
</div>
<div id="ol-panels">{"".join(panels)}</div>
<script>
(function(){{
  // Show panel by index (called from summary table row click)
  function showOlByIdx(idx){{
    var sel=document.getElementById("ol-select");
    if(sel) sel.value="ol_"+idx;
    showOl("ol_"+idx);
    // Scroll to the drill-down section smoothly
    var selEl=document.getElementById("ol-select");
    if(selEl) selEl.scrollIntoView({{behavior:"smooth",block:"start"}});
  }}
  window.showOlByIdx=showOlByIdx;

  function showOl(id){{
    document.querySelectorAll("#ol-panels .var-panel").forEach(function(p){{p.style.display="none";}});
    var el=document.getElementById(id);
    if(el){{el.style.display="block"; renderPendingCharts(el);}}
  }}
  window.showOl=showOl;

  // Wire up summary table row clicks
  document.querySelectorAll(".ol-sum-row").forEach(function(row){{
    row.addEventListener("click", function(){{
      var idx=parseInt(this.getAttribute("data-var-idx"));
      showOlByIdx(idx);
    }});
    // Hover highlight
    row.addEventListener("mouseenter", function(){{this.style.background="#ede9fe";}});
    row.addEventListener("mouseleave", function(){{this.style.background="";}});
  }});

  // Show first panel on load
  var first=document.querySelector("#ol-panels .var-panel");
  if(first){{first.style.display="block"; renderPendingCharts(first);}}
}})();
</script>'''
    return html


def _sec_correlations(R):
    corr   = R.get("correlations", {})
    target = R.get("target_col")
    cfg    = R.get("config", {})
    thresh = cfg.get("corr_threshold", 0.75)

    if not corr:
        return _alert("Correlations section was disabled. Re-run with set_sections(correlations=True).", "yellow")

    try:
        import plotly.graph_objects as go
        import plotly.express as px
    except ImportError:
        return _alert("Install plotly for correlation charts.", "yellow")

    # ── Three sub-tabs: Numeric | Categorical | Target ────────────────────────
    html = '''<div class="sub-tabs">
  <button class="sub-tab active" onclick="showSubTab(this,'corr-num')">🔢 Numeric — Pearson</button>
  <button class="sub-tab" onclick="showSubTab(this,'corr-cat')">🏷️ Categorical — Cramér\'s V</button>
  <button class="sub-tab" onclick="showSubTab(this,'corr-tgt')">🎯 Target Correlation</button>
</div>'''

    # ── NUMERIC PEARSON ───────────────────────────────────────────────────────
    html += '<div id="corr-num" class="sub-panel">'
    hm     = corr.get("pearson", pd.DataFrame())
    n_vars = corr.get("n_vars", 0)
    total  = corr.get("total_rows", 0)
    sn     = corr.get("sample_size", total)
    pct    = round(sn / total * 100, 1) if total else 100

    html += _collapsible("ℹ️ About Pearson correlation", """
<p><strong>Pearson r</strong> measures the linear relationship between two numeric variables.</p>
<ul>
<li>Range: −1 to +1 · |r| ≥ 0.7 = <strong>strong</strong> · 0.4–0.7 = <strong>moderate</strong> · &lt;0.4 = <strong>weak</strong></li>
<li>Sensitive to outliers. Best for normally distributed data.</li>
</ul>
<p><strong>VIF</strong> (Variance Inflation Factor) detects multicollinearity. VIF &gt;10 = severe · 5–10 = moderate · &lt;5 = OK</p>""")

    if len(hm) < 2:
        html += _alert("Need ≥ 2 numeric features to compute Pearson correlation.", "yellow")
    else:
        html += f'<p class="caption"><strong>{n_vars} numeric features</strong> · {sn:,} of {total:,} rows ({pct}%){" — sampled for speed" if corr.get("sampled") else ""}</p>'

        # Target quick bar
        if target and target in hm.columns:
            tc_quick = hm[target].drop(target, errors="ignore").dropna().sort_values(key=abs, ascending=True)
            if len(tc_quick):
                bar_c = [_C["purple"] if abs(v) >= 0.5 else _C["accent"] if abs(v) >= 0.3
                         else _C["green"] if abs(v) >= 0.1 else _C["cyan"] for v in tc_quick]
                fig_q = go.Figure(go.Bar(
                    x=tc_quick.values, y=tc_quick.index.tolist(), orientation="h",
                    marker_color=bar_c,
                    text=[f"{v:+.3f}" for v in tc_quick.values],
                    textposition="auto", textfont_size=9,
                ))
                fig_q.update_layout(
                    title=dict(text=f"🎯 All features vs Target: {target}  (Pearson r)", font_size=13),
                    xaxis=dict(range=[-1,1], title="Pearson r",
                               zeroline=True, zerolinecolor="#374151", zerolinewidth=1.5),
                    yaxis_title="",
                )
                h = max(300, len(tc_quick) * 22)
                html += _sec(f"All features vs Target: {target}")
                html += _chart_div(_fig_json(fig_q, h), "pearson-target-bar", h)
                html += '<div class="pills">'
                html += _pill("● |r|≥0.5 Strong",   _C["purple"])
                html += _pill("● 0.3–0.5 Moderate",  _C["accent"])
                html += _pill("● 0.1–0.3 Weak",      _C["green"])
                html += _pill("● <0.1 Negligible",   _C["cyan"])
                html += '</div>' + _divider()

        # Heatmap
        html += _sec("Pearson Correlation Heatmap")
        fig_hm = px.imshow(hm, color_continuous_scale="RdBu_r", zmin=-1, zmax=1, text_auto=".2f")
        fig_hm.update_layout(title=dict(text="Pearson Correlation Matrix", font_size=13))
        fig_hm.update_traces(textfont_size=9)
        h_hm = max(350, len(hm) * 45)
        html += _chart_div(_fig_json(fig_hm, h_hm), "pearson-heatmap", h_hm)
        html += _divider()

        # High-corr pairs with threshold slider
        pt = corr.get("pair_table", pd.DataFrame())
        if len(pt):
            html += _sec("High-Correlation Pairs")
            html += f'''<div class="slider-group" style="max-width:480px;margin-bottom:12px">
  <label>|r| threshold: <strong id="corr-thresh-label">{thresh:.2f}</strong></label>
  <input type="range" id="corr-thresh-sl" min="0" max="100" value="{int(thresh*100)}" step="1"
         oninput="filterCorrTable(this.value)">
</div>
<p class="caption" id="corr-thresh-count"></p>'''

            def _pt_style(col, val, row):
                if col == "Pearson r":
                    v = abs(_safe_float(val))
                    if v >= 0.7: return "background:#ede9fe;color:#5b21b6;font-weight:700"
                    if v >= 0.4: return "background:#dbeafe;color:#1e3a5f;font-weight:600"
                    return ""
                return ""

            html += _table(pt, _pt_style, id_="corr-pairs-table", cls="sortable")
            html += _divider()

        # VIF
        vif = corr.get("vif", pd.DataFrame())
        if len(vif):
            html += _sec("VIF — Variance Inflation Factor")
            html += '<p class="caption">VIF &gt;10 = severe multicollinearity · 5–10 = moderate · &lt;5 = OK</p>'

            def _vif_style(col, val, row):
                if col == "VIF":
                    v = _safe_float(val)
                    if v > 10: return "background:#fee2e2;color:#991b1b;font-weight:700"
                    if v > 5:  return "background:#fef9c3;color:#a16207"
                    return "background:#dcfce7;color:#166534"
                return ""

            html += _table(vif, _vif_style)

    html += '</div>'  # corr-num

    # ── CATEGORICAL CRAMÉR'S V ─────────────────────────────────────────────────
    html += '<div id="corr-cat" class="sub-panel" style="display:none">'
    chi_df    = corr.get("cat_chi2", pd.DataFrame())
    skipped   = corr.get("chi_skipped", [])
    chi_cap   = corr.get("chi_max_cardinality", 10_000)
    total_rows= corr.get("total_rows", 0)

    html += _collapsible("ℹ️ About Cramér's V", """
<p><strong>Cramér's V</strong> measures association strength between two categorical variables.</p>
<ul>
<li>Ranges 0 to 1, independent of sample size.</li>
<li>V ≥ 0.3 = <strong>Strong</strong> · 0.1–0.3 = <strong>Moderate</strong> · &lt;0.1 = <strong>Weak</strong></li>
<li>Computed on the full dataset using exact contingency tables.</li>
</ul>""")

    html += f'<p class="caption">Computed on full {total_rows:,} rows · Columns with &gt;{chi_cap:,} unique values skipped'
    if skipped: html += f' · <strong>{len(skipped)} column(s) skipped</strong>'
    html += '</p>'

    if not len(chi_df):
        html += _alert("No categorical column pairs found (need ≥ 2 categorical columns).", "yellow")
    else:
        n_strong = int((chi_df["Cramér's V"].fillna(0) >= 0.3).sum())
        n_mod    = int(((chi_df["Cramér's V"].fillna(0) >= 0.1) & (chi_df["Cramér's V"].fillna(0) < 0.3)).sum())
        n_tgt    = int((chi_df["vs Target"] == "🎯").sum())

        html += '<div class="metrics-row">'
        html += _metric("Total pairs",      len(chi_df))
        html += _metric("Strong (V ≥ 0.3)", n_strong)
        html += _metric("Moderate",         n_mod)
        html += _metric("vs Target pairs",  n_tgt)
        html += '</div>'

        # Store full CV data as JSON for JS filter
        cv_rows = chi_df[["Variable A","Variable B","Cramér's V","Strength","vs Target"]].copy()
        cv_rows["Cramér's V"] = cv_rows["Cramér's V"].round(4)
        cv_json = _j(cv_rows.to_dict(orient="records"))

        html += f'''<div class="cv-controls">
  <label class="checkbox-label">
    <input type="checkbox" id="cv-tgt-only" onchange="filterCramersV()"> Target pairs only
  </label>
</div>
<div id="cv-table-wrap"></div>
<div id="cv-bar-wrap"></div>
<script>
(function(){{
  var CV_DATA={cv_json};
  window.CV_DATA=CV_DATA;
  function renderCV(data){{
    var wrap=document.getElementById("cv-table-wrap");
    var rows=data.map(function(r){{
      var v=r["Cramér\'s V"]||0;
      var bg=v>=0.3?"background:#ede9fe;color:#5b21b6;font-weight:700":v>=0.1?"background:#dbeafe;color:#1e3a5f":"";
      var tgt=r["vs Target"]==="🎯"?"background:#f5f3ff;font-weight:700":"";
      return "<tr><td>"+r["Variable A"]+"</td><td>"+r["Variable B"]+"</td>"+
        "<td style=\\""+bg+"\\">"+v.toFixed(4)+"</td>"+
        "<td style=\\""+bg+"\\">"+r["Strength"]+"</td>"+
        "<td style=\\""+tgt+"\\">"+r["vs Target"]+"</td></tr>";
    }}).join("");
    wrap.innerHTML='<div class="table-wrap"><table class="data-table sortable"><thead><tr>'+
      '<th>Variable A</th><th>Variable B</th><th>Cramér\'s V</th><th>Strength</th><th>vs Target</th>'+
      '</tr></thead><tbody>'+rows+'</tbody></table></div>';
  }}
  function renderCVBar(data){{
    if(!data.length) return;
    var wrap=document.getElementById("cv-bar-wrap");
    var top=data.slice(0,20);
    var pairs=top.map(function(r){{return r["Variable A"]+" × "+r["Variable B"];}});
    var vals=top.map(function(r){{return r["Cramér\'s V"];}});
    var clrs=vals.map(function(v){{return v>=0.3?"{_C["purple"]}":v>=0.1?"{_C["accent"]}":"{_C["cyan"]}";}});
    var fig={{data:[{{type:"bar",x:vals,y:pairs,orientation:"h",marker:{{color:clrs}},
      text:top.map(function(r){{return "V="+r["Cramér\'s V"].toFixed(4)+"  "+r["Strength"]}}),
      textposition:"outside",textfont:{{size:9}}}}],
      layout:{{height:{max(300, min(20,len(chi_df))*26)},
        margin:{{l:0,r:120,t:36,b:40}},
        paper_bgcolor:"rgba(0,0,0,0)",plot_bgcolor:"rgba(0,0,0,0)",
        font:{{family:"\'DM Sans\',sans-serif",size:11,color:"#374151"}},
        xaxis:{{title:"Cramér\'s V",range:[0,Math.min(Math.max.apply(null,vals)*1.4,1.05)]}},
        yaxis:{{title:""}},
        title:{{text:"Categorical Association Strength (Cramér\'s V)",font:{{size:13}}}}}}}};
    wrap.innerHTML='<div class="plotly-chart" data-height="{max(300, min(20,len(chi_df))*26)}" id="cv-bar-chart"></div>';
    if(window.Plotly) Plotly.newPlot("cv-bar-chart",fig.data,fig.layout,{{responsive:true}});
    else wrap.setAttribute("data-fig",JSON.stringify(fig));
  }}
  function filterCramersV(){{
    var tgtOnly=document.getElementById("cv-tgt-only").checked;
    var data=tgtOnly?CV_DATA.filter(function(r){{return r["vs Target"]==="🎯";}}):CV_DATA;
    renderCV(data); renderCVBar(data);
  }}
  window.filterCramersV=filterCramersV;
  renderCV(CV_DATA); renderCVBar(CV_DATA);
}})();
</script>'''

    html += '</div>'  # corr-cat

    # ── TARGET CORRELATION ────────────────────────────────────────────────────
    html += '<div id="corr-tgt" class="sub-panel" style="display:none">'
    if not target:
        html += _alert("No target column defined. Pass target_col= to inspect() or run_eda().", "yellow")
    else:
        html += f'<p class="caption">Target: <strong>{_esc(target)}</strong> — association strength of every feature with your outcome.</p>'
        ts = corr.get("target_summary", pd.DataFrame())
        if len(ts):
            html += _sec(f"All Features vs Target: {target}  (ranked by strength)")
            html += '<p class="caption">Numeric → <strong>Pearson r</strong> · Categorical → <strong>Cramér\'s V</strong> · Higher absolute value = stronger association.</p>'

            ts_plot = ts.dropna(subset=["Value"]).copy()
            ts_plot = ts_plot.sort_values("Value", key=abs, ascending=True).tail(40)
            bar_c = []
            for _, row in ts_plot.iterrows():
                v = abs(_safe_float(row["Value"]))
                if row["Type"] == "Categorical":
                    bar_c.append(_C["purple"] if v >= 0.3 else _C["accent"] if v >= 0.1 else _C["cyan"])
                else:
                    bar_c.append("#7c3aed" if v >= 0.5 else _C["accent"] if v >= 0.3 else _C["green"] if v >= 0.1 else _C["cyan"])

            fig_ts = go.Figure(go.Bar(
                x=ts_plot["Value"].abs(), y=ts_plot["Feature"], orientation="h",
                marker_color=bar_c,
                text=ts_plot.apply(lambda r: f"{r['Metric']}: {abs(_safe_float(r['Value'])):.4f}", axis=1),
                textposition="auto", textfont_size=9,
            ))
            fig_ts.update_layout(
                title=dict(text=f"Feature Association with {target}  (top 40, abs value)", font_size=12),
                xaxis=dict(range=[0,1.05], title="Association Strength (absolute)"),
                yaxis_title="",
            )
            h_ts = max(320, len(ts_plot) * 24)
            html += _chart_div(_fig_json(fig_ts, h_ts), "ts-bar", h_ts)
            html += '<div class="pills">'
            html += _pill("● Strong",     _C["purple"])
            html += _pill("● Moderate",   _C["accent"])
            html += _pill("● Weak",       _C["green"])
            html += _pill("● Negligible", _C["cyan"])
            html += _pill("🏷️ Categorical (Cramér's V)", "#d97706")
            html += _pill("🔢 Numeric (Pearson r)",      "#0284c7")
            html += '</div>'

            html += _divider()

            def _ts_style(col, val, row):
                if col == "Value":
                    v = abs(_safe_float(val))
                    s = str(row.get("Strength",""))
                    if s == "Strong":   return "background:#ede9fe;color:#5b21b6;font-weight:700"
                    if s == "Moderate": return "background:#dbeafe;color:#1e3a5f;font-weight:600"
                    if s == "Weak":     return "background:#dcfce7;color:#166534"
                if col == "Strength":
                    s = str(val)
                    if s == "Strong":   return "background:#ede9fe;color:#5b21b6;font-weight:700"
                    if s == "Moderate": return "background:#dbeafe;color:#1e3a5f;font-weight:600"
                    if s == "Weak":     return "background:#dcfce7;color:#166534"
                if col == "Type":
                    if str(val) == "Categorical": return "background:#fef9c3;color:#78350f"
                    return "background:#e0f2fe;color:#0369a1"
                return ""

            html += _table(ts.reset_index(drop=True), _ts_style, id_="ts-table", cls="sortable")

        tc = corr.get("target_corr", pd.DataFrame())
        if len(tc):
            def _tc_style(col, val, row):
                if col == "Pearson r":
                    v = abs(_safe_float(val))
                    if v >= 0.5: return "background:#ede9fe;color:#5b21b6;font-weight:700"
                    if v >= 0.3: return "background:#dbeafe;color:#1e3a5f;font-weight:600"
                    if v >= 0.1: return "background:#dcfce7;color:#166534"
                return ""
            html += _collapsible(f"🔢 Numeric detail — Pearson r with {target}",
                                  _table(tc, _tc_style))

        if len(chi_df):
            tgt_chi = chi_df[chi_df["vs Target"] == "🎯"].copy()
            if len(tgt_chi):
                def _tc2_style(col, val, row):
                    if col == "Cramér's V":
                        v = _safe_float(val)
                        if v >= 0.3: return "background:#ede9fe;color:#5b21b6;font-weight:700"
                        if v >= 0.1: return "background:#dbeafe;color:#1e3a5f"
                    return ""
                html += _collapsible(f"🏷️ Categorical detail — Cramér's V vs {target}",
                                      _table(tgt_chi.reset_index(drop=True), _tc2_style))

    html += '</div>'  # corr-tgt
    return html


def _sec_comparison(R):
    cmp = R.get("comparison", {})
    if not cmp or not isinstance(cmp, dict) or not cmp.get("per_col_tables"):
        return _alert("""No comparison data configured. Set it up with:
<pre>plan.set_comparison(df=df2, label_a="A", label_b="B",
    groupby_col="Region", agg_cols=["Premium","Claim_Flag"])</pre>""", "blue")

    try:
        import plotly.graph_objects as go
    except ImportError:
        return _alert("Install plotly for comparison charts.", "yellow")

    la  = cmp["label_a"]; lb = cmp["label_b"]
    ra  = cmp.get("rows_a", 0); rb = cmp.get("rows_b", 0)
    gb  = cmp.get("groupby_col", [])
    gb_str = ", ".join(gb) if isinstance(gb, list) else str(gb or "—")
    sum_a = cmp.get("summary_a", pd.DataFrame())
    sum_b = cmp.get("summary_b", pd.DataFrame())
    per_col = cmp.get("per_col_tables", {})

    html = '<div class="metrics-row">'
    html += _metric(f"📁 {la} — Rows", f"{ra:,}")
    html += _metric(f"📁 {lb} — Rows", f"{rb:,}")
    html += _metric("Row Δ",           f"{rb-ra:+,}")
    html += _metric("Grouped by",      gb_str)
    html += '</div>' + _divider()

    # Summaries side by side
    html += _sec("📋 Dataset Summaries")
    html += '<div class="two-col">'
    for label, df_sum in [(la, sum_a), (lb, sum_b)]:
        html += f'<div><h4 style="font-family:\'DM Sans\',sans-serif;color:#374151;margin:0 0 8px">{_esc(label)}</h4>'
        if len(df_sum):
            def _sum_style(col, val, row):
                if col == "Missing %":
                    v = _safe_float(val)
                    if v >= 30: return "background:#fee2e2;color:#991b1b"
                    if v >= 10: return "background:#fef9c3;color:#a16207"
                    if v > 0:   return "background:#fffbeb;color:#78350f"
                    return "background:#dcfce7;color:#166534"
                return ""
            html += _table(df_sum, _sum_style)
        else:
            html += _alert("No summary data.", "yellow")
        html += '</div>'
    html += '</div>' + _divider()

    # Comparison tables
    html += _sec("⚖️ Comparison by Group")
    html += f'<p class="caption">For each group value of <strong>{_esc(gb_str)}</strong>, shows {_esc(la)} vs {_esc(lb)}, Diff, Diff %, Match %. 🟢 100% · 🟡 95–99% · 🟠 85–94% · 🔴 &lt;85%</p>'

    keys = list(per_col.keys())
    if len(keys) > 1:
        opts = "".join(f'<option value="{_esc(k)}">{_esc(per_col[k]["col"])} ({_esc(per_col[k]["fn"])})</option>' for k in keys)
        html += f'<select id="cmp-sel" onchange="showCmpTable(this.value)" class="var-select">{opts}</select>'

    for ki, key in enumerate(keys):
        entry     = per_col[key]
        tbl       = entry["table"].copy()
        grp_label = entry["grp_label"]
        col_name  = entry["col"]
        fn_name   = entry["fn"]
        is_first  = ki == 0

        def _cmp_row_style(col, val, row):
            is_tot = str(row.get(grp_label, "")) == "TOTAL"
            bold   = "font-weight:700;" if is_tot else ""
            extra  = "border-top:2px solid #374151;" if is_tot else ""
            if col == "Match %":
                v = _safe_float(val)
                if v >= 100: return f"background:#dcfce7;color:#166534;{bold}{extra}"
                if v >= 95:  return f"background:#bbf7d0;color:#14532d;{bold}{extra}"
                if v >= 85:  return f"background:#fef9c3;color:#a16207;{bold}{extra}"
                if v >= 70:  return f"background:#fed7aa;color:#9a3412;{bold}{extra}"
                return f"background:#fee2e2;color:#991b1b;{bold}{extra}"
            if col == "Diff %":
                v = abs(_safe_float(val))
                if v == 0:   return f"background:#dcfce7;color:#166534;{bold}{extra}"
                if v < 5:    return f"background:#bbf7d0;color:#14532d;{bold}{extra}"
                if v < 15:   return f"background:#fef9c3;color:#a16207;{bold}{extra}"
                if v < 30:   return f"background:#fed7aa;color:#9a3412;{bold}{extra}"
                return f"background:#fee2e2;color:#991b1b;{bold}{extra}"
            if col == "Diff (A−B)":
                v = _safe_float(val)
                if v > 0:   return f"color:#166534;font-weight:600;{extra}"
                if v < 0:   return f"color:#b91c1c;font-weight:600;{extra}"
                return f"color:#6b7280;{extra}"
            return bold + extra

        disp = f'style="display:{"block" if is_first else "none"}"'
        html += f'<div id="cmptbl_{_esc(key)}" {disp}>'
        html += _table(tbl, _cmp_row_style, cls="sortable")

        # Bar chart
        plot_tbl = tbl[tbl[grp_label] != "TOTAL"].copy()
        if len(plot_tbl):
            fig = go.Figure()
            fig.add_trace(go.Bar(name=la, x=plot_tbl[grp_label].astype(str), y=plot_tbl[la],
                                  marker_color=_C["accent"],
                                  text=plot_tbl[la].apply(_fmt_num), textposition="outside", textfont_size=9))
            fig.add_trace(go.Bar(name=lb, x=plot_tbl[grp_label].astype(str), y=plot_tbl[lb],
                                  marker_color=_C["cyan"],
                                  text=plot_tbl[lb].apply(_fmt_num), textposition="outside", textfont_size=9))
            fig.update_layout(barmode="group",
                               title=dict(text=f"{col_name} ({fn_name}) — {la} vs {lb} by {gb_str}", font_size=13),
                               xaxis_title=gb_str, yaxis_title=f"{col_name} ({fn_name})", bargap=0.12)
            html += _chart_div(_fig_json(fig, 340), f"cmp_bar_{ki}", 340)

            if "Match %" in plot_tbl.columns:
                bar_c = [_C["green"] if v >= 100 else "#86efac" if v >= 95 else _C["orange"]
                          if v >= 85 else "#f97316" if v >= 70 else _C["red"]
                          for v in plot_tbl["Match %"]]
                fig_m = go.Figure(go.Bar(
                    x=plot_tbl[grp_label].astype(str), y=plot_tbl["Match %"],
                    marker_color=bar_c,
                    text=plot_tbl["Match %"].apply(lambda v: f"{v:.1f}%"),
                    textposition="inside", textfont_color="white", textfont_size=10,
                ))
                fig_m.add_hline(y=95, line_dash="dash", line_color=_C["orange"],
                                 annotation_text="95% threshold", annotation_font_size=9)
                fig_m.update_layout(title=dict(text=f"Match % by {gb_str}  ({col_name} {fn_name})", font_size=13),
                                     xaxis_title=gb_str, yaxis=dict(title="Match %", range=[0,105]))
                html += _chart_div(_fig_json(fig_m, 260), f"cmp_match_{ki}", 260)

        html += '</div>'  # cmptbl_key

    if len(keys) > 1:
        html += f'''<script>
(function(){{
  var keys={_j(keys)};
  window.showCmpTable=function(key){{
    keys.forEach(function(k){{
      var el=document.getElementById("cmptbl_"+k);
      if(el) el.style.display=(k===key?"block":"none");
    }});
  }};
}})();
</script>'''

    return html


def _sec_scorecard(R):
    sc   = R.get("scorecard", pd.DataFrame())
    recs = R.get("recommendations", [])

    if not len(sc):
        return _alert("Scorecard section was disabled. Re-run with set_sections(scorecard=True).", "yellow")

    n_fix = int((sc["Status"] == "❌ Fix First").sum())
    n_rev = int((sc["Status"] == "⚠️ Review").sum())
    n_ok  = int((sc["Status"] == "✅ Good").sum())
    tot   = len(sc)

    html = '<div class="metrics-row">'
    html += _metric("Total",      tot)
    html += _metric("🔴 Fix First", n_fix)
    html += _metric("🟡 Review",    n_rev)
    html += _metric("🟢 Good",      n_ok)
    html += '</div>'

    # Quality bar
    wf = round(n_fix / tot * 200) if tot else 0
    wr = round(n_rev / tot * 200) if tot else 0
    wo = 200 - wf - wr
    html += f'''<div style="display:flex;border-radius:6px;overflow:hidden;height:10px;margin:8px 0 16px;max-width:500px">
  <div style="width:{wf}px;background:#ef4444"></div>
  <div style="width:{wr}px;background:#f59e0b"></div>
  <div style="width:{wo}px;background:#22c55e"></div>
</div>'''

    html += _divider()

    # Score distribution histogram
    try:
        import plotly.graph_objects as go
        score_col = "Overall (0-100)"
        fig_h = go.Figure()
        fig_h.add_trace(go.Histogram(
            x=sc[score_col], xbins=dict(start=0, end=100, size=5),
            marker_color=[_C["red"] if x < 55 else _C["orange"] if x < 80 else _C["green"]
                          for x in sc[score_col]],
            opacity=0.88,
        ))
        fig_h.update_layout(
            title=dict(text="Score Distribution", font_size=13),
            xaxis=dict(title="Score (0–100)", range=[0, 103]),
            yaxis_title="# Features",
            bargap=0.05,
            shapes=[
                dict(type="line", x0=55, x1=55, y0=0, y1=1, yref="paper",
                     line=dict(color=_C["orange"], dash="dash", width=1.5)),
                dict(type="line", x0=80, x1=80, y0=0, y1=1, yref="paper",
                     line=dict(color=_C["green"], dash="dash", width=1.5)),
            ]
        )
        html += _sec("Score Distribution")
        html += _chart_div(_fig_json(fig_h, 220), "sc-hist", 220)
        html += '<div class="pills">'
        html += _pill("● <55 Fix First", _C["red"])
        html += _pill("● 55–79 Review",  _C["orange"])
        html += _pill("● ≥80 Good",      _C["green"])
        html += '</div>'
    except ImportError:
        pass

    html += _divider() + _sec("Feature Scorecard")
    html += '<p class="caption">Weights: Hit Rate 30% · Valid Values 20% · Skewness 15% · Cat Consistency 15% · Outliers 20%</p>'

    # Status filter checkboxes
    html += '''<div class="sc-filters">
  <label class="checkbox-label"><input type="checkbox" class="sc-filter" value="❌ Fix First" checked onchange="filterScorecard()"> ❌ Fix First</label>
  <label class="checkbox-label"><input type="checkbox" class="sc-filter" value="⚠️ Review" checked onchange="filterScorecard()"> ⚠️ Review</label>
  <label class="checkbox-label"><input type="checkbox" class="sc-filter" value="✅ Good" checked onchange="filterScorecard()"> ✅ Good</label>
</div>'''

    score_col = "Overall (0-100)"
    show_cols = ["Feature","Type","Hit Rate","Valid Values","Skewness","Cat Consistency","Outlier Score",score_col,"Status"]
    show_cols = [c for c in show_cols if c in sc.columns]
    sc_show   = sc[show_cols].copy()

    def _sc_row_style(col, val, row):
        if col == "Status":
            s = str(val)
            if "Fix" in s:    return "color:#b91c1c;font-weight:700"
            if "Review" in s: return "color:#b45309;font-weight:700"
            if "Good" in s:   return "color:#166534;font-weight:700"
        if col == score_col:
            v = _safe_float(val)
            if v >= 80: return "background:#dcfce7;color:#166534;font-weight:600"
            if v >= 55: return "background:#fef9c3;color:#a16207;font-weight:600"
            return "background:#fee2e2;color:#991b1b;font-weight:700"
        return ""

    html += _table(sc_show, _sc_row_style, id_="sc-table", cls="sortable")

    # Recommendations
    if recs:
        html += _divider() + _sec("Recommended Actions")

        # Filter checkboxes
        html += '''<div class="sc-filters">
  <label class="checkbox-label"><input type="checkbox" class="rec-filter" value="❌ Fix First" checked onchange="filterRecs()"> ❌ Fix First</label>
  <label class="checkbox-label"><input type="checkbox" class="rec-filter" value="⚠️ Review" checked onchange="filterRecs()"> ⚠️ Review</label>
</div>
<div id="rec-list">'''
        for rec in recs:
            icon = "🔴" if "Fix" in rec["Priority"] else "🟡" if "Review" in rec["Priority"] else "🟢"
            items_html = "".join(
                f'<div class="rec-item"><span class="rec-finding">{_esc(f)}</span>'
                f'<span class="rec-arrow">→</span><code class="rec-action">{_esc(a)}</code></div>'
                for f, a in rec["Items"]
            )
            html += f'''<div class="rec-card" data-priority="{_esc(rec["Priority"])}">
  <div class="rec-header">
    {icon} <strong>{_esc(rec["Feature"])}</strong>
    <span class="rec-type">{_esc(rec["Type"])}</span>
    <span class="rec-priority" style="color:{"#b91c1c" if "Fix" in rec["Priority"] else "#b45309"}">{_esc(rec["Priority"])}</span>
  </div>
  <div class="rec-items">{items_html}</div>
</div>'''
        html += '</div>'
    else:
        html += _alert("✅ No significant issues found.", "green")

    return html


# ─────────────────────────────────────────────────────────────────────────────
# CSS + JS
# ─────────────────────────────────────────────────────────────────────────────

_CSS = """
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap');

:root{
  --bg:#f8f9fc; --surface:#ffffff; --border:#e5e7ef;
  --text:#1a1d2e; --text2:#6b7280; --text3:#9ca3af;
  --accent:#6366f1; --accent-light:#ede9fe;
  --radius:10px; --shadow:0 1px 3px rgba(0,0,0,.08),0 1px 2px rgba(0,0,0,.06);
  --shadow-md:0 4px 6px rgba(0,0,0,.07),0 2px 4px rgba(0,0,0,.06);
}

*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);font-size:14px;line-height:1.6}

/* ── Layout ── */
.layout{display:flex;min-height:100vh}
.sidebar{width:240px;min-width:240px;background:#0f1117;color:#e8eaf0;
         position:sticky;top:0;height:100vh;overflow-y:auto;
         display:flex;flex-direction:column;flex-shrink:0}
.main{flex:1;min-width:0;padding:24px 32px;max-width:1400px}

/* ── Sidebar ── */
.sidebar-header{padding:20px 20px 12px;border-bottom:1px solid #2d3145}
.sidebar-logo{font-size:20px;font-weight:700;letter-spacing:-.5px}
.sidebar-sub{font-size:11px;color:#6b7280;margin-top:2px}
.sidebar-section{padding:12px 16px 4px;font-size:10px;font-weight:600;
                 text-transform:uppercase;letter-spacing:.08em;color:#4b5563}
.nav-item{display:flex;align-items:center;gap:8px;padding:8px 20px;
          font-size:13px;cursor:pointer;border-left:3px solid transparent;
          transition:all .15s;color:#9ca3af;white-space:nowrap;overflow:hidden}
.nav-item:hover{background:rgba(255,255,255,.05);color:#e8eaf0}
.nav-item.active{background:rgba(99,102,241,.15);border-left-color:#6366f1;color:#c4b5fd}
.nav-icon{width:18px;text-align:center;flex-shrink:0}
.sidebar-stats{padding:16px 20px;border-top:1px solid #2d3145;margin-top:auto}
.stat-row{display:flex;justify-content:space-between;font-size:12px;
          padding:3px 0;color:#9ca3af}
.stat-row strong{color:#e8eaf0}
.quality-bar{height:6px;border-radius:3px;overflow:hidden;display:flex;margin:6px 0}
.quality-bar div{transition:width .3s}

/* ── Page header ── */
.page-header{background:linear-gradient(135deg,#4f46e5 0%,#7c3aed 100%);
             border-radius:var(--radius);padding:20px 24px;margin-bottom:24px;color:#fff}
.page-header h1{font-size:22px;font-weight:700;letter-spacing:-.5px}
.page-header p{font-size:13px;opacity:.85;margin-top:4px}

/* ── Tabs ── */
.tab-pane{display:none}
.tab-pane.active{display:block}

/* ── Sub-tabs (within a tab) ── */
.sub-tabs{display:flex;gap:2px;border-bottom:2px solid var(--border);margin-bottom:20px;overflow-x:auto}
.sub-tab{padding:8px 16px;font-size:13px;font-weight:600;cursor:pointer;
         border:none;background:none;color:var(--text2);border-bottom:2px solid transparent;
         margin-bottom:-2px;white-space:nowrap;transition:all .15s}
.sub-tab:hover{color:var(--text)}
.sub-tab.active{color:var(--accent);border-bottom-color:var(--accent)}
.sub-panel{display:none}
.sub-panel.active{display:block}

/* ── Metrics ── */
.metrics-row{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0}
.metric-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);
             padding:.65rem 1.1rem .55rem;min-width:110px;flex:1;max-width:200px}
.metric-val{font-size:1.25rem;font-weight:700;color:var(--text);line-height:1.2}
.metric-label{font-size:.7rem;color:var(--text2);text-transform:uppercase;letter-spacing:.04em;margin-top:2px}
.metric-sub{font-size:.72rem;color:var(--text3);margin-top:1px}

/* ── Section header ── */
.sec-head{font-size:.95rem;font-weight:700;color:var(--text);
          border-bottom:2px solid var(--accent);padding-bottom:4px;
          display:inline-block;margin:18px 0 10px}
.divider{border:none;border-top:1px solid var(--border);margin:18px 0}
.caption{font-size:.82rem;color:var(--text2);margin:4px 0 8px}
.empty{color:var(--text3);font-style:italic;padding:8px 0;font-size:.85rem}

/* ── Alerts ── */
.alert{padding:.45rem .85rem;border-radius:7px;margin:.3rem 0 .4rem;
       font-size:.85rem;line-height:1.5}

/* ── Badges & Pills ── */
.badge{display:inline-block;padding:2px 8px;border-radius:999px;
       font-size:.75rem;font-weight:600;margin:2px}
.pill{display:inline-block;padding:3px 10px;border-radius:999px;
      font-size:.78rem;font-weight:600;margin:2px 3px}
.pills{display:flex;flex-wrap:wrap;gap:4px;margin:8px 0}

/* ── Tables ── */
.table-wrap{overflow-x:auto;margin:8px 0;border-radius:8px;
            box-shadow:var(--shadow);border:1px solid var(--border)}
.data-table{border-collapse:collapse;width:100%;font-size:.82rem;background:var(--surface)}
.data-table th{background:#f1f5f9;padding:8px 12px;text-align:left;
               font-weight:600;font-size:.78rem;color:var(--text2);
               border-bottom:2px solid var(--border);
               cursor:pointer;user-select:none;white-space:nowrap}
.data-table th:hover{background:#e2e8f0}
.data-table th.sort-asc::after{content:" ↑";color:var(--accent)}
.data-table th.sort-desc::after{content:" ↓";color:var(--accent)}
.data-table td{padding:7px 12px;border-bottom:1px solid #f1f5f9;vertical-align:middle}
.data-table tr:last-child td{border-bottom:none}
.data-table tr:hover td{background:#f8f9fc}
.data-table.hidden-row{display:none}
.table-controls{margin:6px 0 12px}
.table-search{width:100%;max-width:320px;padding:7px 12px;border:1px solid var(--border);
              border-radius:7px;font-size:.82rem;font-family:'DM Sans',sans-serif;
              background:var(--surface);color:var(--text);outline:none}
.table-search:focus{border-color:var(--accent);box-shadow:0 0 0 2px rgba(99,102,241,.15)}

/* ── Variable explorer ── */
.vex-controls{margin-bottom:16px}
.var-select{padding:8px 12px;border:1px solid var(--border);border-radius:8px;
            font-size:.88rem;font-family:'DM Sans',sans-serif;
            background:var(--surface);color:var(--text);
            min-width:260px;outline:none;cursor:pointer}
.var-select:focus{border-color:var(--accent)}
.var-title{font-size:1.1rem;font-weight:700;margin:0 0 12px;color:var(--text)}
.var-dtype{font-size:.78rem;font-weight:500;padding:2px 8px;border-radius:999px;
           background:var(--accent-light);color:var(--accent);margin-left:8px}
.scale-toggle{display:flex;gap:4px;margin-bottom:10px}
.scale-btn{padding:5px 14px;border:1px solid var(--border);border-radius:6px;
           font-size:.8rem;font-weight:600;cursor:pointer;background:var(--surface);
           color:var(--text2);transition:all .15s}
.scale-btn.active{background:var(--accent);color:#fff;border-color:var(--accent)}

/* ── Plotly containers ── */
.plotly-chart{width:100%;margin:10px 0;border-radius:8px;overflow:hidden}

/* ── Outlier sliders ── */
.outlier-controls{display:grid;grid-template-columns:1fr 1fr;gap:16px;
                  background:var(--surface);border:1px solid var(--border);
                  border-radius:var(--radius);padding:14px 18px;margin:12px 0}
.slider-group{display:flex;flex-direction:column;gap:6px}
.slider-group label{font-size:.82rem;color:var(--text2)}
.slider-group strong{color:var(--text)}
input[type=range]{width:100%;accent-color:var(--accent);cursor:pointer}

/* ── Correlation threshold ── */
.cv-controls{display:flex;gap:16px;align-items:center;margin:10px 0}
.checkbox-label{display:flex;align-items:center;gap:6px;font-size:.84rem;cursor:pointer}
.checkbox-label input{accent-color:var(--accent);width:15px;height:15px}

/* ── Scorecard filters ── */
.sc-filters{display:flex;gap:16px;margin:8px 0 12px;flex-wrap:wrap}

/* ── Collapsible ── */
.collapsible{border:1px solid var(--border);border-radius:var(--radius);
             margin:8px 0;overflow:hidden}
.collapsible summary{padding:10px 14px;font-size:.88rem;font-weight:600;
                     cursor:pointer;list-style:none;user-select:none;
                     background:var(--surface);color:var(--text)}
.collapsible summary::-webkit-details-marker{display:none}
.collapsible summary::before{content:"▶ ";font-size:.7rem;color:var(--text3);margin-right:4px;
                              transition:transform .2s;display:inline-block}
.collapsible[open] summary::before{transform:rotate(90deg)}
.collapsible summary:hover{background:#f8f9fc}
.collapsible-body{padding:14px;border-top:1px solid var(--border);background:var(--bg)}

/* ── Recommendations ── */
.rec-card{background:var(--surface);border:1px solid var(--border);
          border-radius:var(--radius);margin:8px 0;overflow:hidden}
.rec-header{padding:10px 14px;display:flex;align-items:center;gap:8px;
            font-size:.9rem;flex-wrap:wrap;background:#fafafa}
.rec-type{font-size:.75rem;padding:2px 7px;border-radius:999px;
          background:var(--accent-light);color:var(--accent)}
.rec-priority{font-size:.78rem;font-weight:700;margin-left:auto}
.rec-items{padding:10px 14px;display:flex;flex-direction:column;gap:6px}
.rec-item{display:flex;align-items:baseline;gap:8px;font-size:.83rem}
.rec-finding{color:var(--text2)}
.rec-arrow{color:var(--text3)}
.rec-action{background:#f1f5f9;padding:2px 7px;border-radius:4px;
            font-family:'DM Mono',monospace;font-size:.78rem;color:var(--text)}

/* ── Two-column layout ── */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px}
@media(max-width:768px){.two-col{grid-template-columns:1fr}
  .sidebar{display:none}.outlier-controls{grid-template-columns:1fr}}
"""

_JS = r"""
// ── Chart rendering ──────────────────────────────────────────────────────────
function renderPendingCharts(container) {
  var els = (container||document).querySelectorAll(".plotly-chart[data-fig]");
  els.forEach(function(el) {
    try {
      var fig = JSON.parse(el.getAttribute("data-fig"));
      var h   = parseInt(el.getAttribute("data-height")||"320");
      if (!fig || !fig.data) return;
      if (fig.layout) fig.layout.height = h;
      Plotly.newPlot(el.id, fig.data, fig.layout||{}, {responsive:true, displayModeBar:false});
      el.removeAttribute("data-fig");
    } catch(e) { console.warn("Chart render error", el.id, e); }
  });
}

// ── Tab navigation ───────────────────────────────────────────────────────────
function showTab(tabId) {
  document.querySelectorAll(".tab-pane").forEach(function(p) { p.classList.remove("active"); });
  document.querySelectorAll(".nav-item").forEach(function(n) { n.classList.remove("active"); });
  var pane = document.getElementById(tabId);
  if (pane) {
    pane.classList.add("active");
    renderPendingCharts(pane);
  }
  var nav = document.querySelector('[data-tab="'+tabId+'"]');
  if (nav) nav.classList.add("active");
}

// ── Sub-tab navigation ────────────────────────────────────────────────────────
function showSubTab(btn, panelId) {
  var parent = btn.closest(".tab-pane")||document;
  parent.querySelectorAll(".sub-tab").forEach(function(b){ b.classList.remove("active"); });
  parent.querySelectorAll(".sub-panel").forEach(function(p){ p.style.display="none"; });
  btn.classList.add("active");
  var panel = document.getElementById(panelId);
  if (panel) { panel.style.display="block"; renderPendingCharts(panel); }
}

// ── Scale toggle (linear / log) ──────────────────────────────────────────────
function toggleScale(btn, showId, hideId) {
  var showEl = document.getElementById(showId);
  var hideEl = document.getElementById(hideId);
  if (!showEl || !hideEl) return;
  showEl.style.display = "block";
  hideEl.style.display = "none";
  renderPendingCharts(showEl);
  // Update button states
  var group = btn.closest(".scale-toggle");
  if (group) group.querySelectorAll(".scale-btn").forEach(function(b){ b.classList.remove("active"); });
  btn.classList.add("active");
}

// ── Table sort ───────────────────────────────────────────────────────────────
document.addEventListener("click", function(e) {
  var th = e.target.closest("th");
  if (!th) return;
  var table = th.closest("table.sortable");
  if (!table) return;
  var idx   = Array.from(th.parentNode.children).indexOf(th);
  var tbody = table.querySelector("tbody");
  var rows  = Array.from(tbody.querySelectorAll("tr"));
  var asc   = th.classList.contains("sort-asc");

  table.querySelectorAll("th").forEach(function(h){
    h.classList.remove("sort-asc","sort-desc");
  });

  rows.sort(function(a, b) {
    var av = a.cells[idx] ? a.cells[idx].textContent.trim() : "";
    var bv = b.cells[idx] ? b.cells[idx].textContent.trim() : "";
    var an = parseFloat(av.replace(/[,%]/g,"")), bn = parseFloat(bv.replace(/[,%]/g,""));
    if (!isNaN(an) && !isNaN(bn)) return asc ? an-bn : bn-an;
    return asc ? av.localeCompare(bv) : bv.localeCompare(av);
  });

  rows.forEach(function(r){ tbody.appendChild(r); });
  th.classList.add(asc ? "sort-desc" : "sort-asc");
});

// ── Table search ─────────────────────────────────────────────────────────────
document.addEventListener("input", function(e) {
  if (!e.target.classList.contains("table-search")) return;
  var q     = e.target.value.toLowerCase();
  var tid   = e.target.getAttribute("data-target");
  var table = tid ? document.getElementById(tid) : null;
  if (!table) return;
  table.querySelectorAll("tbody tr").forEach(function(row) {
    row.style.display = row.textContent.toLowerCase().includes(q) ? "" : "none";
  });
});

// ── Outlier sliders ───────────────────────────────────────────────────────────
function updateOutlier(idx, loVal, hiVal) {
  var loSl = document.getElementById("lo_sl_"+idx);
  var hiSl = document.getElementById("hi_sl_"+idx);
  if (!loSl || !hiSl) return;

  var lo = loVal !== null ? parseInt(loVal) : parseInt(loSl.value);
  var hi = hiVal !== null ? parseInt(hiVal) : parseInt(hiSl.value);

  var dataEl = document.getElementById("ol_data_"+idx);
  if (!dataEl) return;
  var pcts  = JSON.parse(dataEl.getAttribute("data-pct")||"[]");
  var total = parseInt(dataEl.getAttribute("data-total")||"0");

  if (!pcts.length) return;
  var loV = pcts[lo], hiV = pcts[hi];

  // Update labels
  var loLab = document.getElementById("lo_val_"+idx);
  var hiLab = document.getElementById("hi_val_"+idx);
  if (loLab) loLab.textContent = "P"+lo+" = "+loV.toPrecision(5);
  if (hiLab) hiLab.textContent = "P"+hi+" = "+hiV.toPrecision(5);

  // Update metric cards
  var elPLo  = document.getElementById("ol_p_lo_"+idx);
  var elLabLo= document.getElementById("ol_lab_lo_"+idx);
  var elPHi  = document.getElementById("ol_p_hi_"+idx);
  var elLabHi= document.getElementById("ol_lab_hi_"+idx);
  var elCnt  = document.getElementById("ol_count_"+idx);
  var elPct  = document.getElementById("ol_pct_"+idx);

  if (elPLo)   elPLo.textContent   = loV.toPrecision(5);
  if (elLabLo) elLabLo.textContent = "P"+lo;
  if (elPHi)   elPHi.textContent   = hiV.toPrecision(5);
  if (elLabHi) elLabHi.textContent = "P"+hi;

  // Count outliers using stored (sampled) array
  var arr = JSON.parse(dataEl.getAttribute("data-arr")||"[]");
  if (arr.length && total > 0) {
    var sampleSize = arr.length;
    var nOut = arr.filter(function(v){ return v < loV || v > hiV; }).length;
    // Scale back to full population
    var nOutEst = Math.round(nOut / sampleSize * total);
    var pctOut  = (nOut / sampleSize * 100).toFixed(2);
    if (elCnt) elCnt.textContent = nOutEst.toLocaleString() + (sampleSize < total ? "~" : "");
    if (elPct) elPct.textContent = pctOut + "%";
  }

  // Update boxplot vlines
  var boxDiv = document.getElementById("ol_box_"+idx);
  if (boxDiv && window.Plotly) {
    Plotly.relayout(boxDiv, {
      shapes: [
        {type:"line",x0:loV,x1:loV,y0:0,y1:1,yref:"paper",
         line:{color:"#f59e0b",dash:"dash",width:2}},
        {type:"line",x0:hiV,x1:hiV,y0:0,y1:1,yref:"paper",
         line:{color:"#ef4444",dash:"dash",width:2}},
      ]
    });
  }

  // Update histogram vrects
  var histDiv = document.getElementById("ol_hist_"+idx);
  if (histDiv && window.Plotly) {
    var p1  = pcts[1], p99 = pcts[99];
    var pad = (p99 - p1) * 0.05;
    var shapes = [];
    if (loV > p1 - pad) {
      shapes.push({type:"rect",x0:p1-pad,x1:loV,y0:0,y1:1,yref:"paper",
                   fillcolor:"#f59e0b",opacity:0.12,line:{width:0}});
    }
    if (hiV < p99 + pad) {
      shapes.push({type:"rect",x0:hiV,x1:p99+pad,y0:0,y1:1,yref:"paper",
                   fillcolor:"#ef4444",opacity:0.12,line:{width:0}});
    }
    Plotly.relayout(histDiv, {shapes: shapes});
  }
}

// ── Correlation threshold slider ──────────────────────────────────────────────
function filterCorrTable(val) {
  var thresh = val / 100;
  var label  = document.getElementById("corr-thresh-label");
  if (label) label.textContent = thresh.toFixed(2);

  var table = document.getElementById("corr-pairs-table");
  var count = 0;
  if (table) {
    table.querySelectorAll("tbody tr").forEach(function(row) {
      var rCell = row.querySelector('td[data-col="Pearson r"]') || row.cells[2];
      if (!rCell) return;
      var v = Math.abs(parseFloat(rCell.textContent));
      var show = !isNaN(v) && v >= thresh;
      row.style.display = show ? "" : "none";
      if (show) count++;
    });
  }
  var countEl = document.getElementById("corr-thresh-count");
  if (countEl) countEl.textContent = count + " pairs with |r| ≥ " + thresh.toFixed(2);
}

// ── Scorecard filter ──────────────────────────────────────────────────────────
function filterScorecard() {
  var checked = Array.from(document.querySelectorAll(".sc-filter:checked")).map(function(cb){return cb.value;});
  var table   = document.getElementById("sc-table");
  if (!table) return;
  table.querySelectorAll("tbody tr").forEach(function(row) {
    // Status is last meaningful column — find it
    var statusCell = Array.from(row.cells).find(function(td){ return td.textContent.includes("Fix")||td.textContent.includes("Review")||td.textContent.includes("Good"); });
    if (!statusCell) return;
    var status = statusCell.textContent.trim();
    row.style.display = checked.some(function(c){ return status.includes(c.replace("❌ ","").replace("⚠️ ","").replace("✅ ","")); }) ? "" : "none";
  });
}

// ── Recommendations filter ────────────────────────────────────────────────────
function filterRecs() {
  var checked = Array.from(document.querySelectorAll(".rec-filter:checked")).map(function(cb){return cb.value;});
  document.querySelectorAll(".rec-card").forEach(function(card) {
    var pri = card.getAttribute("data-priority")||"";
    card.style.display = checked.some(function(c){ return pri===c; }) ? "" : "none";
  });
}

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", function() {
  // Activate first sub-panels
  document.querySelectorAll(".sub-panels").forEach(function(sp) {
    var first = sp.querySelector(".sub-panel");
    if (first) first.style.display = "block";
  });

  // Init corr threshold display
  var sl = document.getElementById("corr-thresh-sl");
  if (sl) filterCorrTable(sl.value);

  // Render charts in the initially-active tab
  var activePane = document.querySelector(".tab-pane.active");
  if (activePane) renderPendingCharts(activePane);

  // Show first sub-tab panel in each tab
  document.querySelectorAll(".tab-pane").forEach(function(tp) {
    var firstPanel = tp.querySelector(".sub-panel");
    if (firstPanel) firstPanel.style.display = "block";
    var firstBtn = tp.querySelector(".sub-tab");
    if (firstBtn) firstBtn.classList.add("active");
  });
});
"""


# ─────────────────────────────────────────────────────────────────────────────
# Plotly CDN — bundled as a minimal self-contained reference
# We use the CDN URL but with a fallback note. For true offline use,
# the caller can pass plotly_src with the full plotly.min.js content.
# ─────────────────────────────────────────────────────────────────────────────
_PLOTLY_CDN = "https://cdn.plot.ly/plotly-2.32.0.min.js"


# ─────────────────────────────────────────────────────────────────────────────
# Main entry point
# ─────────────────────────────────────────────────────────────────────────────

def generate_report(results: dict,
                    output_path: str | None = None,
                    open_browser: bool = True,
                    offline: bool = False) -> str:
    """
    Generate a fully interactive HTML EDA dashboard from run_eda() results.

    Parameters
    ----------
    results      : dict returned by run_eda()
    output_path  : optional file path to save the HTML (e.g. "report.html" or
                   "/dbfs/FileStore/reports/eda_report.html")
    open_browser : if True and output_path is set, opens the file in the default
                   browser automatically (local use only)
    offline      : if True, attempts to embed Plotly.js inline (requires
                   plotly to be installed). If False, loads from CDN.
                   Default False — CDN is fine for most corporate environments.

    Returns
    -------
    str : the complete HTML string (suitable for displayHTML() in Databricks)

    Examples
    --------
    # Databricks — render inline
    html = generate_report(results)
    displayHTML(html)

    # Save to DBFS
    generate_report(results, output_path="/dbfs/FileStore/eda_report.html")

    # Local — save and auto-open
    generate_report(results, output_path="eda_report.html")
    """
    target  = results.get("target_col")
    n_rows  = results.get("n_rows", 0)
    n_feat  = results.get("n_features", 0)
    elapsed = results.get("elapsed_sec", 0)
    dm      = results.get("dtype_map", {})
    sc      = results.get("scorecard", pd.DataFrame())
    n_fix   = int((sc["Status"] == "❌ Fix First").sum()) if len(sc) else 0
    n_rev   = int((sc["Status"] == "⚠️ Review").sum())   if len(sc) else 0
    n_ok    = int((sc["Status"] == "✅ Good").sum())      if len(sc) else 0
    tot_sc  = len(sc)

    # ── Nav items ────────────────────────────────────────────────────────────
    corr = results.get("correlations", {})
    cmp  = results.get("comparison", {})
    tabs = [
        ("tab-overview",    "📋", "Overview"),
        ("tab-vex",         "🔬", "Variable Explorer"),
        ("tab-hitrate",     "💧", "Hit Rate"),
        ("tab-catquality",  "🏷️", "Category Quality"),
        ("tab-outliers",    "⚡", "Outliers"),
        ("tab-corr",        "🔗", "Correlations"),
        ("tab-comparison",  "⚖️", "Data Comparison"),
        ("tab-scorecard",   "🏆", "Quality Scorecard"),
    ]
    nav_html = "\n".join(
        f'<div class="nav-item{"active" if i==0 else ""}" data-tab="{tid}" '
        f'onclick="showTab(\'{tid}\')">'
        f'<span class="nav-icon">{icon}</span>{label}</div>'
        for i, (tid, icon, label) in enumerate(tabs)
    )

    # Sidebar quality bar
    wf = round(n_fix/tot_sc*180) if tot_sc else 0
    wr = round(n_rev/tot_sc*180) if tot_sc else 0
    wo = 180 - wf - wr

    sidebar_html = f"""
<div class="sidebar">
  <div class="sidebar-header">
    <div class="sidebar-logo">📊 EDA Toolkit</div>
    <div class="sidebar-sub">Insurance Analytics · v5</div>
  </div>
  <div class="sidebar-section">Navigation</div>
  {nav_html}
  <div class="sidebar-stats">
    <div class="stat-row"><span>Rows</span><strong>{n_rows:,}</strong></div>
    <div class="stat-row"><span>Columns</span><strong>{n_feat}</strong></div>
    <div class="stat-row"><span>Target</span><strong>{_esc(target or "—")}</strong></div>
    <div class="stat-row"><span>Runtime</span><strong>{elapsed:.1f}s</strong></div>
    {"" if not tot_sc else f'''
    <div class="stat-row" style="margin-top:8px"><span>Quality</span><span></span></div>
    <div class="quality-bar">
      <div style="width:{wf}px;background:#ef4444"></div>
      <div style="width:{wr}px;background:#f59e0b"></div>
      <div style="width:{wo}px;background:#22c55e"></div>
    </div>
    <div class="stat-row"><span>🔴 Fix</span><strong>{n_fix}</strong></div>
    <div class="stat-row"><span>🟡 Review</span><strong>{n_rev}</strong></div>
    <div class="stat-row"><span>🟢 Good</span><strong>{n_ok}</strong></div>
    '''}
  </div>
</div>"""

    # ── Page header ──────────────────────────────────────────────────────────
    type_summary = "  ·  ".join(
        f"{cnt} {t}" for t, cnt in pd.Series(dm).value_counts().items()
    ) if dm else ""
    header_html = f"""<div class="page-header">
  <h1>🔍 Insurance EDA Report</h1>
  <p>{n_rows:,} rows &nbsp;·&nbsp; {n_feat} features &nbsp;·&nbsp; {type_summary}
     &nbsp;·&nbsp; Target: {_esc(target or "—")} &nbsp;·&nbsp; Runtime: {elapsed:.1f}s</p>
</div>"""

    # ── Build all tab content (lazy: only render charts when tab opened) ──────
    print("[HTML] Building tab content...", end="", flush=True)

    tab_content = {
        "tab-overview":   _sec_overview(results),
        "tab-vex":        _sec_variable_explorer(results),
        "tab-hitrate":    _sec_hit_rate(results),
        "tab-catquality": _sec_category_quality(results),
        "tab-outliers":   _sec_outliers(results),
        "tab-corr":       _sec_correlations(results),
        "tab-comparison": _sec_comparison(results),
        "tab-scorecard":  _sec_scorecard(results),
    }
    print(" done.")

    tabs_html = "\n".join(
        f'<div id="{tid}" class="tab-pane{"active" if i==0 else ""}">'
        f'{content}'
        f'</div>'
        for i, (tid, content) in enumerate(tab_content.items())
    )

    # ── Plotly script ─────────────────────────────────────────────────────────
    if offline:
        try:
            import plotly
            plotly_path = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
            if plotly_path.exists():
                plotly_script = f"<script>{plotly_path.read_text()}</script>"
            else:
                plotly_script = f'<script src="{_PLOTLY_CDN}"></script>'
        except Exception:
            plotly_script = f'<script src="{_PLOTLY_CDN}"></script>'
    else:
        plotly_script = f'<script src="{_PLOTLY_CDN}"></script>'

    # ── Assemble full HTML ─────────────────────────────────────────────────────
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>EDA Report — {_esc(target or "no target")} — {n_rows:,} rows</title>
{plotly_script}
<style>{_CSS}</style>
</head>
<body>
<div class="layout">
  {sidebar_html}
  <div class="main">
    {header_html}
    {tabs_html}
  </div>
</div>
<script>{_JS}</script>
</body>
</html>"""

    # ── Save / open ───────────────────────────────────────────────────────────
    if output_path:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
        size_kb = path.stat().st_size / 1024
        print(f"[HTML] Saved → {path}  ({size_kb:.0f} KB)")
        if open_browser and not str(output_path).startswith("/dbfs"):
            try:
                webbrowser.open(path.resolve().as_uri())
            except Exception:
                pass

    return html
