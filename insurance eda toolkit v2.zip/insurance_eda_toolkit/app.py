"""
Insurance EDA Toolkit v2.0 — Streamlit Dashboard
==================================================
Run:  streamlit run app.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import io, json, zipfile, os

from eda_engine import run_eda
from charts import (
    fig_histogram, fig_boxplot, fig_violin, fig_ecdf, fig_log_histogram,
    fig_hitrate_bar, fig_missing_bar, fig_corr_heatmap,
    fig_importance_bar, fig_iv_bar, fig_outlier_bar,
    fig_skewness_bar, fig_dtype_pie, fig_flags_bar,
    fig_zero_inflation, fig_woe,
)

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Insurance EDA Toolkit v2",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
html,body,[class*="css"]{font-family:'Segoe UI',sans-serif;}
.eda-header{background:linear-gradient(135deg,#1f4e79,#2e75b6);color:white;
  padding:1.2rem 2rem;border-radius:12px;margin-bottom:1rem;}
.eda-header h1{margin:0;font-size:1.7rem;}
.eda-header p{margin:.2rem 0 0;opacity:.85;font-size:.92rem;}
.kpi-card{background:white;border:1px solid #dce6f0;border-radius:10px;
  padding:.9rem 1rem;text-align:center;box-shadow:0 2px 6px rgba(0,0,0,.06);}
.kpi-card .value{font-size:1.8rem;font-weight:700;color:#1f4e79;}
.kpi-card .label{font-size:.75rem;color:#555;margin-top:.2rem;}
.sec{background:#f0f4f8;border-left:5px solid #2e75b6;padding:.5rem 1rem;
  border-radius:4px;margin:1rem 0 .6rem;font-weight:600;font-size:1rem;color:#1f4e79;}
.badge{display:inline-block;border-radius:12px;padding:.12rem .55rem;
  font-size:.72rem;font-weight:600;margin:.1rem;}
.badge-warn{background:#fff3cd;color:#856404;border:1px solid #ffc107;}
.badge-danger{background:#f8d7da;color:#842029;border:1px solid #f5c2c7;}
.badge-ok{background:#d1e7dd;color:#0f5132;border:1px solid #badbcc;}
.badge-info{background:#cfe2ff;color:#084298;border:1px solid #b6d4fe;}
.rec-box{background:#f0f7ff;border:1px solid #b3d4f5;border-radius:8px;
  padding:.85rem 1rem;margin:.5rem 0;}
.rec-finding{color:#444;font-size:.84rem;margin:.12rem 0;}
.rec-action{color:#1f4e79;font-size:.84rem;font-weight:600;margin:.12rem 0;}
.rec-reason{color:#777;font-size:.78rem;margin:.08rem 0 .25rem 1rem;font-style:italic;}
.feat-card{background:white;border:1px solid #dce6f0;border-radius:10px;
  padding:1rem;margin-bottom:.7rem;}
[data-testid="stSidebar"]{background:#1f4e79;}
[data-testid="stSidebar"] *:not(.stButton *){color:white!important;}
[data-testid="stSidebar"] .stSelectbox > div[data-baseweb="select"] > div{
  background:#2e75b6!important;}
.stTabs [data-baseweb="tab"]{border-radius:8px 8px 0 0;padding:.4rem .9rem;font-weight:600;}
</style>
""", unsafe_allow_html=True)


# ── Helpers ───────────────────────────────────────────────────────────────────
def kpi(val, label, col):
    col.markdown(f'<div class="kpi-card"><div class="value">{val}</div>'
                 f'<div class="label">{label}</div></div>', unsafe_allow_html=True)

def sec(title):
    st.markdown(f'<div class="sec">📌 {title}</div>', unsafe_allow_html=True)

def badge(text, kind="warn"):
    return f'<span class="badge badge-{kind}">{text}</span>'

def dtype_badge(dtype):
    cm = {"Numeric":"#2e75b6","Categorical":"#ed7d31","Boolean":"#70ad47","Date":"#7030a0"}
    c  = cm.get(dtype,"#888")
    return f'<span style="background:{c};color:white;padding:2px 8px;border-radius:10px;font-size:.72rem;font-weight:600">{dtype}</span>'

def priority_badge(p):
    if "Critical" in p:   return badge(p, "danger")
    if "High"     in p:   return badge(p, "warn")
    if "Medium"   in p:   return badge(p, "info")
    return badge(p, "ok")

def render_recommendation(rec: dict):
    findings = rec.get("Findings", [])
    actions  = rec.get("Recommended_Actions", [])
    reasons  = rec.get("Reasons", [])
    html     = '<div class="rec-box">'
    if findings:
        html += "<b>🔍 Findings:</b><br>"
        for f in findings:
            html += f'<div class="rec-finding">• {f}</div>'
    if actions:
        html += "<b>✅ Recommended Actions:</b><br>"
        for i, a in enumerate(actions):
            html += f'<div class="rec-action">→ {a}</div>'
            if i < len(reasons):
                html += f'<div class="rec-reason">↳ {reasons[i]}</div>'
    html += "</div>"
    st.markdown(html, unsafe_allow_html=True)


# ── SIDEBAR ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Configuration")
    st.markdown("---")

    uploaded_file = st.file_uploader("Upload Dataset (CSV)", type=["csv"])

    if uploaded_file:
        sep = st.selectbox("Delimiter", [",", ";", "|", "\t"], index=0)
        try:
            df_raw   = pd.read_csv(uploaded_file, sep=sep, low_memory=False)
            all_cols = df_raw.columns.tolist()

            target_col = st.selectbox("Target Variable", ["(None)"] + all_cols)
            target_col = None if target_col == "(None)" else target_col

            st.markdown("---")
            st.markdown("### 🔬 EDA Steps")
            st.caption("Toggle steps on/off:")
            steps = {
                "STEP_METADATA":           st.checkbox("Metadata & Flags",        value=True),
                "STEP_DISTRIBUTION":       st.checkbox("Distribution Stats",       value=True),
                "STEP_HITRATE":            st.checkbox("Hit Rate Analysis",        value=True),
                "STEP_OUTLIERS":           st.checkbox("Outlier Detection",        value=True),
                "STEP_MISSING":            st.checkbox("Missing Value Diagnostics",value=True),
                "STEP_CORRELATION":        st.checkbox("Correlation Analysis",     value=True),
                "STEP_FEATURE_IMPORTANCE": st.checkbox("Feature Importance",       value=bool(target_col)),
                "STEP_DISTRIBUTION_PLOTS": st.checkbox("Distribution Plot Data",   value=True),
                "STEP_IV_WOE":             st.checkbox("IV / WoE Analysis",        value=bool(target_col)),
                "STEP_ZERO_INFLATION":     st.checkbox("Zero Inflation Analysis",  value=True),
                "STEP_RARE_CATEGORIES":    st.checkbox("Rare Category Analysis",   value=True),
            }

            st.markdown("---")
            st.markdown("### ⚡ Performance")
            corr_threshold = st.slider("Correlation Threshold", 0.5, 1.0, 0.8, 0.05)
            max_feat_shown = st.slider("Max Features in Explorer", 10, 300, 50, 10)

            n_rows    = len(df_raw)
            use_samp  = st.checkbox("Enable Row Sampling", value=n_rows > 500_000)
            samp_size = None
            if use_samp:
                samp_pct  = st.select_slider("Sample Size", ["5%","10%","20%","50%","100%"],
                                              value="20%" if n_rows > 1_000_000 else "50%")
                samp_frac = int(samp_pct.replace("%",""))/100
                samp_size = int(n_rows * samp_frac)
                st.caption(f"Analyzing **{samp_size:,}** of {n_rows:,} rows")

            run_btn = st.button("▶  Run EDA", use_container_width=True, type="primary")

        except Exception as e:
            st.error(f"Error reading file: {e}")
            df_raw  = None
            run_btn = False
            steps   = {}
            target_col  = None
            corr_threshold = 0.8
            max_feat_shown = 50
            use_samp = False
            samp_size = None
    else:
        df_raw = None; run_btn = False; steps = {}
        target_col = None; corr_threshold = 0.8; max_feat_shown = 50
        use_samp = False; samp_size = None

    st.markdown("---")
    st.markdown("**Insurance EDA Toolkit v2.0**")
    st.markdown("📊 11 analysis steps | ⚡ 2.5M × 300 in <10 min")


# ── HEADER ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="eda-header">
  <h1>📊 Insurance EDA Toolkit v2.0</h1>
  <p>Scalable EDA & Preprocessing Engine · Feature Importance · IV/WoE · Automated Recommendations</p>
</div>
""", unsafe_allow_html=True)


# ── SAMPLE DATA BUTTON ────────────────────────────────────────────────────────
if df_raw is None:
    st.info("👈 Upload a CSV or load the **sample insurance dataset** below.")
    if st.button("📂 Load Sample Insurance Dataset (5,000 rows)"):
        np.random.seed(42); n = 5_000
        df_raw = pd.DataFrame({
            "Policy_ID":      range(1, n+1),
            "Vehicle_Age":    np.random.exponential(5, n),
            "Vehicle_Value":  np.random.lognormal(10, 0.8, n),
            "Driver_Age":     np.clip(np.random.normal(38, 12, n), 18, 85),
            "Annual_Mileage": np.random.exponential(12000, n),
            "NCD_Years":      np.random.randint(0, 10, n).astype(float),
            "Policy_Duration":np.random.exponential(2, n),
            "Premium":        np.random.lognormal(6.5, 0.6, n),
            "Claim_Count":    np.random.poisson(0.15, n).astype(float),
            "Claim_Amount":   np.where(np.random.random(n) < 0.12,
                                       np.random.lognormal(7, 1.2, n), 0),
            "Vehicle_Type":   np.random.choice(["Sedan","SUV","Hatchback","Truck","Van","Convertible","Other"], n,
                                                p=[.35,.25,.20,.08,.06,.04,.02]),
            "Vehicle_Make":   np.random.choice(["Toyota","Ford","BMW","Honda","Nissan","Mercedes",
                                                 "Hyundai","Chevrolet","Audi","VW","Kia","Mazda"], n,
                                                p=[.18,.15,.10,.10,.09,.08,.07,.07,.06,.05,.03,.02]),
            "Region":         np.random.choice(["North","South","East","West","Central"], n),
            "Coverage_Type":  np.random.choice(["Comprehensive","Third Party","TP Fire & Theft"], n,
                                                p=[.55,.30,.15]),
            "Is_Commercial":  np.random.choice([True, False], n, p=[.15,.85]),
            "Renewal_Flag":   np.random.choice([0, 1], n, p=[.25,.75]),
            "Claim_Flag":     np.random.choice([0, 1], n, p=[.88,.12]),
        })
        for col, pct in [("Vehicle_Age",.08),("Vehicle_Make",.05),("Annual_Mileage",.15),("NCD_Years",.03)]:
            df_raw.loc[np.random.random(n)<pct, col] = np.nan
        df_raw.loc[np.random.choice(n, 20), "Vehicle_Value"] *= 15
        df_raw.loc[np.random.choice(n, 10), "Annual_Mileage"] *= 10

        target_col = "Claim_Flag"
        corr_threshold = 0.8; max_feat_shown = 50
        steps = {k: True for k in [
            "STEP_METADATA","STEP_DISTRIBUTION","STEP_HITRATE","STEP_OUTLIERS",
            "STEP_MISSING","STEP_CORRELATION","STEP_FEATURE_IMPORTANCE",
            "STEP_DISTRIBUTION_PLOTS","STEP_IV_WOE","STEP_ZERO_INFLATION","STEP_RARE_CATEGORIES"
        ]}
        use_samp = False; samp_size = None; run_btn = True


# ── RUN EDA ───────────────────────────────────────────────────────────────────
if df_raw is not None and run_btn:
    df_to_run = df_raw
    samp_note = ""
    if use_samp and samp_size and samp_size < len(df_raw):
        df_to_run = df_raw.sample(n=samp_size, random_state=42).reset_index(drop=True)
        samp_note = f" (sampled {samp_size:,} of {len(df_raw):,} rows)"
        st.info(f"⚡ Sampling: analyzing **{samp_size:,}** rows ({100*samp_size//len(df_raw)}% of data)")

    prog_bar  = st.progress(0, text="Starting...")
    stat_text = st.empty()

    def _cb(pct, msg):
        prog_bar.progress(min(pct,100), text=msg)
        stat_text.caption(f"⏱ {msg}")

    R = run_eda(df_to_run, target_col=target_col,
                corr_threshold=corr_threshold,
                progress_callback=_cb, **steps)

    prog_bar.progress(100, text="Complete!")
    stat_text.empty()

    st.session_state.update({"R": R, "df": df_to_run,
                              "target": target_col, "samp_note": samp_note,
                              "max_feat": max_feat_shown})
    elapsed = R.get("elapsed_sec", 0)
    st.success(f"✅ Done in **{elapsed:.1f}s** ({elapsed/60:.1f} min) — "
               f"**{R['n_features']} features** × **{R['n_rows']:,} rows**{samp_note}")


# ═══════════════════════════════════════════════════════════════════════════════
#  DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════
if "R" not in st.session_state:
    st.markdown("""
    <div style="text-align:center;padding:3rem 2rem;background:white;border-radius:16px;
         border:2px dashed #b3d4f5;margin-top:2rem;">
      <h2 style="color:#1f4e79">👈 Get Started</h2>
      <p style="color:#555;font-size:1rem">Upload a CSV or load the sample dataset, then click <b>Run EDA</b></p>
      <br>
      <div style="display:flex;justify-content:center;gap:1.5rem;flex-wrap:wrap">
        <div style="background:#f0f7ff;padding:.9rem 1.4rem;border-radius:10px;min-width:155px">
          <b style="color:#1f4e79">Step 1</b><br>Upload CSV</div>
        <div style="background:#f0f7ff;padding:.9rem 1.4rem;border-radius:10px;min-width:155px">
          <b style="color:#1f4e79">Step 2</b><br>Configure Steps</div>
        <div style="background:#f0f7ff;padding:.9rem 1.4rem;border-radius:10px;min-width:155px">
          <b style="color:#1f4e79">Step 3</b><br>Run EDA</div>
        <div style="background:#f0f7ff;padding:.9rem 1.4rem;border-radius:10px;min-width:155px">
          <b style="color:#1f4e79">Step 4</b><br>Explore & Export</div>
      </div>
    </div>""", unsafe_allow_html=True)
    st.stop()


R          = st.session_state["R"]
df         = st.session_state["df"]
target     = st.session_state["target"]
samp_note  = st.session_state.get("samp_note","")
max_feat   = st.session_state.get("max_feat", 50)

meta_df       = R["metadata"]
distributions = R["distributions"]
hit_rates     = R["hit_rates"]
outliers_d    = R["outliers"]
missing_d     = R["missing"]
plot_data     = R["plot_data"]
corr_d        = R["correlations"]
importance_d  = R["importance"]
iv_d          = R["iv_woe"]
zero_d        = R["zero_inflation"]
rare_d        = R["rare_categories"]
recs          = R["recommendations"]
feature_cols  = R["feature_cols"]
dtype_map     = R["dtype_map"]
rec_lookup    = {r["Feature"]: r for r in recs}

if samp_note:
    st.info(f"📊 Results based on sampled data{samp_note}")

tabs = st.tabs([
    "🏠 Overview",
    "🔬 Feature Explorer",
    "📈 Distributions",
    "📊 Hit Rates",
    "🚨 Outliers",
    "❓ Missing Values",
    "🔗 Correlations",
    "🎯 Feature Importance",
    "📐 IV / WoE",
    "✅ Recommendations",
    "📥 Export",
])


# ══ TAB 0: OVERVIEW ═══════════════════════════════════════════════════════════
with tabs[0]:
    sec("Dataset Summary")
    c1,c2,c3,c4,c5,c6 = st.columns(6)
    kpi(f"{R['n_rows']:,}", "Rows", c1)
    kpi(str(R['n_features']), "Features", c2)
    kpi(str(sum(1 for v in dtype_map.values() if v=="Numeric")), "Numeric", c3)
    kpi(str(sum(1 for v in dtype_map.values() if v=="Categorical")), "Categorical", c4)
    kpi(str((meta_df["Missing %"]>0).sum()) if not meta_df.empty else "—", "With Missing", c5)
    kpi(target or "None", "Target", c6)

    st.markdown("")
    cl, cr = st.columns(2)
    with cl:
        sec("Feature Types")
        if not meta_df.empty:
            st.plotly_chart(fig_dtype_pie(meta_df), use_container_width=True)
    with cr:
        sec("Feature Flags")
        if not meta_df.empty:
            st.plotly_chart(fig_flags_bar(meta_df), use_container_width=True)

    sec("Feature Metadata Table")
    if not meta_df.empty:
        st.dataframe(
            meta_df.sort_values("Missing %", ascending=False).reset_index(drop=True)
            .style.background_gradient(subset=["Missing %"], cmap="OrRd")
            .background_gradient(subset=["Top Value %"], cmap="Blues"),
            use_container_width=True, height=440,
        )


# ══ TAB 1: FEATURE EXPLORER ════════════════════════════════════════════════════
with tabs[1]:
    sec("Feature Deep Dive")
    sel = st.selectbox("Select Feature", feature_cols, key="feat_sel")
    fm  = meta_df[meta_df["Feature"]==sel].iloc[0] if not meta_df.empty else {}
    dt  = dtype_map.get(sel, "Numeric")
    s   = df[sel]

    # Header card
    flags_raw = fm.get("Flags","—") if hasattr(fm,"get") else str(fm["Flags"])
    bdg = ""
    if flags_raw and flags_raw != "—":
        for fl in flags_raw.split(","):
            fl = fl.strip()
            sev = "danger" if fl in ["HIGH_MISSING","NEAR_CONSTANT"] else "warn"
            bdg += badge(fl, sev)

    imp_score = importance_d.get(sel, {}).get("score") if importance_d else None
    iv_score  = iv_d.get(sel, {}).get("iv") if iv_d else None
    imp_txt   = f" | Importance: <b>{imp_score:.3f}</b>" if imp_score is not None else ""
    iv_txt    = f" | IV: <b>{iv_score:.3f}</b>" if iv_score is not None else ""

    if hasattr(fm, "__getitem__"):
        st.markdown(f"""
        <div class="feat-card">
          <b style="font-size:1.1rem">{sel}</b>&nbsp;{dtype_badge(dt)}&nbsp;&nbsp;{bdg}
          <br><br>
          <span style="color:#555;font-size:.84rem">
          <b>Total Obs:</b> {int(fm["Total Obs"]):,} &nbsp;|&nbsp;
          <b>Unique:</b> {int(fm["Unique Values"])} &nbsp;|&nbsp;
          <b>Missing:</b> {fm["Missing %"]}% &nbsp;|&nbsp;
          <b>Zero %:</b> {fm["Zero %"]}% &nbsp;|&nbsp;
          <b>Top Value:</b> {fm["Top Value %"]}%
          {imp_txt}{iv_txt}
          </span>
        </div>""", unsafe_allow_html=True)

    if dt == "Numeric":
        pd_  = plot_data.get(sel, {})
        c1, c2 = st.columns(2)
        c1.plotly_chart(fig_histogram(pd_, sel), use_container_width=True)
        c2.plotly_chart(fig_boxplot(pd_, sel),   use_container_width=True)
        c3, c4 = st.columns(2)
        c3.plotly_chart(fig_violin(pd_, sel),    use_container_width=True)
        c4.plotly_chart(fig_ecdf(pd_, sel),      use_container_width=True)

        if sel in distributions:
            d = distributions[sel]
            st.markdown("#### 📊 Distribution Statistics")
            r1 = st.columns(5)
            for col_w, (lab, key) in zip(r1, [("Min","min"),("Max","max"),("Mean","mean"),("Median","median"),("Std","std")]):
                col_w.metric(lab, f"{d[key]:.4g}")
            r2 = st.columns(5)
            for col_w, (lab, key) in zip(r2, [("Skewness","skewness"),("Kurtosis","kurtosis"),("P1","p1"),("P25","p25"),("P99","p99")]):
                col_w.metric(lab, f"{d[key]:.4g}")
            st.info(f"**Shape:** {d['shape']}  |  **Zero %:** {d['zero_pct']:.1f}%  |  **Unique Density:** {d['unique_density']:.4f}")

            if abs(d["skewness"]) > 1.5:
                st.plotly_chart(fig_log_histogram(pd_, sel), use_container_width=True)

        if sel in outliers_d:
            o = outliers_d[sel]
            st.markdown("#### 🚨 Outlier Summary")
            oc = st.columns(4)
            oc[0].metric("IQR Outliers",   f"{o['iqr_count']} ({o['iqr_pct']}%)")
            oc[1].metric("Z-Score Outliers",f"{o['zscore_count']} ({o['zscore_pct']}%)")
            oc[2].metric("Percentile Out", f"{o['pct_count']} ({o['pct_pct']}%)")
            oc[3].metric("P99 Cap",         f"{o['p99_cap']}")
            if o["flags"] != "—":
                st.warning(f"⚠️ **{o['flags']}**")

    else:
        if sel in hit_rates:
            c1, c2 = st.columns([2,1])
            c1.plotly_chart(fig_hitrate_bar(hit_rates[sel], sel), use_container_width=True)
            c2.dataframe(hit_rates[sel], use_container_width=True, height=320)
        if sel in rare_d:
            st.warning(f"⚠️ **{rare_d[sel]['rare_count']} rare categories** "
                       f"({rare_d[sel]['rare_exposure_pct']:.1f}% combined exposure): "
                       f"{', '.join(str(x) for x in rare_d[sel]['rare_categories'][:10])}")

    if sel in missing_d and missing_d[sel]["missing_count"] > 0:
        m = missing_d[sel]
        st.markdown("#### ❓ Missing Values")
        mc = st.columns(3)
        mc[0].metric("Missing Count", m["missing_count"])
        mc[1].metric("Missing %",     f"{m['missing_pct']}%")
        mc[2].metric("Informative?",  "Yes ⚠️" if m["informative_missing"] else "No ✓")

    if sel in iv_d:
        iv_row = iv_d[sel]
        st.markdown(f"#### 📐 IV = {iv_row['iv']:.4f} → **{iv_row['iv_power']}**")
        st.plotly_chart(fig_woe(iv_row["woe_table"], sel), use_container_width=True)

    st.markdown("#### ✅ Recommendation")
    if sel in rec_lookup:
        render_recommendation(rec_lookup[sel])

    st.markdown("---")
    sec(f"Feature Cards (top {max_feat})")
    shown = feature_cols[:max_feat]
    for i in range(0, len(shown), 3):
        chunk = shown[i:i+3]
        cols  = st.columns(3)
        for j, feat in enumerate(chunk):
            fmr = meta_df[meta_df["Feature"]==feat]
            if len(fmr) == 0: continue
            fmr = fmr.iloc[0]
            flags_r2 = str(fmr["Flags"])
            bdg2 = "".join(badge(fl.strip(),"danger" if fl.strip() in ["HIGH_MISSING","NEAR_CONSTANT"] else "warn")
                           for fl in flags_r2.split(",") if fl.strip() and fl.strip()!="—")
            with cols[j]:
                with st.expander(f"**{feat}** [{dtype_map.get(feat,'?')}]", expanded=False):
                    imp_s = importance_d.get(feat,{}).get("score","—") if importance_d else "—"
                    iv_s  = iv_d.get(feat,{}).get("iv","—") if iv_d else "—"
                    st.markdown(f"Missing: **{fmr['Missing %']}%** | Unique: **{fmr['Unique Values']}**<br>{bdg2}", unsafe_allow_html=True)
                    if imp_s != "—": st.write(f"Importance: `{imp_s:.3f}`")
                    if iv_s  != "—": st.write(f"IV: `{iv_s:.3f}`")
                    if feat in rec_lookup:
                        for a in rec_lookup[feat]["Recommended_Actions"][:2]:
                            st.markdown(f"→ {a}")


# ══ TAB 2: DISTRIBUTIONS ═══════════════════════════════════════════════════════
with tabs[2]:
    sec("Distribution Analysis")
    num_feats = [c for c in feature_cols if dtype_map.get(c) == "Numeric"]
    if not num_feats:
        st.info("No numeric features.")
    else:
        st.plotly_chart(fig_skewness_bar(distributions), use_container_width=True)

        sec("Distribution Statistics Table")
        if distributions:
            drows = []
            for f in num_feats:
                if f in distributions:
                    d = distributions[f]
                    drows.append({"Feature":f,"Min":round(d["min"],4),"Max":round(d["max"],4),
                                   "Mean":round(d["mean"],4),"Median":round(d["median"],4),
                                   "Std":round(d["std"],4),"Skewness":round(d["skewness"],4),
                                   "Kurtosis":round(d["kurtosis"],4),"Zero %":round(d["zero_pct"],2),
                                   "P1":round(d["p1"],4),"P25":round(d["p25"],4),
                                   "P75":round(d["p75"],4),"P99":round(d["p99"],4),"Shape":d["shape"]})
            if drows:
                dst = pd.DataFrame(drows)
                st.dataframe(dst.style.background_gradient(subset=["Skewness"],cmap="RdYlGn_r")
                               .background_gradient(subset=["Zero %"],cmap="OrRd"),
                             use_container_width=True, height=400)

        sec("Individual Plots")
        sel_num = st.multiselect("Select features",num_feats,default=num_feats[:min(3,len(num_feats))],key="dist_ms")
        for feat in sel_num:
            pd_ = plot_data.get(feat,{})
            with st.expander(f"📈 {feat}", expanded=True):
                cols = st.columns(2)
                cols[0].plotly_chart(fig_histogram(pd_, feat), use_container_width=True)
                cols[1].plotly_chart(fig_boxplot(pd_, feat),   use_container_width=True)
                cols2 = st.columns(2)
                cols2[0].plotly_chart(fig_violin(pd_, feat),   use_container_width=True)
                cols2[1].plotly_chart(fig_ecdf(pd_, feat),     use_container_width=True)


# ══ TAB 3: HIT RATES ═══════════════════════════════════════════════════════════
with tabs[3]:
    sec("Hit Rate Analysis")
    cat_feats = [c for c in feature_cols if dtype_map.get(c) in ["Categorical","Boolean"]]
    num_feats2= [c for c in feature_cols if dtype_map.get(c) == "Numeric"]

    if cat_feats:
        sec("Categorical Features")
        sel_cats = st.multiselect("Select categorical features", cat_feats,
                                   default=cat_feats[:min(3,len(cat_feats))], key="hr_cat")
        for feat in sel_cats:
            if feat in hit_rates:
                with st.expander(f"📊 {feat}", expanded=True):
                    c1,c2 = st.columns([2,1])
                    c1.plotly_chart(fig_hitrate_bar(hit_rates[feat], feat), use_container_width=True)
                    c2.dataframe(hit_rates[feat], use_container_width=True, height=280)

    if num_feats2:
        sec("Numeric Features (Binned)")
        sel_nums = st.multiselect("Select numeric features", num_feats2,
                                   default=num_feats2[:min(3,len(num_feats2))], key="hr_num")
        for feat in sel_nums:
            if feat in hit_rates and len(hit_rates[feat]) > 0:
                with st.expander(f"📊 {feat}", expanded=True):
                    c1,c2 = st.columns([2,1])
                    c1.plotly_chart(fig_hitrate_bar(hit_rates[feat], feat), use_container_width=True)
                    c2.dataframe(hit_rates[feat], use_container_width=True, height=280)


# ══ TAB 4: OUTLIERS ════════════════════════════════════════════════════════════
with tabs[4]:
    sec("Outlier Detection")
    if not outliers_d:
        st.info("No numeric features or outlier step was disabled.")
    else:
        st.plotly_chart(fig_outlier_bar(outliers_d), use_container_width=True)

        sec("Outlier Summary Table")
        orows = [{"Feature":k,"IQR Lower":v["iqr_lower"],"IQR Upper":v["iqr_upper"],
                   "IQR Count":v["iqr_count"],"IQR %":v["iqr_pct"],
                   "Z-Score Count":v["zscore_count"],"Z-Score %":v["zscore_pct"],
                   "P99 Cap":v["p99_cap"],"Flags":v["flags"]} for k,v in outliers_d.items()]
        odf = pd.DataFrame(orows).sort_values("IQR %", ascending=False)
        st.dataframe(odf.style.background_gradient(subset=["IQR %"],cmap="OrRd"),
                     use_container_width=True, height=400)

        flagged = [(k,v) for k,v in outliers_d.items() if v["flags"] != "—"]
        if flagged:
            sec(f"⚠️ Flagged Features ({len(flagged)})")
            for k,v in flagged:
                st.error(f"**{k}** — {v['flags']} | IQR: {v['iqr_pct']}% | P99: {v['p99_cap']}")


# ══ TAB 5: MISSING VALUES ═══════════════════════════════════════════════════════
with tabs[5]:
    sec("Missing Value Diagnostics")
    if not meta_df.empty:
        st.plotly_chart(fig_missing_bar(meta_df), use_container_width=True)

    if missing_d:
        mrows = [{"Feature":k,"Missing Count":v["missing_count"],"Missing %":v["missing_pct"],
                   "Informative":("Yes" if v["informative_missing"] else "No"),
                   "Data Type":dtype_map.get(k,"?")} for k,v in missing_d.items()]
        mdf = pd.DataFrame(mrows).sort_values("Missing %",ascending=False)
        mdf_f = mdf[mdf["Missing %"] > 0]
        if len(mdf_f) == 0:
            st.success("🎉 No missing values!")
        else:
            st.dataframe(mdf_f.style.background_gradient(subset=["Missing %"],cmap="OrRd"),
                         use_container_width=True, height=400)

    sec("Imputation Reference Guide")
    st.markdown("""
| Missing % | Data Type | Recommended Treatment | Reason |
|---|---|---|---|
| < 5% | Numeric | Mean or median imputation | Low impact; simple imputation sufficient |
| 5–30% | Numeric | Median + optional missing indicator | Median robust to skew; indicator preserves signal |
| > 30% | Numeric | Median + mandatory missing indicator | High missingness likely informative |
| Any | Categorical | Create 'Unknown' category | Preserves missingness as a distinct risk class |
| Any | Boolean | Mode (most frequent) imputation | Neutral assumption for binary flags |
| Structural | Any | Investigate with target — may be MNAR | Missing Not At Random needs domain knowledge |
""")


# ══ TAB 6: CORRELATIONS ════════════════════════════════════════════════════════
with tabs[6]:
    sec("Correlation Analysis")
    if not corr_d or corr_d.get("pearson",pd.DataFrame()).empty:
        st.info("Correlation step disabled or < 2 numeric features.")
    else:
        note = corr_d.get("note","")
        if note: st.caption(f"ℹ️ {note}")

        c1,c2 = st.columns(2)
        c1.plotly_chart(fig_corr_heatmap(corr_d["pearson"],"Pearson Correlation"), use_container_width=True)
        if not corr_d.get("spearman",pd.DataFrame()).empty:
            c2.plotly_chart(fig_corr_heatmap(corr_d["spearman"],"Spearman Correlation"), use_container_width=True)
        else:
            c2.info("Spearman skipped for large datasets (> 500K rows).")

        pairs = corr_d.get("high_corr_pairs",[])
        if pairs:
            sec(f"⚠️ High Correlation Pairs — {len(pairs)}")
            st.dataframe(pd.DataFrame(pairs), use_container_width=True)
            st.warning("These pairs may cause multicollinearity. Consider VIF analysis or removing one from each pair.")
        else:
            st.success(f"✅ No feature pairs with |r| ≥ {R.get('corr_threshold',0.8)} found.")


# ══ TAB 7: FEATURE IMPORTANCE ═══════════════════════════════════════════════════
with tabs[7]:
    sec("Feature Importance")
    if not importance_d:
        st.info("Feature importance step disabled or no target variable specified.")
    else:
        st.caption("**Numeric:** Pearson |r| computed on entire dataset (vectorized). "
                   "**Categorical:** Cramér V computed on 300K sample. "
                   "Both measure association strength with the target variable.")

        st.plotly_chart(fig_importance_bar(importance_d, top_n=40), use_container_width=True)

        sec("Importance Table")
        imp_rows = [{"Feature":k,"Score":v["score"],"Interpretation":v["interpretation"],
                      "Method":v["method"],"Data Type":dtype_map.get(k,"?")}
                     for k,v in importance_d.items()]
        imp_df = pd.DataFrame(imp_rows)
        st.dataframe(imp_df.style.background_gradient(subset=["Score"],cmap="RdYlGn"),
                     use_container_width=True, height=440)

        low_imp = [k for k,v in importance_d.items() if v["score"] < 0.02]
        if low_imp:
            sec(f"⚠️ Very Low Importance Features ({len(low_imp)})")
            st.warning(f"Consider dropping: **{', '.join(low_imp[:15])}**{'...' if len(low_imp)>15 else ''}")

        if zero_d:
            sec("Zero-Inflated Features")
            st.plotly_chart(fig_zero_inflation(zero_d), use_container_width=True)


# ══ TAB 8: IV / WoE ═══════════════════════════════════════════════════════════
with tabs[8]:
    sec("Information Value (IV) & Weight of Evidence (WoE)")
    if not iv_d:
        st.info("IV/WoE step disabled or no target variable specified (requires binary 0/1 target).")
    else:
        st.caption("**IV** measures each feature's discriminatory power. "
                   "**WoE** shows how each bin differentiates good vs bad risks — "
                   "standard technique in insurance and credit risk GLM modeling.")

        st.plotly_chart(fig_iv_bar(iv_d, top_n=40), use_container_width=True)

        sec("IV Summary Table")
        iv_rows = [{"Feature":k,"IV":round(v["iv"],4),"Predictive Power":v["iv_power"],
                     "Data Type":dtype_map.get(k,"?")} for k,v in iv_d.items()]
        iv_df = pd.DataFrame(iv_rows)
        st.dataframe(iv_df.style.background_gradient(subset=["IV"],cmap="RdYlGn"),
                     use_container_width=True, height=400)

        sec("WoE Charts — Select Feature")
        iv_feats = list(iv_d.keys())
        sel_iv   = st.selectbox("Feature for WoE detail", iv_feats, key="iv_sel")
        if sel_iv in iv_d:
            iv_row = iv_d[sel_iv]
            st.markdown(f"**IV = {iv_row['iv']:.4f} → {iv_row['iv_power']}**")
            st.plotly_chart(fig_woe(iv_row["woe_table"], sel_iv), use_container_width=True)
            st.dataframe(pd.DataFrame(iv_row["woe_table"]).round(4), use_container_width=True)


# ══ TAB 9: RECOMMENDATIONS ════════════════════════════════════════════════════
with tabs[9]:
    sec("Automated Preprocessing Recommendations")
    st.caption("Every feature gets a data-driven recommendation with reason. "
               "Filter, search, and sort by priority.")

    # Filters
    fc1, fc2, fc3, fc4 = st.columns(4)
    filt_dtype  = fc1.multiselect("Data Type", ["Numeric","Categorical","Boolean","Date"],
                                   default=["Numeric","Categorical","Boolean","Date"], key="rf_dtype")
    filt_search = fc2.text_input("Search feature", key="rf_search")
    filt_prio   = fc3.multiselect("Priority", ["🔴 Critical","🟠 High","🟡 Medium","🟢 Low"],
                                   default=["🔴 Critical","🟠 High","🟡 Medium","🟢 Low"], key="rf_prio")
    filt_flagged= fc4.checkbox("Flagged only", key="rf_flag")

    filtered = recs
    if filt_dtype:
        filtered = [r for r in filtered if r["Data_Type"] in filt_dtype]
    if filt_search:
        filtered = [r for r in filtered if filt_search.lower() in r["Feature"].lower()]
    if filt_prio:
        filtered = [r for r in filtered if r.get("Priority","") in filt_prio]
    if filt_flagged and not meta_df.empty:
        flagged_set = set(meta_df[meta_df["Flags"]!="—"]["Feature"].tolist())
        filtered = [r for r in filtered if r["Feature"] in flagged_set]

    # Sort by priority
    prio_order = {"🔴 Critical":0,"🟠 High":1,"🟡 Medium":2,"🟢 Low":3}
    filtered   = sorted(filtered, key=lambda r: prio_order.get(r.get("Priority","🟢 Low"), 3))

    st.markdown(f"*Showing **{len(filtered)}** of **{len(recs)}** features.*")

    for rec in filtered:
        feat   = rec["Feature"]
        dt     = rec["Data_Type"]
        prio   = rec.get("Priority","🟢 Low")
        flags_r= meta_df[meta_df["Feature"]==feat]["Flags"].values[0] if not meta_df.empty and feat in meta_df["Feature"].values else "—"
        bdg3   = "".join(badge(fl.strip(),"danger" if fl.strip() in ["HIGH_MISSING","NEAR_CONSTANT"] else "warn")
                         for fl in str(flags_r).split(",") if fl.strip() and fl.strip()!="—")

        with st.expander(f"{prio}  {feat}  [{dt}]", expanded=False):
            st.markdown(f"{dtype_badge(dt)}&nbsp;{priority_badge(prio)}&nbsp;{bdg3}", unsafe_allow_html=True)
            render_recommendation(rec)


# ══ TAB 10: EXPORT ═════════════════════════════════════════════════════════════
with tabs[10]:
    sec("Export All Results")
    st.markdown("Download individual files or a single **ZIP** with everything.")

    # ── Build ZIP in memory ──────────────────────────────────────────────────
    def build_zip() -> bytes:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            # Metadata CSV
            if not meta_df.empty:
                zf.writestr("eda_metadata.csv", meta_df.to_csv(index=False))

            # Distributions CSV
            if distributions:
                drows = [{"Feature":k,**v} for k,v in distributions.items()]
                zf.writestr("eda_distributions.csv", pd.DataFrame(drows).to_csv(index=False))

            # Outliers CSV
            if outliers_d:
                orows = [{"Feature":k,**{kk:vv for kk,vv in v.items() if kk!="flags"},
                           "Flags":v["flags"]} for k,v in outliers_d.items()]
                zf.writestr("eda_outliers.csv", pd.DataFrame(orows).to_csv(index=False))

            # Missing CSV
            if missing_d:
                mrows = [{"Feature":k,**v} for k,v in missing_d.items()]
                zf.writestr("eda_missing.csv", pd.DataFrame(mrows).to_csv(index=False))

            # Importance CSV
            if importance_d:
                irows = [{"Feature":k,**v} for k,v in importance_d.items()]
                zf.writestr("eda_feature_importance.csv", pd.DataFrame(irows).to_csv(index=False))

            # IV CSV
            if iv_d:
                iv_rows = [{"Feature":k,"IV":v["iv"],"IV_Power":v["iv_power"]} for k,v in iv_d.items()]
                zf.writestr("eda_iv_woe.csv", pd.DataFrame(iv_rows).to_csv(index=False))

            # Correlation CSV
            if corr_d and not corr_d.get("pearson",pd.DataFrame()).empty:
                zf.writestr("eda_pearson_correlation.csv", corr_d["pearson"].to_csv())

            # Recommendations JSON + Markdown
            zf.writestr("eda_recommendations.json", json.dumps(recs, indent=2))

            md_lines = ["# Insurance EDA — Recommendations\n"]
            for rec in sorted(recs, key=lambda r: prio_order.get(r.get("Priority","🟢 Low"),3)):
                md_lines += [
                    f"## {rec['Feature']} [{rec['Data_Type']}] — {rec.get('Priority','')}",
                    "**Findings:**",
                    *[f"- {f}" for f in rec["Findings"]],
                    "**Recommended Actions:**",
                ]
                for i,(a,r_) in enumerate(zip(rec["Recommended_Actions"], rec.get("Reasons",[]))):
                    md_lines.append(f"- {a}")
                    md_lines.append(f"  *Reason: {r_}*")
                md_lines.append("\n---\n")
            zf.writestr("eda_recommendations.md", "\n".join(md_lines))

            # Excel workbook
            try:
                xl_buf = io.BytesIO()
                with pd.ExcelWriter(xl_buf, engine="openpyxl") as writer:
                    if not meta_df.empty:
                        meta_df.to_excel(writer, sheet_name="Metadata", index=False)
                    if distributions:
                        pd.DataFrame([{"Feature":k,**v} for k,v in distributions.items()]
                                      ).to_excel(writer, sheet_name="Distributions", index=False)
                    if outliers_d:
                        pd.DataFrame(orows).to_excel(writer, sheet_name="Outliers", index=False)
                    if missing_d:
                        pd.DataFrame(mrows).to_excel(writer, sheet_name="Missing", index=False)
                    if importance_d:
                        pd.DataFrame(irows).to_excel(writer, sheet_name="Importance", index=False)
                    if iv_d:
                        pd.DataFrame(iv_rows).to_excel(writer, sheet_name="IV_WoE", index=False)
                    if corr_d and not corr_d.get("pearson",pd.DataFrame()).empty:
                        corr_d["pearson"].to_excel(writer, sheet_name="Pearson_Corr")
                xl_buf.seek(0)
                zf.writestr("eda_full_report.xlsx", xl_buf.read())
            except Exception as e:
                zf.writestr("excel_error.txt", str(e))

        buf.seek(0)
        return buf.read()

    # ── Download buttons ──────────────────────────────────────────────────────
    zip_bytes = build_zip()
    st.download_button("⬇️ Download Complete EDA ZIP (all files)", data=zip_bytes,
                       file_name="insurance_eda_results.zip",
                       mime="application/zip", use_container_width=True, type="primary")

    st.markdown("---")
    c1, c2, c3 = st.columns(3)

    with c1:
        st.markdown("**Metadata CSV**")
        if not meta_df.empty:
            st.download_button("⬇️ metadata.csv", meta_df.to_csv(index=False),
                               "eda_metadata.csv","text/csv", use_container_width=True)

    with c2:
        st.markdown("**Recommendations JSON**")
        st.download_button("⬇️ recommendations.json", json.dumps(recs, indent=2),
                           "eda_recommendations.json","application/json", use_container_width=True)

    with c3:
        st.markdown("**Importance CSV**")
        if importance_d:
            irows = [{"Feature":k,**v} for k,v in importance_d.items()]
            st.download_button("⬇️ importance.csv", pd.DataFrame(irows).to_csv(index=False),
                               "eda_feature_importance.csv","text/csv", use_container_width=True)

    c4, c5, c6 = st.columns(3)
    with c4:
        st.markdown("**Distributions CSV**")
        if distributions:
            drows = [{"Feature":k,**v} for k,v in distributions.items()]
            st.download_button("⬇️ distributions.csv", pd.DataFrame(drows).to_csv(index=False),
                               "eda_distributions.csv","text/csv", use_container_width=True)
    with c5:
        st.markdown("**IV / WoE CSV**")
        if iv_d:
            iv_rows = [{"Feature":k,"IV":v["iv"],"Power":v["iv_power"]} for k,v in iv_d.items()]
            st.download_button("⬇️ iv_woe.csv", pd.DataFrame(iv_rows).to_csv(index=False),
                               "eda_iv_woe.csv","text/csv", use_container_width=True)
    with c6:
        st.markdown("**Pearson Correlation CSV**")
        if corr_d and not corr_d.get("pearson",pd.DataFrame()).empty:
            st.download_button("⬇️ pearson_corr.csv", corr_d["pearson"].to_csv(),
                               "eda_pearson_correlation.csv","text/csv", use_container_width=True)
