"""
Insurance EDA Toolkit v2.0 — Chart Builder
============================================
All Plotly figures. Returns go.Figure objects consumed by Streamlit.
"""

import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings("ignore")

C = dict(
    primary="#1f4e79", secondary="#2e75b6", accent="#ed7d31",
    success="#70ad47", danger="#c00000", warn="#ffc000",
    bar="#2e75b6", bar2="#ed7d31", bg="#f9f9f9",
    grid="#e8ecf0",
)

# ── helpers ──────────────────────────────────────────────────────────────────
def _layout(fig, title="", h=360, margin=(50,20,60,50)):
    fig.update_layout(
        title=dict(text=title, font=dict(size=13, color=C["primary"])),
        template="plotly_white", height=h,
        margin=dict(l=margin[0], r=margin[1], t=margin[2], b=margin[3]),
        paper_bgcolor="white", plot_bgcolor="white",
        font=dict(family="Segoe UI", size=11),
    )
    return fig


# ── Distribution: histogram + KDE ────────────────────────────────────────────
def fig_histogram(plot_data: dict, feature_name: str) -> go.Figure:
    if not plot_data or "sample" not in plot_data:
        return go.Figure()
    sample = np.array(plot_data["sample"])
    if len(sample) == 0:
        return go.Figure()

    fig = go.Figure()
    fig.add_trace(go.Histogram(
        x=sample, nbinsx=50, name="Frequency",
        marker_color=C["bar"], opacity=0.72,
        histnorm="probability density",
    ))
    try:
        from scipy.stats import gaussian_kde
        kde = gaussian_kde(sample)
        xr  = np.linspace(sample.min(), sample.max(), 300)
        fig.add_trace(go.Scatter(
            x=xr, y=kde(xr), mode="lines", name="KDE",
            line=dict(color=C["accent"], width=2.5),
        ))
    except Exception:
        pass

    # Mean line
    fig.add_vline(x=float(np.mean(sample)), line_dash="dash",
                  line_color=C["danger"], annotation_text="Mean",
                  annotation_position="top right")

    return _layout(fig, f"Histogram & KDE — {feature_name}")


def fig_boxplot(plot_data: dict, feature_name: str) -> go.Figure:
    if not plot_data or "sample" not in plot_data:
        return go.Figure()
    sample = np.array(plot_data["sample"])

    fig = go.Figure(go.Box(
        y=sample, name=feature_name,
        marker_color=C["secondary"],
        boxmean="sd", boxpoints="outliers",
        jitter=0.3, pointpos=-1.6,
        line=dict(width=2),
    ))
    return _layout(fig, f"Box Plot — {feature_name}")


def fig_violin(plot_data: dict, feature_name: str) -> go.Figure:
    if not plot_data or "sample" not in plot_data:
        return go.Figure()
    sample = np.array(plot_data["sample"])

    fig = go.Figure(go.Violin(
        y=sample, name=feature_name,
        box_visible=True, meanline_visible=True,
        fillcolor=C["secondary"], opacity=0.6,
        line_color=C["primary"],
    ))
    return _layout(fig, f"Violin Plot — {feature_name}")


def fig_ecdf(plot_data: dict, feature_name: str) -> go.Figure:
    """Empirical CDF plot."""
    if not plot_data or "sample" not in plot_data:
        return go.Figure()
    sample = np.sort(np.array(plot_data["sample"]))
    y_ecdf = np.arange(1, len(sample)+1) / len(sample)

    fig = go.Figure(go.Scatter(
        x=sample, y=y_ecdf, mode="lines",
        line=dict(color=C["primary"], width=2),
        name="ECDF",
    ))
    fig.add_hline(y=0.5, line_dash="dot", line_color=C["accent"], annotation_text="P50")
    fig.add_hline(y=0.9, line_dash="dot", line_color=C["danger"], annotation_text="P90")
    fig.update_yaxes(title="Cumulative Probability")
    return _layout(fig, f"Empirical CDF — {feature_name}")


def fig_log_histogram(plot_data: dict, feature_name: str) -> go.Figure:
    """Histogram of log1p transformed values — for skewed distributions."""
    if not plot_data or "sample" not in plot_data:
        return go.Figure()
    sample = np.array(plot_data["sample"])
    log_sample = np.log1p(np.abs(sample))

    fig = go.Figure(go.Histogram(
        x=log_sample, nbinsx=50, name="log1p",
        marker_color=C["success"], opacity=0.72,
        histnorm="probability density",
    ))
    return _layout(fig, f"log1p Distribution — {feature_name}")


# ── Hit rate / category exposure ─────────────────────────────────────────────
def fig_hitrate_bar(hit_df: pd.DataFrame, feature_name: str,
                    top_n: int = 25) -> go.Figure:
    if hit_df is None or len(hit_df) == 0:
        return go.Figure()

    df = hit_df.head(top_n).copy()
    colors = [
        C["danger"] if str(r) == "RARE" else
        (C["warn"]  if str(r) == "DOMINANT" else C["bar"])
        for r in df.get("Flag", [""] * len(df))
    ]
    fig = go.Figure(go.Bar(
        y=df["Value"].astype(str) if "Value" in df.columns else df["Bin"].astype(str),
        x=df["Hit Rate %"],
        orientation="h",
        marker_color=colors,
        text=df["Hit Rate %"].apply(lambda v: f"{v:.1f}%"),
        textposition="outside",
    ))
    fig.update_layout(yaxis=dict(autorange="reversed"))
    return _layout(fig, f"Category Exposure — {feature_name}",
                   h=max(300, len(df)*28+80), margin=(150,80,60,40))


# ── Missing values summary ────────────────────────────────────────────────────
def fig_missing_bar(metadata_df: pd.DataFrame, top_n: int = 40) -> go.Figure:
    df = metadata_df[metadata_df["Missing %"] > 0].sort_values("Missing %", ascending=True).tail(top_n)
    if len(df) == 0:
        fig = go.Figure()
        fig.add_annotation(text="✅ No missing values found", xref="paper",
                           yref="paper", x=0.5, y=0.5, showarrow=False,
                           font=dict(size=16, color=C["success"]))
        return _layout(fig, "Missing Values")

    colors = [C["danger"] if v > 30 else (C["warn"] if v > 10 else C["bar"])
              for v in df["Missing %"]]

    fig = go.Figure(go.Bar(
        y=df["Feature"], x=df["Missing %"],
        orientation="h", marker_color=colors,
        text=df["Missing %"].apply(lambda v: f"{v:.1f}%"),
        textposition="outside",
    ))
    fig.add_vline(x=30, line_dash="dash", line_color=C["danger"],
                  annotation_text="30% threshold", annotation_position="top right")
    return _layout(fig, "Missing Values by Feature",
                   h=max(300, len(df)*22+100), margin=(160,80,60,40))


# ── Correlation heatmap ───────────────────────────────────────────────────────
def fig_corr_heatmap(corr_matrix: pd.DataFrame, title: str = "Pearson Correlation") -> go.Figure:
    if corr_matrix is None or corr_matrix.empty:
        return go.Figure()
    cols = corr_matrix.columns.tolist()[:30]
    cm   = corr_matrix.loc[cols, cols]

    fig = go.Figure(go.Heatmap(
        z=cm.values, x=cm.columns, y=cm.index,
        colorscale="RdBu_r", zmin=-1, zmax=1,
        colorbar=dict(title="r"),
        text=cm.round(2).values, texttemplate="%{text}",
        textfont=dict(size=8),
    ))
    return _layout(fig, title,
                   h=max(400, len(cols)*28+100), margin=(130,40,80,130))


# ── Feature importance bar ────────────────────────────────────────────────────
def fig_importance_bar(importance: dict, top_n: int = 40) -> go.Figure:
    if not importance:
        return go.Figure()

    items = sorted(importance.items(), key=lambda x: x[1]["score"], reverse=True)[:top_n]
    feats  = [i[0] for i in items]
    scores = [i[1]["score"] for i in items]
    interp = [i[1]["interpretation"] for i in items]
    methods = [i[1]["method"] for i in items]

    color_map = {"Strong": C["danger"], "Moderate": C["accent"],
                 "Weak": C["bar"], "Negligible": C["grid"]}
    colors = [color_map.get(i, C["bar"]) for i in interp]

    fig = go.Figure(go.Bar(
        y=feats, x=scores, orientation="h",
        marker_color=colors,
        text=[f"{s:.3f}" for s in scores],
        textposition="outside",
        customdata=[[m, i] for m, i in zip(methods, interp)],
        hovertemplate="<b>%{y}</b><br>Score: %{x:.4f}<br>Method: %{customdata[0]}<br>Strength: %{customdata[1]}<extra></extra>",
    ))
    fig.update_layout(yaxis=dict(autorange="reversed"))

    # Legend annotations
    for label, color in [("Strong ≥0.3", C["danger"]), ("Moderate ≥0.15", C["accent"]),
                          ("Weak ≥0.05", C["bar"]), ("Negligible", C["grid"])]:
        fig.add_annotation(text=f"● {label}", xref="paper", yref="paper",
                           x=1.01, y=0.95 - list(color_map.values()).index(color)*0.07,
                           showarrow=False, font=dict(color=color, size=10), xanchor="left")

    return _layout(fig, f"Feature Importance — Top {min(top_n, len(items))} Features",
                   h=max(400, len(items)*22+100), margin=(160,160,60,40))


# ── IV bar chart ─────────────────────────────────────────────────────────────
def fig_iv_bar(iv_result: dict, top_n: int = 40) -> go.Figure:
    if not iv_result:
        return go.Figure()

    items = sorted(iv_result.items(), key=lambda x: x[1]["iv"], reverse=True)[:top_n]
    feats  = [i[0] for i in items]
    ivs    = [i[1]["iv"] for i in items]
    power  = [i[1]["iv_power"] for i in items]

    color_map = {"Very Strong (suspicious)": "#7030a0", "Strong": C["danger"],
                 "Medium": C["accent"], "Weak": C["bar"], "Useless": C["grid"]}
    colors = [color_map.get(p, C["bar"]) for p in power]

    fig = go.Figure(go.Bar(
        y=feats, x=ivs, orientation="h", marker_color=colors,
        text=[f"{v:.3f}" for v in ivs], textposition="outside",
        customdata=power,
        hovertemplate="<b>%{y}</b><br>IV: %{x:.4f}<br>Power: %{customdata}<extra></extra>",
    ))
    # Reference lines
    for x, label in [(0.02, "Weak"), (0.1, "Medium"), (0.3, "Strong"), (0.5, "Suspicious")]:
        fig.add_vline(x=x, line_dash="dot", line_color="#888",
                      annotation_text=label, annotation_position="top right",
                      annotation_font_size=9)
    fig.update_layout(yaxis=dict(autorange="reversed"))
    return _layout(fig, f"Information Value (IV) — Top {min(top_n, len(items))} Features",
                   h=max(400, len(items)*22+100), margin=(160,80,60,40))


# ── Outlier summary ───────────────────────────────────────────────────────────
def fig_outlier_bar(outliers: dict, top_n: int = 30) -> go.Figure:
    if not outliers:
        return go.Figure()
    rows = [{"Feature": k, "IQR %": v["iqr_pct"], "Z-Score %": v["zscore_pct"]}
            for k, v in outliers.items()]
    df = pd.DataFrame(rows).sort_values("IQR %", ascending=False).head(top_n)

    fig = go.Figure()
    fig.add_trace(go.Bar(name="IQR", x=df["Feature"], y=df["IQR %"], marker_color=C["bar"]))
    fig.add_trace(go.Bar(name="Z-Score", x=df["Feature"], y=df["Z-Score %"], marker_color=C["accent"]))
    fig.update_layout(barmode="group", xaxis=dict(tickangle=-45))
    return _layout(fig, f"Outlier % by Feature (Top {min(top_n, len(df))})",
                   h=420, margin=(40,20,60,130))


# ── Skewness bar ─────────────────────────────────────────────────────────────
def fig_skewness_bar(distributions: dict, top_n: int = 40) -> go.Figure:
    rows = [(k, v["skewness"]) for k, v in distributions.items()]
    if not rows:
        return go.Figure()
    df = pd.DataFrame(rows, columns=["Feature", "Skewness"])
    df = df.reindex(df["Skewness"].abs().sort_values(ascending=False).index).head(top_n)
    colors = [C["danger"] if abs(v) > 2 else (C["accent"] if abs(v) > 1 else C["bar"])
              for v in df["Skewness"]]

    fig = go.Figure(go.Bar(
        x=df["Feature"], y=df["Skewness"], marker_color=colors,
        text=df["Skewness"].round(2), textposition="outside",
    ))
    fig.add_hline(y=1,  line_dash="dash", line_color=C["accent"], annotation_text="+1")
    fig.add_hline(y=-1, line_dash="dash", line_color=C["accent"], annotation_text="-1")
    fig.add_hline(y=2,  line_dash="dot",  line_color=C["danger"],  annotation_text="+2")
    fig.add_hline(y=-2, line_dash="dot",  line_color=C["danger"],  annotation_text="-2")
    fig.update_xaxes(tickangle=-45)
    return _layout(fig, f"Skewness — Top {min(top_n, len(df))} Numeric Features", h=420, margin=(40,20,60,130))


# ── Data types pie ────────────────────────────────────────────────────────────
def fig_dtype_pie(metadata_df: pd.DataFrame) -> go.Figure:
    counts = metadata_df["Data Type"].value_counts()
    fig = go.Figure(go.Pie(
        labels=counts.index, values=counts.values, hole=0.42,
        marker_colors=[C["primary"], C["accent"], C["success"], C["secondary"]],
        textinfo="label+percent",
    ))
    return _layout(fig, "Feature Types", h=300)


# ── Flags bar ─────────────────────────────────────────────────────────────────
def fig_flags_bar(metadata_df: pd.DataFrame) -> go.Figure:
    from collections import Counter
    all_flags = []
    for f in metadata_df["Flags"]:
        if f and f != "—":
            all_flags.extend([x.strip() for x in str(f).split(",")])
    if not all_flags:
        fig = go.Figure()
        fig.add_annotation(text="✅ No flags raised", xref="paper", yref="paper",
                           x=0.5, y=0.5, showarrow=False, font=dict(size=16, color=C["success"]))
        return _layout(fig, "Feature Flags")

    counts = Counter(all_flags)
    df = pd.DataFrame(list(counts.items()), columns=["Flag", "Count"]).sort_values("Count", ascending=False)
    colors = [C["danger"] if f in ["HIGH_MISSING","NEAR_CONSTANT","EXTREME_OUTLIERS","POTENTIAL_DATA_ERROR"]
              else C["accent"] for f in df["Flag"]]
    fig = go.Figure(go.Bar(x=df["Flag"], y=df["Count"], marker_color=colors,
                            text=df["Count"], textposition="outside"))
    return _layout(fig, "Feature Flags Summary", h=340)


# ── Zero inflation ────────────────────────────────────────────────────────────
def fig_zero_inflation(zero_data: dict) -> go.Figure:
    if not zero_data:
        return go.Figure()
    df = pd.DataFrame([
        {"Feature": k, "Zero %": v["zero_pct"], "Flag": v["flag"]}
        for k, v in zero_data.items()
    ]).sort_values("Zero %", ascending=False)

    colors = [C["danger"] if f == "ZERO_INFLATED" else C["accent"] for f in df["Flag"]]
    fig = go.Figure(go.Bar(
        x=df["Feature"], y=df["Zero %"], marker_color=colors,
        text=df["Zero %"].apply(lambda v: f"{v:.1f}%"), textposition="outside",
    ))
    fig.add_hline(y=20, line_dash="dash", line_color=C["danger"], annotation_text="Zero-Inflated threshold (20%)")
    fig.update_xaxes(tickangle=-45)
    return _layout(fig, "Zero Inflation by Feature", h=400, margin=(40,20,60,130))


# ── WoE chart for a single feature ───────────────────────────────────────────
def fig_woe(woe_table: list, feature_name: str) -> go.Figure:
    if not woe_table:
        return go.Figure()
    df = pd.DataFrame(woe_table)
    colors = [C["success"] if w >= 0 else C["danger"] for w in df["woe"]]

    fig = make_subplots(rows=1, cols=2, subplot_titles=["WoE by Bin", "Event vs Non-Event Distribution"])

    fig.add_trace(go.Bar(x=df["bin"].astype(str), y=df["woe"], marker_color=colors,
                          name="WoE"), row=1, col=1)
    fig.add_trace(go.Bar(x=df["bin"].astype(str), y=df["events"], name="Events",
                          marker_color=C["danger"]), row=1, col=2)
    fig.add_trace(go.Bar(x=df["bin"].astype(str), y=df["nonevents"], name="Non-Events",
                          marker_color=C["bar"]), row=1, col=2)

    fig.update_xaxes(tickangle=-45)
    fig.update_layout(barmode="group", template="plotly_white", height=380,
                      title=dict(text=f"WoE / IV — {feature_name}", font=dict(size=13)),
                      margin=dict(l=50, r=20, t=60, b=100))
    return fig
