# Feature Selection Dashboard — Insurance EDA Toolkit v5

Standalone actuarial feature analysis tool.
Separate from the EDA Dashboard — focused entirely on how each feature
relates to the target variable.

---

## Quick Start

```python
from eda_toolkit import inspect, run_eda, generate_fs_report

plan = inspect(df, target_col="pure_premium")
plan.fix(policy_no="ID-like")
plan.set_sections(target_analysis=True)

plan.set_target_analysis(
    n_bins       = [5, 10, 20],
    exposure_col = "earned_exposure",
    bin_by       = "amount",
)

plan.confirm()
df_clean = plan.apply_to_df()
results  = run_eda(df_clean, plan)

generate_fs_report(results, output_path="feature_selection.html")
```

---

## Installation

Same as EDA Dashboard — see `README_EDA.md`.

---

## What it shows

Three tabs:

### Tab 1 — Target Overview
- Stat cards: Count, Mean, Median, Std Dev, P95, P99, Skewness, Zero %
- Histogram of target distribution (clipped P1–P99 by default, log1p toggle)
- Summary table with all statistics

### Tab 2 — Categorical vs Target
For each categorical feature:
- **Gold bars** = total exposure per category (left axis) — primary
- **Navy bars** = row count per category (right axis) — secondary
- **Gold line** = mean/median/sum target per category (right axis)
- Download table: category, count, %, exposure, exp%, mean, median, sum

### Tab 3 — Numerical vs Target
For each numeric feature:
- **Gold bars** = total exposure per bin (left axis) — primary
- **Navy bars** = row count per bin (right axis) — secondary
- **Gold line** = mean/median/sum target per bin (right axis)
- Download table: bin range, count, %, exposure, exp%, mean, median, sum

---

## Binning configuration

### set_target_analysis() — full reference

```python
plan.set_target_analysis(

    n_bins = [5, 10, 20],
    # Bin counts to pre-compute. Each becomes a slider step in the dashboard.
    # More values = more pre-computation but richer interactivity.
    # Default: [5, 10, 20]

    bin_methods = ["equal", "quantile", "exposure"],
    # Methods to pre-compute. Options:
    #   "equal"    — equal-width intervals (simple, ignores exposure)
    #   "quantile" — equal row count per bin
    #   "exposure" — equal EXPOSURE per bin (actuarially correct)
    # Default: ["equal", "quantile"] if no exposure_col
    #          ["equal", "quantile", "exposure"] if exposure_col is set

    exposure_col = "earned_exposure",
    # Your exposure column. Examples:
    #   "earned_exposure", "policy_count", "car_years", "payroll"
    # Required for "exposure" method and for exposure bars in charts.
    # Default: None

    bin_by = "amount",
    # How to define equal-exposure bins:
    #   "amount" — each bin has equal SUM of exposure_col
    #              e.g. each bin has same total earned car-years
    #              THIS IS THE ACTUARIALLY CORRECT OPTION
    #              Mean target is equally credible in every bin.
    #   "count"  — each bin has equal number of rows (same as "quantile")
    # Default: "amount"
)
```

### Why equal-exposure binning?

Standard equal-width or quantile binning gives bins with very different
exposure amounts. This means the mean target in a thin bin (few car-years)
is less credible than in a heavy bin.

Equal-exposure binning ensures every bin has the same total earned exposure,
so all mean target estimates carry equal statistical weight — exactly what
you need for GLM feature selection and relativity derivation.

```
Equal-width bins (wrong for insurance):
  Age 18-30:  rows=800,  exposure=320  ← thin, unstable mean
  Age 31-50:  rows=4200, exposure=1890 ← very stable
  Age 51-70:  rows=600,  exposure=280  ← thin again

Equal-exposure bins (correct):
  Age 18-24:  rows=410,  exposure=500  ← each bin ~500 exposure
  Age 25-35:  rows=890,  exposure=498
  Age 36-48:  rows=920,  exposure=501
  Age 49-70:  rows=780,  exposure=501  ← credible estimates throughout
```

---

## Dashboard controls

### Global (top bar)

| Control            | Options                    | Effect                          |
|--------------------|----------------------------|---------------------------------|
| Metric             | Mean / Median / Sum        | What the gold line shows        |
| Log Y              | On / Off                   | Log scale on Y axis             |
| Count bars         | On / Off                   | Show/hide navy count bars       |
| Exposure bars      | On / Off                   | Show/hide gold exposure bars    |
| Sort categories    | By Count / By Metric / A-Z | Sort order for cat features     |
| Group small        | 0% – 5% slider             | Merge low-% cats into "Other"   |

### Numerical tab

| Control  | Options                     | Effect                          |
|----------|-----------------------------|---------------------------------|
| Feature  | Dropdown                    | Switch numeric feature          |
| Binning  | Equal Width / Equal Count / Equal Exposure | Binning method   |
| Bins     | Slider (e.g. 5 / 10 / 20)  | Number of bins                  |

> Equal Exposure is the default when exposure_col is configured.

---

## Chart reading guide

```
Left Y axis (gold):   Exposure per bin/category
Right Y axis (navy):  Row count + Mean target line

Gold bars  ↑ = more exposure in this bin
Navy bars  ↑ = more rows in this bin
Gold line  ↑ = higher mean target (loss ratio / frequency / severity)

Actuarial signal: look for where the gold LINE moves significantly
                  while gold BARS are roughly equal height
                  → that's genuine differentiation, not a data artefact
```

---

## Usage in Databricks

```python
%pip install git+https://github.com/your-org/eda_toolkit.git

from eda_toolkit import inspect, run_eda, generate_fs_report

# Collect from Spark — sample if >5M rows
df = (spark.table("catalog.commercial_liability.policy_data")
           .toPandas())

plan = inspect(df, target_col="frequency")
plan.fix(policy_no="ID-like")
plan.set_sections(target_analysis=True)
plan.set_target_analysis(
    n_bins       = [5, 10, 20],
    exposure_col = "earned_exposure",
    bin_by       = "amount",
)
plan.confirm()
results = run_eda(plan.apply_to_df(), plan)

# Render in notebook
html = generate_fs_report(results)
displayHTML(html)

# Save to DBFS
generate_fs_report(results, output_path="/dbfs/FileStore/reports/feature_selection.html")
```

---

## Both dashboards from one run_eda()

```python
results = run_eda(df_clean, plan)

# EDA Dashboard
generate_report(results,    output_path="eda_dashboard.html")

# Feature Selection Dashboard
generate_fs_report(results, output_path="feature_selection.html")
```

Both dashboards are generated from the same `results` dict.
`run_eda()` is called once.

---

## Performance (2.47M rows × 113 features, exposure_col set)

| Section                        | Time   |
|--------------------------------|--------|
| Target univariate histogram    | ~0.1s  |
| 42 categorical × groupby       | ~6s    |
| 60 numeric × 3 methods × 3 bin configs | ~25s |
| **Total pre-computation**      | **~31s** |
| HTML generation                | ~1s    |

No data is sampled. All computation on full dataset.
Only aggregated tables (KB, not GB) are embedded in the HTML.
