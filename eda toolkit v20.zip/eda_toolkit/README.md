# Insurance EDA Toolkit — v5

A self-contained, zero-infrastructure EDA dashboard purpose-built for insurance and actuarial datasets. Runs entirely locally — no data leaves your machine.

Tested up to **1M+ rows × 200 columns** with sub-10s runtimes.

Two output modes:
- **Streamlit** — interactive web app (local use, Jupyter)
- **HTML** — self-contained dashboard file (Databricks, sharing, offline)

---

## Table of Contents

1. [Quick Start](#1-quick-start)
2. [Installation](#2-installation)
3. [Full Workflow](#3-full-workflow)
4. [Output Modes — Streamlit vs HTML](#4-output-modes--streamlit-vs-html)
5. [Running in Databricks](#5-running-in-databricks)
6. [Column Type System](#6-column-type-system)
7. [Configuration Reference](#7-configuration-reference)
8. [Dashboard Tabs — What Each One Shows](#8-dashboard-tabs--what-each-one-shows)
9. [Correlations — Detailed Guide](#9-correlations--detailed-guide)
10. [Outliers Tab — Guide](#10-outliers-tab--guide)
11. [Data Comparison Tab — Guide](#11-data-comparison-tab--guide)
12. [Quality Scorecard](#12-quality-scorecard)
13. [Performance & Benchmarks](#13-performance--benchmarks)
14. [What's New in v5](#14-whats-new-in-v5)
15. [Troubleshooting](#15-troubleshooting)

---

## 1. Quick Start

```python
from eda_toolkit import inspect, run_eda, launch_app

plan = inspect(df, target_col="Claim_Flag")
plan.confirm()

df_clean = plan.apply_to_df()
results  = run_eda(df_clean, plan)

# Streamlit (local)
launch_app(results)

# HTML dashboard (Databricks / sharing)
html = launch_app(results, mode="html")
displayHTML(html)                             # Databricks one-liner
```

That's the minimum. Everything else is optional.

---

## 2. Installation

### Dependencies

```
pandas >= 1.5
numpy  >= 1.23
scipy
scikit-learn
streamlit >= 1.28      # Streamlit mode only
plotly    >= 5.0       # Both modes
```

```bash
pip install pandas numpy scipy scikit-learn streamlit plotly
```

### Setup

Unzip `eda_toolkit_v5.zip` and add the folder to your Python path:

```python
import sys
sys.path.insert(0, "/path/to/eda_toolkit")

from eda_toolkit import inspect, run_eda, launch_app
```

In Databricks, upload the zip to DBFS and unzip:

```python
import zipfile, sys

with zipfile.ZipFile("/dbfs/FileStore/eda_toolkit_v5.zip", "r") as z:
    z.extractall("/dbfs/FileStore/eda_toolkit")

sys.path.insert(0, "/dbfs/FileStore/eda_toolkit")
```

---

## 3. Full Workflow

The toolkit follows a four-step pattern: **inspect → configure → run → visualise**.

```python
from eda_toolkit import inspect, run_eda, launch_app

# ── Step 1: Inspect ───────────────────────────────────────────────────────────
plan = inspect(df, target_col="Claim_Flag")
# Prints a type-detection summary. Review it before proceeding.

# ── Step 2: Fix wrong detections (optional) ───────────────────────────────────
plan.fix(
    Policy_Year  = "Categorical",   # detected as Numeric — override
    Risk_Score   = "Numeric",       # detected as Categorical — override
    Policy_No    = "ID-like",       # force exclusion from analysis
)

# ── Step 3: Configure sections (optional) ─────────────────────────────────────
plan.set_sections(
    correlations     = True,   # Pearson, Cramér's V, VIF, target correlation
    category_quality = True,   # fuzzy/duplicate category detection
    scorecard        = True,   # quality score per column + recommendations
)

# ── Step 4: Tune correlation performance (optional) ───────────────────────────
plan.set_corr_options(
    corr_sample         = 100_000,  # rows for Pearson (default 100k)
    chi_max_cardinality = 10_000,   # skip cats with > N unique values
    corr_threshold      = 0.75,     # |r| threshold for flagging high pairs
)

# ── Step 5: Key column stats (optional) ───────────────────────────────────────
plan.set_key_stats(
    key_cols       = ["Policy_Number"],
    composite_keys = [["Policy_Number", "Eff_Date"]],
)

# ── Step 6: Comparison dataset (optional) ─────────────────────────────────────
plan.set_comparison(
    df          = df_prior_year,
    label_a     = "Current Year",
    label_b     = "Prior Year",
    groupby_col = "Policy_Year",
    agg_config  = {
        "Premium":       ["sum", "mean"],
        "Claim_Flag":    ["sum", "mean"],
        "Policy_Number": ["count", "nunique"],
    },
)

# ── Step 7: Confirm ───────────────────────────────────────────────────────────
plan.confirm()
# Prints a confirmed type table and cast plan. Check before running.

# ── Step 8: Apply and run ─────────────────────────────────────────────────────
df_clean = plan.apply_to_df()
results  = run_eda(df_clean, plan)

# ── Step 9: Visualise ─────────────────────────────────────────────────────────
launch_app(results)                          # Streamlit (local)
launch_app(results, mode="html")             # HTML (Databricks / sharing)
```

---

## 4. Output Modes — Streamlit vs HTML

### Mode 1 — Streamlit (default)

```python
launch_app(results)
```

Starts a local Streamlit server and opens your browser at `http://localhost:8501`. Best for interactive local exploration. Stop by clicking **Stop Server** in the sidebar or pressing `Ctrl+C`.

```python
# Custom port
launch_app(results, port=8502)
```

### Mode 2 — HTML dashboard

```python
from eda_toolkit import generate_report

html = generate_report(results)
```

Generates a single self-contained `.html` file with fully interactive charts (Plotly), tab navigation, sliders, dropdowns, sortable tables, and filters — all running in pure JavaScript with no server required.

```python
# Render inline in Databricks or Jupyter
html = generate_report(results)
displayHTML(html)                            # Databricks
# or: from IPython.display import HTML, display; display(HTML(html))

# Save to file — auto-opens in browser locally
generate_report(results, output_path="eda_report.html")

# Save to DBFS (accessible at your Databricks workspace URL)
generate_report(results, output_path="/dbfs/FileStore/reports/eda_report.html")

# Fully offline (embeds Plotly.js inline — larger file)
generate_report(results, output_path="report_offline.html", offline=True)
```

Or use the unified `launch_app` entry point:

```python
# HTML via launch_app
launch_app(results, mode="html")                                    # return string
launch_app(results, mode="html", output_path="report.html")         # save + open
launch_app(results, mode="html",
           output_path="/dbfs/FileStore/eda_report.html")           # DBFS
launch_app(results, mode="html", offline=True)                      # offline embed
```

### Streamlit vs HTML — when to use which

| | Streamlit | HTML |
|---|---|---|
| Interactive dropdowns & sliders | ✅ | ✅ (JS-powered) |
| Variable switching speed | ~0.5–2s round-trip | Instant (<5ms) |
| Requires running server | Yes | No |
| Works in Databricks | Needs proxy / ngrok | `displayHTML(html)` — 1 line |
| Shareable with colleagues | Share URL (dies with cluster) | Share the file (permanent) |
| Works offline / behind firewall | No | Yes |
| File size (typical 20-col dataset) | N/A | ~4–8 MB |

---

## 5. Running in Databricks

### Recommended: HTML mode

The simplest and most reliable approach. No ports, no tunnels, no firewall issues.

```python
# Cell 1 — install and unzip
%pip install plotly -q

import zipfile, sys
with zipfile.ZipFile("/dbfs/FileStore/eda_toolkit_v5.zip", "r") as z:
    z.extractall("/dbfs/FileStore/eda_toolkit")
sys.path.insert(0, "/dbfs/FileStore/eda_toolkit")

# Cell 2 — load data
df = spark.table("catalog.schema.your_table").toPandas()
# or: df = pd.read_parquet("/dbfs/FileStore/your_data.parquet")

# Cell 3 — run EDA
from eda_toolkit import inspect, run_eda, launch_app

plan = inspect(df, target_col="Claim_Flag")
plan.fix(Policy_No="ID-like")
plan.confirm()
df_clean = plan.apply_to_df()
results  = run_eda(df_clean, plan)

# Cell 4 — render dashboard inline
html = launch_app(results, mode="html")
displayHTML(html)

# Or save permanently to DBFS
launch_app(results, mode="html",
           output_path="/dbfs/FileStore/reports/eda_report.html")
# Access at: https://your-workspace.azuredatabricks.net/files/reports/eda_report.html
```

### Loading data from different Databricks sources

```python
# Delta table
df = spark.table("catalog.schema.table").toPandas()

# SQL Warehouse
from databricks import sql
conn = sql.connect(
    server_hostname = "your-workspace.azuredatabricks.net",
    http_path       = "/sql/1.0/warehouses/your_warehouse_id",
    access_token    = dbutils.secrets.get("scope", "token"),
)
df = pd.read_sql("SELECT * FROM catalog.schema.table LIMIT 500000", conn)
conn.close()

# DBFS parquet / CSV
df = pd.read_parquet("/dbfs/FileStore/your_data.parquet")
df = pd.read_csv("/dbfs/FileStore/your_data.csv")
```

### Databricks + Streamlit (driver proxy)

If you specifically need the Streamlit app in Databricks:

```python
%pip install streamlit -q

launch_app(results, databricks=True)
# Tries the built-in Databricks driver proxy automatically.
# If the proxy is unavailable, falls back to rendering natively
# in the notebook using Plotly + HTML.
```

---

## 6. Column Type System

### Auto-detected types

| Type | Detected when | Analysed as |
|---|---|---|
| `Numeric` | Float/int with many unique values | Histogram, mean/median/std/P25/P75/P95/P99, IQR outliers, skewness, Pearson |
| `Boolean` | Exactly 2 unique values, or Y/N/Yes/No/True/False | Treated as Numeric 0.0/1.0 |
| `Categorical` | String column with low–medium cardinality | Frequency table, rare/dominant detection, fuzzy matching, Cramér's V |
| `Date` | datetime64 dtype | Min/max date, year counts, month counts |
| `ID-like` | High cardinality (>80% unique values) | Listed with sample values only — excluded from all stats |
| `Constant` | Single unique value (≥5% populated) | Flagged — excluded, zero variance |
| `Unknown` | Entirely null | Excluded |

### Overriding detections

```python
plan.fix(
    Policy_Year  = "Categorical",   # was Numeric (years 2020–2023)
    Risk_Score   = "Numeric",       # was Categorical (high cardinality string)
    Policy_No    = "ID-like",       # force exclude
    Legacy_Flag  = "Boolean",       # stored as 0.0/1.0 float
)
```

### What apply_to_df() does

```python
df_clean = plan.apply_to_df()
```

| Source type | Cast applied |
|---|---|
| `Numeric` / `Boolean` | Cast to `float64` |
| `Categorical` | Cast to pandas `category` dtype |
| `Date` | Cast to `datetime64` |
| `ID-like` / `Constant` / `Unknown` | **Dropped from df_clean** |

Dropped columns are listed in the confirm output. The target column is always kept even if it would otherwise be dropped.

---

## 7. Configuration Reference

### inspect()

```python
plan = inspect(
    df,
    target_col = "Claim_Flag",   # column to treat as the outcome variable
    id_ratio   = 0.80,           # fraction of unique values that triggers ID-like detection
)
```

### plan.fix()

```python
plan.fix(
    col_name = "Type",   # any keyword arg: col name = desired type string
)

# Multiple fixes in one call
plan.fix(Policy_Year="Categorical", Risk_Score="Numeric", ID_Col="ID-like")
```

Valid types: `"Numeric"`, `"Categorical"`, `"Boolean"`, `"Date"`, `"ID-like"`, `"Constant"`, `"Unknown"`

### plan.set_sections()

```python
plan.set_sections(
    correlations     = True,   # Pearson matrix, Cramér's V, VIF, target correlation
    category_quality = True,   # fuzzy category matching
    scorecard        = True,   # quality scorecard + recommendations
)
```

Turn off expensive sections for faster runs on very large data:

```python
# Fastest possible run
plan.set_sections(correlations=False, category_quality=False, scorecard=True)
```

### plan.set_corr_options()

```python
plan.set_corr_options(
    corr_sample         = 100_000,  # rows sampled for Pearson matrix
    chi_max_cardinality = 10_000,   # categoricals with > N unique values skipped in Cramér's V
    corr_threshold      = 0.75,     # |r| threshold for flagging high-correlation pairs
)
```

| Parameter | Default | Notes |
|---|---|---|
| `corr_sample` | 100,000 | Pearson r is statistically stable at 50k+. Lower to 20k for speed |
| `chi_max_cardinality` | 10,000 | Raise to 50k to include high-cardinality code columns |
| `corr_threshold` | 0.75 | Lower to 0.5 to surface moderate pairs; raise to 0.9 for severe only |

### plan.set_key_stats()

```python
plan.set_key_stats(
    key_cols       = ["Policy_Number"],                     # uniqueness check per column
    composite_keys = [["Policy_Number", "Eff_Date"]],       # uniqueness check for combinations
)
```

Shows count, unique count, and duplicate rate for each key. Composite key builder checks if the combination is a perfect unique identifier.

### plan.set_comparison()

```python
# Simple — one aggregation per column
plan.set_comparison(
    df          = df_prior_year,
    label_a     = "Current Year",     # label for df passed to inspect()
    label_b     = "Prior Year",       # label for df passed here
    groupby_col = "Policy_Year",      # column(s) to group by
    agg_cols    = ["Premium", "Claim_Flag", "Exposure"],
)

# Advanced — multiple aggregations per column
plan.set_comparison(
    df          = df_prior_year,
    label_a     = "Current",
    label_b     = "Prior",
    groupby_col = ["Region", "Policy_Year"],   # multi-group
    agg_config  = {
        "Premium":       ["sum", "mean"],
        "Claim_Flag":    ["sum", "mean"],
        "Policy_Number": ["count", "nunique"],
        "Exposure":      ["sum"],
    },
)
```

---

## 8. Dashboard Tabs — What Each One Shows

### Tab 1 — Overview

- KPI row: total rows, columns, numeric count, categorical count, overall missing %
- Column type distribution donut chart
- Missing value bar chart (sorted worst → best, colour-coded)
- Full feature table with searchable/sortable columns: type, missing %, hit rate %, unique count, mean/top value, skewness, zero %, inf %
- Key column stats: uniqueness, duplicate detection
- Composite key builder: test multi-column combinations as unique keys

### Tab 2 — Variable Explorer

Select any variable from the dropdown. The panel switches instantly (HTML: <5ms, Streamlit: ~0.5–2s).

**Numeric / Boolean columns:**
- 8 stat metrics: mean, median, std, min, max, skewness, missing %, zero %
- Shape description (Near-Normal, Right-Skewed, Log-Normal, Zero-Inflated)
- P25 / P75 / P95 / P99 percentiles
- Histogram with mean and median vlines
- Linear / Log Y-axis toggle
- Alerts for high skewness, sparseness, zero inflation, inf values

**Categorical columns:**
- Unique count, rare count, missing %, top value %
- Bar chart of top 25 categories (RARE in red, DOMINANT in cyan)
- Linear / Log Y-axis toggle
- Full category table (sortable) in expandable section
- Alerts for high cardinality, rare categories, missing data

**Date columns:**
- Min date, max date, unique count, missing %
- Records by year bar chart
- Records by month bar chart

**ID-like columns:**
- Unique count, missing %, hit rate %
- 5 sample values displayed

### Tab 3 — Hit Rate

- Horizontal bar chart of hit rate (% non-null) for every column
- Colour coded: ≥95% green · 75–94% amber · <75% red
- Target column highlighted purple
- Sortable hit rate table with missing % progress bars

### Tab 4 — Category Quality

- Summary metrics: columns with similar cats, total similar pairs found, high-cardinality cols skipped
- Expandable per-column panels showing fuzzy-matched pairs with similarity scores and reason codes
- Similarity reason codes: "Case/spacing difference", "Same words, different order", "Same text, different number", "One is prefix of other", "Similar spelling"
- Rare Categories Explorer: dropdown to select a column, shows rare (<1% share) and dominant (>80% share) categories side by side

### Tab 5 — Outliers

**Summary table (top)** — all numeric variables in one view:

| Variable | IQR Outliers | IQR % | P5 | P95 | Fence Lo | Fence Hi | Skewness | Inf % | Severity |
|---|---|---|---|---|---|---|---|---|---|

Colour coded by severity: 🔴 IQR%≥10% · 🟡 5–9% · 🟢 1–4% · ✅ <1%

Click any row to jump directly to that variable's detail panel.

**Variable detail (below)** — drill into any variable:
- Two live sliders: lower percentile cutoff (P0–P20, default P5) and upper percentile cutoff (P80–P100, default P95)
- 6 live metrics: P(lo) value, P(hi) value, count outside range, % outside, IQR outlier count, IQR outlier %
- IQR fence values displayed
- Boxplot with fence lines (updates live as you drag sliders)
- Histogram with outlier zone shading (updates live)
- X-axis clipped to P1–P99 for readability

### Tab 6 — Correlations

See [Section 9](#9-correlations--detailed-guide) for full detail.

### Tab 7 — Data Comparison

See [Section 11](#11-data-comparison-tab--guide) for full detail.

### Tab 8 — Quality Scorecard

See [Section 12](#12-quality-scorecard) for full detail.

---

## 9. Correlations — Detailed Guide

### Sub-tab 1 — Numeric Pearson

**Target bar chart** (shown first): every numeric feature's Pearson r with the target, sorted by absolute value. Colour coded by strength.

**Pearson heatmap**: full matrix for all numeric features including target.

**High-correlation pairs**: table of all pairs with |r| ≥ threshold.

In the HTML dashboard, a **live threshold slider** filters the pairs table instantly — drag from 0.0 to 1.0 to see more or fewer pairs.

**VIF table**: Variance Inflation Factor per feature. Detects multicollinearity.

| Metric | Threshold | Meaning |
|---|---|---|
| Pearson r | ≥ 0.7 | Strong linear relationship |
| Pearson r | 0.4–0.7 | Moderate |
| Pearson r | < 0.4 | Weak |
| VIF | > 10 | Severe multicollinearity — consider dropping |
| VIF | 5–10 | Moderate |
| VIF | < 5 | OK |

### Sub-tab 2 — Categorical Cramér's V

Pure Cramér's V computed on the full dataset (no sampling, no chi-square, no p-values). Uses exact contingency tables via numpy — fast even at 1M rows.

**Target pairs only toggle**: filter the table and bar chart to show only pairs involving the target column.

The bar chart shows the top 20 pairs sorted by association strength.

| Cramér's V | Strength |
|---|---|
| ≥ 0.3 | Strong |
| 0.1–0.3 | Moderate |
| < 0.1 | Weak |

Columns with more unique values than `chi_max_cardinality` (default 10,000) are skipped. A notice lists all skipped columns. To include them:

```python
plan.set_corr_options(chi_max_cardinality=50_000)
```

### Sub-tab 3 — Target Correlation

**Combined summary table**: every feature ranked by association strength with the target.

| Feature | Type | Metric | Value | Strength |
|---|---|---|---|---|
| Premium | Numeric | Pearson r | 0.4821 | Moderate |
| Region | Categorical | Cramér's V | 0.3102 | Strong |
| Age | Numeric | Pearson r | −0.2341 | Weak |

- Numeric features → Pearson r
- Categorical features → Cramér's V
- Sorted by absolute value — strongest predictors at the top
- Bar chart of top 40 features

Expandable sub-sections: numeric detail (Pearson r only) and categorical detail (Cramér's V only).

---

## 10. Outliers Tab — Guide

### Reading the summary table

The summary table gives you a full dataset-level picture before drilling in. Key columns:

- **IQR Outliers**: count of values outside the IQR fences (Q1 − 1.5×IQR, Q3 + 1.5×IQR)
- **IQR %**: percentage outside IQR fences — the primary severity signal
- **P5 / P95**: the default percentile cutoffs (adjustable with sliders)
- **Fence Lo / Hi**: the fixed IQR fence values computed during `run_eda()`
- **Skewness**: distribution shape — high skewness often indicates outlier sensitivity
- **Severity**: automatic classification based on IQR%

### Using the sliders

The sliders let you explore **percentile-based** outlier cutoffs independently of the IQR method:

```
Lower cutoff:  P0 ──────●────── P20   (default P5)
Upper cutoff:  P80 ────────●── P100   (default P95)
```

Drag either slider and the following update instantly in the browser:
- P(lo) value, P(hi) value
- Count of values outside the custom range
- % outside the custom range
- Vertical fence lines on the boxplot
- Shaded outlier zones on the histogram

This lets you answer questions like "what if I cap at P1/P99 instead of P5/P95?" or "how many values are above the 99th percentile?" without re-running the analysis.

### IQR vs percentile cutoffs

| Method | What it measures | Best for |
|---|---|---|
| IQR (fixed) | Values beyond Q1−1.5×IQR or Q3+1.5×IQR | Standard outlier detection, non-skewed data |
| Percentile cutoff (sliders) | Values beyond a chosen percentile | Skewed distributions, capping strategies |

Both are shown simultaneously in the detail panel so you can compare them.

### Zero-inflated columns

When a column has >30% zeros the IQR is computed on the non-zero values only (shown as a blue info alert). This avoids the fence collapsing to zero and falsely flagging all non-zero values as outliers.

---

## 11. Data Comparison Tab — Guide

Requires `plan.set_comparison(...)` before `run_eda()`.

### What it compares

For each aggregation you configure (sum, mean, count, etc.) the tab shows a table with:

| Group | A value | B value | Diff (A−B) | Diff % | Match % |
|---|---|---|---|---|---|
| 2020 | 12,450,000 | 12,100,000 | 350,000 | 2.89% | 97.1% |
| 2021 | 11,200,000 | 10,800,000 | 400,000 | 3.70% | 96.3% |
| TOTAL | 23,650,000 | 22,900,000 | 750,000 | 3.28% | 96.7% |

### Match % colour coding

| Match % | Colour | Meaning |
|---|---|---|
| 100% | 🟢 Dark green | Exact match |
| ≥ 95% | 🟢 Light green | Very close |
| 85–94% | 🟡 Yellow | Moderate difference |
| 70–84% | 🟠 Orange | Notable difference |
| < 70% | 🔴 Red | Large difference |

### Dataset summaries

Side-by-side descriptive statistics (count, missing%, sum, mean, median, min, max) for each configured column in both DataFrames. Missing % cells are colour-coded green/amber/red.

### Multi-group comparison

```python
plan.set_comparison(
    df          = df_prior,
    label_a     = "Current",
    label_b     = "Prior",
    groupby_col = ["Region", "Policy_Year"],   # creates combined group keys
    agg_config  = {"Premium": ["sum", "mean"]},
)
```

Multiple aggregations generate a dropdown selector — pick "Premium (sum)" or "Premium (mean)" to switch between views.

---

## 12. Quality Scorecard

Each column receives a score from 0 to 100 based on five weighted components:

| Component | Weight | What it penalises |
|---|---|---|
| Hit Rate | 30% | Missing data — primary signal |
| Valid Values | 20% | Zero inflation (>30% zeros), inf values, dominant categories |
| Outlier Score | 20% | High IQR outlier percentage |
| Skewness | 15% | Very high skewness (numeric only) |
| Cat Consistency | 15% | Fuzzy-matched similar categories |

### Hard overrides

High missing data overrides other good scores:

- Hit rate < 50% → overall capped at 40 → always `❌ Fix First`
- Hit rate < 25% → overall capped at 20

This prevents a column that's 80% null from scoring `⚠️ Review` because its other signals look fine.

### Status thresholds

| Score | Status | Meaning |
|---|---|---|
| ≥ 80 | ✅ Good | No action needed |
| 55–79 | ⚠️ Review | Investigate before modelling |
| < 55 | ❌ Fix First | Address before any modelling |

### Recommendations

For every column that scores below 80, the toolkit generates specific remediation actions:

| Finding | Recommended Action |
|---|---|
| High missing (80%) | Add `col_missing` flag + median impute |
| Zero-inflated (40% zeros) | Two-part model or Tweedie GLM |
| Log-normal skewed | Apply `log1p` transform |
| 3 similar category pairs | Group similar labels, review data entry |
| ID column | Exclude from modelling |
| Date column | Extract year, month, quarter, day-of-week |

The recommendations section has checkboxes to filter by Fix First / Review priority.

---

## 13. Performance & Benchmarks

### run_eda() runtimes (14 cols: 8 numeric + 5 categorical + 1 target)

| Rows | Time |
|---|---|
| 1,000 | 0.11s |
| 10,000 | 0.17s |
| 100,000 | 0.84s |
| 500,000 | 3.15s |
| 1,000,000 | 6.45s |

### HTML report generation (extra cost on top of run_eda)

| Dataset | Build time | File size |
|---|---|---|
| 10k rows × 20 cols | +0.04s | ~4 MB |
| 100k rows × 50 cols | +0.13s | ~6 MB |
| 10k rows × 100 cols | +0.22s | ~8 MB |

File size is dominated by Plotly chart data, not row count. A 100-col dataset generates more charts than a 1M-row / 20-col dataset.

### Performance presets

**Fast mode** (very large datasets, exploratory pass):

```python
plan.set_sections(correlations=False, category_quality=False)
plan.set_corr_options(corr_sample=20_000, chi_max_cardinality=1_000)
```

**Standard mode** (most use cases):

```python
plan.set_corr_options(corr_sample=100_000, chi_max_cardinality=10_000)
```

**High accuracy mode** (final analysis, report quality):

```python
plan.set_corr_options(corr_sample=500_000, chi_max_cardinality=50_000)
```

### What makes it fast

- **Sampling once per column**: all percentile, std, skewness, and nunique stats are computed on a single 100k-row sample. Min/max always use the full array.
- **Pearson via numpy**: vectorised upper-triangle extraction — no Python loop over pairs.
- **Cramér's V via bincount**: pure numpy contingency tables, no scipy, no sampling.
- **VIF via matrix inversion**: one `numpy.linalg.inv()` call instead of N regression fits.
- **dtype_map passthrough**: after `plan.confirm()`, the dtype map is stored in config. `run_eda()` uses it directly and skips re-detection.

---

## 14. What's New in v5

### HTML dashboard mode

A completely new `generate_report()` function produces a self-contained `.html` file. All 8 tabs, all charts, all interactive features — runs in any browser with no server.

```python
from eda_toolkit import generate_report

html = generate_report(results)
displayHTML(html)   # Databricks
```

### Outliers tab redesign

- **Summary table** at the top: all numeric variables with IQR outlier count, IQR%, P5/P95, fences, skewness, severity rating — sortable, searchable, click any row to jump to that variable's detail
- Six metric cards in the detail panel (added IQR count and IQR% alongside the percentile metrics)

### Cramér's V replaces chi-square

All categorical correlation is now pure Cramér's V computed on the full dataset. No sampling, no p-values, no scipy dependency. Columns: `Variable A, Variable B, Cramér's V, Strength, vs Target`.

### Scorecard hard overrides

High missing data now correctly dominates the score. A column with 80% missing will always be `❌ Fix First` regardless of other signals. Previous versions could score it `⚠️ Review` due to score dilution.

### detect_type fix

A column that is 99%+ null with one non-null value is now classified as `Numeric` (correct) rather than `Constant`, so it receives proper missing analysis instead of being silently discarded.

### outlier dict aliases

The `outlier` dict now includes standard aliases alongside the existing keys:

```python
res["outlier"]["count"]   # same as iqr_count
res["outlier"]["pct"]     # same as iqr_pct
res["outlier"]["lower"]   # same as fence_lo
res["outlier"]["upper"]   # same as fence_hi
```

### Column truncation fix

All `st.dataframe()` calls now use explicit `TextColumn(width=...)` and `NumberColumn(format=...)` configs. Values no longer truncate to `3…` or `6…`.

---

## 15. Troubleshooting

**`KeyError: 'Significance'`**
You have an old version of `app.py`. Replace the entire `eda_toolkit/` folder with the contents of the new zip.

**Chi-square shows "No categorical column pairs"**
Ensure you called `plan.confirm()` then `df_clean = plan.apply_to_df()` before `run_eda()`. The engine needs category-dtype columns to detect pairs.

**Correlations taking > 2 minutes**
Use fast mode:
```python
plan.set_corr_options(corr_sample=20_000, chi_max_cardinality=1_000)
```

**HTML file is too large to email**
The file size comes from embedded chart data. For wide datasets (100+ cols) use `plot_sample` truncation — charts use at most 20k points per column by default.

**Target not appearing in Pearson matrix**
The target must be numeric. String targets (e.g. `"Low"/"High"`) appear only in the Cramér's V section.

**`displayHTML()` not found**
You are not in Databricks. Use `from IPython.display import HTML, display; display(HTML(html))` in Jupyter instead.

**Databricks driver proxy not working**
Try `launch_app(results, mode="html")` instead — the HTML approach has no proxy requirement.

**`infer_datetime_format` warning in apply_to_df()**
This is a pandas version compatibility warning (non-fatal). The Date column is already cast correctly. No action needed.

**Memory errors on very large data**
For 2M+ rows with many columns, sample before EDA or drop unused columns first:
```python
df_sample = df.sample(500_000, random_state=42)
# or
df = df[["Premium", "Claim_Flag", "Region", "Age"]]  # keep only needed cols
```

**`StreamlitDuplicateElementId` error**
Replace the old `eda_toolkit/` folder entirely. Do not merge — full replace.

**Numbers truncated in Streamlit tables (`33…`)**
You have an old `app.py`. The new version uses explicit `TextColumn`/`NumberColumn` configs on every `st.dataframe()` call. Replace the folder.
