# -*- coding: utf-8 -*-
"""
feature_selection_dashboard.py — Insurance EDA Toolkit v5
Feature Selection Dashboard (separate from EDA Dashboard).

Chart specification:
  Categorical vs Target:
    - Gold bars  = exposure SUM per category   (left axis, primary)
    - Navy bars  = row count per category      (right axis, secondary)
    - Gold line  = mean target per category    (right axis)

  Numerical vs Target (default: equal-exposure binning):
    - Gold bars  = exposure SUM per bin        (left axis, primary)
    - Navy bars  = row count per bin           (right axis, secondary)
    - Gold line  = mean target per bin         (right axis)

Default binning: equal-exposure (equal sum of exposure_col per bin)
X-axis labels: truncated + angled when > 8 items
Pagination: 30 categories per page

Usage:
    from eda_toolkit import generate_fs_report
    generate_fs_report(results, output_path="feature_selection.html")

    # Databricks
    html = generate_fs_report(results)
    displayHTML(html)
"""
from __future__ import annotations
import json, webbrowser
from pathlib import Path
import numpy as np
import pandas as pd

PLOTLY_CDN = "https://cdn.plot.ly/plotly-2.35.0.min.js"


class _Enc(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, np.integer):  return int(o)
        if isinstance(o, np.floating): return float(o)
        if isinstance(o, np.ndarray):  return o.tolist()
        try:
            if pd.isna(o): return None
        except Exception:
            pass
        return super().default(o)


def _j(v):   return json.dumps(v, cls=_Enc, separators=(",", ":"))
def _esc(s): return (str(s).replace("&","&amp;").replace("<","&lt;")
                    .replace(">","&gt;").replace('"','&quot;').replace("'","&#39;"))


# ══════════════════════════════════════════════════════════════
#  CSS
# ══════════════════════════════════════════════════════════════
CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

/* Chubb brand: Navy #002B5C | Gold #C8922A | Blue #004A97 */
:root {
  --bg:#EEF1F7; --surf:#fff; --bdr:#D4DCE8;
  --txt:#0D1B2E; --txt2:#4A5568; --txt3:#8A98AA;
  --acc:#C8922A; --acc-l:#FDF3E3;
  --navy:#002B5C; --navy2:#004A97;
  --r:10px;
  --sh:0 1px 4px rgba(0,43,92,.08);
  --sh2:0 4px 16px rgba(0,43,92,.14);
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);
     color:var(--txt);font-size:14px;line-height:1.6;min-height:100vh}

/* header */
.hdr{background:linear-gradient(135deg,var(--navy) 0%,var(--navy2) 100%);
     box-shadow:0 3px 16px rgba(0,43,92,.3);position:sticky;top:0;z-index:100}
.hdr-row{display:flex;align-items:center;gap:16px;padding:12px 28px}
.logo{background:var(--acc);color:#fff;font-size:12px;font-weight:800;
      padding:5px 10px;border-radius:7px;white-space:nowrap;letter-spacing:-.2px}
.hdr-title{color:#fff;font-size:17px;font-weight:700;letter-spacing:-.3px}
.hdr-sub{color:rgba(255,255,255,.55);font-size:11px;margin-top:1px}
.hdr-meta{margin-left:auto;display:flex;gap:18px;font-size:12px;
          color:rgba(255,255,255,.6)}
.hdr-meta strong{color:#fff}

/* nav tabs */
.nav{background:var(--navy);border-top:1px solid rgba(255,255,255,.1);
     display:flex;padding:0 20px;overflow-x:auto}
.nav-btn{padding:10px 22px;font-size:13px;font-weight:500;cursor:pointer;
         border:none;background:none;color:rgba(255,255,255,.5);
         border-bottom:3px solid transparent;margin-bottom:-1px;
         font-family:inherit;transition:all .13s;white-space:nowrap}
.nav-btn:hover{color:rgba(255,255,255,.85)}
.nav-btn.on{color:#fff;border-bottom-color:var(--acc);font-weight:600}
.tab{display:none}.tab.on{display:block}

/* page */
.page{max-width:1360px;margin:0 auto;padding:22px 26px 48px}

/* controls */
.ctrls{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;
       background:var(--surf);border:1px solid var(--bdr);
       border-left:4px solid var(--acc);border-radius:var(--r);
       padding:12px 18px;margin-bottom:18px;box-shadow:var(--sh)}
.cg{display:flex;flex-direction:column;gap:4px}
.cl{font-size:.69rem;font-weight:700;text-transform:uppercase;
    letter-spacing:.07em;color:var(--txt2)}
.br{display:flex;gap:3px;flex-wrap:wrap}
.cb{padding:5px 12px;border:1px solid var(--bdr);border-radius:6px;
    font-size:.79rem;font-weight:500;cursor:pointer;background:var(--surf);
    color:var(--txt2);font-family:inherit;transition:all .11s;white-space:nowrap}
.cb:hover{border-color:var(--navy2);color:var(--navy2)}
.cb.on{background:var(--navy);color:#fff;border-color:var(--navy);font-weight:600}
.tg{display:flex;align-items:center;gap:5px;font-size:.81rem;cursor:pointer;
    padding:5px 11px;border:1px solid var(--bdr);border-radius:6px;
    background:var(--surf);transition:all .11s;user-select:none;white-space:nowrap}
.tg input{accent-color:var(--acc);width:13px;height:13px}
.tg:hover{border-color:var(--acc);background:var(--acc-l)}
.csep{width:1px;background:var(--bdr);align-self:stretch;margin:0 2px}

/* feature row */
.fr{display:flex;flex-wrap:wrap;gap:10px;align-items:center;
    background:var(--surf);border:1px solid var(--bdr);
    border-left:4px solid var(--navy2);border-radius:var(--r);
    padding:10px 16px;margin-bottom:14px;box-shadow:var(--sh)}
.fl{font-size:.82rem;font-weight:700;color:var(--navy);white-space:nowrap}
.fs{padding:7px 11px;border:1px solid var(--bdr);border-radius:6px;
    font-size:.86rem;font-family:inherit;background:var(--surf);
    color:var(--txt);min-width:200px;flex:1;max-width:400px;outline:none}
.fs:focus{border-color:var(--navy2)}
.mb{padding:5px 12px;border:1px solid var(--bdr);border-radius:6px;
    font-size:.79rem;font-weight:500;cursor:pointer;background:var(--surf);
    color:var(--txt2);font-family:inherit;transition:all .11s}
.mb.on{background:var(--navy2);color:#fff;border-color:var(--navy2)}
.bl{font-size:.82rem;color:var(--navy);font-weight:700;min-width:48px}
.rng{accent-color:var(--acc);cursor:pointer;width:120px}

/* chart */
.cw{background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);
    margin:10px 0;overflow:hidden;position:relative;box-shadow:var(--sh)}
.cl2{position:absolute;inset:0;display:flex;align-items:center;
     justify-content:center;gap:10px;background:var(--surf);z-index:2;
     font-size:.82rem;color:var(--txt2);transition:opacity .35s}
.cl2.done{opacity:0;pointer-events:none}
.sp{width:20px;height:20px;border:2.5px solid var(--bdr);
    border-top-color:var(--acc);border-radius:50%;
    animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.cd{width:100%;min-height:360px}

/* legend strip */
.leg{display:flex;flex-wrap:wrap;gap:12px;align-items:center;
     padding:7px 12px;background:#f5f8ff;border-radius:6px;
     border:1px solid var(--bdr);margin:8px 0 12px;font-size:.78rem;color:var(--txt2)}
.li{display:flex;align-items:center;gap:5px}
.ls{width:13px;height:13px;border-radius:3px;flex-shrink:0}
.lline{display:inline-block;width:22px;height:3px;background:#C8922A;
       vertical-align:middle;margin-right:4px;border-radius:2px}

/* stat grid */
.sg{display:grid;grid-template-columns:repeat(auto-fill,minmax(108px,1fr));
    gap:10px;margin:12px 0 18px}
.sc{background:var(--surf);border:1px solid var(--bdr);
    border-top:3px solid var(--acc);border-radius:var(--r);
    padding:.55rem .9rem .45rem;box-shadow:var(--sh)}
.sv{font-size:1.05rem;font-weight:700;color:var(--navy);line-height:1.2}
.sl{font-size:.67rem;color:var(--txt2);text-transform:uppercase;
    letter-spacing:.05em;margin-top:2px}

/* tables */
.tw{overflow-x:auto;margin:10px 0;border-radius:8px;
    box-shadow:var(--sh);border:1px solid var(--bdr)}
.dt{border-collapse:collapse;width:100%;font-size:.80rem;background:var(--surf)}
.dt th{background:#EEF3FA;padding:7px 11px;text-align:left;font-weight:600;
       font-size:.73rem;color:var(--navy2);border-bottom:2px solid var(--bdr);
       cursor:pointer;user-select:none;white-space:nowrap}
.dt th:hover{background:#E0E8F5}
.dt th.sa::after{content:" \u2191";color:var(--acc)}
.dt th.sd::after{content:" \u2193";color:var(--acc)}
.dt td{padding:6px 11px;border-bottom:1px solid #F0F4FA;vertical-align:middle}
.dt tr:last-child td{border-bottom:none}
.dt tbody tr:hover td{background:#F5F8FF}
.tc{display:flex;align-items:center;gap:8px;margin:5px 0 10px;flex-wrap:wrap}
.dl{display:inline-flex;align-items:center;gap:4px;padding:5px 12px;
    background:var(--surf);border:1px solid var(--bdr);border-radius:6px;
    font-size:.77rem;font-weight:500;color:var(--txt2);text-decoration:none;transition:all .12s}
.dl:hover{background:var(--acc-l);color:var(--acc);border-color:var(--acc)}

/* pagination */
.pgc{display:flex;align-items:center;gap:8px;margin:6px 0 10px;
     font-size:.81rem;color:var(--txt2)}
.pgb{padding:4px 12px;border:1px solid var(--bdr);border-radius:5px;
     font-size:.77rem;cursor:pointer;background:var(--surf);
     color:var(--navy2);transition:all .11s}
.pgb:hover:not(:disabled){background:var(--navy2);color:#fff;border-color:var(--navy2)}
.pgb:disabled{opacity:.38;cursor:not-allowed}
.pgi{font-weight:600;color:var(--navy)}

.sh{font-size:.9rem;font-weight:700;color:var(--navy);
    border-bottom:2px solid var(--acc);padding-bottom:3px;
    display:inline-block;margin:14px 0 9px}
.cap{font-size:.80rem;color:var(--txt2);margin:3px 0 7px}
.warn{padding:.45rem .85rem;border-radius:6px;font-size:.83rem;
      background:#fffbeb;color:#78350f;border-left:3px solid #f59e0b;margin:.3rem 0}

/* fullscreen */
#fso{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);
     z-index:9999;align-items:center;justify-content:center}
#fso.on{display:flex}
#fsb{background:#fff;border-radius:12px;padding:8px;
     width:96vw;max-height:96vh;overflow:auto;position:relative}
#fsc{position:absolute;top:10px;right:12px;font-size:20px;
     cursor:pointer;color:#64748b;background:none;border:none;z-index:10}
#fsp{width:100%;height:82vh}

@media(max-width:760px){.hdr-meta{display:none}.page{padding:14px 12px 32px}}
"""


# ══════════════════════════════════════════════════════════════
#  JavaScript
# ══════════════════════════════════════════════════════════════
JS = r"""
// ─────────────────────────────────────────────────────────────
//  FEATURE SELECTION DASHBOARD
// ─────────────────────────────────────────────────────────────
var S = {
  metric:   'mean',   // mean | median | sum
  logY:     false,
  showExp:  true,     // show exposure bars
  showCnt:  true,     // show count bars
  catSort:  'count',  // count | metric | alpha
  grpSmall: 0,        // pct threshold to group into Other
  catPage:  0,
  catPgSz:  30,
  method:   'exposure',  // default: equal-exposure
  bins:     20,
};
var ACT = { type: null, col: null };
var FIGS = {};   // id -> {data, layout}

// ── formatting ───────────────────────────────────────────────
function F(v, d) {
  if (v === null || v === undefined || v === '') return '\u2014';
  var f = +v; if (isNaN(f)) return '\u2014';
  d = (d !== undefined) ? d : 4;
  if (Math.abs(f) >= 1e6) return (f/1e6).toFixed(2)+'M';
  if (Math.abs(f) >= 1e3) return f.toLocaleString(undefined,{maximumFractionDigits:2});
  return f.toFixed(d);
}
function trunc(s, n) {
  n = n || 28;
  return (s && s.length > n) ? s.slice(0, n-1)+'\u2026' : (s||'');
}

// ── tabs ────────────────────────────────────────────────────
function showTab(id) {
  document.querySelectorAll('.tab').forEach(function(p){p.classList.remove('on');});
  document.querySelectorAll('.nav-btn').forEach(function(b){b.classList.remove('on');});
  var pane = document.getElementById(id);
  var btn  = document.querySelector('[data-tab="'+id+'"]');
  if (pane) pane.classList.add('on');
  if (btn)  btn.classList.add('on');
  window.scrollTo({top:0, behavior:'smooth'});
  setTimeout(function(){
    if (id==='tab-u') renderUni();
    else if (id==='tab-c' && ACT.col) renderCat(ACT.col);
    else if (id==='tab-n' && ACT.col) renderNum(ACT.col);
  }, 60);
}

// ── global controls ─────────────────────────────────────────
function setMetric(m) {
  S.metric = m;
  document.querySelectorAll('.mb2').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-m')===m);
  });
  refresh();
}
function togLog(cb)  { S.logY    = cb.checked; refresh(); }
function togExp(cb)  { S.showExp = cb.checked; refresh(); }
function togCnt(cb)  { S.showCnt = cb.checked; refresh(); }
function setSort(s) {
  S.catSort = s; S.catPage = 0;
  document.querySelectorAll('.sb').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-s')===s);
  });
  refresh();
}
function setGrp(v) {
  S.grpSmall = +v; S.catPage = 0;
  var el = document.getElementById('grp-lbl');
  if (el) el.textContent = v>0 ? '<'+v+'%' : 'Off';
  refresh();
}
function setMeth(m) {
  S.method = m;
  document.querySelectorAll('.meth').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-meth')===m);
  });
  refreshNum();
}
function setBins(idx, bins) {
  S.bins = bins[+idx] || bins[0];
  var el = document.getElementById('bins-v');
  if (el) el.textContent = S.bins+' bins';
  refreshNum();
}
function refresh() {
  if (ACT.type==='cat') renderCat(ACT.col);
  else if (ACT.type==='num') renderNum(ACT.col);
  else if (ACT.type==='uni') renderUni();
}
function refreshNum() { if (ACT.type==='num') renderNum(ACT.col); }

// ── chart renderer ──────────────────────────────────────────
function plot(id, data, layout) {
  var el = document.getElementById(id);
  if (!el || !window.Plotly) return;
  // hide loader
  var wrap = el.closest('.cw');
  if (wrap) {
    var ldr = wrap.querySelector('.cl2');
    if (ldr) { ldr.style.opacity='0'; setTimeout(function(){ldr.classList.add('done');},350); }
  }
  var cfg = {
    responsive: true, displayModeBar: true, displaylogo: false,
    modeBarButtonsToRemove: ['sendDataToCloud','lasso2d','select2d'],
  };
  FIGS[id] = {data:data, layout:layout};
  try {
    if (el._plotted) Plotly.react(id, data, layout, cfg);
    else { Plotly.newPlot(id, data, layout, cfg); el._plotted = true; }
  } catch(e) { console.warn('chart error', id, e); }
}

// ── fullscreen ──────────────────────────────────────────────
function openFS(id) {
  var fig = FIGS[id]; if(!fig||!window.Plotly) return;
  var ov=document.getElementById('fso'), pl=document.getElementById('fsp');
  if(!ov||!pl) return;
  var lay = Object.assign({}, fig.layout||{});
  lay.height = Math.floor(window.innerHeight*0.83);
  lay.autosize = true;
  Plotly.newPlot(pl, fig.data, lay, {responsive:true, displayModeBar:true, displaylogo:false});
  ov.classList.add('on');
}
function closeFS() {
  var ov=document.getElementById('fso'); if(ov) ov.classList.remove('on');
  var pl=document.getElementById('fsp'); if(pl&&window.Plotly) Plotly.purge(pl);
}
document.addEventListener('click',function(e){
  if(e.target===document.getElementById('fso')) closeFS();
});

// ── table sort ──────────────────────────────────────────────
document.addEventListener('click',function(e){
  var th=e.target.closest('th'); if(!th) return;
  var tbl=th.closest('table.srt'); if(!tbl) return;
  var idx=Array.from(th.parentNode.children).indexOf(th);
  var tbody=tbl.querySelector('tbody');
  var rows=Array.from(tbody.querySelectorAll('tr'));
  var asc=th.classList.contains('sa');
  tbl.querySelectorAll('th').forEach(function(h){h.classList.remove('sa','sd');});
  rows.sort(function(a,b){
    var av=a.cells[idx]?a.cells[idx].textContent.trim():'';
    var bv=b.cells[idx]?b.cells[idx].textContent.trim():'';
    var an=parseFloat(av.replace(/[,%M]/g,'')), bn=parseFloat(bv.replace(/[,%M]/g,''));
    if(!isNaN(an)&&!isNaN(bn)) return asc?an-bn:bn-an;
    return asc?av.localeCompare(bv):bv.localeCompare(av);
  });
  rows.forEach(function(r){tbody.appendChild(r);});
  th.classList.add(asc?'sd':'sa');
});

// ════════════════════════════════════════════════════════════
//  UNIVARIATE
// ════════════════════════════════════════════════════════════
function renderUni() {
  ACT.type = 'uni';
  var D = window.D_UNI;
  if (!D || !window.Plotly) return;
  var hist = S.logY ? D.hist_log : D.hist_clip;
  if (!hist || !hist.counts || !hist.counts.length) return;

  var edges=hist.edges, counts=hist.counts, mids=[], labs=[];
  for (var i=0;i<counts.length;i++) {
    var lo=+edges[i], hi=+edges[i+1];
    mids.push((lo+hi)/2);
    labs.push('['+lo.toPrecision(4)+', '+hi.toPrecision(4)+')');
  }
  var data = [{
    type:'bar', x:mids, y:counts, name:'Count',
    marker:{color:'rgba(0,43,92,0.68)',line:{color:'rgba(0,43,92,0.85)',width:0.4}},
    hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>',
    text: labs,
  }];
  var layout = {
    title:{text:(window.D_TGT||'Target')+' \u2014 Distribution'+(S.logY?' (log1p)':''),
           font:{size:14,color:'#0D1B2E'}},
    xaxis:{title:window.D_TGT||'Target',gridcolor:'#D4DCE8',zeroline:false},
    yaxis:{title:'Count',type:S.logY?'log':'linear',gridcolor:'#D4DCE8'},
    paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
    font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
    height:380,margin:{l:65,r:20,t:48,b:54},bargap:0.04,
  };
  plot('uni-ch', data, layout);
  buildUniTbl();
}

function buildUniTbl() {
  var D=window.D_UNI; if(!D) return;
  var s=D.stats;
  var rows=[['Count',(s.count||0).toLocaleString()],
    ['Mean',F(s.mean)],['Median',F(s.median)],['Std Dev',F(s.std)],
    ['Min',F(s.min)],['Max',F(s.max)],
    ['P25',F(s.p25)],['P75',F(s.p75)],['P95',F(s.p95)],['P99',F(s.p99)],
    ['Skewness',F(s.skewness,3)],['Zero %',F(s.zero_pct,2)+'%']];
  var h='<div class="tw" style="max-width:360px"><table class="dt">'
    +'<thead><tr><th>Statistic</th><th style="text-align:right">Value</th></tr></thead><tbody>';
  rows.forEach(function(r){
    h+='<tr><td>'+r[0]+'</td>'
      +'<td style="text-align:right;font-weight:600;color:var(--navy)">'+r[1]+'</td></tr>';
  });
  h+='</tbody></table></div>';
  var el=document.getElementById('uni-tbl'); if(el) el.innerHTML=h;
}

// ════════════════════════════════════════════════════════════
//  CATEGORICAL
//  Primary bars  = exposure SUM (gold, left axis)
//  Secondary bars = row count   (navy, right axis)
//  Line          = mean target  (right axis)
// ════════════════════════════════════════════════════════════
function selCat(col) { ACT={type:'cat',col:col}; S.catPage=0; renderCat(col); }
function catPg(d)    { S.catPage=Math.max(0,S.catPage+d); renderCat(ACT.col); }

function renderCat(col) {
  var all=window.D_CAT&&window.D_CAT[col];
  if (!all||!all.length||!window.Plotly) return;
  var m=S.metric;
  var ec=window.D_EC||'';
  var hasE=!!(ec&&all.length&&all[0].exposure_sum!==undefined);

  // Group small categories
  var data=all.slice();
  if (S.grpSmall>0) {
    var kept=[],grp=[];
    data.forEach(function(r){(+r.pct<S.grpSmall?grp:kept).push(r);});
    if (grp.length) {
      var n=grp.reduce(function(a,r){return a+(+r.count||0);},0);
      var ws=grp.reduce(function(a,r){return a+(+r.mean||0)*(+r.count||0);},0);
      var es=grp.reduce(function(a,r){return a+(+r.exposure_sum||0);},0);
      var ep=grp.reduce(function(a,r){return a+(+r.exposure_pct||0);},0);
      kept.push({category:'(Other)',count:n,
        pct:grp.reduce(function(a,r){return a+(+r.pct||0);},0),
        mean:n>0?ws/n:0,median:0,
        sum:grp.reduce(function(a,r){return a+(+r.sum||0);},0),
        exposure_sum:es,exposure_pct:ep});
    }
    data=kept;
  }

  // Sort
  if (S.catSort==='metric') data.sort(function(a,b){return(+b[m]||0)-(+a[m]||0);});
  else if (S.catSort==='alpha') data.sort(function(a,b){return a.category.localeCompare(b.category);});
  else data.sort(function(a,b){return(+b.count||0)-(+a.count||0);});

  // Paginate
  var ps=S.catPgSz, tot=Math.max(1,Math.ceil(data.length/ps));
  S.catPage=Math.min(S.catPage,tot-1);
  var page=data.slice(S.catPage*ps,(S.catPage+1)*ps);

  var pgEl=document.getElementById('cat-pi');
  if(pgEl) pgEl.textContent=(S.catPage*ps+1)+'\u2013'+Math.min((S.catPage+1)*ps,data.length)+' of '+data.length;
  var prev=document.getElementById('cat-prev'),next=document.getElementById('cat-next');
  if(prev) prev.disabled=S.catPage===0;
  if(next) next.disabled=S.catPage>=tot-1;
  var pgw=document.getElementById('cat-pg');
  if(pgw) pgw.style.display=data.length>ps?'flex':'none';

  var cats  = page.map(function(r){return trunc(r.category,28);});
  var expos = hasE ? page.map(function(r){return+r.exposure_sum||0;}) : [];
  var cnts  = page.map(function(r){return+r.count||0;});
  var mvals = page.map(function(r){return+r[m]||0;});
  var mLbl  = ({mean:'Mean',median:'Median',sum:'Sum'}[m]||m)+' '+window.D_TGT;
  var ylog  = S.logY?'log':'linear';
  var angle = cats.length>8?-40:0;
  var bMgn  = cats.length>8?115:65;
  var h     = cats.length>18?500:cats.length>9?430:370;

  var traces=[];

  // Bar 1: Exposure (gold, left axis) — PRIMARY
  if (hasE && S.showExp) {
    traces.push({
      type:'bar',x:cats,y:expos,name:ec+' (exposure)',yaxis:'y',
      marker:{color:'rgba(200,146,42,0.55)',line:{color:'rgba(200,146,42,0.85)',width:0.5}},
      hovertemplate:'<b>%{x}</b><br>'+ec+': %{y:,.2f}<extra></extra>',
    });
  }

  // Bar 2: Count (navy, right axis) — SECONDARY
  if (S.showCnt) {
    traces.push({
      type:'bar',x:cats,y:cnts,name:'Row Count',yaxis:'y2',
      marker:{color:'rgba(0,43,92,0.45)',line:{color:'rgba(0,43,92,0.7)',width:0.5}},
      hovertemplate:'<b>%{x}</b><br>Count: %{y:,}<extra></extra>',
    });
  }

  // Line: Mean target (gold line, right axis)
  traces.push({
    type:'scatter',mode:'lines+markers',x:cats,y:mvals,
    name:mLbl,yaxis:'y2',
    line:{color:'#C8922A',width:2.5},
    marker:{color:'#C8922A',size:8,symbol:'circle',line:{color:'#fff',width:1.5}},
    hovertemplate:'<b>%{x}</b><br>'+mLbl+': %{y:.6g}<extra></extra>',
  });

  var expTitle = (hasE&&S.showExp) ? ec : '';
  var y2Title  = (S.showCnt?'Count':'') + (S.showCnt&&mvals.length?' / ':'') + mLbl;

  var layout={
    title:{text:col+' vs '+window.D_TGT+(tot>1?' (pg '+(S.catPage+1)+'/'+tot+')':''),
           font:{size:14,color:'#0D1B2E'}},
    xaxis:{type:'category',tickangle:angle,tickfont:{size:10},
           gridcolor:'#D4DCE8',zeroline:false,automargin:true},
    yaxis:{title:expTitle,side:'left',color:'rgba(200,146,42,0.85)',
           gridcolor:'#D4DCE8',zeroline:false,
           titlefont:{color:'rgba(200,146,42,0.9)',size:11},
           tickfont:{color:'rgba(200,146,42,0.9)'}},
    yaxis2:{title:y2Title,overlaying:'y',side:'right',showgrid:false,
            color:'rgba(0,43,92,0.75)',
            titlefont:{color:'rgba(0,43,92,0.75)',size:11},
            tickfont:{color:'rgba(0,43,92,0.75)'}},
    paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
    font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
    height:h,margin:{l:80,r:90,t:48,b:bMgn},
    legend:{orientation:'h',x:0,y:-0.22,bgcolor:'rgba(0,0,0,0)',font:{size:11}},
    barmode:'group',bargap:0.18,bargroupgap:0.06,
  };
  plot('cat-ch', traces, layout);
  catTbl(page, data, m, mLbl, hasE, ec, col);
}

function catTbl(page,all,m,mLbl,hasE,ec,col){
  var h='<tr><th>Category</th><th>Count</th><th>%</th>'
    +(hasE?'<th>'+ec+'</th><th>Exp%</th>':'')
    +'<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows=page.map(function(r){
    var it=r.category==='(Other)'?' style="font-style:italic;color:var(--txt2)"':'';
    return '<tr'+it+'>'
      +'<td style="font-weight:500;max-width:200px;word-break:break-word">'+r.category+'</td>'
      +'<td style="text-align:right">'+(+r.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+F(r.pct,1)+'%</td>'
      +(hasE?'<td style="text-align:right">'+F(r.exposure_sum,2)+'</td>'
            +'<td style="text-align:right">'+F(r.exposure_pct,1)+'%</td>':'')
      +'<td style="text-align:right;color:var(--acc);font-weight:700">'+F(r.mean,4)+'</td>'
      +'<td style="text-align:right">'+F(r.median,4)+'</td>'
      +'<td style="text-align:right">'+F(r.sum,2)+'</td></tr>';
  }).join('');
  var csvH='Category,Count,Pct'+(hasE?','+ec+',ExpPct':'')+',Mean,Median,Sum';
  var csv=csvH+'\n'+all.map(function(r){
    var b=['"'+r.category+'"',r.count,r.pct];
    if(hasE)b=b.concat([r.exposure_sum,r.exposure_pct]);
    return b.concat([r.mean,r.median,r.sum]).join(',');
  }).join('\n');
  var b64=btoa(unescape(encodeURIComponent(csv)));
  var tbl='<div class="tw"><table class="dt srt"><thead>'+h+'</thead><tbody>'+rows+'</tbody></table></div>'
    +'<div class="tc"><a class="dl" href="data:text/csv;base64,'+b64
    +'" download="'+(col||'cat')+'_vs_target.csv">DL Download CSV ('+all.length+' rows)</a></div>';
  var el=document.getElementById('cat-tbl');if(el)el.innerHTML=tbl;
}

// ════════════════════════════════════════════════════════════
//  NUMERICAL
//  Default: equal-exposure bins (equal sum of exposure_col)
//  Primary bars  = exposure SUM per bin  (gold, left axis)
//  Secondary bars = row count per bin    (navy, right axis)
//  Line          = mean target per bin   (right axis)
// ════════════════════════════════════════════════════════════
function selNum(col) { ACT={type:'num',col:col}; renderNum(col); }

function renderNum(col) {
  var all=window.D_NUM&&window.D_NUM[col];
  if (!all||!window.Plotly) return;
  var meth=S.method, nb=S.bins;
  var bins=(all[meth]&&all[meth][nb])?all[meth][nb]:[];

  // Fallback: try other available methods/bins
  if (!bins||!bins.length) {
    var methods=Object.keys(all);
    for(var mi=0;mi<methods.length;mi++){
      var bks=Object.keys(all[methods[mi]]).map(Number).sort(function(a,b){return a-b;});
      if(bks.length){bins=all[methods[mi]][bks[0]]||[];if(bins.length)break;}
    }
  }
  if (!bins||!bins.length) {
    var el=document.getElementById('num-ch');
    if(el) el.innerHTML='<p class="cap" style="padding:22px">No data for '+meth+' / '+nb+' bins.</p>';
    return;
  }

  var m=S.metric;
  var ec=window.D_EC||'';
  var hasE=!!(ec&&bins.length&&bins[0].exposure_sum!==undefined);
  var mids  = bins.map(function(b){return((+b.bin_lo||0)+(+b.bin_hi||0))/2;});
  var labs  = bins.map(function(b){return b.bin;});
  var expos = hasE?bins.map(function(b){return+b.exposure_sum||0;}):[]; 
  var cnts  = bins.map(function(b){return+b.count||0;});
  var mvals = bins.map(function(b){return+b[m]||0;});
  var mLbl  = ({mean:'Mean',median:'Median',sum:'Sum'}[m]||m)+' '+window.D_TGT;
  var ylog  = S.logY?'log':'linear';
  var bNote = (meth==='exposure'&&window.D_BY==='amount')
    ? ' \u00b7 equal '+ec+'/bin'
    : (meth==='exposure')?' \u00b7 equal rows/bin':'';

  var traces=[];

  // Bar 1: Exposure (gold, left axis) — PRIMARY
  if (hasE && S.showExp) {
    traces.push({
      type:'bar',x:mids,y:expos,name:ec+' (exposure)',yaxis:'y',
      marker:{color:'rgba(200,146,42,0.55)',line:{color:'rgba(200,146,42,0.85)',width:0.5}},
      hovertemplate:'%{text}<br>'+ec+': %{y:,.2f}<extra></extra>',
      text:labs,
    });
  }

  // Bar 2: Count (navy, right axis) — SECONDARY
  if (S.showCnt) {
    traces.push({
      type:'bar',x:mids,y:cnts,name:'Row Count',yaxis:'y2',
      marker:{color:'rgba(0,43,92,0.45)',line:{color:'rgba(0,43,92,0.7)',width:0.5}},
      hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>',
      text:labs,
    });
  }

  // Line: Mean target (gold, right axis)
  traces.push({
    type:'scatter',mode:'lines+markers',x:mids,y:mvals,
    name:mLbl,yaxis:'y2',
    line:{color:'#C8922A',width:2.5},
    marker:{color:'#C8922A',size:8,symbol:'circle',line:{color:'#fff',width:1.5}},
    hovertemplate:'%{text}<br>'+mLbl+': %{y:.6g}<extra></extra>',
    text:labs,
  });

  var expTitle = (hasE&&S.showExp)?ec:'';
  var y2Title  = (S.showCnt?'Count / ':'')+mLbl;

  var layout={
    title:{text:col+' vs '+window.D_TGT+' ['+meth+', '+nb+' bins'+bNote+']',
           font:{size:14,color:'#0D1B2E'}},
    xaxis:{title:col,gridcolor:'#D4DCE8',zeroline:false},
    yaxis:{title:expTitle,side:'left',color:'rgba(200,146,42,0.85)',
           gridcolor:'#D4DCE8',zeroline:false,
           titlefont:{color:'rgba(200,146,42,0.9)',size:11},
           tickfont:{color:'rgba(200,146,42,0.9)'}},
    yaxis2:{title:y2Title,overlaying:'y',side:'right',showgrid:false,
            color:'rgba(0,43,92,0.75)',
            titlefont:{color:'rgba(0,43,92,0.75)',size:11},
            tickfont:{color:'rgba(0,43,92,0.75)'}},
    paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
    font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
    height:400,margin:{l:80,r:90,t:48,b:62},
    legend:{orientation:'h',x:0,y:-0.16,bgcolor:'rgba(0,0,0,0)',font:{size:11}},
    barmode:'group',bargap:0.14,bargroupgap:0.05,
  };
  plot('num-ch', traces, layout);
  numTbl(bins, m, mLbl, hasE, ec, col);
}

function numTbl(bins,m,mLbl,hasE,ec,col){
  var h='<tr><th>Bin</th><th>Count</th><th>%</th>'
    +(hasE?'<th>'+ec+'</th><th>Exp%</th>':'')
    +'<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows=bins.map(function(b){
    return '<tr>'
      +'<td style="font-family:monospace;font-size:.78rem;white-space:nowrap">'+b.bin+'</td>'
      +'<td style="text-align:right">'+(+b.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+F(b.pct,1)+'%</td>'
      +(hasE?'<td style="text-align:right">'+F(b.exposure_sum,2)+'</td>'
            +'<td style="text-align:right">'+F(b.exposure_pct,1)+'%</td>':'')
      +'<td style="text-align:right;color:var(--acc);font-weight:700">'+F(b.mean,4)+'</td>'
      +'<td style="text-align:right">'+F(b.median,4)+'</td>'
      +'<td style="text-align:right">'+F(b.sum,2)+'</td></tr>';
  }).join('');
  var csvH='Bin,Bin_Lo,Bin_Hi,Count,Pct'+(hasE?','+ec+',ExpPct':'')+',Mean,Median,Sum';
  var csv=csvH+'\n'+bins.map(function(b){
    var base=['"'+b.bin+'"',b.bin_lo,b.bin_hi,b.count,b.pct];
    if(hasE)base=base.concat([b.exposure_sum,b.exposure_pct]);
    return base.concat([b.mean,b.median,b.sum]).join(',');
  }).join('\n');
  var b64=btoa(unescape(encodeURIComponent(csv)));
  var tbl='<div class="tw"><table class="dt srt"><thead>'+h+'</thead><tbody>'+rows+'</tbody></table></div>'
    +'<div class="tc"><a class="dl" href="data:text/csv;base64,'+b64
    +'" download="'+(col||'num')+'_binned.csv">DL Download CSV</a></div>';
  var el=document.getElementById('num-tbl');if(el)el.innerHTML=tbl;
}

// ── init ────────────────────────────────────────────────────
window.addEventListener('load', function() {
  renderUni();
  var fc=window._FC, fn=window._FN;
  if (fc) selCat(fc);
  if (fn) selNum(fn);
  showTab('tab-u');
});
"""


# ══════════════════════════════════════════════════════════════
#  HTML builder
# ══════════════════════════════════════════════════════════════

def generate_fs_report(results: dict,
                        output_path=None,
                        open_browser: bool = True,
                        offline: bool = False) -> str:
    """
    Generate the Feature Selection Dashboard — a standalone HTML file.

    Separate from generate_report() (the EDA Dashboard).
    Focused on actuarial feature analysis:
      - Target Overview (univariate)
      - Categorical vs Target (exposure bars + count bars + mean line)
      - Numerical vs Target  (exposure bars + count bars + mean line)

    Default binning: equal-exposure (equal SUM of exposure_col per bin)

    Parameters
    ----------
    results     : dict from run_eda()
    output_path : e.g. "feature_selection.html"
    open_browser: auto-open after saving (local only)
    offline     : embed Plotly.js inline (no internet needed)

    Returns
    -------
    str : complete self-contained HTML

    Usage
    -----
    from eda_toolkit import generate_fs_report

    generate_fs_report(results, output_path="feature_selection.html")

    # Databricks
    html = generate_fs_report(results)
    displayHTML(html)
    """
    target = results.get("target_col")
    dta    = results.get("deep_target_analysis", {})
    n_rows = results.get("n_rows", 0)

    if not target:
        return "<html><body><p>No target column defined.</p></body></html>"
    if not dta:
        return ("<html><body><p>Target Analysis not computed. "
                "Call plan.set_sections(target_analysis=True) before run_eda()."
                "</p></body></html>")

    cat_cols    = sorted(dta.get("categorical", {}).keys())
    num_cols    = sorted(dta.get("numeric",     {}).keys())
    uni         = dta.get("univariate",  {})
    n_bins_list = dta.get("n_bins_list", [5, 10, 20])
    bin_methods = dta.get("bin_methods", ["equal", "quantile"])
    exposure_col= dta.get("exposure_col") or ""
    bin_by      = dta.get("bin_by", "amount")
    ta_elapsed  = dta.get("elapsed_sec", 0)

    # Default method: prefer "exposure" if available, else "equal"
    default_method = "exposure" if "exposure" in bin_methods else bin_methods[0] if bin_methods else "equal"
    n_bins_def     = 20 if 20 in n_bins_list else n_bins_list[0] if n_bins_list else 10
    def_bin_idx    = n_bins_list.index(n_bins_def) if n_bins_def in n_bins_list else 0
    bins_json      = _j(n_bins_list)

    # ── Stat cards ────────────────────────────────────────────
    stats = uni.get("stats", {})
    stat_cards = ""
    for lbl, key, fmt_s in [
        ("Count","count",",.0f"),("Mean","mean",".4g"),("Median","median",".4g"),
        ("Std Dev","std",".4g"),("P95","p95",".4g"),("P99","p99",".4g"),
        ("Skewness","skewness",".3f"),("Zero %","zero_pct",".2f"),
    ]:
        v = stats.get(key); disp = "—"
        if v is not None:
            try:
                fv = float(v)
                disp = (f"{int(fv):,}" if key=="count"
                        else f"{fv:.2f}%" if key=="zero_pct"
                        else format(fv, fmt_s))
            except Exception:
                disp = str(v)
        stat_cards += (f'<div class="sc"><div class="sv">{disp}</div>'
                       f'<div class="sl">{lbl}</div></div>')

    # ── Dropdowns ─────────────────────────────────────────────
    cat_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in cat_cols)
    num_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in num_cols)

    # ── Method buttons (only show what was pre-computed) ──────
    METHOD_LABELS = {
        "equal":    "Equal Width",
        "quantile": "Equal Count",
        "exposure": f"Equal Exposure" + (f" ({bin_by})" if exposure_col else ""),
    }
    meth_btns = "".join(
        (f'<button class="mb on" data-meth="{m}" onclick="setMeth(\'{m}\')">'
         f'{METHOD_LABELS.get(m, m)}</button>'
         if m == default_method else
         f'<button class="mb" data-meth="{m}" onclick="setMeth(\'{m}\')">'
         f'{METHOD_LABELS.get(m, m)}</button>')
        for i, m in enumerate(bin_methods)
    )

    # ── Legend strip ──────────────────────────────────────────
    exp_item = (f'<span class="li">'
                f'<span class="ls" style="background:rgba(200,146,42,.55)"></span>'
                f'{_esc(exposure_col)} (exposure, left axis)</span>'
                if exposure_col else "")
    legend = (f'<div class="leg">'
              f'{exp_item}'
              f'<span class="li"><span class="ls" style="background:rgba(0,43,92,.45)"></span>'
              f'Row Count (right axis)</span>'
              f'<span class="li"><span class="lline"></span>Mean {_esc(target)} (right axis)</span>'
              f'<span style="margin-left:auto;font-size:.72rem;color:var(--txt3)">'
              f'Gold bars = primary (left) &nbsp;&#183;&nbsp; Navy bars + line = secondary (right)'
              f'</span></div>')

    # ── Display toggles ───────────────────────────────────────
    expo_tog = (f'<label class="tg"><input type="checkbox" checked onchange="togExp(this)"> '
                f'{_esc(exposure_col)}</label>'
                if exposure_col else "")

    # ── Data script ───────────────────────────────────────────
    data_script = f"""<script>
window.D_TGT = {_j(target)};
window.D_UNI = {_j(uni)};
window.D_CAT = {_j(dta.get("categorical", {}))};
window.D_NUM = {_j(dta.get("numeric", {}))};
window.D_EC  = {_j(exposure_col)};
window.D_BY  = {_j(bin_by)};
window._FC   = {_j(cat_cols[0] if cat_cols else "")};
window._FN   = {_j(num_cols[0] if num_cols else "")};
</script>"""

    # ── Plotly ────────────────────────────────────────────────
    if offline:
        try:
            import plotly
            jp = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
            plotly_tag = f"<script>{jp.read_text()}</script>" if jp.exists() else f'<script src="{PLOTLY_CDN}"></script>'
        except Exception:
            plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'
    else:
        plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'

    no_cat = '<div class="warn">No categorical features found.</div>' if not cat_cols else ""
    no_num = '<div class="warn">No numeric features found.</div>' if not num_cols else ""

    # ── Assemble HTML ─────────────────────────────────────────
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Feature Selection &mdash; {_esc(target)} &mdash; {n_rows:,} rows</title>
{plotly_tag}
<style>{CSS}</style>
</head>
<body>
{data_script}

<!-- Fullscreen overlay -->
<div id="fso">
  <div id="fsb">
    <button id="fsc" onclick="closeFS()">&#10005;</button>
    <div id="fsp"></div>
  </div>
</div>

<!-- Header -->
<div class="hdr">
  <div class="hdr-row">
    <div class="logo">RC</div>
    <div>
      <div class="hdr-title">Feature Selection Dashboard</div>
      <div class="hdr-sub">Chubb &middot; Risk Cohorts &middot; v5</div>
    </div>
    <div class="hdr-meta">
      <span>Rows <strong>{n_rows:,}</strong></span>
      <span>Target <strong>{_esc(target)}</strong></span>
      <span>Cat <strong>{len(cat_cols)}</strong></span>
      <span>Num <strong>{len(num_cols)}</strong></span>
      {"<span>Exposure <strong>" + _esc(exposure_col) + "</strong></span>" if exposure_col else ""}
      <span>Runtime <strong>{ta_elapsed:.1f}s</strong></span>
    </div>
  </div>
  <div class="nav">
    <button class="nav-btn on" data-tab="tab-u" onclick="showTab('tab-u')">Target Overview</button>
    <button class="nav-btn"    data-tab="tab-c" onclick="showTab('tab-c')">Categorical vs Target</button>
    <button class="nav-btn"    data-tab="tab-n" onclick="showTab('tab-n')">Numerical vs Target</button>
  </div>
</div>

<div class="page">

<!-- Global controls -->
<div class="ctrls">
  <div class="cg">
    <div class="cl">Metric</div>
    <div class="br">
      <button class="cb mb2 on" data-m="mean"   onclick="setMetric('mean')">Mean</button>
      <button class="cb mb2"    data-m="median" onclick="setMetric('median')">Median</button>
      <button class="cb mb2"    data-m="sum"    onclick="setMetric('sum')">Sum</button>
    </div>
  </div>
  <div class="csep"></div>
  <div class="cg">
    <div class="cl">Chart options</div>
    <div class="br">
      <label class="tg"><input type="checkbox" onchange="togLog(this)"> Log Y</label>
      <label class="tg"><input type="checkbox" checked onchange="togCnt(this)"> Count bars</label>
      {expo_tog}
    </div>
  </div>
  <div class="csep"></div>
  <div class="cg">
    <div class="cl">Sort categories</div>
    <div class="br">
      <button class="cb sb on" data-s="count"  onclick="setSort('count')">By Count</button>
      <button class="cb sb"    data-s="metric" onclick="setSort('metric')">By Metric</button>
      <button class="cb sb"    data-s="alpha"  onclick="setSort('alpha')">A &ndash; Z</button>
    </div>
  </div>
  <div class="csep"></div>
  <div class="cg">
    <div class="cl">Group small &mdash; <span id="grp-lbl" style="color:var(--acc)">Off</span></div>
    <input type="range" class="rng" min="0" max="5" step="0.5" value="0" oninput="setGrp(this.value)">
  </div>
  <div class="cg" style="margin-left:auto;font-size:.72rem;color:var(--txt3);line-height:1.75;text-align:right">
    {n_rows:,} rows &middot; No sampling<br>Pre-computed in {ta_elapsed:.1f}s
  </div>
</div>

<!-- ═══ TAB: UNIVARIATE ═══ -->
<div id="tab-u" class="tab on">
  <h3 class="sh">Target Overview &mdash; {_esc(target)}</h3>
  <p class="cap">{n_rows:,} rows &middot; full dataset &middot; no sampling</p>
  <div class="sg">{stat_cards}</div>
  <div class="cw">
    <div class="cl2"><div class="sp"></div><span>Rendering...</span></div>
    <div id="uni-ch" class="cd"></div>
  </div>
  <div id="uni-tbl" style="margin-top:16px"></div>
</div>

<!-- ═══ TAB: CATEGORICAL ═══ -->
<div id="tab-c" class="tab">
  <h3 class="sh">Categorical Features vs {_esc(target)}</h3>
  {legend}
  {no_cat}
  {(f'<div class="fr">'
    f'<label class="fl">Feature</label>'
    f'<select class="fs" onchange="selCat(this.value)">{cat_opts}</select>'
    f'<span style="font-size:.77rem;color:var(--txt2)">{len(cat_cols)} features &middot; 30/page</span>'
    f'</div>') if cat_cols else ""}
  {('<div id="cat-pg" class="pgc" style="display:none">'
    '<button class="pgb" id="cat-prev" onclick="catPg(-1)">&#8592; Prev</button>'
    '<span class="pgi" id="cat-pi"></span>'
    '<button class="pgb" id="cat-next" onclick="catPg(1)">Next &#8594;</button>'
    '</div>') if cat_cols else ""}
  {('<div class="cw"><div class="cl2"><div class="sp"></div><span>Rendering...</span></div>'
    '<div id="cat-ch" class="cd"></div></div>'
    '<div id="cat-tbl" style="margin-top:12px"></div>') if cat_cols else ""}
</div>

<!-- ═══ TAB: NUMERICAL ═══ -->
<div id="tab-n" class="tab">
  <h3 class="sh">Numerical Features vs {_esc(target)}</h3>
  {legend}
  {no_num}
  {(f'<div class="fr">'
    f'<label class="fl">Feature</label>'
    f'<select class="fs" onchange="selNum(this.value)">{num_opts}</select>'
    f'<label class="fl" style="margin-left:8px">Binning</label>'
    f'{meth_btns}'
    f'<label class="fl">Bins</label>'
    f'<span class="bl" id="bins-v">{n_bins_def}</span>'
    f'<input type="range" class="rng" min="0" max="{len(n_bins_list)-1}" step="1"'
    f' value="{def_bin_idx}" oninput="setBins(this.value,{bins_json})">'
    f'</div>') if num_cols else ""}
  {('<div class="cw"><div class="cl2"><div class="sp"></div><span>Rendering...</span></div>'
    '<div id="num-ch" class="cd"></div></div>'
    '<div id="num-tbl" style="margin-top:12px"></div>') if num_cols else ""}
</div>

</div><!-- .page -->

<script>
{JS}
// Set default method from Python config
S.method = {_j(default_method)};
S.bins   = {n_bins_def};
// Mark correct method button as active
document.querySelectorAll('.mb').forEach(function(b){{
  b.classList.toggle('on', b.getAttribute('data-meth') === S.method);
}});
</script>
</body>
</html>"""

    if output_path:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
        size = path.stat().st_size / 1024
        print(f"[FS] Saved -> {path}  ({size:.0f} KB)")
        if open_browser and not str(output_path).startswith("/dbfs"):
            try:
                webbrowser.open(path.resolve().as_uri())
            except Exception:
                pass

    return html
