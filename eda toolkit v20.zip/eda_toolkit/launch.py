# -*- coding: utf-8 -*-
"""
launch.py — Insurance EDA Toolkit v4

FULL WORKFLOW:
─────────────
    from eda_toolkit import inspect, run_eda, launch_app

    plan = inspect(df, target_col="Claim_Flag")
    plan.fix(Policy_Year="Categorical")     # override wrong detections
    plan.confirm()
    df_clean = plan.apply_to_df()           # cast + drop constants/unknowns

    # Optional: toggle expensive sections off to save time
    plan.set_sections(correlations=True, category_quality=True,
                      scorecard=True, target_analysis=True)

    # Optional: define key columns for overview stats
    plan.set_key_stats(
        key_cols    = ["Policy_Number"],            # count / unique / dup rate
        composite_keys = [["Policy_Number","Eff_Date"]]  # concat + check uniqueness
    )

    # Optional: define a second dataframe for comparison
    plan.set_comparison(
        df          = df_renewals,
        label_a     = "New Business",
        label_b     = "Renewals",
        groupby_col = "Region",
        agg_cols    = ["Premium","Claim_Flag","Exposure"],
    )

    results = run_eda(df_clean, plan)
    launch_app(results)
"""

import sys, os, pickle, subprocess, threading, time, webbrowser
from pathlib import Path
import pandas as pd
import numpy as np

_DIR = Path(__file__).parent
sys.path.insert(0, str(_DIR))

from eda_engine import detect_type, run_eda as _run_eda

VALID_TYPES = {"Numeric","Categorical","Boolean","Date","ID-like","Unknown","Constant"}

_ICON = {"Numeric":"🔢","Categorical":"🏷️","Boolean":"☑️","Date":"📅",
         "ID-like":"🔑","Unknown":"❓","Constant":"🔒"}

_MEANING = {
    "Numeric":     "Continuous number — histogram, stats, IQR outlier check",
    "Categorical": "Discrete labels — frequency table, fuzzy duplicate check",
    "Boolean":     "Binary flag (0/1) — treated as Numeric",
    "Date":        "Date/time — extract year, month, quarter for modelling",
    "ID-like":     "Identifier — too many unique values, excluded from analysis",
    "Unknown":     "Entirely null or unreadable — excluded from analysis",
    "Constant":    "Zero-variance column — single unique value, drop before modelling",
}

_CAST_MAP = {"Numeric":"float64","Boolean":"float64","Categorical":"category",
             "Date":"datetime","ID-like":None,"Unknown":None,"Constant":None}


def _sample_vals(s, n=5):
    vals = s.dropna().head(n).tolist()
    return ", ".join(str(v)[:22] for v in vals) if vals else "—"


def _col_warnings(col, s, detected):
    warns = []; nu = int(s.dropna().nunique()); mp = float(s.isna().mean()*100)
    if mp == 100: warns.append("ALL NULL — will be excluded")
    elif mp > 20: warns.append(f"{mp:.0f}% missing")
    if detected == "Constant":
        warns.append("Zero-variance — single unique value, useless for modelling")
    if detected == "Numeric":
        try:
            clean = s.dropna().astype(float)
            if nu<=150 and ((clean>=1900)&(clean<=2100)).mean()>0.90:
                warns.append("Looks like a YEAR — consider 'Date' or 'Categorical'")
        except Exception: pass
        if 2 < nu <= 8: warns.append(f"Only {nu} unique values — consider 'Categorical'")
    if detected == "Categorical":
        if nu > 100: warns.append(f"High cardinality ({nu} unique) — is this an ID column?")
        try:
            sample = s.dropna().astype(str).head(50)
            dl = sum(1 for v in sample if any(sep in v for sep in ["-","/"]) and any(c.isdigit() for c in v))
            if dl / max(len(sample),1) > 0.7: warns.append("Values look like dates — consider 'Date'")
        except Exception: pass
    if detected == "ID-like": warns.append("Will be excluded from EDA analysis")
    return warns


# ─────────────────────────────────────────────────────────────────────────────
# InspectPlan
# ─────────────────────────────────────────────────────────────────────────────

class InspectPlan:
    """
    Holds confirmed column types + all EDA configuration.

    Methods
    -------
    plan.fix(**kwargs)              — override auto-detected types
    plan.confirm()                  — print confirmed table, mark ready
    plan.apply_to_df(...)           — cast df to confirmed types, drop constants
    plan.set_sections(...)          — toggle which analysis sections run
    plan.set_key_stats(...)         — define key cols + composite keys for overview
    plan.set_comparison(...)        — define second df for side-by-side comparison
    plan.set(key, value)            — set any raw config key
    """

    def __init__(self, df, dtype_map, config):
        self._df        = df
        self._dtype_map = dict(dtype_map)
        self._overrides = {}
        self._config    = dict(config)
        self._confirmed = False

    # ── fix ───────────────────────────────────────────────────────────────────
    def fix(self, **kwargs):
        """Override auto-detected types. Valid: Numeric Categorical Boolean Date ID-like Unknown Constant"""
        for col, new_type in kwargs.items():
            if col not in self._dtype_map:
                print(f"  ⚠️  '{col}' not found. Available: {list(self._dtype_map.keys())[:8]}...")
                continue
            if new_type not in VALID_TYPES:
                print(f"  ⚠️  '{new_type}' invalid. Options: {sorted(VALID_TYPES)}")
                continue
            old = self._dtype_map[col]; self._dtype_map[col] = new_type; self._overrides[col] = new_type
            print(f"  ✔  {col}: {old} → {new_type}")
        self._confirmed = False
        if kwargs: print("\n  Call plan.confirm() to review and proceed.")
        return self

    # ── set ───────────────────────────────────────────────────────────────────
    def set(self, key, value):
        """Set any raw config key."""
        self._config[key] = value
        return self

    # ── set_sections ──────────────────────────────────────────────────────────
    def set_sections(self, correlations=True, category_quality=True,
                     scorecard=True, target_analysis=True):
        """
        Toggle which analysis sections run. Disable to save time on large datasets.

        Parameters
        ----------
        correlations     : bool  (default True)
        category_quality : bool  (default True)  — fuzzy category matching
        scorecard        : bool  (default True)  — quality scorecard + recommendations
        target_analysis  : bool  (default True)  — feature vs target correlations
        """
        self._config["sections"] = {
            "correlations":     correlations,
            "category_quality": category_quality,
            "scorecard":        scorecard,
            "target_analysis":  target_analysis,
        }
        on  = [k for k,v in self._config["sections"].items() if v]
        off = [k for k,v in self._config["sections"].items() if not v]
        print(f"  ✔  Sections ON : {', '.join(on) or 'none'}")
        if off: print(f"  ⏭  Sections OFF: {', '.join(off)}")
        return self

    # ── set_corr_options ──────────────────────────────────────────────────────
    def set_corr_options(self, corr_sample=100_000, chi_sample=20_000,
                         chi_max_cardinality=10_000, corr_threshold=0.75):
        """
        Tune performance and sensitivity of the Correlations section.

        Parameters
        ----------
        corr_sample          : int    Rows sampled for Pearson matrix (default 100,000).
                                      Increase for more accuracy, lower to save time.
        chi_sample           : int    Rows sampled for chi-square tests (default 20,000).
                                      Chi-square is statistically valid at 10k+ rows.
        chi_max_cardinality  : int    Categorical columns with more unique values than
                                      this threshold are SKIPPED in chi-square to avoid
                                      enormous contingency tables (default 10,000).
                                      Raise to 20,000+ if you have near-ID columns you
                                      still want tested.
        corr_threshold       : float  |r| threshold for flagging high Pearson pairs
                                      (default 0.75).

        Examples
        --------
        # Default — fast, suitable for large datasets
        plan.set_corr_options()

        # Increase chi-square cardinality cap for a dataset with many codes
        plan.set_corr_options(chi_max_cardinality=20_000)

        # High-accuracy mode for smaller datasets
        plan.set_corr_options(corr_sample=500_000, chi_sample=100_000)
        """
        self._config["corr_sample"]          = corr_sample
        self._config["chi_sample"]           = chi_sample
        self._config["chi_max_cardinality"]  = chi_max_cardinality
        self._config["corr_threshold"]       = corr_threshold
        print(f"  ✔  Correlation options set:")
        print(f"     Pearson sample        : {corr_sample:,} rows")
        print(f"     Chi-square sample     : {chi_sample:,} rows")
        print(f"     Chi max cardinality   : {chi_max_cardinality:,} unique values (skip above this)")
        print(f"     High-corr threshold   : |r| ≥ {corr_threshold}")
        return self


    def set_target_analysis(self,
                             n_bins: list | None = None,
                             bin_methods: list | None = None,
                             exposure_col: str | None = None,
                             bin_by: str = "count"):
        """
        Configure the Target Analysis tab binning behaviour.

        Parameters
        ----------
        n_bins       : list[int]   Bin counts to pre-compute.
                                   Default [5, 10, 20].
                                   Each value creates a separate config the user
                                   can switch between via the slider in the tab.

        bin_methods  : list[str]   Binning methods to pre-compute. Options:
                                   "equal"    — equal-width intervals
                                   "quantile" — equal row count per bin
                                   "exposure" — equal exposure per bin (actuarially
                                                correct for insurance modelling)
                                   Default ["equal", "quantile", "exposure"] if
                                   exposure_col is set, else ["equal", "quantile"].

        exposure_col : str | None  Column containing exposure (e.g. "earned_exposure",
                                   "policy_count", "car_years").
                                   Required for "exposure" binning method.
                                   If None, "exposure" method is skipped.

        bin_by       : str         How to measure exposure in equal-exposure binning.
                                   "count"  — each bin has equal number of rows
                                              (same as quantile, useful baseline)
                                   "amount" — each bin has equal SUM of exposure_col
                                              (actuarially correct: equal earned exposure)
                                   Default "amount" when exposure_col is set.

        Examples
        --------
        # Basic — equal width and quantile, 3 bin configs
        plan.set_target_analysis(n_bins=[5, 10, 20])

        # Actuarially correct — equal exposure amount per bin
        plan.set_target_analysis(
            n_bins       = [5, 10, 20],
            exposure_col = "earned_exposure",
            bin_by       = "amount",   # each bin has same total earned_exposure
        )

        # Toggle between count-based and amount-based exposure binning
        plan.set_target_analysis(
            n_bins       = [5, 10, 20],
            exposure_col = "policy_count",
            bin_by       = "count",    # each bin has same number of policies
        )
        """
        if n_bins is None:
            n_bins = [5, 10, 20]

        # Build default methods list
        if bin_methods is None:
            if exposure_col:
                bin_methods = ["equal", "quantile", "exposure"]
            else:
                bin_methods = ["equal", "quantile"]

        # Validate bin_by
        if bin_by not in ("count", "amount"):
            print(f"  ⚠️  bin_by='{bin_by}' invalid. Use 'count' or 'amount'. Defaulting to 'amount'.")
            bin_by = "amount"

        # Validate exposure_col
        if "exposure" in bin_methods and not exposure_col:
            print("  ⚠️  'exposure' method requested but exposure_col not set — skipping.")
            bin_methods = [m for m in bin_methods if m != "exposure"]

        if exposure_col and exposure_col not in self._dtype_map and exposure_col not in self._df.columns:
            print(f"  ⚠️  exposure_col='{exposure_col}' not found in dataset.")
            exposure_col = None

        self._config["ta_n_bins"]      = n_bins
        self._config["ta_methods"]     = bin_methods
        self._config["ta_exposure_col"]= exposure_col
        self._config["ta_bin_by"]      = bin_by

        print(f"  ✔  Target Analysis configured:")
        print(f"     Bin counts    : {n_bins}")
        print(f"     Bin methods   : {bin_methods}")
        if exposure_col:
            print(f"     Exposure col  : {exposure_col}")
            print(f"     Bin by        : {bin_by} ({'equal sum of ' + exposure_col if bin_by == 'amount' else 'equal row count'})")
        return self

    def set_key_stats(self, key_cols=None, composite_keys=None):
        """
        Define key columns to show count/unique/duplicate stats on the Overview page.

        Parameters
        ----------
        key_cols       : list[str]       — columns to analyse individually
                         e.g. ["Policy_Number", "Risk_ID"]
        composite_keys : list[list[str]] — groups of columns to concatenate as composite keys
                         e.g. [["Policy_Number","Eff_Date"], ["Risk_ID","Line"]]
        """
        self._config["key_stats"] = {
            "key_cols":       list(key_cols or []),
            "composite_keys": [list(k) for k in (composite_keys or [])],
        }
        print(f"  ✔  Key columns     : {key_cols or []}")
        print(f"  ✔  Composite keys  : {composite_keys or []}")
        return self

    # ── set_comparison ────────────────────────────────────────────────────────
    def set_comparison(self, df, label_a=None, label_b="Dataset B",
                       groupby_col=None, agg_cols=None, agg_config=None):
        """
        Define a second DataFrame to compare side-by-side on the Comparison tab.

        Parameters
        ----------
        df          : pd.DataFrame   — the second dataset to compare against
        label_a     : str            — label for the primary dataset (default: "Primary")
        label_b     : str            — label for the comparison dataset
        groupby_col : str or list    — column(s) to group both datasets by.
                                       Single: "Region"
                                       Multiple: ["Region","Policy_Year"]
        agg_cols    : list[str]      — columns to summarise using default count/mean/median/sum
        agg_config  : dict           — per-column aggregation methods (overrides agg_cols)
                                       e.g. {"Premium": ["sum","mean"],
                                             "Policy_Number": ["count","nunique"],
                                             "Claim_Flag": ["sum","mean"]}

        Examples
        --------
        # Simple — default agg (count/mean/median/sum) on listed columns
        plan.set_comparison(
            df=df_renewals, label_a="New Business", label_b="Renewals",
            groupby_col="Region",
            agg_cols=["Premium","Claim_Flag","Exposure"],
        )

        # Advanced — per-column aggregation methods
        plan.set_comparison(
            df=df_renewals, label_a="New Business", label_b="Renewals",
            groupby_col=["Region","Policy_Year"],
            agg_config={
                "Premium":       ["sum","mean"],
                "Policy_Number": ["count","nunique"],
                "Claim_Flag":    ["sum","mean"],
                "Exposure":      ["sum"],
            },
        )
        """
        # Normalise groupby_col to always be a list internally
        if isinstance(groupby_col, str):
            grp = [groupby_col]
        elif isinstance(groupby_col, list):
            grp = groupby_col
        else:
            grp = [self._config.get("groupby_col","")] if self._config.get("groupby_col") else []

        self._config["comparison"] = {
            "df":         df,
            "label_a":    label_a or "Primary",
            "label_b":    label_b,
            "groupby_col": grp,
            "agg_cols":   list(agg_cols or []),
            "agg_config": dict(agg_config or {}),
        }
        print(f"  ✔  Comparison configured")
        print(f"     Primary   : {label_a or 'Primary'}  ({len(self._df):,} rows)")
        print(f"     Comparison: {label_b}  ({len(df):,} rows)")
        if grp:    print(f"     Group by  : {grp}")
        if agg_config: print(f"     Agg config: {list(agg_config.keys())}")
        elif agg_cols: print(f"     Agg cols  : {agg_cols}")
        return self

    # ── confirm ───────────────────────────────────────────────────────────────
    def confirm(self):
        print("\n" + "═"*72)
        print("  ✅  CONFIRMED COLUMN TYPES")
        print("═"*72)
        print(f"  {'#':<4} {'Column':<30} {'Type':<16} {'Status'}")
        print("  " + "─"*62)
        for i,(col,dtype) in enumerate(self._dtype_map.items(), 1):
            icon    = _ICON.get(dtype,"❓")
            changed = "  ← overridden" if col in self._overrides else ""
            warn    = "  ⚠️ WILL BE DROPPED" if dtype in ("Constant","ID-like","Unknown") else ""
            print(f"  {i:<4} {col:<30} {icon} {dtype:<14}{changed}{warn}")
        print("─"*72)
        tc = self._config.get("target_col")
        if tc: print(f"  Target column : {tc}")
        if self._overrides: print(f"  Manual overrides: {len(self._overrides)} column(s)")
        secs = self._config.get("sections",{})
        if secs:
            off = [k for k,v in secs.items() if not v]
            if off: print(f"  Sections OFF  : {', '.join(off)}")
        cmp = self._config.get("comparison",{})
        if cmp: print(f"  Comparison    : {cmp.get('label_a','A')} vs {cmp.get('label_b','B')}")
        ks = self._config.get("key_stats",{})
        if ks.get("key_cols"): print(f"  Key stats     : {ks['key_cols']}")
        print()
        print("  Next steps:")
        print("    df_clean = plan.apply_to_df()")
        print("    results  = run_eda(df_clean, plan)")
        print()
        self._confirmed = True
        self._config["dtype_map"] = dict(self._dtype_map)  # pass to run_eda
        return self

    # ── apply_to_df ───────────────────────────────────────────────────────────
    def apply_to_df(self, drop_constants=True, drop_id_like=False, drop_unknown=True):
        """
        Return a copy of df cast to confirmed EDA types.

        Numeric      → float64
        Boolean      → float64 (0/1)
        Categorical  → category dtype
        Date         → datetime64[ns]
        Constant     → dropped if drop_constants=True (default)
        Unknown      → dropped if drop_unknown=True (default)
        ID-like      → kept by default (useful for joins); drop if drop_id_like=True
        """
        df = self._df.copy(); dropped = []; cast_log = []
        _TRUE = {"1","y","yes","true","t","1.0","male","m"}
        for col, eda_type in self._dtype_map.items():
            if col not in df.columns: continue
            if eda_type=="Constant" and drop_constants:
                df.drop(columns=[col], inplace=True); dropped.append((col,"Constant — dropped")); continue
            if eda_type=="Unknown" and drop_unknown:
                df.drop(columns=[col], inplace=True); dropped.append((col,"Unknown (all-null) — dropped")); continue
            if eda_type=="ID-like" and drop_id_like:
                df.drop(columns=[col], inplace=True); dropped.append((col,"ID-like — dropped")); continue
            orig = str(df[col].dtype)
            try:
                if eda_type=="Numeric":
                    df[col] = pd.to_numeric(df[col], errors="coerce").astype("float64")
                    cast_log.append((col, orig, "float64"))
                elif eda_type=="Boolean":
                    if df[col].dtype==object:
                        df[col] = df[col].map(lambda v: 1.0 if str(v).strip().lower() in _TRUE
                                              else (0.0 if pd.notna(v) else np.nan)).astype("float64")
                    else:
                        df[col] = pd.to_numeric(df[col], errors="coerce").astype("float64")
                    cast_log.append((col, orig, "float64 (boolean)"))
                elif eda_type=="Categorical":
                    df[col] = df[col].astype("category")
                    cast_log.append((col, orig, "category"))
                elif eda_type=="Date":
                    df[col] = pd.to_datetime(df[col], errors="coerce", infer_datetime_format=True)
                    cast_log.append((col, orig, "datetime64[ns]"))
            except Exception as e:
                print(f"  ⚠️  Could not cast '{col}' ({eda_type}): {e}")

        print(f"\n{'═'*60}")
        print(f"  apply_to_df() — {len(df.columns)} columns kept, {len(dropped)} dropped")
        print(f"{'═'*60}")
        if cast_log:
            print(f"\n  CASTS APPLIED ({len(cast_log)}):")
            for col, old, new in cast_log:
                print(f"    {_ICON.get(self._dtype_map.get(col,''),'  ')} {col:<28} {old:<14} → {new}")
        if dropped:
            print(f"\n  DROPPED ({len(dropped)}):")
            for col, reason in dropped: print(f"    🗑  {col:<28} {reason}")
        print(f"\n  Shape: {df.shape}"); print(f"  Call: results = run_eda(df_clean, plan)\n")
        return df

    # ── internal ──────────────────────────────────────────────────────────────
    def _as_config(self):
        cfg = dict(self._config); cfg["dtype_overrides"] = dict(self._overrides)
        return cfg

    def get(self, key, default=None):
        return self._config.get(key, default)

    def __repr__(self):
        st = "confirmed ✅" if self._confirmed else "not confirmed ⚠️"
        return f"<InspectPlan {len(self._dtype_map)} cols, {len(self._overrides)} override(s), {st}>"


# ─────────────────────────────────────────────────────────────────────────────
# inspect()
# ─────────────────────────────────────────────────────────────────────────────

def inspect(df, target_col=None, id_ratio=0.8, **config_kwargs):
    """
    Detect column types and show a pre-flight confirmation table.
    Returns InspectPlan.
    """
    n_rows, n_cols = df.shape
    feats = [c for c in df.columns if c != target_col]

    print(f"\n{'═'*80}")
    print(f"  EDA TOOLKIT — PRE-FLIGHT INSPECTION")
    print(f"  {n_rows:,} rows  ×  {n_cols} columns", end="")
    if target_col: print(f"  |  Target: {target_col}", end="")
    print(f"\n{'═'*80}\n")

    dtype_map    = {c: detect_type(df[c], id_ratio) for c in feats}
    warnings_map = {c: _col_warnings(c, df[c], dtype_map[c]) for c in feats}

    # Print table — wider columns so sample values don't truncate
    print(f"  {'#':<4} {'Column':<30} {'Pandas dtype':<14} {'Detected as':<18}"
          f"{'Unique':>8} {'Missing':>8}  Sample values")
    print("  " + "─"*116)
    for i, col in enumerate(feats, 1):
        dt      = dtype_map[col]; icon = _ICON.get(dt,"❓")
        pd_type = str(df[col].dtype)
        nu      = int(df[col].nunique()); mp = float(df[col].isna().mean()*100)
        sample  = _sample_vals(df[col], n=4)
        warn    = " ⚠️" if warnings_map[col] else ""
        print(f"  {i:<4} {col:<30} {pd_type:<14} {icon} {dt:<16} {nu:>8,} {mp:>6.1f}%{warn}  {sample}")
    print("  " + "─"*116)

    all_warns = [(c,w) for c,ws in warnings_map.items() for w in ws]
    if all_warns:
        print(f"\n  ⚠️  WARNINGS ({len(all_warns)}):\n")
        for c,w in all_warns: print(f"     {c:<30} → {w}")
    else:
        print(f"\n  ✅  No warnings detected.")

    print(f"\n  TYPE KEY:")
    for t,m in _MEANING.items(): print(f"    {_ICON[t]} {t:<14}  {m}")

    print(f"""
  {'─'*78}
  QUICK START:
    plan.fix(ColumnName="CorrectType")        # fix wrong detections
    plan.confirm()                             # review + mark ready
    df_clean = plan.apply_to_df()             # cast types, drop constants/unknowns

  OPTIONAL CONFIGURATION:
    plan.set_sections(correlations=True, category_quality=True,
                      scorecard=True, target_analysis=True)

    plan.set_key_stats(
        key_cols       = ["Policy_Number"],
        composite_keys = [["Policy_Number","Eff_Date"]]
    )

    plan.set_comparison(
        df=df2, label_a="New Business", label_b="Renewals",
        groupby_col="Region", agg_cols=["Premium","Claim_Flag"]
    )

    results = run_eda(df_clean, plan)

  Valid types: Numeric  Categorical  Boolean  Date  ID-like  Unknown  Constant
  {'─'*78}
""")

    config = {"target_col": target_col, "id_ratio": id_ratio}
    config.update(config_kwargs)
    return InspectPlan(df, dtype_map, config)


# ─────────────────────────────────────────────────────────────────────────────
# run_eda()
# ─────────────────────────────────────────────────────────────────────────────

def run_eda(df, config):
    """Run full EDA. Accepts InspectPlan or plain dict."""
    if isinstance(config, InspectPlan):
        if not config._confirmed:
            print("  ⚠️  plan.confirm() not called — proceeding.\n")
        cfg = config._as_config()
    elif isinstance(config, dict):
        cfg = config
    else:
        cfg = {}
    return _run_eda(df, cfg)


# ─────────────────────────────────────────────────────────────────────────────
# launch_app()
# ─────────────────────────────────────────────────────────────────────────────

def launch_app(results, port=8501, databricks=False, ngrok_token=None,
               mode="streamlit", output_path=None, open_browser=True, offline=False):
    """
    Launch the EDA dashboard.

    Parameters
    ----------
    results      : dict returned by run_eda()
    mode         : "streamlit" (default) — starts the Streamlit server
                   "html"                — generates a self-contained HTML report
    port         : int   local port for Streamlit mode (default 8501)
    databricks   : bool  set True when running inside a Databricks cluster
    ngrok_token  : str   ngrok auth token (only used if databricks=True)
    output_path  : str   file path for HTML output (mode="html" only)
                         e.g. "report.html" or "/dbfs/FileStore/eda_report.html"
    open_browser : bool  auto-open HTML file in browser (local, mode="html" only)
    offline      : bool  embed Plotly.js inline for offline use (mode="html" only)

    Examples
    --------
    # Streamlit (local)
    launch_app(results)

    # HTML — save and auto-open
    launch_app(results, mode="html", output_path="eda_report.html")

    # HTML — Databricks inline
    html = launch_app(results, mode="html")
    displayHTML(html)

    # HTML — Databricks save to DBFS
    launch_app(results, mode="html", output_path="/dbfs/FileStore/eda_report.html")

    # Streamlit — Databricks via driver proxy
    launch_app(results, databricks=True)
    """
    if mode == "html":
        try:
            from .html_report import generate_report
        except ImportError:
            from html_report import generate_report
        return generate_report(results, output_path=output_path,
                                open_browser=open_browser, offline=offline)
    pkl_path = _DIR / "_results.pkl"
    with open(pkl_path, "wb") as f:
        pickle.dump(results, f)

    shim = _DIR / "_entry.py"
    shim.write_text(f"""\
import sys, pickle
from pathlib import Path
_d = Path(r"{_DIR}")
sys.path.insert(0, str(_d))
import streamlit as st
from app import main
if "eda_results" not in st.session_state:
    with open(_d / "_results.pkl", "rb") as f:
        st.session_state["eda_results"] = pickle.load(f)
main()
""")

    if databricks:
        if ngrok_token:
            _launch_ngrok(shim, port, ngrok_token)
        else:
            _launch_databricks_proxy(results, shim, port)
        return

    # ── Local mode ────────────────────────────────────────────────────────────
    url = f"http://localhost:{port}"
    print(f"\n{'─'*50}\n  EDA Toolkit  |  {url}  |  Ctrl+C to stop\n{'─'*50}\n")
    def _open(): time.sleep(2.5); webbrowser.open(url)
    threading.Thread(target=_open, daemon=True).start()
    cmd = [sys.executable, "-m", "streamlit", "run", str(shim),
           f"--server.port={port}", "--server.headless=true", "--theme.base=light"]
    try:
        subprocess.run(cmd, cwd=str(_DIR))
    except KeyboardInterrupt:
        print("\n[EDA] Stopped.")


# ─────────────────────────────────────────────────────────────────────────────
# Databricks — driver proxy approach (no ngrok, no firewall issues)
# ─────────────────────────────────────────────────────────────────────────────

def _get_proxy_url(port):
    """
    Build the Databricks driver-proxy URL for this cluster.
    Returns (url, cluster_id) or (None, None) if not in Databricks.
    """
    try:
        import IPython
        dbutils = IPython.get_ipython().user_ns.get("dbutils")
        if dbutils is None:
            return None, None
        ctx        = dbutils.notebook.entry_point.getDbutils().notebook().getContext()
        host       = ctx.browserHostName().get()
        cluster_id = ctx.clusterId().get()
        # Two URL patterns — try the newer org-scoped one first
        url = f"https://{host}/driver-proxy/o/0/{cluster_id}/{port}/"
        return url, cluster_id
    except Exception:
        return None, None


def _start_streamlit_bg(shim, port):
    """Start Streamlit on given port in a background daemon thread."""
    # Write config: disable CORS/XSRF so proxy can reach it
    config_dir = Path.home() / ".streamlit"
    config_dir.mkdir(exist_ok=True)
    (config_dir / "config.toml").write_text(f"""\
[server]
port = {port}
headless = true
enableCORS = false
enableXsrfProtection = false

[theme]
base = "light"
""")

    cmd = [sys.executable, "-m", "streamlit", "run", str(shim),
           f"--server.port={port}", "--server.headless=true"]

    proc_box = [None]
    def _run():
        proc_box[0] = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            cwd=str(_DIR),
        )
        for _ in proc_box[0].stdout:   # drain so buffer never fills
            pass

    threading.Thread(target=_run, daemon=True).start()

    # Wait up to 20s for Streamlit to be ready
    import urllib.request
    print("[EDA] Starting Streamlit...", end="", flush=True)
    for _ in range(20):
        time.sleep(1)
        print(".", end="", flush=True)
        try:
            urllib.request.urlopen(f"http://localhost:{port}/_stcore/health", timeout=1)
            break
        except Exception:
            continue
    print(" ready!")
    return proc_box


def _launch_databricks_proxy(results, shim, port=8501):
    """
    Strategy:
      1. Try Databricks built-in driver proxy (zero config, works on most clusters).
      2. If proxy URL can't be determined, fall back to native notebook rendering.
    """
    # ── Try driver proxy ──────────────────────────────────────────────────────
    proxy_url, cluster_id = _get_proxy_url(port)

    if proxy_url:
        # Install streamlit if needed (usually already present on DBR 13+)
        try:
            import streamlit  # noqa
        except ImportError:
            print("[EDA] Installing streamlit...")
            subprocess.run([sys.executable, "-m", "pip", "install", "streamlit", "plotly", "-q"],
                           capture_output=True)

        _start_streamlit_bg(shim, port)

        # Display clickable link + iframe inside the notebook
        try:
            import IPython.display as ipd
            ipd.display(ipd.HTML(f"""
<div style="font-family:sans-serif;padding:16px;background:#f0f4ff;
            border-left:4px solid #4f46e5;border-radius:6px;margin:8px 0">
  <b style="font-size:16px">🚀 EDA Toolkit is running</b><br><br>
  <a href="{proxy_url}" target="_blank"
     style="font-size:14px;color:#4f46e5;font-weight:600">
    👉 Open in new tab: {proxy_url}
  </a><br><br>
  <span style="color:#555;font-size:12px">
    Uses Databricks driver proxy — no external tools required.<br>
    Active as long as the cluster is running.
  </span>
</div>
<iframe src="{proxy_url}" width="100%" height="900"
        frameborder="0" style="border-radius:6px;margin-top:8px">
</iframe>
"""))
        except Exception:
            print(f"\n{'─'*60}")
            print(f"  🚀 EDA Toolkit running via Databricks driver proxy")
            print(f"  👉 Open: {proxy_url}")
            print(f"{'─'*60}\n")

        # Keep cell alive
        try:
            while True:
                time.sleep(30)
        except KeyboardInterrupt:
            print("\n[EDA] Stopped.")

    else:
        # ── Proxy URL unavailable — fall back to native rendering ─────────────
        print("[EDA] Driver proxy unavailable — rendering natively in notebook.")
        _render_native(results)


# ─────────────────────────────────────────────────────────────────────────────
# Native notebook rendering — no server needed at all
# ─────────────────────────────────────────────────────────────────────────────

def _render_native(results):
    """
    Render the full EDA report as HTML + Plotly directly inside the notebook.
    No Streamlit, no ports, no tunnels. Works on any Databricks cluster.
    """
    try:
        import plotly.graph_objects as go
        import plotly.express as px
        import IPython.display as ipd
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "plotly", "-q"],
                       capture_output=True)
        import plotly.graph_objects as go
        import plotly.express as px
        import IPython.display as ipd

    cr   = results.get("col_results", {})
    corr = results.get("correlations", {})
    sc   = results.get("scorecard", pd.DataFrame())
    recs = results.get("recommendations", [])
    dm   = results.get("dtype_map", {})
    n_rows = results.get("n_rows", 0)
    target = results.get("target_col")

    PURPLE = "#7c3aed"; ACCENT = "#3b82f6"; RED = "#ef4444"
    GREEN  = "#22c55e"; ORANGE = "#f97316"; CYAN  = "#06b6d4"

    def _html(h): ipd.display(ipd.HTML(h))
    def _fig(f):  ipd.display(f)
    def _sec(t, sub=False):
        size = "18px" if not sub else "14px"
        _html(f'<h3 style="font-family:sans-serif;font-size:{size};'
              f'color:#1e293b;margin:20px 0 6px">{t}</h3>')
    def _divider(): _html('<hr style="border:none;border-top:1px solid #e2e8f0;margin:16px 0">')

    # ── Header ────────────────────────────────────────────────────────────────
    _html(f"""
<div style="font-family:sans-serif;background:linear-gradient(135deg,#4f46e5,#7c3aed);
            padding:20px 24px;border-radius:10px;color:white;margin-bottom:16px">
  <div style="font-size:22px;font-weight:700">🔍 Insurance EDA Toolkit</div>
  <div style="font-size:13px;opacity:0.85;margin-top:4px">
    {n_rows:,} rows &nbsp;·&nbsp;
    {len(cr)} features &nbsp;·&nbsp;
    Target: {target or '—'} &nbsp;·&nbsp;
    Runtime: {results.get('elapsed_sec',0):.1f}s
  </div>
</div>""")

    # ── Feature type summary cards ────────────────────────────────────────────
    type_counts = pd.Series(dm).value_counts()
    icon_map = {"Numeric":"🔢","Categorical":"🏷️","Boolean":"☑️","Date":"📅",
                "ID-like":"🔑","Unknown":"❓","Constant":"🔒"}
    cards = "".join(
        f'<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;'
        f'padding:12px 18px;text-align:center;min-width:100px">'
        f'<div style="font-size:22px">{icon_map.get(t,"❓")}</div>'
        f'<div style="font-weight:600;font-size:16px">{c}</div>'
        f'<div style="font-size:11px;color:#64748b">{t}</div></div>'
        for t, c in type_counts.items()
    )
    _html(f'<div style="display:flex;gap:10px;flex-wrap:wrap;margin:8px 0">{cards}</div>')

    # ── Scorecard ─────────────────────────────────────────────────────────────
    _divider(); _sec("📊 Feature Scorecard")
    if len(sc):
        score_col = "Overall (0-100)"
        fix = sc[sc["Status"]=="❌ Fix First"]
        rev = sc[sc["Status"]=="⚠️ Review"]
        good= sc[sc["Status"]=="✅ Good"]
        _html(f"""
<div style="display:flex;gap:12px;margin-bottom:12px;font-family:sans-serif">
  <div style="background:#fee2e2;border-radius:8px;padding:10px 20px;text-align:center">
    <div style="font-size:24px;font-weight:700;color:#991b1b">{len(fix)}</div>
    <div style="font-size:12px;color:#991b1b">❌ Fix First</div></div>
  <div style="background:#fef9c3;border-radius:8px;padding:10px 20px;text-align:center">
    <div style="font-size:24px;font-weight:700;color:#a16207">{len(rev)}</div>
    <div style="font-size:12px;color:#a16207">⚠️ Review</div></div>
  <div style="background:#dcfce7;border-radius:8px;padding:10px 20px;text-align:center">
    <div style="font-size:24px;font-weight:700;color:#166534">{len(good)}</div>
    <div style="font-size:12px;color:#166534">✅ Good</div></div>
</div>""")
        # Score bar chart
        sc_plot = sc.sort_values(score_col)
        colors = [RED if s=="❌ Fix First" else ORANGE if s=="⚠️ Review" else GREEN
                  for s in sc_plot["Status"]]
        fig = go.Figure(go.Bar(
            x=sc_plot[score_col], y=sc_plot["Feature"], orientation="h",
            marker_color=colors,
            text=sc_plot[score_col].apply(lambda v: f"{v:.0f}"),
            textposition="outside", textfont_size=9,
        ))
        fig.update_layout(
            height=max(300, len(sc_plot)*24), margin=dict(l=0,r=40,t=10,b=10),
            xaxis=dict(range=[0,115], title="Score (0–100)"),
            yaxis_title="", plot_bgcolor="white",
        )
        fig.add_vline(x=55, line_dash="dash", line_color=ORANGE, line_width=1)
        fig.add_vline(x=80, line_dash="dash", line_color=GREEN,  line_width=1)
        _fig(fig)

        # Full scorecard table
        show_cols = ["Feature","Type","Hit Rate","Valid Values","Skewness",
                     "Cat Consistency","Outlier Score", score_col,"Status"]
        show_cols = [c for c in show_cols if c in sc.columns]
        ipd.display(sc[show_cols].reset_index(drop=True))

    # ── Missing / Hit rate chart ──────────────────────────────────────────────
    _divider(); _sec("💧 Hit Rate per Feature")
    hr_rows = [{"Feature":col,"Hit Rate %":res["hit_rate_pct"],"Type":res["dtype"]}
               for col,res in cr.items()]
    df_hr = pd.DataFrame(hr_rows).sort_values("Hit Rate %")
    colors_hr = [GREEN if h>=95 else ORANGE if h>=75 else RED for h in df_hr["Hit Rate %"]]
    fig_hr = go.Figure(go.Bar(
        x=df_hr["Hit Rate %"], y=df_hr["Feature"], orientation="h",
        marker_color=colors_hr,
        text=df_hr["Hit Rate %"].apply(lambda v: f"{v:.1f}%"),
        textposition="inside", textfont_color="white", textfont_size=9,
    ))
    fig_hr.update_layout(
        height=max(300, len(df_hr)*22), margin=dict(l=0,r=10,t=10,b=10),
        xaxis=dict(range=[0,100], title="Hit Rate %"), yaxis_title="",
        plot_bgcolor="white",
    )
    _fig(fig_hr)

    # ── Numeric distributions ─────────────────────────────────────────────────
    num_cols = [c for c,r in cr.items() if r["dtype"]=="Numeric" and r.get("plot_sample")]
    if num_cols:
        _divider(); _sec("🔢 Numeric Distributions")
        ncols = 3
        for i in range(0, len(num_cols), ncols):
            batch = num_cols[i:i+ncols]
            fig_d = go.Figure()
            from plotly.subplots import make_subplots
            fig_d = make_subplots(rows=1, cols=len(batch),
                                  subplot_titles=batch)
            for j, col in enumerate(batch, 1):
                res = cr[col]
                samp = res["plot_sample"]
                fig_d.add_trace(go.Histogram(
                    x=samp, name=col, nbinsx=40,
                    marker_color=ACCENT, opacity=0.75, showlegend=False,
                ), row=1, col=j)
                d = res.get("dist",{})
                if d.get("mean") is not None:
                    fig_d.add_vline(x=d["mean"], line_dash="dash",
                                    line_color=PURPLE, line_width=1.5, col=j, row=1)
            fig_d.update_layout(height=260, margin=dict(l=10,r=10,t=30,b=10),
                                plot_bgcolor="white")
            _fig(fig_d)

    # ── Categorical top values ────────────────────────────────────────────────
    cat_cols = [c for c,r in cr.items() if r["dtype"]=="Categorical"
                and len(r.get("category_table",pd.DataFrame()))>0]
    if cat_cols:
        _divider(); _sec("🏷️ Categorical Distributions (top 10 values)")
        for col in cat_cols[:12]:   # cap at 12 to avoid notebook overload
            tbl = cr[col]["category_table"].head(10)
            bar_colors = [RED if f=="RARE" else CYAN if f=="DOMINANT" else ACCENT
                          for f in tbl["Flag"]]
            fig_c = go.Figure(go.Bar(
                x=tbl["Category"].astype(str), y=tbl["Share %"],
                marker_color=bar_colors, text=tbl["Count"],
                textposition="outside", textfont_size=8,
            ))
            fig_c.update_layout(
                title=dict(text=col, font_size=12),
                height=220, margin=dict(l=10,r=10,t=30,b=60),
                yaxis_title="Share %", xaxis_title="",
                plot_bgcolor="white",
            )
            fig_c.update_xaxes(tickangle=30)
            _fig(fig_c)

    # ── Cramér's V ───────────────────────────────────────────────────────────
    cv = corr.get("cat_chi2", pd.DataFrame())
    if len(cv):
        _divider(); _sec("🔗 Categorical Associations — Cramér's V")
        top_cv = cv.head(20).copy()
        top_cv["pair"] = top_cv["Variable A"] + "  ×  " + top_cv["Variable B"]
        top_cv = top_cv.sort_values("Cramér's V", ascending=True)
        bar_c = [PURPLE if v>=0.3 else ACCENT if v>=0.1 else CYAN
                 for v in top_cv["Cramér's V"]]
        fig_cv = go.Figure(go.Bar(
            x=top_cv["Cramér's V"], y=top_cv["pair"], orientation="h",
            marker_color=bar_c,
            text=top_cv.apply(lambda r: "V={:.3f}  {}".format(
                r.get("Cramér's V",0), r.get("Strength","")), axis=1),
            textposition="outside", textfont_size=9,
        ))
        fig_cv.update_layout(
            height=max(300, len(top_cv)*26),
            margin=dict(l=0,r=120,t=10,b=10),
            xaxis=dict(range=[0, min(top_cv["Cramér's V"].max()*1.4,1.05)],
                       title="Cramér's V"),
            yaxis_title="", plot_bgcolor="white",
        )
        _fig(fig_cv)
        ipd.display(cv.reset_index(drop=True))

    # ── Pearson correlations ──────────────────────────────────────────────────
    pearson = corr.get("pearson", pd.DataFrame())
    if len(pearson):
        _divider(); _sec("📈 Pearson Correlation Heatmap (numeric features)")
        fig_p = px.imshow(
            pearson, color_continuous_scale="RdBu_r",
            zmin=-1, zmax=1, text_auto=".2f",
        )
        fig_p.update_layout(height=max(350, len(pearson)*45),
                            margin=dict(l=10,r=10,t=10,b=10))
        fig_p.update_traces(textfont_size=9)
        _fig(fig_p)

    # ── Target summary ────────────────────────────────────────────────────────
    ts = corr.get("target_summary", pd.DataFrame())
    if len(ts):
        _divider(); _sec(f"🎯 Feature Association with Target: {target}")
        ipd.display(ts.reset_index(drop=True))

    # ── Date columns ─────────────────────────────────────────────────────────
    date_cols = [c for c,r in cr.items() if r["dtype"]=="Date"]
    if date_cols:
        _divider(); _sec("📅 Date Column Distributions")
        for col in date_cols:
            res = cr[col]
            yc = res.get("year_counts",{})
            mc = res.get("month_counts",{})
            if yc or mc:
                from plotly.subplots import make_subplots
                fig_dt = make_subplots(rows=1, cols=2,
                                       subplot_titles=[f"{col} — by Year",
                                                       f"{col} — by Month"])
                if yc:
                    yr = sorted(yc.keys())
                    fig_dt.add_trace(go.Bar(x=yr, y=[yc[y] for y in yr],
                                            marker_color=ACCENT, showlegend=False),
                                     row=1, col=1)
                if mc:
                    MN = ["Jan","Feb","Mar","Apr","May","Jun",
                          "Jul","Aug","Sep","Oct","Nov","Dec"]
                    mo = sorted(mc.keys())
                    fig_dt.add_trace(go.Bar(x=[MN[m-1] for m in mo],
                                            y=[mc[m] for m in mo],
                                            marker_color=PURPLE, showlegend=False),
                                     row=1, col=2)
                fig_dt.update_layout(height=250, margin=dict(l=10,r=10,t=30,b=10),
                                     plot_bgcolor="white")
                _fig(fig_dt)

    # ── Recommendations ───────────────────────────────────────────────────────
    if recs:
        _divider(); _sec("💡 Recommendations")
        fix_recs = [r for r in recs if r["Priority"]=="❌ Fix First"]
        rev_recs  = [r for r in recs if r["Priority"]=="⚠️ Review"]
        for group, label, color in [
            (fix_recs,"❌ Fix First","#fee2e2"),
            (rev_recs, "⚠️ Review",  "#fef9c3"),
        ]:
            if not group: continue
            rows_html = "".join(
                f'<tr><td style="padding:4px 8px;font-weight:600">{r["Feature"]}</td>'
                f'<td style="padding:4px 8px;color:#555">{r["Type"]}</td>'
                f'<td style="padding:4px 8px">'
                + " &nbsp;|&nbsp; ".join(f'<b>{f}</b> → {a}' for f,a in r["Items"])
                + '</td></tr>'
                for r in group
            )
            _html(f"""
<div style="margin:8px 0">
  <div style="font-weight:600;font-size:13px;margin-bottom:6px">{label}</div>
  <table style="border-collapse:collapse;font-family:sans-serif;font-size:12px;
                background:{color};border-radius:6px;width:100%">
  <thead><tr>
    <th style="padding:6px 8px;text-align:left">Feature</th>
    <th style="padding:6px 8px;text-align:left">Type</th>
    <th style="padding:6px 8px;text-align:left">Finding → Action</th>
  </tr></thead>
  <tbody>{rows_html}</tbody></table></div>""")

    _html('<div style="font-family:sans-serif;font-size:11px;color:#94a3b8;'
          'margin-top:24px">EDA Toolkit — rendered natively in Databricks notebook</div>')
    print("\n[EDA] Native render complete.")


# ─────────────────────────────────────────────────────────────────────────────
# ngrok path (kept for users who have access)
# ─────────────────────────────────────────────────────────────────────────────

def _launch_ngrok(shim, port=8501, ngrok_token=None):
    """Start Streamlit and expose via ngrok tunnel."""
    for pkg in ["streamlit","pyngrok","plotly"]:
        try: __import__(pkg.replace("-","_"))
        except ImportError:
            subprocess.run([sys.executable,"-m","pip","install",pkg,"-q"],
                           capture_output=True)

    _start_streamlit_bg(shim, port)

    try: from pyngrok import ngrok
    except ImportError:
        subprocess.run([sys.executable,"-m","pip","install","pyngrok","-q"],
                       capture_output=True)
        from pyngrok import ngrok

    if ngrok_token: ngrok.set_auth_token(ngrok_token)
    for t in ngrok.get_tunnels(): ngrok.disconnect(t.public_url)
    tunnel = ngrok.connect(port, "http")
    url = tunnel.public_url
    print(f"\n{'─'*60}\n  🚀 EDA Toolkit running\n  👉 {url}\n{'─'*60}\n")
    try:
        while True: time.sleep(30)
    except KeyboardInterrupt:
        ngrok.kill()
        print("\n[EDA] Stopped.")


def _start_streamlit_bg(shim, port):
    """Start Streamlit in background, wait until healthy."""
    config_dir = Path.home() / ".streamlit"
    config_dir.mkdir(exist_ok=True)
    (config_dir / "config.toml").write_text(f"""\
[server]
port = {port}
headless = true
enableCORS = false
enableXsrfProtection = false

[theme]
base = "light"
""")
    cmd = [sys.executable, "-m", "streamlit", "run", str(shim),
           f"--server.port={port}", "--server.headless=true"]
    proc_box = [None]
    def _run():
        proc_box[0] = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=str(_DIR))
        for _ in proc_box[0].stdout: pass
    threading.Thread(target=_run, daemon=True).start()
    import urllib.request
    print("[EDA] Starting Streamlit...", end="", flush=True)
    for _ in range(20):
        time.sleep(1); print(".", end="", flush=True)
        try:
            urllib.request.urlopen(f"http://localhost:{port}/_stcore/health", timeout=1)
            break
        except Exception: continue
    print(" ready!")
    return proc_box


# ─────────────────────────────────────────────────────────────────────────────
# print_summary()
# ─────────────────────────────────────────────────────────────────────────────

def print_summary(results):
    print(f"\n{'═'*55}")
    print(f"  EDA SUMMARY — {results['n_rows']:,} rows × {results['n_features']} features")
    print(f"  Runtime: {results['elapsed_sec']:.1f}s")
    print(f"{'═'*55}")
    print("\n  FEATURE TYPES:")
    for dtype, cnt in pd.Series(results["dtype_map"]).value_counts().items():
        print(f"    {_ICON.get(dtype,'❓')} {dtype:<15}: {cnt}")
    sc = results.get("scorecard", pd.DataFrame())
    if len(sc):
        print(f"\n  SCORECARD:")
        print(f"    🔴 Fix First : {(sc['Status']=='❌ Fix First').sum()}")
        print(f"    🟡 Review    : {(sc['Status']=='⚠️ Review').sum()}")
        print(f"    🟢 Good      : {(sc['Status']=='✅ Good').sum()}")
        fix = sc[sc['Status']=='❌ Fix First']['Feature'].tolist()
        if fix: print(f"\n  FIX FIRST: {', '.join(fix)}")
    recs = results.get("recommendations",[])
    critical = [r for r in recs if "Fix" in r["Priority"]]
    if critical:
        print(f"\n  TOP ACTIONS:")
        for r in critical[:5]:
            for finding, action in r["Items"][:1]:
                print(f"    • {r['Feature']}: {action}")
    print(f"\n{'═'*55}\n")
