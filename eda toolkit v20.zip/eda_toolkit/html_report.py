# -*- coding: utf-8 -*-
"""
html_report.py — Insurance EDA Toolkit v5
Self-contained interactive HTML dashboard. No server. No Streamlit.

Fixes in this version:
  - Charts are fully interactive (zoom, pan, hover, fullscreen)
  - Proper responsive sizing — no stretching
  - Loading spinners per chart
  - CSV download on every table
  - Cramér's V chart renders correctly
  - Standardised colour coding across all tables
  - Fullscreen button on Pearson heatmap
  - Missing bar height auto-scales to number of features
"""
from __future__ import annotations
import json, math, webbrowser, base64, io
from pathlib import Path
import numpy as np
import pandas as pd

# ── palette ───────────────────────────────────────────────────────────────────
C = dict(
    accent="#6366f1", cyan="#06b6d4", red="#ef4444",
    orange="#f59e0b", green="#22c55e", purple="#7c3aed",
    grid="#e8ecf0", bg="rgba(0,0,0,0)",
)
PLOTLY_CDN = "https://cdn.plot.ly/plotly-2.35.0.min.js"

# ── JSON encoder ──────────────────────────────────────────────────────────────
class _Enc(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, np.integer):   return int(o)
        if isinstance(o, np.floating):  return float(o)
        if isinstance(o, np.ndarray):   return o.tolist()
        if isinstance(o, pd.Timestamp): return str(o)
        try:
            if pd.isna(o): return None
        except Exception:
            pass
        return super().default(o)

def _j(v):   return json.dumps(v, cls=_Enc, separators=(",", ":"))
def _sf(v, d=0.0):
    try:    return float(v)
    except: return d
def _esc(s):
    return (str(s).replace("&","&amp;").replace("<","&lt;")
            .replace(">","&gt;").replace('"','&quot;').replace("'","&#39;"))
def _fmtn(v):
    try:
        f = float(v)
        if abs(f) >= 1e6: return f"{f/1e6:.3f}M"
        if abs(f) >= 1e3: return f"{f:,.2f}"
        return f"{f:.4g}"
    except:
        return str(v)

# ── figure → JSON ─────────────────────────────────────────────────────────────
def _fig(fig, h=320, modebar=True):
    """Serialise a Plotly figure.  h is the initial height in px."""
    try:
        fig.update_layout(
            height=h,
            margin=dict(l=40, r=20, t=40, b=44),
            paper_bgcolor=C["bg"],
            plot_bgcolor=C["bg"],
            font=dict(family="Inter,system-ui,sans-serif", size=11, color="#374151"),
            legend=dict(bgcolor=C["bg"], font_size=10),
            modebar=dict(bgcolor="rgba(0,0,0,0)", color="#6b7280",
                         activecolor=C["accent"]),
        )
        fig.update_xaxes(gridcolor=C["grid"], linecolor=C["grid"],
                         zerolinecolor=C["grid"], zerolinewidth=1)
        fig.update_yaxes(gridcolor=C["grid"], linecolor=C["grid"],
                         zerolinecolor=C["grid"])
        return fig.to_json()
    except Exception:
        return "{}"

# ── colour-coding helpers (standardised) ─────────────────────────────────────
def _col_missing(pct):
    """Standard cell style for a missing % value."""
    v = _sf(pct)
    if v >= 50:  return "background:#fee2e2;color:#991b1b;font-weight:700"
    if v >= 20:  return "background:#fee2e2;color:#991b1b"
    if v >= 10:  return "background:#fef9c3;color:#a16207"
    if v > 0:    return "background:#fffbeb;color:#78350f"
    return "background:#dcfce7;color:#166534"

def _col_hitrate(pct):
    """Standard cell style for a hit-rate % value."""
    v = _sf(pct)
    if v >= 95:  return "background:#dcfce7;color:#166534;font-weight:600"
    if v >= 75:  return "background:#fef9c3;color:#a16207"
    return "background:#fee2e2;color:#991b1b;font-weight:600"

def _col_iqr(pct):
    v = _sf(pct)
    if v >= 10:  return "background:#fee2e2;color:#991b1b;font-weight:700"
    if v >= 5:   return "background:#fef9c3;color:#a16207;font-weight:600"
    if v >= 1:   return "background:#dcfce7;color:#166534"
    return "background:#f0fdf4;color:#166534"

def _col_cramersv(v):
    x = _sf(v)
    if x >= 0.3: return "background:#ede9fe;color:#5b21b6;font-weight:700"
    if x >= 0.1: return "background:#dbeafe;color:#1e3a5f;font-weight:600"
    return ""

def _col_pearsonr(v):
    x = abs(_sf(v))
    if x >= 0.7: return "background:#ede9fe;color:#5b21b6;font-weight:700"
    if x >= 0.4: return "background:#dbeafe;color:#1e3a5f;font-weight:600"
    if x >= 0.1: return "background:#dcfce7;color:#166534"
    return ""

def _col_score(v):
    x = _sf(v)
    if x >= 80:  return "background:#dcfce7;color:#166534;font-weight:600"
    if x >= 55:  return "background:#fef9c3;color:#a16207;font-weight:600"
    return "background:#fee2e2;color:#991b1b;font-weight:700"

def _col_status(v):
    s = str(v)
    if "Fix"    in s: return "color:#b91c1c;font-weight:700"
    if "Review" in s: return "color:#b45309;font-weight:700"
    if "Good"   in s: return "color:#166534;font-weight:600"
    return ""

def _col_matchpct(v, bold=False):
    x = _sf(v); b = "font-weight:700;" if bold else ""
    if x >= 100: return f"background:#dcfce7;color:#166534;{b}"
    if x >= 95:  return f"background:#bbf7d0;color:#14532d;{b}"
    if x >= 85:  return f"background:#fef9c3;color:#a16207;{b}"
    if x >= 70:  return f"background:#fed7aa;color:#9a3412;{b}"
    return f"background:#fee2e2;color:#991b1b;{b}"

def _col_diffpct(v, bold=False):
    x = abs(_sf(v)); b = "font-weight:700;" if bold else ""
    if x == 0:  return f"background:#dcfce7;color:#166534;{b}"
    if x < 5:   return f"background:#bbf7d0;color:#14532d;{b}"
    if x < 15:  return f"background:#fef9c3;color:#a16207;{b}"
    if x < 30:  return f"background:#fed7aa;color:#9a3412;{b}"
    return f"background:#fee2e2;color:#991b1b;{b}"

def _col_vif(v):
    x = _sf(v)
    if x > 10: return "background:#fee2e2;color:#991b1b;font-weight:700"
    if x > 5:  return "background:#fef9c3;color:#a16207"
    return "background:#dcfce7;color:#166534"

# ── HTML primitives ───────────────────────────────────────────────────────────
def metric(label, value, sub=""):
    s = f'<div class="ms">{_esc(str(sub))}</div>' if sub else ""
    return (f'<div class="mc">'
            f'<div class="mv">{_esc(str(value))}</div>'
            f'<div class="ml">{_esc(label)}</div>{s}</div>')

def alert(msg, kind="yellow"):
    m = {"red":("#fef2f2","#b91c1c","#ef4444"),
         "yellow":("#fffbeb","#78350f","#f59e0b"),
         "blue":("#eff6ff","#1e3a5f","#3b82f6"),
         "green":("#f0fdf4","#14532d","#22c55e"),
         "purple":("#f5f3ff","#3b0764","#7c3aed")}
    bg, fg, bd = m.get(kind, m["yellow"])
    return (f'<div class="al" style="background:{bg};color:{fg};'
            f'border-left:3px solid {bd}">{msg}</div>')

def badge(text, bg="#ede9fe", fg="#5b21b6"):
    return (f'<span class="bdg" style="background:{bg};color:{fg}">'
            f'{_esc(text)}</span>')

def sec(t):
    return f'<h3 class="sh">{_esc(t)}</h3>'

def divider():
    return '<hr class="dv">'

def chart(fig_json, cid, h=320, fullscreen=False):
    """
    Emit a chart container using a JS global registry for figure data.
    Avoids HTML-attribute quoting issues with apostrophes in Plotly JSON
    (e.g. "Cramér\'s V" contains a single quote that breaks data-fig='...').
    """
    fs_btn = (f'<button class="fs-btn" onclick="fsChart(\'{cid}\')" '
              f'title="Fullscreen">⛶</button>') if fullscreen else ""
    # Store fig JSON in a JS registry keyed by chart id — no HTML attribute quoting issues
    safe_json = fig_json.replace("\\", "\\\\").replace("`", "\\`")
    js_reg = (f'<script>window._FIGS=window._FIGS||{{}};'
              f'window._FIGS["{cid}"]=JSON.parse(`{safe_json}`);</script>')
    return (js_reg +
            f'<div class="chart-wrap" id="wrap_{cid}">'
            f'  <div class="chart-loader"><div class="spinner"></div>'
            f'  <span>Rendering…</span></div>'
            f'  {fs_btn}'
            f'  <div id="{cid}" class="pc" data-h="{h}" data-reg="1"></div>'
            f'</div>')

def collapsible(title, body, open_=False):
    a = " open" if open_ else ""
    return (f'<details class="col"{a}>'
            f'<summary>{_esc(title)}</summary>'
            f'<div class="col-body">{body}</div></details>')

def csv_btn(df, label="Download CSV", filename="data.csv"):
    """Inline CSV download button — no server needed."""
    if df is None or not len(df):
        return ""
    try:
        csv = df.to_csv(index=False)
        b64 = base64.b64encode(csv.encode()).decode()
        return (f'<a class="dl-btn" download="{_esc(filename)}" '
                f'href="data:text/csv;base64,{b64}">⬇ {_esc(label)}</a>')
    except Exception:
        return ""

def table(df, style_fn=None, tid="", cls="", dl_label="", dl_file="data.csv"):
    """Render DataFrame as styled HTML table with optional download."""
    if df is None or not len(df):
        return '<p class="empty">No data.</p>'
    id_attr = f' id="{tid}"' if tid else ""
    heads = "".join(f'<th>{_esc(c)}</th>' for c in df.columns)
    rows = []
    for _, row in df.iterrows():
        cells = []
        for c in df.columns:
            v = row[c]
            st = style_fn(c, v, row) if style_fn else ""
            try:
                d = "—" if isinstance(v, float) and math.isnan(v) else _esc(str(v))
            except Exception:
                d = _esc(str(v))
            cells.append(f'<td style="{st}">{d}</td>')
        rows.append(f'<tr>{"".join(cells)}</tr>')
    tc = f'dt{(" " + cls) if cls else ""}'
    dl = csv_btn(df, dl_label, dl_file) if dl_label else ""
    return (f'<div class="tw">'
            f'<table{id_attr} class="{tc}">'
            f'<thead><tr>{heads}</tr></thead>'
            f'<tbody>{"".join(rows)}</tbody>'
            f'</table></div>'
            + (f'<div class="tbl-actions">{dl}</div>' if dl else ""))

def tbl_controls(tid, dl_df=None, dl_label="Download CSV", dl_file="data.csv"):
    """Search input + optional download button row for a table."""
    dl = csv_btn(dl_df, dl_label, dl_file) if dl_df is not None and len(dl_df) else ""
    return (f'<div class="tbl-ctrl">'
            f'<input class="srch" data-tgt="{tid}" placeholder="🔍 Search…">'
            f'{dl}</div>')

# ── section builders ──────────────────────────────────────────────────────────

def _overview(R):
    import plotly.graph_objects as go
    import plotly.express as px

    cr = R.get("col_results", {}); dm = R.get("dtype_map", {})
    n_rows = R.get("n_rows", 0); n_feat = R.get("n_features", 0)
    target = R.get("target_col")
    n_num = sum(1 for t in dm.values() if t in ("Numeric","Boolean"))
    n_cat = sum(1 for t in dm.values() if t == "Categorical")
    n_date= sum(1 for t in dm.values() if t == "Date")
    t_cells = n_rows * n_feat
    t_miss  = sum(v["missing_count"] for v in cr.values())
    miss_pct = round(t_miss / t_cells * 100, 2) if t_cells else 0

    out = '<div class="mr">'
    out += metric("Total Rows",      f"{n_rows:,}")
    out += metric("Features",        n_feat)
    out += metric("Numeric / Bool",  n_num)
    out += metric("Categorical",     n_cat)
    out += metric("Date",            n_date)
    out += metric("Overall Missing", f"{miss_pct:.1f}%")
    out += '</div>'
    if target:
        out += f'<p class="cap">🎯 Target column: <strong>{_esc(target)}</strong></p>'
    out += divider()

    # ── Donut + Missing bar ───────────────────────────────────────────────────
    tc = pd.Series(dm).value_counts().reset_index()
    tc.columns = ["Type", "Count"]
    cm = {"Numeric":C["accent"],"Categorical":C["cyan"],"Boolean":C["orange"],
          "Date":"#10b981","ID-like":"#94a3b8","Constant":C["red"],"Unknown":"#e5e7ef"}
    colors = [cm.get(t, "#94a3b8") for t in tc["Type"]]
    fd = go.Figure(go.Pie(labels=tc["Type"], values=tc["Count"], hole=0.55,
        marker=dict(colors=colors), textposition="inside",
        textinfo="percent+label", textfont_size=10))
    fd.update_layout(showlegend=True,
                     legend=dict(orientation="v", x=1.02, y=0.5))

    miss_data = [(c, r["missing_pct"]) for c, r in cr.items() if r["missing_pct"] > 0]
    out += '<div class="two-col">'
    out += f'<div>{sec("Column Type Distribution")}{chart(_fig(fd, 280), "c-donut", 280)}</div>'

    if miss_data:
        mdf = pd.DataFrame(miss_data, columns=["Feature", "Missing %"]).sort_values("Missing %")
        # cap at 500px — for large datasets show top 20 worst only, user can scroll table
        TOP_N = 30
        if len(mdf) > TOP_N:
            mdf_plot = mdf.tail(TOP_N).copy()
            cap_note = f" (top {TOP_N} shown — see table below for all)"
        else:
            mdf_plot = mdf.copy()
            cap_note = ""
        h_miss = max(240, min(len(mdf_plot) * 22 + 60, 500))
        bc = [C["red"] if v >= 20 else C["orange"] if v >= 10 else C["accent"]
              for v in mdf_plot["Missing %"]]
        fm = go.Figure(go.Bar(
            x=mdf_plot["Missing %"], y=mdf_plot["Feature"], orientation="h",
            marker_color=bc,
            text=mdf_plot["Missing %"].apply(lambda v: f"{v:.1f}%"),
            textposition="outside", textfont_size=9,
        ))
        fm.update_layout(
            xaxis=dict(range=[0, 115], title="Missing %",
                       tickvals=[0, 25, 50, 75, 100]),
            yaxis_title="",
            margin=dict(l=140, r=60, t=36, b=40),
        )
        out += (f'<div>{sec("Missing Value Overview")}'
                f'<p class="cap">Features with missing data{cap_note}</p>'
                f'{chart(_fig(fm, h_miss), "c-miss", h_miss)}</div>')
    else:
        out += (f'<div>{sec("Missing Value Overview")}'
                f'{alert("✅ No missing values in any column.", "green")}</div>')
    out += '</div>' + divider()

    # ── Feature table ─────────────────────────────────────────────────────────
    out += sec("All Features at a Glance")
    rows = []
    for col, res in cr.items():
        dtype = res["dtype"]; dist = res.get("dist", {})
        sk = res.get("skewness"); inf_p = res.get("inf_pct", 0.0)
        mt = (f"{dist['mean']:.4g}" if dist and dtype == "Numeric"
              else (str(res.get("category_table", pd.DataFrame()).iloc[0]["Category"])[:20]
                    if dtype == "Categorical" and len(res.get("category_table", pd.DataFrame()))
                    else res.get("constant_value", "—") if dtype == "Constant" else "—"))
        rows.append({"Feature": col, "Type": dtype,
                     "Missing %": res["missing_pct"],
                     "Hit Rate %": res["hit_rate_pct"],
                     "Unique": res["n_unique"],
                     "Mean / Top": mt,
                     "Skewness": round(sk, 3) if sk is not None else "—",
                     "Zero %": res.get("zero_pct", 0),
                     "Inf %": round(inf_p, 2)})
    feat_df = pd.DataFrame(rows)

    def _fts(c, v, row):
        if c == "Missing %":  return _col_missing(v)
        if c == "Hit Rate %": return _col_hitrate(v)
        if c == "Type":
            dc = {"Numeric":C["accent"],"Categorical":C["cyan"],"Boolean":C["orange"],
                  "Date":"#10b981","ID-like":"#94a3b8","Constant":C["red"]}
            co = dc.get(str(v), "#94a3b8")
            return f"color:{co};font-weight:600"
        if c == "Skewness":
            x = abs(_sf(v))
            if x > 2: return "color:#b91c1c;font-weight:600"
            if x > 1: return "color:#b45309"
        if c == "Inf %":
            if _sf(v) > 0: return "color:#b91c1c;font-weight:600"
        return ""

    out += table(feat_df, _fts, "feat-tbl", "sortable",
                 dl_label="Download Feature Table", dl_file="feature_overview.csv")
    out += tbl_controls("feat-tbl")
    return out


def _variable_explorer(R):
    import plotly.graph_objects as go

    cr = R.get("col_results", {})
    if not cr:
        return alert("No features analysed.", "yellow")

    opts = "".join(f'<option value="vp{i}">{_esc(c)}</option>'
                   for i, c in enumerate(cr.keys()))
    panels = []

    for i, (col, res) in enumerate(cr.items()):
        dtype = res["dtype"]; dist = res.get("dist", {})
        inf_p = res.get("inf_pct", 0.0)
        sample = res.get("plot_sample", [])

        p = f'<div id="vp{i}" class="vp" style="display:none">'
        p += (f'<div class="vp-head">'
              f'<span class="vp-name">{_esc(col)}</span>'
              f'<span class="vp-dtype">{_esc(dtype)}</span></div>')

        # ── Numeric / Boolean ─────────────────────────────────────────────────
        if dtype in ("Numeric", "Boolean") and dist:
            p += '<div class="mr">'
            for lbl, k in [("Mean","mean"),("Median","median"),("Std","std"),
                           ("Min","min"),("Max","max"),("Skewness","skewness")]:
                val = dist.get(k)
                p += metric(lbl, f"{val:.4g}" if val is not None else "—")
            p += metric("Missing %", f"{res['missing_pct']:.1f}%")
            p += metric("Zero %",    f"{res.get('zero_pct',0):.1f}%")
            p += '</div>'

            sk = dist.get("skewness", 0) or 0
            if inf_p > 0:     p += alert(f"🔴 {inf_p:.2f}% Inf values excluded from stats", "red")
            if abs(sk) > 2:   p += alert(f"⚠️ Very high skewness ({sk:.2f}) — consider log1p", "red")
            elif abs(sk) > 1: p += alert(f"⚠️ High skewness ({sk:.2f})", "yellow")
            if res["missing_pct"] > 20: p += alert(f"⚠️ Sparse — {res['missing_pct']:.1f}% missing", "red")
            elif res["missing_pct"] > 5: p += alert(f"ℹ️ {res['missing_pct']:.1f}% missing", "yellow")
            if res.get("zero_inflated"): p += alert("ℹ️ Zero-inflated (>30% zeros) — consider two-part model", "blue")
            if dist:
                p += (f'<p class="cap">Shape: <strong>{_esc(dist.get("shape","—"))}</strong>'
                      f' · P25={dist.get("p25","—")} · P75={dist.get("p75","—")}'
                      f' · P95={dist.get("p95","—")} · P99={dist.get("p99","—")}</p>')

            if sample:
                arr = [x for x in sample
                       if x is not None and not (isinstance(x, float) and math.isnan(x))]
                # linear histogram
                fl = go.Figure()
                fl.add_trace(go.Histogram(x=arr, nbinsx=60, name="Distribution",
                    marker_color=C["accent"], opacity=0.85,
                    marker_line=dict(width=0.3, color="#fff")))
                if dist:
                    fl.add_vline(x=dist["mean"], line_dash="dash", line_color=C["orange"],
                                 annotation_text="Mean", annotation_font_size=10)
                    fl.add_vline(x=dist["median"], line_dash="dot", line_color=C["green"],
                                 annotation_text="Median", annotation_font_size=10)
                fl.update_layout(title=dict(text=f"Distribution — {col}", font_size=13),
                                 xaxis_title=col, yaxis_title="Count", bargap=0.02)
                # log histogram
                flog = go.Figure()
                flog.add_trace(go.Histogram(x=arr, nbinsx=60,
                    marker_color=C["accent"], opacity=0.85,
                    marker_line=dict(width=0.3, color="#fff")))
                if dist:
                    flog.add_vline(x=dist["mean"], line_dash="dash", line_color=C["orange"])
                    flog.add_vline(x=dist["median"], line_dash="dot", line_color=C["green"])
                flog.update_layout(yaxis_type="log",
                    title=dict(text=f"Distribution (Log Y) — {col}", font_size=13),
                    xaxis_title=col, yaxis_title="Count (log)", bargap=0.02)

                p += (f'<div class="stog">'
                      f'<button class="stob on" onclick="togScale(this,\'vlin{i}\',\'vlog{i}\')">Linear</button>'
                      f'<button class="stob" onclick="togScale(this,\'vlog{i}\',\'vlin{i}\')">Log Y</button>'
                      f'</div>')
                p += f'<div id="vlin{i}">{chart(_fig(fl), f"vc_lin{i}")}</div>'
                p += f'<div id="vlog{i}" style="display:none">{chart(_fig(flog), f"vc_log{i}")}</div>'

        # ── Categorical ───────────────────────────────────────────────────────
        elif dtype == "Categorical":
            nu = res["n_unique"]; rare = res.get("rare_count", 0)
            p += '<div class="mr">'
            p += metric("Unique",     nu)
            p += metric("Rare (<1%)", rare)
            p += metric("Missing %",  f"{res['missing_pct']:.1f}%")
            p += metric("Top Val %",  f"{res.get('top_val_pct',0):.1f}%")
            p += '</div>'
            if nu > 100: p += alert(f"⚠️ High cardinality — {nu} unique values", "yellow")
            if rare > 5: p += alert(f"⚠️ {rare} rare categories (< 1% share)", "yellow")
            if res["missing_pct"] > 10: p += alert(f"⚠️ {res['missing_pct']:.1f}% missing", "red")

            tbl_ = res.get("category_table", pd.DataFrame())
            if len(tbl_):
                t25 = tbl_.head(25)
                bc = [C["red"] if f == "RARE" else C["cyan"] if f == "DOMINANT" else C["accent"]
                      for f in t25["Flag"]]
                h_cat = max(220, min(len(t25) * 28 + 60, 500))
                # linear
                fl = go.Figure(go.Bar(
                    x=t25["Category"].astype(str), y=t25["Share %"],
                    marker_color=bc,
                    text=t25["Count"], textposition="outside", textfont_size=9,
                ))
                fl.update_layout(title=dict(text=f"Top Categories — {col}", font_size=13),
                                  yaxis_title="Share %", bargap=0.15)
                fl.update_xaxes(tickangle=35)
                # log
                flog = go.Figure(go.Bar(
                    x=t25["Category"].astype(str), y=t25["Share %"],
                    marker_color=bc,
                    text=t25["Count"], textposition="outside", textfont_size=9,
                ))
                flog.update_layout(yaxis_type="log",
                    title=dict(text=f"Top Categories (Log Y) — {col}", font_size=13),
                    yaxis_title="Share % (log)", bargap=0.15)
                flog.update_xaxes(tickangle=35)

                p += (f'<div class="stog">'
                      f'<button class="stob on" onclick="togScale(this,\'clin{i}\',\'clog{i}\')">Linear</button>'
                      f'<button class="stob" onclick="togScale(this,\'clog{i}\',\'clin{i}\')">Log Y</button>'
                      f'</div>')
                p += f'<div id="clin{i}">{chart(_fig(fl, h_cat), f"cc_lin{i}", h_cat)}</div>'
                p += f'<div id="clog{i}" style="display:none">{chart(_fig(flog, h_cat), f"cc_log{i}", h_cat)}</div>'
                p += collapsible("Full category table",
                                  table(tbl_,
                                        lambda c,v,row: ("background:#fee2e2;color:#991b1b" if str(row.get("Flag",""))=="RARE"
                                                         else "background:#cffafe;color:#0e7490" if str(row.get("Flag",""))=="DOMINANT"
                                                         else "") if c=="Flag" else "",
                                        tid=f"ctbl{i}") +
                                  csv_btn(tbl_, "Download CSV", f"cat_{col}.csv"))

        # ── ID-like ───────────────────────────────────────────────────────────
        elif dtype == "ID-like":
            p += '<div class="mr">'
            p += metric("Unique Values", f"{res['n_unique']:,}")
            p += metric("Missing %",     f"{res['missing_pct']:.1f}%")
            p += metric("Hit Rate %",    f"{res['hit_rate_pct']:.1f}%")
            p += '</div>'
            p += alert("🔑 Identifier column — excluded from all analysis.", "blue")
            samps = res.get("sample_values", [])
            if samps:
                p += f'<p class="cap"><strong>Sample values:</strong> {", ".join(_esc(str(s)) for s in samps)}</p>'

        # ── Date ─────────────────────────────────────────────────────────────
        elif dtype == "Date":
            p += '<div class="mr">'
            p += metric("Min Date",  res.get("date_min", "—"))
            p += metric("Max Date",  res.get("date_max", "—"))
            p += metric("Unique",    f"{res['n_unique']:,}")
            p += metric("Missing %", f"{res['missing_pct']:.1f}%")
            p += '</div>'
            yc = res.get("year_counts", {})
            mc = res.get("month_counts", {})
            if yc:
                yr = sorted(yc.keys())
                # auto-width: each bar ~40px, min 320, max fills container
                h_yr = max(280, min(len(yr) * 44 + 80, 420))
                fy = go.Figure(go.Bar(
                    x=yr, y=[yc[y] for y in yr],
                    marker_color=C["accent"],
                    text=[f"{yc[y]:,}" for y in yr],
                    textposition="outside", textfont_size=9,
                ))
                fy.update_layout(
                    title=dict(text=f"{col} — Records by Year", font_size=13),
                    xaxis=dict(title="Year", type="category",
                               tickangle=0, dtick=1),
                    yaxis_title="Records",
                    bargap=0.25,
                )
                p += f'{chart(_fig(fy, h_yr), f"cy{i}", h_yr)}'
            if mc:
                MN = ["Jan","Feb","Mar","Apr","May","Jun",
                      "Jul","Aug","Sep","Oct","Nov","Dec"]
                mo = sorted(mc.keys())
                # always show all 12 months (fill missing with 0)
                mo_labels = [MN[m-1] for m in mo]
                mo_vals   = [mc[m] for m in mo]
                h_mo = 280
                fm_ = go.Figure(go.Bar(
                    x=mo_labels, y=mo_vals,
                    marker_color=C["purple"],
                    text=[f"{v:,}" for v in mo_vals],
                    textposition="outside", textfont_size=9,
                ))
                fm_.update_layout(
                    title=dict(text=f"{col} — Records by Month", font_size=13),
                    xaxis=dict(title="Month", type="category", tickangle=0),
                    yaxis_title="Records",
                    bargap=0.25,
                )
                p += f'{chart(_fig(fm_, h_mo), f"cm{i}", h_mo)}'

        # ── Constant ─────────────────────────────────────────────────────────
        elif dtype == "Constant":
            p += alert(f"🔒 Constant column — value: <strong>{_esc(str(res.get('constant_value','?')))}</strong>. Zero variance. Drop before modelling.", "red")

        else:
            p += metric("Missing %", f"{res['missing_pct']:.1f}%")
            p += alert(f"Type: {_esc(dtype)}", "blue")

        p += '</div>'
        panels.append(p)

    return (f'<div class="vex-bar">'
            f'<label class="vex-label">Select Variable</label>'
            f'<select class="vsel" onchange="showVP(this.value)">{opts}</select>'
            f'</div>'
            f'<div id="vex-panels">{"".join(panels)}</div>'
            f'<script>(function(){{'
            f'  function showVP(id){{'
            f'    document.querySelectorAll("#vex-panels .vp").forEach(function(e){{e.style.display="none";}});'
            f'    var el=document.getElementById(id);'
            f'    if(el){{el.style.display="block";renderCharts(el);setTimeout(function(){{renderCharts(el);}},150);}}'
            f'  }}'
            f'  window.showVP=showVP;'
            f'  var first=document.querySelector("#vex-panels .vp");'
            f'  if(first){{first.style.display="block";window.addEventListener("load",function(){{renderCharts(first);setTimeout(function(){{renderCharts(first);}},200);}});}}'
            f'}})();</script>')


def _hit_rate(R):
    import plotly.graph_objects as go

    cr = R.get("col_results", {}); target = R.get("target_col")
    if not cr:
        return alert("No data.", "yellow")

    rows = [{"Feature": c, "Hit Rate %": r["hit_rate_pct"],
             "Missing %": r["missing_pct"], "Type": r["dtype"]}
            for c, r in cr.items()]
    df_hr = pd.DataFrame(rows).sort_values("Hit Rate %", ascending=True)

    h_bar = max(300, min(len(df_hr) * 28 + 60, 700))
    bc = [C["green"] if h >= 95 else C["orange"] if h >= 75 else C["red"]
          for h in df_hr["Hit Rate %"]]
    fh = go.Figure(go.Bar(
        x=df_hr["Hit Rate %"], y=df_hr["Feature"], orientation="h",
        marker_color=bc,
        text=df_hr["Hit Rate %"].apply(lambda v: f"{v:.1f}%"),
        textposition="inside", textfont_size=9, textfont_color="white",
    ))
    fh.update_layout(
        title=dict(text="Hit Rate per Feature (% non-null)", font_size=13),
        xaxis=dict(range=[0, 110], title="Hit Rate %"),
        yaxis_title="",
    )

    out = chart(_fig(fh, h_bar), "hr-chart", h_bar)
    out += ('<div class="pills">'
            + badge("● ≥95% Good",        "#dcfce7", "#166534")
            + badge("● 75–94% Review",    "#fef9c3", "#a16207")
            + badge("● <75% Problem",     "#fee2e2", "#991b1b")
            + '</div>' + divider() + sec("Hit Rate Table"))

    def _hs(c, v, row):
        if c == "Hit Rate %": return _col_hitrate(v)
        if c == "Missing %":  return _col_missing(v)
        return ""

    out += table(df_hr.reset_index(drop=True), _hs, "hr-tbl", "sortable",
                 dl_label="Download Hit Rate CSV", dl_file="hit_rate.csv")
    out += tbl_controls("hr-tbl")
    return out


def _category_quality(R):
    cr    = R.get("col_results", {})
    fuzzy = R.get("fuzzy_categories", {})
    cat_cols = [c for c, r in cr.items() if r["dtype"] == "Categorical"]
    if not cat_cols:
        return alert("No categorical columns.", "yellow")

    with_m   = {c: v for c, v in fuzzy.items() if isinstance(v, list) and len(v) > 0}
    skipped  = [c for c, v in fuzzy.items() if isinstance(v, list) and len(v) == 0]

    out = '<div class="mr">'
    out += metric("Cols with similar cats", len(with_m))
    out += metric("Total similar pairs",    sum(len(v) for v in with_m.values()))
    out += metric("Skipped (high-card)",    len(skipped))
    out += '</div>' + divider() + sec("Similar / Duplicate Category Pairs")

    if not with_m:
        out += alert("✅ No similar or duplicate categories detected.", "green")
    else:
        for col, matches in with_m.items():
            nu = cr[col].get("n_unique", 0); rare = cr[col].get("rare_count", 0)
            mdf = pd.DataFrame(matches)

            def _ss(c, v, row):
                if c == "Similarity":
                    x = _sf(v)
                    if x == 1.0:  return "background:#fee2e2;color:#991b1b;font-weight:700"
                    if x >= 0.95: return "background:#fef9c3;color:#a16207"
                return ""

            inner = (table(mdf, _ss, dl_label="Download CSV",
                           dl_file=f"fuzzy_{col}.csv"))
            out += collapsible(
                f"🏷️ {col} — {len(matches)} pair(s)  ({nu} cats, {rare} rare)",
                inner, open_=True)

    if skipped:
        sl = "".join(f'<li>{_esc(c)} ({cr[c].get("n_unique",0)} cats)</li>'
                     for c in sorted(skipped))
        out += collapsible(f"ℹ️ {len(skipped)} high-cardinality cols skipped",
                            f"<ul>{sl}</ul>")

    out += divider() + sec("Rare Categories Explorer")
    opts = "".join(f'<option value="rcp{i}">{_esc(c)}</option>'
                   for i, c in enumerate(cat_cols))
    panels = []
    for i, col in enumerate(cat_cols):
        tbl_ = cr[col].get("category_table", pd.DataFrame())
        rare_df = tbl_[tbl_["Flag"] == "RARE"]      if len(tbl_) else pd.DataFrame()
        dom_df  = tbl_[tbl_["Flag"] == "DOMINANT"]  if len(tbl_) else pd.DataFrame()
        p = f'<div id="rcp{i}" class="vp" style="display:none"><div class="two-col">'
        p += '<div>'
        if len(rare_df):
            p += alert(f"⚠️ {len(rare_df)} rare categories", "yellow")
            p += table(rare_df.reset_index(drop=True),
                       dl_label="Download", dl_file=f"rare_{col}.csv")
        else:
            p += alert(f"✅ No rare categories in <strong>{_esc(col)}</strong>", "green")
        p += '</div><div>'
        if len(dom_df):
            p += alert("⚠️ Dominant category detected", "yellow")
            p += table(dom_df.reset_index(drop=True),
                       dl_label="Download", dl_file=f"dominant_{col}.csv")
        else:
            p += '<p class="cap">No dominant category.</p>'
        p += '</div></div></div>'
        panels.append(p)

    out += (f'<div class="vex-bar">'
            f'<label class="vex-label">Select Column</label>'
            f'<select class="vsel" onchange="showRCP(this.value)">{opts}</select>'
            f'</div>'
            f'<div id="rcp-panels">{"".join(panels)}</div>'
            f'<script>(function(){{'
            f'  function showRCP(id){{'
            f'    document.querySelectorAll("#rcp-panels .vp").forEach(function(e){{e.style.display="none";}});'
            f'    var el=document.getElementById(id); if(el) el.style.display="block";'
            f'  }}'
            f'  window.showRCP=showRCP;'
            f'  var first=document.querySelector("#rcp-panels .vp");'
            f'  if(first) first.style.display="block";'
            f'}})();</script>')
    return out


def _outliers(R):
    import plotly.graph_objects as go

    cr = R.get("col_results", {})
    num_cols = [c for c, r in cr.items()
                if r["dtype"] in ("Numeric","Boolean") and r.get("plot_sample")]
    if not num_cols:
        return alert("No numeric columns with data.", "yellow")

    # ── pre-compute stats ─────────────────────────────────────────────────────
    stats = {}
    for col in num_cols:
        res  = cr[col]; outl = res.get("outlier", {}); dist = res.get("dist", {})
        samp = res.get("plot_sample", [])
        arr  = sorted([x for x in samp if x is not None
                       and not (isinstance(x, float) and math.isnan(x))])
        if not arr: stats[col] = None; continue
        pcts   = [float(np.percentile(arr, p)) for p in range(101)]
        lo5    = pcts[5];  hi95   = pcts[95]
        p1     = pcts[1];  p99    = pcts[99]
        n_out  = sum(1 for v in arr if v < lo5 or v > hi95)
        iqr_pct= outl.get("iqr_pct", 0.0)
        iqr_cnt= outl.get("iqr_count", outl.get("count", 0))
        sev_lbl= ("🔴 High"    if iqr_pct >= 10 else
                  "🟡 Moderate" if iqr_pct >= 5  else
                  "🟢 Low"     if iqr_pct >= 1  else "✅ Clean")
        stats[col] = dict(arr=arr, pcts=pcts, lo5=lo5, hi95=hi95,
                          p1=p1, p99=p99, n_out=n_out, n_total=len(arr),
                          iqr_pct=iqr_pct, iqr_cnt=iqr_cnt,
                          fence_lo=outl.get("fence_lo","—"),
                          fence_hi=outl.get("fence_hi","—"),
                          note=outl.get("note",""),
                          inf_p=res.get("inf_pct", 0.0),
                          zero_inf=res.get("zero_inflated", False),
                          sk=dist.get("skewness", 0) or 0,
                          sev=sev_lbl)

    # ── summary table ─────────────────────────────────────────────────────────
    out = sec("Outlier Summary — All Variables")
    out += '<p class="cap">IQR method (1.5×IQR fences) · Click any row to jump to detail</p>'

    sum_rows = []
    for col in num_cols:
        s = stats.get(col)
        if not s:
            sum_rows.append({"Variable":col,"IQR Outliers":"—","IQR %":"—",
                             "P5":"—","P95":"—","Fence Lo":"—","Fence Hi":"—",
                             "Skewness":"—","Severity":"—"})
        else:
            sum_rows.append({"Variable":col,
                             "IQR Outliers": s["iqr_cnt"],
                             "IQR %":        round(s["iqr_pct"], 2),
                             "P5":           round(s["lo5"], 4),
                             "P95":          round(s["hi95"], 4),
                             "Fence Lo":     s["fence_lo"],
                             "Fence Hi":     s["fence_hi"],
                             "Skewness":     round(s["sk"], 3),
                             "Severity":     s["sev"]})
    sum_df = pd.DataFrame(sum_rows)

    # custom table with clickable rows
    heads = "".join(f'<th>{_esc(c)}</th>' for c in sum_df.columns)
    tbody = ""
    for idx, row in sum_df.iterrows():
        cells = []
        for c in sum_df.columns:
            v = row[c]; st = ""
            if c == "IQR %":   st = _col_iqr(v)
            elif c == "Severity":
                sev = str(v)
                if "High"     in sev: st = "background:#fee2e2;color:#991b1b;font-weight:600"
                elif "Moderate" in sev: st = "background:#fef9c3;color:#a16207;font-weight:600"
                elif "Low"    in sev: st = "background:#dcfce7;color:#166534"
                else:                 st = "color:#166534"
            elif c == "Skewness":
                x = abs(_sf(v))
                if x > 2: st = "color:#b91c1c;font-weight:600"
                elif x > 1: st = "color:#b45309"
            try:
                d = "—" if isinstance(v, float) and math.isnan(v) else _esc(str(v))
            except Exception:
                d = _esc(str(v))
            cells.append(f'<td style="{st}">{d}</td>')
        tbody += (f'<tr class="ol-row" data-vi="{idx}" style="cursor:pointer">'
                  + "".join(cells) + "</tr>")

    out += (f'<div class="tw"><table id="ol-sum-tbl" class="dt sortable">'
            f'<thead><tr>{heads}</tr></thead>'
            f'<tbody>{tbody}</tbody></table></div>')
    out += ('<div class="tbl-ctrl">'
            + tbl_controls("ol-sum-tbl").replace('<div class="tbl-ctrl">','').rstrip('</div>')
            + csv_btn(sum_df, "Download Summary CSV", "outlier_summary.csv")
            + '</div>')
    out += ('<div class="pills">'
            + badge("🔴 IQR%≥10 High",       "#fee2e2","#991b1b")
            + badge("🟡 IQR% 5–9 Moderate",  "#fef9c3","#a16207")
            + badge("🟢 IQR% 1–4 Low",       "#dcfce7","#166534")
            + badge("✅ IQR% <1 Clean",       "#f0fdf4","#166534")
            + '</div>' + divider())

    # ── variable detail ───────────────────────────────────────────────────────
    out += sec("Variable Detail")
    opts = "".join(f'<option value="op{i}">{_esc(c)}</option>'
                   for i, c in enumerate(num_cols))
    panels = []

    for i, col in enumerate(num_cols):
        s = stats.get(col)
        p = f'<div id="op{i}" class="vp" style="display:none">'
        if not s:
            p += alert("No sample data.", "yellow") + '</div>'
            panels.append(p)
            continue

        arr  = s["arr"]; pcts = s["pcts"]
        p1   = s["p1"];  p99  = s["p99"]
        lo5  = s["lo5"]; hi95 = s["hi95"]
        n_out= s["n_out"]; pad = (p99 - p1) * 0.05

        if s["inf_p"] > 0:  p += alert(f"🔴 {s['inf_p']:.2f}% Inf values excluded", "red")
        if s["note"]:        p += alert(f"ℹ️ {_esc(s['note'])}", "blue")
        if s["zero_inf"]:    p += alert("ℹ️ Zero-inflated — IQR computed on non-zero values", "blue")

        p += (f'<div class="ol-ctrl">'
              f'<div class="sl-grp">'
              f'<label>Lower percentile: <strong id="lo_lbl_{i}">P5 = {lo5:.4g}</strong></label>'
              f'<input type="range" id="lo_sl_{i}" min="0" max="20" value="5" step="1"'
              f' oninput="updOutlier({i},this.value,null)"></div>'
              f'<div class="sl-grp">'
              f'<label>Upper percentile: <strong id="hi_lbl_{i}">P95 = {hi95:.4g}</strong></label>'
              f'<input type="range" id="hi_sl_{i}" min="80" max="100" value="95" step="1"'
              f' oninput="updOutlier({i},null,this.value)"></div></div>')

        p += '<div class="mr">'
        p += (f'<div class="mc"><div class="mv" id="ol_plo_{i}">{lo5:.4g}</div>'
              f'<div class="ml" id="ol_lbplo_{i}">P5</div></div>')
        p += (f'<div class="mc"><div class="mv" id="ol_phi_{i}">{hi95:.4g}</div>'
              f'<div class="ml" id="ol_lbphi_{i}">P95</div></div>')
        pct_def = round(n_out/len(arr)*100, 2) if arr else 0
        p += (f'<div class="mc"><div class="mv" id="ol_cnt_{i}">{n_out:,}</div>'
              f'<div class="ml">Outside range</div></div>')
        p += (f'<div class="mc"><div class="mv" id="ol_pct_{i}">{pct_def:.2f}%</div>'
              f'<div class="ml">% outside</div></div>')
        p += (f'<div class="mc"><div class="mv">{s["iqr_cnt"]:,}</div>'
              f'<div class="ml">IQR outliers</div></div>')
        p += (f'<div class="mc"><div class="mv" style="{_col_iqr(s["iqr_pct"])}">'
              f'{s["iqr_pct"]:.1f}%</div><div class="ml">IQR %</div></div>')
        p += '</div>'
        p += (f'<p class="cap"><strong>IQR fences:</strong> '
              f'lo = {s["fence_lo"]} · hi = {s["fence_hi"]}</p>')

        # boxplot
        fb = go.Figure()
        fb.add_trace(go.Box(x=arr, name=col, marker_color=C["accent"], boxmean="sd",
                             fillcolor="rgba(99,102,241,.15)", line_color=C["accent"]))
        fb.add_vline(x=lo5,  line_dash="dash", line_color=C["orange"],
                     annotation_text="P5",  annotation_font_size=10)
        fb.add_vline(x=hi95, line_dash="dash", line_color=C["red"],
                     annotation_text="P95", annotation_font_size=10)
        fb.update_layout(title=dict(text=f"Boxplot — {col}", font_size=13))

        # histogram
        bin_w = (p99 - p1) / 60 if p99 > p1 else None
        fh_ = go.Figure()
        fh_.add_trace(go.Histogram(x=arr,
            xbins=dict(size=bin_w, start=p1-pad, end=p99+pad) if bin_w else {},
            marker_color=C["accent"], opacity=0.82,
            marker_line=dict(width=0.2, color="#fff")))
        if lo5 > p1 - pad:
            fh_.add_vrect(x0=p1-pad, x1=lo5, fillcolor=C["orange"], opacity=0.12,
                          line_width=0, annotation_text="Low tail",
                          annotation_font_size=9, annotation_position="top left")
        if hi95 < p99 + pad:
            fh_.add_vrect(x0=hi95, x1=p99+pad, fillcolor=C["red"], opacity=0.12,
                          line_width=0, annotation_text="High tail",
                          annotation_font_size=9, annotation_position="top right")
        fh_.update_layout(
            title=dict(text=f"Distribution — {col}  (P1–P99 view)", font_size=13),
            xaxis=dict(title=col, range=[p1-pad, p99+pad]),
            yaxis_title="Count", bargap=0.02)

        p += chart(_fig(fb, 200), f"ob{i}", 200)
        p += chart(_fig(fh_), f"oh{i}")

        if p1 > float(min(arr)) or p99 < float(max(arr)):
            p += (f'<p class="cap">ℹ️ X-axis clipped to P1–P99 '
                  f'[{p1:.4g}, {p99:.4g}]. '
                  f'Full range: [{float(min(arr)):.4g}, {float(max(arr)):.4g}]</p>')

        arr_s = arr[::max(1, len(arr)//10000)]
        p += (f'<div id="od{i}" style="display:none" '
              f'data-pct=\'{_j(pcts)}\' data-arr=\'{_j(arr_s)}\' '
              f'data-n="{len(arr)}"></div>')
        p += '</div>'
        panels.append(p)

    out += (f'<div class="vex-bar">'
            f'<label class="vex-label">Select Variable</label>'
            f'<select class="vsel" onchange="showOP(this.value)">{opts}</select>'
            f'</div>'
            f'<div id="ol-panels">{"".join(panels)}</div>'
            f'<script>(function(){{'
            f'  function showOP(id){{'
            f'    document.querySelectorAll("#ol-panels .vp").forEach(function(e){{e.style.display="none";}});'
            f'    var el=document.getElementById(id);'
            f'    if(el){{el.style.display="block";renderCharts(el);}}'
            f'  }}'
            f'  window.showOP=showOP;'
            f'  document.querySelectorAll(".ol-row").forEach(function(r){{'
            f'    r.addEventListener("click",function(){{'
            f'      var idx=this.getAttribute("data-vi");'
            f'      var sel=document.querySelector(".vsel[onchange*=showOP]");'
            f'      if(sel){{sel.value="op"+idx;showOP("op"+idx);}}'
            f'      document.getElementById("ol-panels").scrollIntoView({{behavior:"smooth",block:"start"}});'
            f'    }});'
            f'    r.addEventListener("mouseenter",function(){{this.style.background="#ede9fe";}});'
            f'    r.addEventListener("mouseleave",function(){{this.style.background="";}});'
            f'  }});'
            f'  var first=document.querySelector("#ol-panels .vp");'
            f'  if(first) first.style.display="block";'
            f'}})();</script>')
    return out


def _correlations(R):
    import plotly.graph_objects as go
    import plotly.express as px

    corr   = R.get("correlations", {})
    target = R.get("target_col")
    cfg    = R.get("config", {})
    thresh = cfg.get("corr_threshold", 0.75)

    if not corr:
        return alert("Correlations disabled. Re-run with set_sections(correlations=True).", "yellow")

    out = ('<div class="stb">'
           '<button class="stab on" onclick="showST(this,\'st-num\')">🔢 Numeric — Pearson</button>'
           '<button class="stab" onclick="showST(this,\'st-cat\')">🏷️ Categorical — Cramér\'s V</button>'
           '<button class="stab" onclick="showST(this,\'st-tgt\')">🎯 Target Correlation</button>'
           '</div>')

    # ── Numeric / Pearson ─────────────────────────────────────────────────────
    out += '<div id="st-num" class="st on">'
    hm     = corr.get("pearson", pd.DataFrame())
    n_vars = corr.get("n_vars", 0)
    total  = corr.get("total_rows", 0)
    sn     = corr.get("sample_size", total)
    pct    = round(sn/total*100, 1) if total else 100

    out += collapsible("ℹ️ About Pearson correlation",
        "<p><strong>Pearson r</strong> measures linear relationship between numeric variables. "
        "Range −1 to +1.<br>"
        "VIF &gt; 10 = severe multicollinearity · 5–10 = moderate · &lt; 5 = OK</p>")

    if len(hm) < 2:
        out += alert("Need ≥ 2 numeric features for Pearson correlation.", "yellow")
    else:
        out += (f'<p class="cap"><strong>{n_vars} numeric features</strong> · '
                f'{sn:,} of {total:,} rows ({pct}%)'
                f'{"  — sampled for speed" if corr.get("sampled") else ""}</p>')

        # target bar chart
        if target and target in hm.columns:
            tc = (hm[target].drop(target, errors="ignore").dropna()
                  .sort_values(key=abs, ascending=True))
            if len(tc):
                bc = [C["purple"] if abs(v)>=0.5 else C["accent"] if abs(v)>=0.3
                      else C["green"] if abs(v)>=0.1 else C["cyan"] for v in tc]
                fq = go.Figure(go.Bar(
                    x=tc.values, y=tc.index.tolist(), orientation="h",
                    marker_color=bc,
                    text=[f"{v:+.3f}" for v in tc.values],
                    textposition="auto", textfont_size=9,
                ))
                fq.update_layout(
                    title=dict(text=f"🎯 Features vs Target: {target}  (Pearson r)",
                               font_size=13),
                    xaxis=dict(range=[-1, 1], title="Pearson r",
                               zeroline=True, zerolinecolor="#374151", zerolinewidth=1.5),
                    yaxis_title="",
                )
                h_ = max(300, len(tc) * 26)
                out += sec(f"Features vs Target: {target}")
                out += chart(_fig(fq, h_), "c-ptgt", h_)
                out += ('<div class="pills">'
                        + badge("|r|≥0.5 Strong",   "#ede9fe", C["purple"])
                        + badge("0.3–0.5 Moderate", "#dbeafe", C["accent"])
                        + badge("0.1–0.3 Weak",     "#dcfce7", C["green"])
                        + badge("<0.1 Negligible",  "#f1f5f9", "#6b7280")
                        + '</div>' + divider())

        # heatmap — auto-height, fullscreen button
        out += sec("Pearson Correlation Heatmap")
        n_cols = len(hm)
        h_hm = max(400, n_cols * 44)  # auto-scale: 44px per variable
        fhm = px.imshow(hm, color_continuous_scale="RdBu_r", zmin=-1, zmax=1,
                        text_auto=".2f")
        fhm.update_layout(title=dict(text="Pearson Correlation Matrix", font_size=13))
        fhm.update_traces(textfont_size=max(7, min(11, 140 // n_cols)))
        out += chart(_fig(fhm, h_hm), "c-hm", h_hm, fullscreen=True)
        out += divider()

        # threshold slider + pairs table
        pt = corr.get("pair_table", pd.DataFrame())
        if len(pt):
            out += sec("High-Correlation Pairs")
            out += (f'<div class="sl-grp" style="max-width:440px;margin-bottom:14px">'
                    f'<label>|r| threshold: <strong id="cth-lbl">{thresh:.2f}</strong></label>'
                    f'<input type="range" id="cth-sl" min="0" max="100" '
                    f'value="{int(thresh*100)}" step="1" oninput="filtCorr(this.value)">'
                    f'</div>'
                    f'<p class="cap" id="cth-cnt"></p>')

            def _ps(c, v, row):
                if c == "Pearson r": return _col_pearsonr(v)
                return ""

            out += table(pt, _ps, "cth-tbl", "sortable",
                         dl_label="Download Pairs CSV", dl_file="pearson_pairs.csv")
            out += tbl_controls("cth-tbl")
            out += divider()

        # VIF
        vif = corr.get("vif", pd.DataFrame())
        if len(vif):
            out += sec("VIF — Variance Inflation Factor")
            out += '<p class="cap">VIF &gt; 10 = severe · 5–10 = moderate · &lt; 5 = OK</p>'
            def _vs(c, v, row):
                if c == "VIF": return _col_vif(v)
                return ""
            out += table(vif, _vs, dl_label="Download VIF CSV", dl_file="vif.csv")

    out += '</div>'  # st-num

    # ── Categorical Cramér's V ────────────────────────────────────────────────
    out += '<div id="st-cat" class="st">'
    cv     = corr.get("cat_chi2", pd.DataFrame())
    chi_cap= corr.get("chi_max_cardinality", 10_000)
    skipped= corr.get("chi_skipped", [])
    total_r= corr.get("total_rows", 0)

    out += collapsible("ℹ️ About Cramér's V",
        "<p><strong>Cramér's V</strong> measures association between categorical variables. "
        "Range 0–1.<br>"
        "V ≥ 0.3 = <strong>Strong</strong> · "
        "0.1–0.3 = <strong>Moderate</strong> · "
        "&lt;0.1 = <strong>Weak</strong>. "
        "Computed on full dataset.</p>")

    out += (f'<p class="cap">Full {total_r:,} rows · '
            f'Columns with &gt;{chi_cap:,} unique values skipped'
            + (f' · <strong>{len(skipped)} skipped</strong>' if skipped else "")
            + '</p>')

    if not len(cv):
        out += alert("No categorical column pairs found (need ≥ 2 categorical columns).", "yellow")
    else:
        n_s = int((cv["Cramér's V"].fillna(0) >= 0.3).sum())
        n_m = int(((cv["Cramér's V"].fillna(0) >= 0.1) &
                   (cv["Cramér's V"].fillna(0) < 0.3)).sum())
        n_t = int((cv["vs Target"] == "TARGET").sum())

        out += '<div class="mr">'
        out += metric("Total pairs",     len(cv))
        out += metric("Strong (V≥0.3)", n_s)
        out += metric("Moderate",        n_m)
        out += metric("vs Target",       n_t)
        out += '</div>'

        # Cramér's V bar chart — rendered directly (NOT via JS injection)
        top_cv = cv.head(20).copy()
        top_cv["pair"] = top_cv["Variable A"] + "  ×  " + top_cv["Variable B"]
        top_cv = top_cv.sort_values("Cramér's V", ascending=True)
        bar_c  = [C["purple"] if v >= 0.3 else C["accent"] if v >= 0.1 else C["cyan"]
                  for v in top_cv["Cramér's V"]]
        h_cv = max(300, len(top_cv) * 26)
        fcv = go.Figure(go.Bar(
            x=top_cv["Cramér's V"], y=top_cv["pair"], orientation="h",
            marker_color=bar_c,
            text=top_cv.apply(
                lambda r: "V={:.4f}  {}".format(r["Cramér's V"], r["Strength"]), axis=1),
            textposition="outside", textfont_size=9,
        ))
        fcv.update_layout(
            title=dict(text="Top Pairs — Cramér's V", font_size=13),
            xaxis=dict(range=[0, min(top_cv["Cramér's V"].max() * 1.4, 1.05)],
                       title="Cramér's V"),
            yaxis_title="",
        )
        out += sec("Association Strength (top 20 pairs)")
        out += chart(_fig(fcv, h_cv), "cv-bar-chart", h_cv)
        out += ('<div class="pills">'
                + badge("V≥0.3 Strong",   "#ede9fe", C["purple"])
                + badge("0.1–0.3 Moderate","#dbeafe", C["accent"])
                + badge("<0.1 Weak",       "#f1f5f9", "#6b7280")
                + '</div>' + divider())

        # Table with target filter
        out += (f'<div class="cv-bar">'
                f'<label class="checkbox-lbl">'
                f'<input type="checkbox" id="cv-tgt" onchange="filtCV()"> '
                f'Target pairs only</label></div>')
        out += f'<div id="cv-tbl-wrap"></div>'

        cv_rows = (cv[["Variable A","Variable B","Cramér's V","Strength","vs Target"]]
                   .assign(**{"Cramér's V": cv["Cramér's V"].round(4)})
                   .to_dict(orient="records"))

        # also render full table immediately as static HTML
        def _cv_st(c, v, row):
            if c == "Cramér's V": return _col_cramersv(v)
            if c == "Strength":   return _col_cramersv(row.get("Cramér's V", 0))
            if c == "vs Target":
                if str(v) == "TARGET": return "background:#f5f3ff;font-weight:700"
            return ""

        cv_tbl_html = table(
            cv[["Variable A","Variable B","Cramér's V","Strength","vs Target"]],
            _cv_st, "cv-full-tbl", "sortable",
            dl_label="Download Cramér's V CSV", dl_file="cramers_v.csv")
        out += f'<div id="cv-static-wrap">{cv_tbl_html}</div>'
        out += tbl_controls("cv-full-tbl")

        cv_json = _j(cv_rows)
        out += f'''<script>
(function(){{
  var CVD={cv_json};
  function buildCVTbl(data){{
    var rows=data.map(function(r){{
      var v=+(r["Cramér\'s V"]||0);
      var bg=v>=0.3?"background:#ede9fe;color:#5b21b6;font-weight:700":v>=0.1?"background:#dbeafe;color:#1e3a5f":"";
      var tg=r["vs Target"]==="TARGET"?"background:#f5f3ff;font-weight:700":"";
      return "<tr><td>"+r["Variable A"]+"</td><td>"+r["Variable B"]+"</td>"+
        "<td style=\\""+bg+"\\">"+v.toFixed(4)+"</td>"+
        "<td style=\\""+bg+"\\">"+r["Strength"]+"</td>"+
        "<td style=\\""+tg+"\\">"+r["vs Target"]+"</td></tr>";
    }}).join("");
    return "<div class=\\"tw\\"><table class=\\"dt sortable\\">"+
      "<thead><tr><th>Variable A</th><th>Variable B</th><th>Cramér\'s V</th>"+
      "<th>Strength</th><th>vs Target</th></tr></thead>"+
      "<tbody>"+rows+"</tbody></table></div>";
  }}
  function filtCV(){{
    var tgt=document.getElementById("cv-tgt"); if(!tgt) return;
    var data=tgt.checked?CVD.filter(function(r){{return r["vs Target"]==="TARGET";}}):CVD;
    var wrap=document.getElementById("cv-static-wrap");
    if(wrap) wrap.innerHTML=buildCVTbl(data);
  }}
  window.filtCV=filtCV;
}})();
</script>'''

    out += '</div>'  # st-cat

    # ── Target Correlation ────────────────────────────────────────────────────
    out += '<div id="st-tgt" class="st">'
    if not target:
        out += alert("No target column defined. Pass target_col= to inspect().", "yellow")
    else:
        out += f'<p class="cap">Target: <strong>{_esc(target)}</strong></p>'
        ts = corr.get("target_summary", pd.DataFrame())
        if len(ts):
            out += sec(f"All Features vs Target: {target}")
            out += ('<p class="cap">Numeric → Pearson r · Categorical → Cramér\'s V · '
                    'Higher absolute value = stronger association</p>')
            tp = ts.dropna(subset=["Value"]).copy()
            tp = tp.sort_values("Value", key=abs, ascending=True).tail(40)
            bc = []
            for _, row in tp.iterrows():
                v = abs(_sf(row["Value"]))
                if row["Type"] == "Categorical":
                    bc.append(C["purple"] if v >= 0.3 else C["accent"] if v >= 0.1 else C["cyan"])
                else:
                    bc.append("#7c3aed" if v >= 0.5 else C["accent"] if v >= 0.3
                               else C["green"] if v >= 0.1 else C["cyan"])
            fts = go.Figure(go.Bar(
                x=tp["Value"].abs(), y=tp["Feature"], orientation="h",
                marker_color=bc,
                text=tp.apply(lambda r: f"{r['Metric']}: {abs(_sf(r['Value'])):.4f}", axis=1),
                textposition="auto", textfont_size=9,
            ))
            fts.update_layout(
                title=dict(text=f"Feature Association with {target}  (top 40)", font_size=12),
                xaxis=dict(range=[0, 1.05], title="Association Strength (absolute)"),
                yaxis_title="",
            )
            h_ts = max(320, len(tp) * 26)
            out += chart(_fig(fts, h_ts), "c-ts", h_ts)
            out += ('<div class="pills">'
                    + badge("Strong",     "#ede9fe", C["purple"])
                    + badge("Moderate",   "#dbeafe", C["accent"])
                    + badge("Weak",       "#dcfce7", C["green"])
                    + badge("🏷️ Categorical","#fef9c3","#78350f")
                    + badge("🔢 Numeric",  "#e0f2fe","#0284c7")
                    + '</div>' + divider())

            def _ts_st(c, v, row):
                if c in ("Value","Strength"):
                    s = str(row.get("Strength",""))
                    if s == "Strong":   return "background:#ede9fe;color:#5b21b6;font-weight:700"
                    if s == "Moderate": return "background:#dbeafe;color:#1e3a5f;font-weight:600"
                    if s == "Weak":     return "background:#dcfce7;color:#166534"
                if c == "Type":
                    if str(v) == "Categorical": return "background:#fef9c3;color:#78350f"
                    return "background:#e0f2fe;color:#0369a1"
                return ""

            out += table(ts.reset_index(drop=True), _ts_st, "ts-tbl", "sortable",
                         dl_label="Download Target Summary CSV", dl_file="target_summary.csv")
            out += tbl_controls("ts-tbl")

        tc2 = corr.get("target_corr", pd.DataFrame())
        if len(tc2):
            def _tc_st(c, v, row):
                if c == "Pearson r": return _col_pearsonr(v)
                return ""
            out += collapsible(
                f"🔢 Numeric detail — Pearson r with {target}",
                table(tc2, _tc_st,
                      dl_label="Download CSV", dl_file="target_pearson.csv"))

        if len(cv):
            tgt_cv = cv[cv["vs Target"] == "TARGET"].copy()
            if len(tgt_cv):
                def _tcv_st(c, v, row):
                    if c == "Cramér's V": return _col_cramersv(v)
                    return ""
                out += collapsible(
                    f"🏷️ Categorical detail — Cramér's V vs {target}",
                    table(tgt_cv.reset_index(drop=True), _tcv_st,
                          dl_label="Download CSV", dl_file="target_cramersv.csv"))

    out += '</div>'  # st-tgt
    return out


def _comparison(R):
    import plotly.graph_objects as go

    cmp = R.get("comparison", {})
    if not cmp or not isinstance(cmp, dict) or not cmp.get("per_col_tables"):
        return alert("No comparison configured. Call plan.set_comparison(...) before run_eda().", "blue")

    la = cmp["label_a"]; lb = cmp["label_b"]
    ra = cmp.get("rows_a", 0); rb = cmp.get("rows_b", 0)
    gb = cmp.get("groupby_col", [])
    gb_str = ", ".join(gb) if isinstance(gb, list) else str(gb or "—")
    sum_a = cmp.get("summary_a", pd.DataFrame())
    sum_b = cmp.get("summary_b", pd.DataFrame())
    per_col = cmp.get("per_col_tables", {})

    out = '<div class="mr">'
    out += metric(f"📁 {la} — Rows", f"{ra:,}")
    out += metric(f"📁 {lb} — Rows", f"{rb:,}")
    out += metric("Row Δ",           f"{rb-ra:+,}")
    out += metric("Grouped by",      gb_str)
    out += '</div>' + divider() + sec("📋 Dataset Summaries")
    out += '<div class="two-col">'

    for lbl, df_s in [(la, sum_a), (lb, sum_b)]:
        out += f'<div><h4 style="font-size:.88rem;color:#374151;margin:0 0 8px">{_esc(lbl)}</h4>'
        if len(df_s):
            def _ss(c, v, row):
                if c == "Missing %": return _col_missing(v)
                return ""
            out += table(df_s, _ss,
                         dl_label=f"Download {lbl} CSV", dl_file=f"{lbl}_summary.csv")
        else:
            out += alert("No summary.", "yellow")
        out += '</div>'
    out += '</div>' + divider() + sec("⚖️ Comparison by Group")
    out += (f'<p class="cap">Groups of <strong>{_esc(gb_str)}</strong> · '
            f'🟢 100% match · 🟡 ≥95% · 🟠 ≥85% · 🔴 &lt;85%</p>')

    keys = list(per_col.keys())
    if len(keys) > 1:
        opts = "".join(
            f'<option value="ct_{_esc(k)}">{_esc(per_col[k]["col"])} ({_esc(per_col[k]["fn"])})</option>'
            for k in keys)
        out += f'<select class="vsel" onchange="showCT(this.value)" style="margin-bottom:12px">{opts}</select>'

    for ki, key in enumerate(keys):
        entry = per_col[key]
        tbl_  = entry["table"].copy()
        grp   = entry["grp_label"]; cn = entry["col"]; fn = entry["fn"]

        def _cr(c, v, row):
            is_tot = str(row.get(grp,"")) == "TOTAL"
            bld = "font-weight:700;" if is_tot else ""
            ex  = "border-top:2px solid #374151;" if is_tot else ""
            if c == "Match %":    return _col_matchpct(v, is_tot) + ex
            if c == "Diff %":     return _col_diffpct(v, is_tot) + ex
            if c == "Diff (A−B)":
                x = _sf(v)
                if x > 0: return f"color:#166534;font-weight:600;{ex}"
                if x < 0: return f"color:#b91c1c;font-weight:600;{ex}"
                return f"color:#6b7280;{ex}"
            return bld + ex

        disp = f'style="display:{"block" if ki==0 else "none"}"'
        out += f'<div id="ct_{_esc(key)}" {disp}>'
        out += table(tbl_, _cr, "sortable",
                     dl_label=f"Download {cn} ({fn}) CSV",
                     dl_file=f"comparison_{cn}_{fn}.csv")

        plot = tbl_[tbl_[grp] != "TOTAL"].copy()
        if len(plot):
            fg = go.Figure()
            fg.add_trace(go.Bar(name=la, x=plot[grp].astype(str), y=plot[la],
                                 marker_color=C["accent"],
                                 text=plot[la].apply(_fmtn),
                                 textposition="outside", textfont_size=9))
            fg.add_trace(go.Bar(name=lb, x=plot[grp].astype(str), y=plot[lb],
                                 marker_color=C["cyan"],
                                 text=plot[lb].apply(_fmtn),
                                 textposition="outside", textfont_size=9))
            fg.update_layout(barmode="group",
                              title=dict(text=f"{cn} ({fn}) — {la} vs {lb}", font_size=13),
                              xaxis_title=gb_str, yaxis_title=f"{cn} ({fn})",
                              bargap=0.12)
            out += chart(_fig(fg, 340), f"cg{ki}", 340)

            if "Match %" in plot.columns:
                bc = [C["green"] if v >= 100 else "#86efac" if v >= 95
                      else C["orange"] if v >= 85 else "#f97316" if v >= 70
                      else C["red"] for v in plot["Match %"]]
                fm = go.Figure(go.Bar(
                    x=plot[grp].astype(str), y=plot["Match %"],
                    marker_color=bc,
                    text=plot["Match %"].apply(lambda v: f"{v:.1f}%"),
                    textposition="inside", textfont_color="white", textfont_size=10,
                ))
                fm.add_hline(y=95, line_dash="dash", line_color=C["orange"])
                fm.update_layout(
                    title=dict(text=f"Match % — {cn} {fn}", font_size=13),
                    xaxis_title=gb_str, yaxis=dict(title="Match %", range=[0, 105]))
                out += chart(_fig(fm, 260), f"cm{ki}", 260)

        out += '</div>'

    if len(keys) > 1:
        out += (f'<script>(function(){{'
                f'  var K={_j(keys)};'
                f'  window.showCT=function(v){{'
                f'    K.forEach(function(k){{'
                f'      var e=document.getElementById("ct_"+k);'
                f'      if(e) e.style.display=(k===v?"block":"none");'
                f'    }});'
                f'  }};'
                f'}})();</script>')
    return out


def _scorecard(R):
    import plotly.graph_objects as go

    sc   = R.get("scorecard", pd.DataFrame())
    recs = R.get("recommendations", [])

    if not len(sc):
        return alert("Scorecard disabled. Re-run with set_sections(scorecard=True).", "yellow")

    n_fix = int((sc["Status"] == "❌ Fix First").sum())
    n_rev = int((sc["Status"] == "⚠️ Review").sum())
    n_ok  = int((sc["Status"] == "✅ Good").sum())
    tot   = len(sc)

    out = '<div class="mr">'
    out += metric("Total",        tot)
    out += metric("🔴 Fix First", n_fix)
    out += metric("🟡 Review",    n_rev)
    out += metric("🟢 Good",      n_ok)
    out += '</div>'

    wf = round(n_fix/tot*220) if tot else 0
    wr = round(n_rev/tot*220) if tot else 0
    wo = 220 - wf - wr
    out += (f'<div style="display:flex;border-radius:6px;overflow:hidden;'
            f'height:10px;margin:8px 0 18px;max-width:540px">'
            f'<div style="width:{wf}px;background:#ef4444"></div>'
            f'<div style="width:{wr}px;background:#f59e0b"></div>'
            f'<div style="width:{wo}px;background:#22c55e"></div></div>')
    out += divider()

    sc_col = "Overall (0-100)"
    fh = go.Figure()
    fh.add_trace(go.Histogram(
        x=sc[sc_col], xbins=dict(start=0, end=100, size=5),
        marker_color=[C["red"] if x < 55 else C["orange"] if x < 80
                      else C["green"] for x in sc[sc_col]],
        opacity=0.88,
    ))
    fh.update_layout(
        title=dict(text="Score Distribution", font_size=13),
        xaxis=dict(title="Score (0–100)", range=[0, 103]),
        yaxis_title="# Features", bargap=0.05,
        shapes=[
            dict(type="line", x0=55, x1=55, y0=0, y1=1, yref="paper",
                 line=dict(color=C["orange"], dash="dash", width=1.5)),
            dict(type="line", x0=80, x1=80, y0=0, y1=1, yref="paper",
                 line=dict(color=C["green"], dash="dash", width=1.5)),
        ]
    )
    out += sec("Score Distribution") + chart(_fig(fh, 220), "sc-hist", 220)
    out += ('<div class="pills">'
            + badge("● <55 Fix First", "#fee2e2", "#991b1b")
            + badge("● 55–79 Review",  "#fef9c3", "#a16207")
            + badge("● ≥80 Good",      "#dcfce7", "#166534")
            + '</div>' + divider() + sec("Feature Scorecard"))
    out += ('<p class="cap">Weights: Hit Rate 30% · Valid Values 20% · '
            'Outliers 20% · Skewness 15% · Cat Consistency 15%</p>')
    out += ('<div class="sc-flt">'
            '<label class="checkbox-lbl"><input type="checkbox" class="scf" '
            'value="Fix" checked onchange="filtSC()"> ❌ Fix First</label>'
            '<label class="checkbox-lbl"><input type="checkbox" class="scf" '
            'value="Review" checked onchange="filtSC()"> ⚠️ Review</label>'
            '<label class="checkbox-lbl"><input type="checkbox" class="scf" '
            'value="Good" checked onchange="filtSC()"> ✅ Good</label></div>')

    show_cols = ["Feature","Type","Hit Rate","Valid Values","Skewness",
                 "Cat Consistency","Outlier Score", sc_col,"Status"]
    show_cols = [c for c in show_cols if c in sc.columns]
    sc_show   = sc[show_cols].copy()

    def _scs(c, v, row):
        if c == "Status":  return _col_status(v)
        if c == sc_col:    return _col_score(v)
        if c == "Hit Rate":
            x = _sf(str(v).replace("%",""))
            return _col_hitrate(x)
        return ""

    out += table(sc_show, _scs, "sc-tbl", "sortable",
                 dl_label="Download Scorecard CSV", dl_file="scorecard.csv")
    out += tbl_controls("sc-tbl")

    if recs:
        out += divider() + sec("Recommended Actions")
        out += ('<div class="sc-flt">'
                '<label class="checkbox-lbl"><input type="checkbox" class="rf" '
                'value="Fix" checked onchange="filtRecs()"> ❌ Fix First</label>'
                '<label class="checkbox-lbl"><input type="checkbox" class="rf" '
                'value="Review" checked onchange="filtRecs()"> ⚠️ Review</label>'
                '</div><div id="recs">')
        rows_flat = []
        for rec in recs:
            icon = ("🔴" if "Fix" in rec["Priority"] else
                    "🟡" if "Review" in rec["Priority"] else "🟢")
            pri_s = ("Fix" if "Fix" in rec["Priority"] else
                     "Review" if "Review" in rec["Priority"] else "Good")
            items = "".join(
                f'<div class="ri"><span class="rf2">{_esc(f)}</span>'
                f'<span class="ra2">→</span><code class="rc">{_esc(a)}</code></div>'
                for f, a in rec["Items"])
            out += (f'<div class="rec" data-p="{pri_s}">'
                    f'<div class="rh">{icon} <strong>{_esc(rec["Feature"])}</strong>'
                    f'<span class="rt">{_esc(rec["Type"])}</span>'
                    f'<span class="rp" style="color:{"#b91c1c" if "Fix" in rec["Priority"] else "#b45309"}">'
                    f'{_esc(rec["Priority"])}</span></div>'
                    f'<div class="rb">{items}</div></div>')
            for f, a in rec["Items"]:
                rows_flat.append({"Feature": rec["Feature"], "Type": rec["Type"],
                                  "Priority": rec["Priority"],
                                  "Finding": f, "Action": a})
        out += '</div>'
        if rows_flat:
            out += csv_btn(pd.DataFrame(rows_flat),
                           "⬇ Download All Recommendations CSV",
                           "recommendations.csv")
    else:
        out += alert("✅ No significant issues found.", "green")

    return out


# ── CSS ───────────────────────────────────────────────────────────────────────
CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=JetBrains+Mono:wght@400;500&display=swap');

/* Chubb Brand Colors: Navy #002B5C | Gold #C8922A | Blue #004A97 */
:root {
  --bg:#EEF1F7; --surf:#ffffff; --bdr:#D4DCE8;
  --txt:#0D1B2E; --txt2:#4A5568; --txt3:#8A98AA;
  --acc:#C8922A; --acc-l:#FDF3E3;
  --navy:#002B5C; --navy2:#004A97;
  --r:10px;
  --sh:0 1px 4px rgba(0,43,92,.08),0 1px 2px rgba(0,43,92,.05);
  --sh2:0 4px 16px rgba(0,43,92,.14);
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--txt);font-size:14px;line-height:1.6}

.lay{display:flex;min-height:100vh}
.side{width:236px;min-width:236px;background:var(--navy);color:#C8D8EC;
      position:sticky;top:0;height:100vh;overflow-y:auto;
      display:flex;flex-direction:column;flex-shrink:0;
      box-shadow:3px 0 18px rgba(0,0,0,.28)}
.main{flex:1;min-width:0;padding:24px 32px 48px;overflow-x:hidden}

/* sidebar */
.sh2{padding:16px 16px 12px;border-bottom:1px solid rgba(255,255,255,.1)}
.sl-logo{display:flex;align-items:center;gap:10px}
.sl-icon{width:36px;height:36px;border-radius:8px;background:var(--acc);
         color:#fff;display:flex;align-items:center;justify-content:center;
         font-size:12px;font-weight:800;flex-shrink:0}
.sl{font-size:14px;font-weight:700;color:#F0F6FF;letter-spacing:-.3px}
.ss{font-size:10px;color:#5B7A9A;margin-top:1px}
.sn{padding:14px 16px 4px;font-size:9px;font-weight:700;
    text-transform:uppercase;letter-spacing:.12em;color:#3A5670}
.ni{display:flex;align-items:center;gap:9px;padding:9px 16px 9px 18px;
    font-size:13px;cursor:pointer;border-left:3px solid transparent;
    transition:all .14s;color:#6A8EA8;white-space:nowrap;user-select:none}
.ni:hover{background:rgba(200,146,42,.1);color:#E8D5A8}
.ni.on{background:rgba(200,146,42,.18);border-left-color:var(--acc);
       color:#F5D98A;font-weight:600}
.ni-ic{width:18px;text-align:center;flex-shrink:0;font-size:14px}
.sts{padding:12px 16px;border-top:1px solid rgba(255,255,255,.08);margin-top:auto}
.sr{display:flex;justify-content:space-between;font-size:11.5px;
    padding:3px 0;color:#3A5670}
.sr strong{color:#C8D8EC}
.qb{height:7px;border-radius:4px;overflow:hidden;display:flex;margin:7px 0}

/* header */
.ph{background:linear-gradient(135deg,var(--navy) 0%,var(--navy2) 100%);
    border-radius:var(--r);padding:22px 28px;margin-bottom:22px;color:#fff;
    box-shadow:0 6px 24px rgba(0,43,92,.30);position:relative;overflow:hidden}
.ph::after{content:"";position:absolute;right:-40px;top:-40px;width:200px;
           height:200px;border-radius:50%;background:rgba(200,146,42,.12);pointer-events:none}
.ph-inner{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;position:relative;z-index:1}
.ph-left{flex:1}
.ph-tag{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.1em;
        color:var(--acc);margin-bottom:6px}
.ph h1{font-size:20px;font-weight:700;letter-spacing:-.4px;line-height:1.2;color:#fff}
.ph p{font-size:12px;opacity:.72;margin-top:6px;color:#C8D8EC}
.ph-badge{background:var(--acc);color:#fff;font-size:11px;font-weight:700;
          padding:4px 12px;border-radius:20px;white-space:nowrap;align-self:flex-start;margin-top:4px}

/* section breadcrumb */
.sec-crumb{display:flex;align-items:center;gap:8px;
           margin-bottom:18px;padding:10px 0 14px;
           border-bottom:2px solid var(--bdr)}
.sec-crumb span{font-size:17px;font-weight:700;color:var(--navy);letter-spacing:-.3px}

.tp{display:none}
.tp.on{display:block}

.stb{display:flex;gap:0;border-bottom:2px solid var(--bdr);margin-bottom:20px;overflow-x:auto;flex-wrap:nowrap}
.stab{padding:9px 18px;font-size:13px;font-weight:500;cursor:pointer;
      border:none;background:none;color:var(--txt2);border-bottom:2px solid transparent;
      margin-bottom:-2px;white-space:nowrap;font-family:inherit;transition:all .14s}
.stab:hover{color:var(--txt);background:var(--bg)}
.stab.on{color:var(--navy);border-bottom-color:var(--navy);font-weight:600}
.st{display:none}
.st.on{display:block}

/* metrics */
.mr{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0 16px}
.mc{background:var(--surf);border:1px solid var(--bdr);border-top:3px solid var(--acc);
    border-radius:var(--r);padding:.65rem 1.1rem .55rem;min-width:100px;
    flex:1;max-width:175px;box-shadow:var(--sh);transition:box-shadow .14s,transform .14s}
.mc:hover{box-shadow:var(--sh2);transform:translateY(-1px)}
.mv{font-size:1.2rem;font-weight:700;color:var(--navy);line-height:1.2}
.ml{font-size:.67rem;color:var(--txt2);text-transform:uppercase;letter-spacing:.05em;margin-top:2px}
.ms{font-size:.69rem;color:var(--txt3);margin-top:1px}

.sh{font-size:.92rem;font-weight:700;color:var(--navy);
    border-bottom:2px solid var(--acc);padding-bottom:4px;
    display:inline-block;margin:16px 0 10px}
.dv{border:none;border-top:1px solid var(--bdr);margin:18px 0}
.cap{font-size:.81rem;color:var(--txt2);margin:4px 0 8px}
.empty{color:var(--txt3);font-style:italic;font-size:.83rem;padding:6px 0}
.al{padding:.5rem .9rem;border-radius:7px;margin:.35rem 0 .45rem;font-size:.84rem;line-height:1.5}
.bdg{padding:2px 10px;border-radius:999px;font-size:.75rem;font-weight:600;display:inline-block;margin:2px 3px}
.pills{display:flex;flex-wrap:wrap;gap:3px;margin:8px 0}

/* tables */
.tw{overflow-x:auto;margin:8px 0;border-radius:8px;box-shadow:var(--sh);border:1px solid var(--bdr)}
.dt{border-collapse:collapse;width:100%;font-size:.81rem;background:var(--surf)}
.dt th{background:#EEF3FA;padding:8px 12px;text-align:left;font-weight:600;
       font-size:.75rem;color:var(--navy2);border-bottom:2px solid var(--bdr);
       cursor:pointer;user-select:none;white-space:nowrap;transition:background .12s}
.dt th:hover{background:#E0E8F5}
.dt th.sa::after{content:" ↑";color:var(--acc);font-size:.7rem}
.dt th.sd::after{content:" ↓";color:var(--acc);font-size:.7rem}
.dt td{padding:7px 12px;border-bottom:1px solid #F0F4FA;vertical-align:middle}
.dt tr:last-child td{border-bottom:none}
.dt tbody tr:hover td{background:#F5F8FF}
.tbl-ctrl{display:flex;align-items:center;gap:10px;margin:6px 0 12px;flex-wrap:wrap}
.tbl-actions{margin:4px 0 8px}
.srch{flex:1;max-width:280px;padding:7px 12px;border:1px solid var(--bdr);
      border-radius:7px;font-size:.81rem;font-family:inherit;
      background:var(--surf);color:var(--txt);outline:none}
.srch:focus{border-color:var(--navy2);box-shadow:0 0 0 2px rgba(0,74,151,.15)}
.dl-btn{display:inline-flex;align-items:center;gap:5px;padding:6px 12px;
        background:var(--surf);border:1px solid var(--bdr);border-radius:7px;
        font-size:.78rem;font-weight:500;color:var(--txt2);cursor:pointer;
        text-decoration:none;transition:all .13s;white-space:nowrap}
.dl-btn:hover{background:var(--acc-l);color:var(--acc);border-color:var(--acc)}

/* charts */
.chart-wrap{position:relative;margin:10px 0;border-radius:8px;
            overflow:hidden;background:var(--surf);
            border:1px solid var(--bdr);box-shadow:var(--sh)}
.chart-loader{position:absolute;inset:0;display:flex;align-items:center;
              justify-content:center;gap:10px;background:var(--surf);
              z-index:2;font-size:.82rem;color:var(--txt2);transition:opacity .3s}
.chart-loader.done{opacity:0;pointer-events:none}
.spinner{width:20px;height:20px;border:2px solid var(--bdr);
         border-top-color:var(--acc);border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.pc{width:100%;min-height:40px}
.fs-btn{position:absolute;top:8px;right:8px;z-index:3;padding:4px 8px;
        background:rgba(255,255,255,.9);border:1px solid var(--bdr);border-radius:5px;
        font-size:14px;cursor:pointer;color:var(--txt2);transition:all .13s;
        backdrop-filter:blur(4px)}
.fs-btn:hover{background:var(--acc-l);color:var(--acc);border-color:var(--acc)}

#fs-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);
            z-index:9999;align-items:center;justify-content:center}
#fs-overlay.on{display:flex}
#fs-container{background:#fff;border-radius:12px;padding:8px;
              width:95vw;max-height:95vh;overflow:auto;position:relative}
#fs-close{position:absolute;top:12px;right:14px;font-size:20px;
          cursor:pointer;color:#64748b;z-index:10;background:none;border:none}
#fs-plot{width:100%;height:80vh}

/* variable explorer */
.vex-bar{display:flex;align-items:center;gap:12px;margin-bottom:16px;
         background:var(--surf);border:1px solid var(--bdr);
         border-left:4px solid var(--acc);border-radius:var(--r);
         padding:12px 16px;box-shadow:var(--sh)}
.vex-label{font-size:.82rem;font-weight:600;color:var(--navy);white-space:nowrap}
.vsel{padding:7px 12px;border:1px solid var(--bdr);border-radius:7px;
      font-size:.87rem;font-family:inherit;background:var(--surf);color:var(--txt);
      min-width:220px;flex:1;outline:none;cursor:pointer}
.vsel:focus{border-color:var(--navy2);box-shadow:0 0 0 2px rgba(0,74,151,.15)}
.vp{background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);
    padding:20px;box-shadow:var(--sh)}
.vp-head{display:flex;align-items:center;gap:10px;margin-bottom:14px;
         padding-bottom:12px;border-bottom:1px solid var(--bdr)}
.vp-name{font-size:1.05rem;font-weight:700;color:var(--navy)}
.vp-dtype{font-size:.74rem;font-weight:600;padding:2px 9px;border-radius:999px;
          background:var(--acc-l);color:var(--acc)}

.stog{display:flex;gap:4px;margin-bottom:10px}
.stob{padding:5px 14px;border:1px solid var(--bdr);border-radius:6px;
      font-size:.79rem;font-weight:500;cursor:pointer;background:var(--surf);
      color:var(--txt2);font-family:inherit;transition:all .13s}
.stob.on{background:var(--navy);color:#fff;border-color:var(--navy);font-weight:600}

.ol-ctrl{display:grid;grid-template-columns:1fr 1fr;gap:16px;
         background:var(--surf);border:1px solid var(--bdr);
         border-radius:var(--r);padding:14px 18px;margin:12px 0}
.sl-grp{display:flex;flex-direction:column;gap:6px}
.sl-grp label{font-size:.81rem;color:var(--txt2)}
.sl-grp strong{color:var(--navy);font-weight:600}
input[type=range]{width:100%;accent-color:var(--acc);cursor:pointer}

.cv-bar{margin:10px 0}
.checkbox-lbl{display:flex;align-items:center;gap:6px;font-size:.83rem;cursor:pointer;user-select:none}
.checkbox-lbl input{accent-color:var(--navy);width:14px;height:14px}
.sc-flt{display:flex;gap:16px;margin:8px 0 12px;flex-wrap:wrap}

.col{border:1px solid var(--bdr);border-radius:var(--r);margin:8px 0;overflow:hidden}
.col summary{padding:10px 14px;font-size:.85rem;font-weight:600;cursor:pointer;
             list-style:none;background:var(--surf);color:var(--navy);user-select:none;transition:background .12s}
.col summary::-webkit-details-marker{display:none}
.col summary::before{content:"▶ ";font-size:.68rem;color:var(--txt3);margin-right:4px;
                      transition:transform .18s;display:inline-block}
.col[open] summary::before{transform:rotate(90deg)}
.col summary:hover{background:#F5F8FF}
.col-body{padding:14px;border-top:1px solid var(--bdr);background:var(--bg)}

.rec{background:var(--surf);border:1px solid var(--bdr);border-left:4px solid var(--acc);
     border-radius:var(--r);margin:8px 0;overflow:hidden;transition:box-shadow .13s}
.rec:hover{box-shadow:var(--sh2)}
.rh{padding:10px 14px;display:flex;align-items:center;gap:8px;font-size:.88rem;flex-wrap:wrap;background:#FAFBFC}
.rt{font-size:.73rem;padding:2px 8px;border-radius:999px;background:var(--acc-l);color:var(--acc)}
.rp{font-size:.76rem;font-weight:700;margin-left:auto}
.rb{padding:10px 14px;display:flex;flex-direction:column;gap:6px}
.ri{display:flex;align-items:baseline;gap:8px;font-size:.81rem;flex-wrap:wrap}
.rf2{color:var(--txt2)} .ra2{color:var(--txt3)}
.rc{background:#EEF3FA;padding:2px 8px;border-radius:4px;
    font-family:'JetBrains Mono',monospace;font-size:.76rem;color:var(--navy)}

.two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px}
@media(max-width:960px){
  .two-col{grid-template-columns:1fr}
  .side{display:none}
  .ol-ctrl{grid-template-columns:1fr}
  .ph-badge{display:none}
}
"""


JS = r"""
// ── chart rendering ──────────────────────────────────────────────────────────
function renderCharts(container) {
  var root = container || document;
  // Render pending charts (data-fig present)
  root.querySelectorAll('.pc[data-fig],.pc[data-reg]').forEach(function(el) {
    _renderOneChart(el);
  });
  // Resize already-rendered charts to fix sizing after hidden->visible transitions
  if (window.Plotly) {
    root.querySelectorAll('.pc:not([data-fig])').forEach(function(el) {
      try { if (el.offsetParent !== null) Plotly.Plots.resize(el); } catch(e) {}
    });
  }
}

function _renderOneChart(el) {
  if (!el || !window.Plotly) return;
  if (!el.id) el.id = 'pc_' + Math.random().toString(36).slice(2,8);
  try {
    // Support both registry-based (data-reg) and attribute-based (data-fig) charts
    var fig = null;
    if (el.getAttribute('data-reg')) {
      fig = window._FIGS && window._FIGS[el.id];
      if (!fig) return; // not yet registered
    } else {
      var figStr = el.getAttribute('data-fig');
      if (!figStr) return;
      fig = JSON.parse(figStr);
      el.removeAttribute('data-fig');
    }
    var h   = parseInt(el.getAttribute('data-h') || '320');
    if (!fig || !fig.data || !fig.data.length) {
      // empty fig — still hide loader
      var wrap = el.closest ? el.closest('.chart-wrap') : null;
      if (wrap) { var ldr = wrap.querySelector('.chart-loader'); if (ldr) ldr.classList.add('done'); }
      return;
    }
    if (fig.layout) fig.layout.height = h;
    var config = {
      responsive: true,
      displayModeBar: true,
      modeBarButtonsToRemove: ['sendDataToCloud','lasso2d','select2d'],
      displaylogo: false
    };
    Plotly.newPlot(el.id, fig.data, fig.layout || {}, config);
    el.removeAttribute('data-fig');
    var wrap = el.closest ? el.closest('.chart-wrap') : null;
    if (wrap) { var loader = wrap.querySelector('.chart-loader'); if (loader) loader.classList.add('done'); }
  } catch(e) { console.warn('Chart error', el.id, e); }
}

// ── tab navigation ────────────────────────────────────────────────────────────
function showTab(id) {
  document.querySelectorAll('.tp').forEach(function(p){ p.classList.remove('on'); });
  document.querySelectorAll('.ni').forEach(function(n){ n.classList.remove('on'); });
  var pane = document.getElementById(id);
  if (pane) {
    pane.classList.add('on');
    // Make sure first sub-panel is visible before rendering
    var firstST = pane.querySelector('.st');
    if (firstST) { firstST.classList.add('on'); firstST.style.display = 'block'; }
    renderCharts(pane);
    // Second pass after layout settles (fixes heatmap sizing)
    setTimeout(function(){ renderCharts(pane); }, 150);
  }
  var nav = document.querySelector('[data-tab="'+id+'"]');
  if (nav) nav.classList.add('on');
  window.scrollTo({top:0, behavior:'smooth'});
}

// ── sub-tab navigation ────────────────────────────────────────────────────────
function showST(btn, panelId) {
  var pane = document.getElementById(panelId);
  if (!pane) return;
  var tp = btn.closest('.tp') || document;
  tp.querySelectorAll('.st').forEach(function(p){
    p.classList.remove('on'); p.style.display='none';
  });
  tp.querySelectorAll('.stab').forEach(function(b){ b.classList.remove('on'); });
  pane.classList.add('on');
  pane.style.display = 'block';
  btn.classList.add('on');
  // First pass: render any pending charts
  renderCharts(pane);
  // Second pass at 250ms: Plotly needs the container to be visible with real dimensions
  setTimeout(function(){
    renderCharts(pane);
    // Force resize all already-rendered charts in this panel
    if (window.Plotly) {
      pane.querySelectorAll('.pc:not([data-fig])').forEach(function(el){
        try { Plotly.relayout(el.id, {autosize:true}); } catch(e){}
      });
    }
  }, 300);
}

// ── scale toggle ──────────────────────────────────────────────────────────────
function togScale(btn, showId, hideId) {
  var s = document.getElementById(showId);
  var h = document.getElementById(hideId);
  if (s) { s.style.display = 'block'; renderCharts(s); setTimeout(function(){ renderCharts(s); }, 100); }
  if (h) { h.style.display = 'none'; }
  var grp = btn.closest('.stog');
  if (grp) grp.querySelectorAll('.stob').forEach(function(b){ b.classList.remove('on'); });
  btn.classList.add('on');
}

// ── fullscreen chart ──────────────────────────────────────────────────────────
function fsChart(cid) {
  var src = document.getElementById(cid);
  if (!src || !window.Plotly) return;
  var overlay = document.getElementById('fs-overlay');
  var plot    = document.getElementById('fs-plot');
  if (!overlay || !plot) return;
  // clone figure data
  var data   = src.data || src._fullData || [];
  var layout = Object.assign({}, src.layout || {});
  layout.height = Math.floor(window.innerHeight * 0.8);
  layout.width  = undefined;
  layout.autosize = true;
  Plotly.newPlot(plot, data, layout, {responsive:true, displayModeBar:true, displaylogo:false});
  overlay.classList.add('on');
}
function closeFSChart() {
  var overlay = document.getElementById('fs-overlay');
  if (overlay) overlay.classList.remove('on');
  var plot = document.getElementById('fs-plot');
  if (plot && window.Plotly) Plotly.purge(plot);
}
// close on backdrop click
document.addEventListener('click', function(e) {
  var ov = document.getElementById('fs-overlay');
  if (e.target === ov) closeFSChart();
});

// ── table sort ────────────────────────────────────────────────────────────────
document.addEventListener('click', function(e) {
  var th = e.target.closest('th');
  if (!th) return;
  var tbl = th.closest('table.sortable');
  if (!tbl) return;
  var idx   = Array.from(th.parentNode.children).indexOf(th);
  var tbody = tbl.querySelector('tbody');
  var rows  = Array.from(tbody.querySelectorAll('tr:not([style*="display: none"])'));
  var all   = Array.from(tbody.querySelectorAll('tr'));
  var asc   = th.classList.contains('sa');
  tbl.querySelectorAll('th').forEach(function(h){ h.classList.remove('sa','sd'); });
  all.sort(function(a, b) {
    var av = a.cells[idx] ? a.cells[idx].textContent.trim() : '';
    var bv = b.cells[idx] ? b.cells[idx].textContent.trim() : '';
    var an = parseFloat(av.replace(/[,%+]/g,'')), bn = parseFloat(bv.replace(/[,%+]/g,''));
    if (!isNaN(an) && !isNaN(bn)) return asc ? an-bn : bn-an;
    return asc ? av.localeCompare(bv) : bv.localeCompare(av);
  });
  all.forEach(function(r){ tbody.appendChild(r); });
  th.classList.add(asc ? 'sd' : 'sa');
});

// ── table search ──────────────────────────────────────────────────────────────
document.addEventListener('input', function(e) {
  if (!e.target.classList.contains('srch')) return;
  var q   = e.target.value.toLowerCase();
  var id  = e.target.getAttribute('data-tgt');
  var tbl = id ? document.getElementById(id) : null;
  if (!tbl) return;
  tbl.querySelectorAll('tbody tr').forEach(function(r) {
    r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
});

// ── outlier sliders ───────────────────────────────────────────────────────────
function updOutlier(idx, lo, hi) {
  var lsl = document.getElementById('lo_sl_'+idx);
  var hsl = document.getElementById('hi_sl_'+idx);
  if (!lsl || !hsl) return;
  var lv = lo !== null ? parseInt(lo) : parseInt(lsl.value);
  var hv = hi !== null ? parseInt(hi) : parseInt(hsl.value);
  var od = document.getElementById('od'+idx);
  if (!od) return;
  var pcts  = JSON.parse(od.getAttribute('data-pct') || '[]');
  var total = parseInt(od.getAttribute('data-n') || '0');
  if (!pcts.length) return;
  var lp = pcts[lv], hp = pcts[hv];
  // update labels
  var ll = document.getElementById('lo_lbl_'+idx);
  var hl = document.getElementById('hi_lbl_'+idx);
  if (ll) ll.textContent = 'P'+lv+' = '+lp.toPrecision(5);
  if (hl) hl.textContent = 'P'+hv+' = '+hp.toPrecision(5);
  // update metric cards
  var ep  = document.getElementById('ol_plo_'+idx);
  var ep2 = document.getElementById('ol_phi_'+idx);
  var elb = document.getElementById('ol_lbplo_'+idx);
  var elb2= document.getElementById('ol_lbphi_'+idx);
  var ec  = document.getElementById('ol_cnt_'+idx);
  var epc = document.getElementById('ol_pct_'+idx);
  if (ep)   ep.textContent  = lp.toPrecision(5);
  if (ep2)  ep2.textContent = hp.toPrecision(5);
  if (elb)  elb.textContent = 'P'+lv;
  if (elb2) elb2.textContent= 'P'+hv;
  // count using sampled array
  var arr = JSON.parse(od.getAttribute('data-arr') || '[]');
  if (arr.length && total > 0) {
    var nOut = arr.filter(function(v){ return v < lp || v > hp; }).length;
    var nEst = Math.round(nOut / arr.length * total);
    var pEst = (nOut / arr.length * 100).toFixed(2);
    if (ec)  ec.textContent  = nEst.toLocaleString() + (arr.length < total ? '~' : '');
    if (epc) epc.textContent = pEst + '%';
  }
  // update boxplot vlines
  var bd = document.getElementById('ob'+idx);
  if (bd && window.Plotly) {
    Plotly.relayout(bd, {shapes:[
      {type:'line',x0:lp,x1:lp,y0:0,y1:1,yref:'paper',line:{color:'#f59e0b',dash:'dash',width:2}},
      {type:'line',x0:hp,x1:hp,y0:0,y1:1,yref:'paper',line:{color:'#ef4444',dash:'dash',width:2}}
    ]});
  }
  // update histogram vrects
  var hd = document.getElementById('oh'+idx);
  if (hd && window.Plotly) {
    var p1=pcts[1], p99=pcts[99], pad=(p99-p1)*.05;
    var shapes=[];
    if (lp > p1-pad) shapes.push({type:'rect',x0:p1-pad,x1:lp,y0:0,y1:1,yref:'paper',
      fillcolor:'#f59e0b',opacity:.12,line:{width:0}});
    if (hp < p99+pad) shapes.push({type:'rect',x0:hp,x1:p99+pad,y0:0,y1:1,yref:'paper',
      fillcolor:'#ef4444',opacity:.12,line:{width:0}});
    Plotly.relayout(hd, {shapes: shapes});
  }
}

// ── corr threshold ────────────────────────────────────────────────────────────
function filtCorr(val) {
  var t = val / 100;
  var lbl = document.getElementById('cth-lbl');
  if (lbl) lbl.textContent = t.toFixed(2);
  var tbl = document.getElementById('cth-tbl');
  var cnt = 0;
  if (tbl) {
    tbl.querySelectorAll('tbody tr').forEach(function(row) {
      var cell = row.cells[2];  // Pearson r is 3rd column
      if (!cell) return;
      var v = Math.abs(parseFloat(cell.textContent));
      var show = !isNaN(v) && v >= t;
      row.style.display = show ? '' : 'none';
      if (show) cnt++;
    });
  }
  var ce = document.getElementById('cth-cnt');
  if (ce) ce.textContent = cnt + ' pairs with |r| \u2265 ' + t.toFixed(2);
}

// ── scorecard filter ──────────────────────────────────────────────────────────
function filtSC() {
  var checked = Array.from(document.querySelectorAll('.scf:checked'))
    .map(function(cb){ return cb.value; });
  var tbl = document.getElementById('sc-tbl');
  if (!tbl) return;
  tbl.querySelectorAll('tbody tr').forEach(function(row) {
    var txt = row.textContent;
    var show = checked.some(function(v){ return txt.includes(v); });
    row.style.display = show ? '' : 'none';
  });
}

// ── recs filter ───────────────────────────────────────────────────────────────
function filtRecs() {
  var checked = Array.from(document.querySelectorAll('.rf:checked'))
    .map(function(cb){ return cb.value; });
  document.querySelectorAll('.rec').forEach(function(c) {
    var p = c.getAttribute('data-p') || '';
    c.style.display = checked.some(function(v){ return p === v; }) ? '' : 'none';
  });
}

// ── init ──────────────────────────────────────────────────────────────────────
window.addEventListener('load', function() {
  // activate first tab + render
  var firstTab = document.querySelector('.tp');
  var firstNav = document.querySelector('.ni');
  if (firstTab) { firstTab.classList.add('on'); }
  if (firstNav) firstNav.classList.add('on');

  // activate first sub-tab in EVERY tab (all tabs need their first ST visible
  // even when the tab itself is hidden, so clicking the tab shows charts)
  document.querySelectorAll('.tp').forEach(function(tp) {
    var firstST  = tp.querySelector('.st');
    var firstBtn = tp.querySelector('.stab');
    if (firstST)  { firstST.classList.add('on');  firstST.style.display = 'block'; }
    if (firstBtn)   firstBtn.classList.add('on');
  });

  // Render charts in the first (visible) tab now
  if (firstTab) renderCharts(firstTab);

  // Second pass for any charts that need layout to settle
  setTimeout(function() {
    if (firstTab) renderCharts(firstTab);
  }, 200);

  // corr threshold init
  var csl = document.getElementById('cth-sl');
  if (csl) filtCorr(csl.value);
});
"""

# ── fullscreen overlay HTML ───────────────────────────────────────────────────
FS_OVERLAY = """
<div id="fs-overlay">
  <div id="fs-container">
    <button id="fs-close" onclick="closeFSChart()" title="Close">✕</button>
    <div id="fs-plot"></div>
  </div>
</div>
"""


# ── main entry point ──────────────────────────────────────────────────────────
def generate_report(results: dict,
                    output_path=None,
                    open_browser: bool = True,
                    offline: bool = False) -> str:
    """
    Generate a self-contained interactive HTML EDA dashboard.

    Parameters
    ----------
    results      : dict returned by run_eda()
    output_path  : optional file path to save  (e.g. "report.html")
    open_browser : auto-open in browser after saving (local only)
    offline      : embed Plotly.js inline (larger file, no internet needed)

    Returns
    -------
    str : complete HTML string

    Examples
    --------
    generate_report(results, output_path="report.html")   # save + open
    html = generate_report(results)                        # get string
    displayHTML(html)                                      # Databricks
    """
    target  = results.get("target_col")
    n_rows  = results.get("n_rows", 0)
    n_feat  = results.get("n_features", 0)
    elapsed = results.get("elapsed_sec", 0)
    dm      = results.get("dtype_map", {})
    sc      = results.get("scorecard", pd.DataFrame())
    n_fix   = int((sc["Status"] == "❌ Fix First").sum()) if len(sc) else 0
    n_rev   = int((sc["Status"] == "⚠️ Review").sum())   if len(sc) else 0
    n_ok    = int((sc["Status"] == "✅ Good").sum())      if len(sc) else 0
    tot_sc  = len(sc)

    TABS = [
        ("tab-ov",  "📋", "Overview"),
        ("tab-vex", "🔬", "Variable Explorer"),
        ("tab-hr",  "💧", "Hit Rate"),
        ("tab-cq",  "🏷️", "Category Quality"),
        ("tab-ol",  "⚡", "Outliers"),
        ("tab-co",  "🔗", "Correlations"),
        ("tab-cp",  "⚖️", "Comparison"),
        ("tab-ta",  "🎯", "Target Analysis"),
        ("tab-sc",  "🏆", "Scorecard"),
    ]
    nav = "\n".join(
        f'<div class="ni" data-tab="{tid}" onclick="showTab(\'{tid}\')">'
        f'<span class="ni-ic">{ic}</span>{lbl}</div>'
        for tid, ic, lbl in TABS
    )

    # section breadcrumbs for each tab
    TAB_LABELS = {tid: (ic, lbl) for tid, ic, lbl in TABS}

    wf = round(n_fix/tot_sc*200) if tot_sc else 0
    wr = round(n_rev/tot_sc*200) if tot_sc else 0
    wo = 200 - wf - wr
    type_s = "  ·  ".join(f"{c} {t}" for t, c in pd.Series(dm).value_counts().items()) if dm else ""

    sidebar = f'''<div class="side">
  <div class="sh2">
    <div class="sl-logo">
      <div class="sl-icon">RC</div>
      <div>
        <div class="sl">Risk Cohorts App</div>
        <div class="ss">Chubb · EDA Analytics · v5</div>
      </div>
    </div>
  </div>
  <div class="sn">Navigation</div>
  {nav}
  <div class="sts">
    <div class="sr"><span>Rows</span><strong>{n_rows:,}</strong></div>
    <div class="sr"><span>Columns</span><strong>{n_feat}</strong></div>
    <div class="sr"><span>Target</span><strong>{_esc(target or "—")}</strong></div>
    <div class="sr"><span>Runtime</span><strong>{elapsed:.1f}s</strong></div>
    {"" if not tot_sc else f'''
    <div class="sr" style="margin-top:10px"><span>Quality</span></div>
    <div class="qb">
      <div style="width:{wf}px;background:#ef4444"></div>
      <div style="width:{wr}px;background:#f59e0b"></div>
      <div style="width:{wo}px;background:#22c55e"></div>
    </div>
    <div class="sr"><span>🔴 Fix</span><strong>{n_fix}</strong></div>
    <div class="sr"><span>🟡 Review</span><strong>{n_rev}</strong></div>
    <div class="sr"><span>🟢 Good</span><strong>{n_ok}</strong></div>'''}
  </div>
</div>'''

    header = f'''<div class="ph">
  <div class="ph-inner">
    <div class="ph-left">
      <div class="ph-tag">Chubb · Risk Cohorts</div>
      <h1>Exploratory Data Analysis Dashboard</h1>
      <p>{n_rows:,} rows  ·  {n_feat} features  ·  {type_s}  ·  Target: {_esc(target or "—")}  ·  {elapsed:.1f}s</p>
    </div>
    <div class="ph-badge">EDA v5</div>
  </div>
</div>'''

    print("[HTML] Building sections...", end="", flush=True)

    # Import Target Analysis module
    try:
        from .target_analysis_html import build_ta_html, TA_CSS, TA_JS
    except ImportError:
        try:
            from target_analysis_html import build_ta_html, TA_CSS, TA_JS
        except ImportError:
            build_ta_html = lambda R: '<div class="al" style="background:#fffbeb;color:#78350f;border-left:3px solid #f59e0b">Target Analysis module not found.</div>'
            TA_CSS = ""
            TA_JS  = ""

    builders = [
        ("tab-ov",  _overview),
        ("tab-vex", _variable_explorer),
        ("tab-hr",  _hit_rate),
        ("tab-cq",  _category_quality),
        ("tab-ol",  _outliers),
        ("tab-co",  _correlations),
        ("tab-cp",  _comparison),
        ("tab-ta",  build_ta_html),
        ("tab-sc",  _scorecard),
    ]
    panes = []
    for tid, fn in builders:
        ic, lbl = TAB_LABELS.get(tid, ("",""))
        breadcrumb = f'<div class="sec-crumb">{ic} <span>{_esc(lbl)}</span></div>'
        try:
            content = fn(results)
        except Exception as e:
            import traceback
            content = alert(f"Error building section: {_esc(str(e))}", "red")
            print(f"\n  [WARN] {tid}: {e}")
        panes.append(f'<div id="{tid}" class="tp">{breadcrumb}{content}</div>')
    print(" done.")

    if offline:
        try:
            import plotly
            js_path = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
            if js_path.exists():
                plotly_tag = f"<script>{js_path.read_text()}</script>"
            else:
                plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'
        except Exception:
            plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'
    else:
        plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>EDA Report — {_esc(target or "no target")} — {n_rows:,} rows</title>
{plotly_tag}
<style>{CSS}{TA_CSS}</style>
</head>
<body>
{FS_OVERLAY}
<div class="lay">
  {sidebar}
  <div class="main">
    {header}
    {"".join(panes)}
  </div>
</div>
<script>{JS}
{TA_JS}
</script>
</body>
</html>"""

    if output_path:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
        size = path.stat().st_size / 1024
        print(f"[HTML] Saved → {path}  ({size:.0f} KB)")
        if open_browser and not str(output_path).startswith("/dbfs"):
            try:
                webbrowser.open(path.resolve().as_uri())
            except Exception:
                pass

    return html
