# EDA Dashboard — Insurance EDA Toolkit v5

Self-contained interactive HTML dashboard for exploratory data analysis.
No server required. Works locally and in Databricks.

---

## Quick Start

```python
from eda_toolkit import inspect, run_eda, generate_report

plan = inspect(df, target_col="frequency")
plan.fix(policy_no="ID-like")
plan.set_sections(correlations=True, category_quality=True, scorecard=True)
plan.confirm()

df_clean = plan.apply_to_df()
results  = run_eda(df_clean, plan)

generate_report(results, output_path="eda_report.html")
```

---

## Installation

```bash
# From zip (recommended)
unzip eda_toolkit_v5.zip
# Then in Python:
import sys
sys.path.insert(0, "path/to/folder/containing/eda_toolkit/")
from eda_toolkit import inspect, run_eda, generate_report

# From Git
pip install git+https://github.com/your-org/eda_toolkit.git

# In Databricks
%pip install git+https://github.com/your-org/eda_toolkit.git
```

---

## Step 1 — inspect()

```python
plan = inspect(df, target_col="pure_premium")
```

Detects column types automatically:

| Type        | Description                              |
|-------------|------------------------------------------|
| Numeric     | Continuous numbers — stats, histograms   |
| Categorical | Discrete labels — frequency tables       |
| Boolean     | Binary 0/1 — treated as Numeric         |
| Date        | Dates — year/month breakdowns            |
| ID-like     | Identifiers — excluded from analysis     |
| Constant    | Zero variance — excluded                 |

**Fix wrong detections:**
```python
plan.fix(
    policy_no    = "ID-like",
    policy_year  = "Categorical",
    claim_flag   = "Boolean",
)
```

---

## Step 2 — Configure sections

```python
plan.set_sections(
    correlations     = True,   # Pearson + Cramér's V (full data, no sampling)
    category_quality = True,   # fuzzy duplicate detection
    scorecard        = True,   # data quality scoring
    target_analysis  = True,   # Target Analysis tab
)
```

**Correlation options:**
```python
plan.set_corr_options(
    corr_threshold = 0.5,    # |r| threshold for high-corr pairs (default 0.75)
)
```

---

## Step 3 — Target Analysis configuration

> Only needed if `target_analysis=True`

```python
plan.set_target_analysis(
    n_bins       = [5, 10, 20],        # bin counts for the slider
    exposure_col = "earned_exposure",  # exposure column name
    bin_by       = "amount",           # "amount" = equal SUM of exposure per bin
                                       # "count"  = equal row count per bin
)
```

**bin_by options:**

| Value    | What it does                              | When to use               |
|----------|-------------------------------------------|---------------------------|
| `amount` | Each bin has equal SUM of exposure_col    | **Recommended for insurance** |
| `count`  | Each bin has equal number of rows         | Baseline comparison       |

**Binning methods pre-computed:**

| Method     | Description                           |
|------------|---------------------------------------|
| `equal`    | Equal-width intervals                 |
| `quantile` | Equal row count per bin               |
| `exposure` | Equal exposure per bin (actuarial)    |

The `exposure` method is automatically included when `exposure_col` is set.

---

## Step 4 — Comparison page

The Comparison tab lets you load multiple DataFrames and compare them side-by-side.

```python
plan.set_comparison(
    df         = df_renewals,            # second DataFrame to compare
    label_a    = "New Business",         # label for original df
    label_b    = "Renewals",             # label for comparison df
    groupby_col= "region",               # group by this column
    agg_cols   = ["premium","claim_amt"],# columns to compare
    agg_config = {
        "premium":   ["sum", "mean"],
        "claim_amt": ["sum", "count"],
    }
)
```

**What the Comparison page shows:**
- Summary statistics for each DataFrame
- Side-by-side grouped bar charts per metric
- Match % per group (colour-coded: green > 95%, amber > 85%, red < 85%)
- Diff % between the two datasets
- TOTAL row at the bottom
- Download CSV for each comparison table

---

## Step 5 — Generate report

```python
# Save locally and auto-open browser
generate_report(results, output_path="eda_report.html")

# Get HTML string (Databricks)
html = generate_report(results)
displayHTML(html)

# Offline mode (embeds Plotly.js, no internet needed)
generate_report(results, output_path="eda_report.html", offline=True)
```

---

## Dashboard Tabs

| Tab              | Contents                                              |
|------------------|-------------------------------------------------------|
| Overview         | Row/column counts, type distribution, missing values  |
| Variable Explorer| Per-variable stats, histograms, category tables       |
| Hit Rate         | Non-null % per feature, bar chart + table             |
| Category Quality | Fuzzy duplicate detection, rare/dominant categories   |
| Outliers         | IQR outliers, interactive percentile sliders          |
| Correlations     | Pearson matrix (full data), Cramér's V, VIF           |
| Comparison       | Multi-DataFrame side-by-side comparison               |
| Target Analysis  | Target vs every feature (see Feature Selection README)|
| Scorecard        | Data quality scores + recommended actions             |

---

## Correlations — what's correct

**Pearson (numeric features):**
- Full data, no sampling
- Symmetric matrix, diagonal = 1.0
- VIF computed via correlation matrix inverse (fast, no regression needed)

**Cramér's V (categorical features):**
- Full data, exact contingency table via `numpy.bincount`
- Never applied to numeric target (avoids spurious V≈1.0)
- When target is numeric: cat features get V computed against binarized target (split at median), shown as `Cramér's V*`
- Strength labels: Strong ≥ 0.3, Moderate 0.1–0.3, Weak < 0.1

---

## Databricks

```python
%pip install git+https://github.com/your-org/eda_toolkit.git

from eda_toolkit import inspect, run_eda, generate_report

plan = inspect(spark.table("catalog.schema.claims").toPandas(),
               target_col="frequency")
plan.set_sections(target_analysis=True)
plan.set_target_analysis(exposure_col="earned_exposure", bin_by="amount")
plan.confirm()

results = run_eda(plan.apply_to_df(), plan)

html = generate_report(results)
displayHTML(html)

# Or save to DBFS
generate_report(results, output_path="/dbfs/FileStore/reports/eda.html")
```

---

## Performance (2.47M rows × 113 features)

| Section          | Time   |
|------------------|--------|
| Column analysis  | ~15s   |
| Correlations     | ~25s   |
| Scorecard        | ~2s    |
| Target Analysis  | ~30s   |
| HTML generation  | ~5s    |
| **Total**        | **~77s** |
