"""
eda_engine.py — Insurance EDA Toolkit v4
Pure computation. No Streamlit. No external calls. 100% local.

v4 additions:
  - _target_analysis(): per-feature correlation/association with target
  - _comparison_summary(): grouped side-by-side comparison of two DataFrames
  - sections config key: dict of bool flags to skip expensive sections
"""

import time, warnings
import numpy as np
import pandas as pd
from scipy.stats import skew as _skew, normaltest

warnings.filterwarnings("ignore")

try:
    from rapidfuzz import fuzz as _fuzz
    def _similarity(a, b):
        return _fuzz.token_sort_ratio(a, b) / 100.0
    _FUZZY_LIB = "rapidfuzz"
except ImportError:
    from difflib import SequenceMatcher
    def _similarity(a, b):
        return SequenceMatcher(None, a.lower(), b.lower()).ratio()
    _FUZZY_LIB = "difflib"


# ── helpers ───────────────────────────────────────────────────────────────────

def _samp(arr, n):
    if len(arr) == 0: return arr
    if len(arr) <= n: return arr
    return arr[np.random.choice(len(arr), n, replace=False)]

def _log(msg, pct=0):
    print(f"[EDA {pct:3d}%] {msg}")

def _nunique(s):
    clean = s.dropna()
    n = len(clean)
    if n == 0: return 0
    if n <= 50_000: return int(clean.nunique())
    return int(clean.sample(50_000, random_state=42).nunique())


# ── type detection ────────────────────────────────────────────────────────────

_BOOL_STRINGS = [
    {"0","1"}, {"y","n"}, {"yes","no"}, {"true","false"}, {"t","f"},
    {"1.0","0.0"}, {"male","female"}, {"m","f"},
]

def _try_parse_date(s) -> bool:
    sample = s.dropna().astype(str).head(300)
    if len(sample) < 5: return False
    has_sep   = sample.str.contains(r'[-/: ]', regex=True)
    has_digit = sample.str.contains(r'\d', regex=True)
    if (has_sep & has_digit).mean() < 0.7: return False
    try:
        p1 = pd.to_datetime(sample, errors="coerce")
        if float(p1.notna().mean()) >= 0.80: return True
        p2 = pd.to_datetime(sample, errors="coerce", dayfirst=True)
        return float(p2.notna().mean()) >= 0.80
    except Exception:
        return False

def _is_bool_strings(s) -> bool:
    raw_unique = s.dropna().astype(str).str.strip().unique()
    if len(raw_unique) == 0 or len(raw_unique) > 2: return False
    lower_unique = set(v.lower() for v in raw_unique)
    return lower_unique in _BOOL_STRINGS

def detect_type(s, id_ratio=0.8) -> str:
    n = len(s)
    if n == 0 or s.isna().all(): return "Unknown"
    if pd.api.types.is_bool_dtype(s): return "Boolean"
    if pd.api.types.is_datetime64_any_dtype(s): return "Date"
    if pd.api.types.is_numeric_dtype(s):
        nu = _nunique(s)
        if nu == 0: return "Unknown"
        if nu == 1: return "Constant"
        if nu == 2: return "Boolean"
        clean = s.dropna()
        if nu <= 150:
            try:
                vals = clean.astype(float)
                if ((vals >= 1900) & (vals <= 2100)).mean() > 0.95 and \
                   (vals == vals.round(0)).mean() > 0.99:
                    return "Date"
            except Exception:
                pass
        if nu / n > id_ratio:
            try:
                if (clean.head(200) == clean.head(200).round(0)).mean() > 0.99:
                    return "ID-like"
            except Exception:
                pass
        return "Numeric"
    if _is_bool_strings(s): return "Boolean"
    nu = _nunique(s)
    if nu == 0: return "Unknown"
    if nu == 1: return "Constant"
    if _try_parse_date(s): return "Date"
    if nu / n > id_ratio: return "ID-like"
    return "Categorical"


# ── per-column analysis ───────────────────────────────────────────────────────

def _analyse_numeric(col, s, n_total, plot_n=20_000, norm_n=5_000):
    if s.dtype == object:
        _TRUE = {"1","y","yes","true","t","1.0","male","m"}
        s = pd.to_numeric(
            s.map(lambda v: 1.0 if str(v).strip().lower() in _TRUE
                  else (0.0 if pd.notna(v) else np.nan)),
            errors="coerce")
    arr       = pd.to_numeric(s, errors="coerce").to_numpy(dtype=float, na_value=np.nan)
    missing   = int(np.isnan(arr).sum())
    inf_count = int(np.isinf(arr).sum())
    clean     = arr[~np.isnan(arr) & ~np.isinf(arr)]
    nc        = len(clean)

    base = dict(
        dtype="Numeric", missing_count=missing,
        missing_pct=round(missing / n_total * 100, 1),
        hit_rate_pct=round((n_total - missing) / n_total * 100, 1),
        inf_count=inf_count, inf_pct=round(inf_count / n_total * 100, 2),
        n_unique=0, zero_pct=0.0, dist={}, outlier={},
        plot_sample=[], zero_inflated=False, skewness=None,
    )
    if nc == 0: return base

    pcts     = np.percentile(clean, [1, 5, 10, 25, 50, 75, 90, 95, 99])
    mean     = float(clean.mean())
    std      = float(clean.std()) if nc > 1 else 0.0
    zero_pct = round(float((clean == 0).mean()) * 100, 1)
    zero_inf = zero_pct > 30
    nu       = int(pd.Series(_samp(clean, 50_000)).nunique())
    base.update(n_unique=nu, zero_pct=zero_pct, zero_inflated=zero_inf)

    sk = round(float(_skew(clean)), 3) if nc > 3 else 0.0
    if not np.isfinite(sk): sk = 0.0
    base["skewness"] = sk

    pos = clean[clean > 0]; is_ln = False
    if len(pos) > 50:
        try:
            _, lp = normaltest(np.log(_samp(pos, norm_n))); is_ln = bool(lp > 0.05)
        except Exception: pass

    tags = []
    if zero_inf:            tags.append("Zero-Inflated")
    if is_ln and sk > 0.5:  tags.append("Log-Normal")
    elif sk > 1.0:           tags.append("Right-Skewed")
    elif sk < -1.0:          tags.append("Left-Skewed")
    if not tags:             tags.append("Near-Normal")

    base["dist"] = dict(
        mean=round(mean,4), median=round(float(pcts[4]),4), std=round(std,4),
        min=round(float(clean.min()),4), max=round(float(clean.max()),4),
        p25=round(float(pcts[3]),4), p75=round(float(pcts[5]),4),
        p95=round(float(pcts[7]),4), p99=round(float(pcts[8]),4),
        skewness=sk, is_lognormal=is_ln, shape=", ".join(tags),
    )

    k = 1.5
    if zero_inf:
        nz = clean[clean > 0]
        q1 = float(np.percentile(nz, 25)) if len(nz) else 0.0
        q3 = float(np.percentile(nz, 75)) if len(nz) else 0.0
        iqr = q3 - q1; fence_lo = 0.0; fence_hi = round(q3 + k*iqr, 4)
        iqr_cnt = int((clean > fence_hi).sum()); note = "IQR on non-zero values (zero-inflated)"
    else:
        q1, q3 = float(pcts[3]), float(pcts[5]); iqr = q3 - q1
        fence_lo = round(q1 - k*iqr, 4); fence_hi = round(q3 + k*iqr, 4)
        iqr_cnt = int(((clean < fence_lo) | (clean > fence_hi)).sum()); note = ""

    base["outlier"] = dict(
        q1=round(q1,4), q3=round(q3,4), iqr=round(iqr,4),
        fence_lo=fence_lo, fence_hi=fence_hi,
        iqr_count=iqr_cnt, iqr_pct=round(iqr_cnt/nc*100,1),
        p99_cap=round(float(pcts[8]),4), note=note,
    )
    base["plot_sample"] = _samp(clean, plot_n).tolist()
    return base


def _analyse_categorical(col, s, n_total, rare_pct=1.0):
    missing = int(s.isna().sum())
    vc  = s.value_counts(dropna=True)
    nu  = len(vc)
    top = round(float(vc.iloc[0]) / n_total * 100, 1) if nu else 0.0
    hr  = pd.DataFrame({
        "Category": vc.index.astype(str),
        "Count":    vc.values,
        "Share %":  (vc.values / n_total * 100).round(1),
    }).head(30)
    hr["Flag"] = hr["Share %"].apply(
        lambda x: "RARE" if x < rare_pct else ("DOMINANT" if x > 80 else ""))
    return dict(
        dtype="Categorical",
        missing_count=missing, missing_pct=round(missing/n_total*100,1),
        hit_rate_pct=round((n_total-missing)/n_total*100,1),
        inf_count=0, inf_pct=0.0, n_unique=nu, top_val_pct=top,
        category_table=hr, rare_count=int((hr["Flag"]=="RARE").sum()),
        dist={}, outlier={}, plot_sample=[], zero_inflated=False, skewness=None,
    )


# ── target analysis ───────────────────────────────────────────────────────────

def _cramers_v(x, y):
    try:
        ct   = pd.crosstab(x, y)
        n    = ct.values.sum()
        if n == 0: return 0.0
        exp  = np.outer(ct.sum(axis=1), ct.sum(axis=0)) / n
        chi2 = float(((ct.values - exp)**2 / (exp + 1e-9)).sum())
        r, k = ct.shape
        return round(float(np.sqrt(chi2 / n / max(min(k-1, r-1), 1))), 4)
    except Exception:
        return None

def _target_analysis(df, col_results, dtype_map, target_col, sample_n=50_000):
    if target_col not in df.columns: return {}
    t       = df[target_col].copy()
    t_num   = pd.to_numeric(t, errors="coerce")
    t_clean = t_num.dropna()
    t_nu    = int(t_clean.nunique()) if len(t_clean) else 0
    if t_nu == 0: return {}
    t_flavour = "binary" if t_nu <= 2 else ("categorical" if (t_nu <= 20 or not pd.api.types.is_numeric_dtype(t)) else "numeric")

    results = {}
    for col, res in col_results.items():
        dtype = res["dtype"]
        entry = dict(method="—", stat=None, pvalue=None, abs_stat=0.0,
                     label="—", bar_data=None, scatter_x=None, scatter_y=None,
                     t_flavour=t_flavour)
        try:
            if dtype in ("Numeric", "Boolean"):
                feat_num = pd.to_numeric(df[col], errors="coerce")
                mask     = feat_num.notna() & t_num.notna()
                f_v = feat_num[mask]; t_v = t_num[mask]
                if len(f_v) < 30: results[col] = entry; continue
                if len(f_v) > sample_n:
                    idx = np.random.choice(len(f_v), sample_n, replace=False)
                    f_v = f_v.iloc[idx]; t_v = t_v.iloc[idx]
                from scipy.stats import pearsonr
                r, p = pearsonr(f_v, t_v)
                method = "Pearson r" if t_flavour == "numeric" else "Point-biserial r"
                scat_idx = np.random.choice(len(f_v), min(3000, len(f_v)), replace=False)
                entry.update(method=method, stat=round(r,4), pvalue=round(p,6),
                             abs_stat=abs(r), label=f"r = {r:.3f}",
                             scatter_x=f_v.values[scat_idx].tolist(),
                             scatter_y=t_v.values[scat_idx].tolist())

            elif dtype == "Categorical":
                feat_s = df[col].dropna()
                t_s    = t[feat_s.index].dropna()
                feat_s = feat_s.loc[t_s.index]
                if len(feat_s) < 30: results[col] = entry; continue
                if t_flavour in ("binary", "numeric"):
                    t_num_s = pd.to_numeric(t_s, errors="coerce")
                    grp = (pd.DataFrame({"cat": feat_s.values, "target": t_num_s.values})
                             .dropna().groupby("cat")["target"]
                             .agg(["mean","count"]).reset_index())
                    grp.columns = ["Category","Mean Target","Count"]
                    grp = grp.sort_values("Mean Target", ascending=False).head(30)
                    grp["Mean Target"] = grp["Mean Target"].round(4)
                    t_bin = (t_num >= t_num.median()).astype(str)
                    v = _cramers_v(feat_s, t_bin)
                    entry.update(method="Mean Rate / Cramér's V", stat=v,
                                 abs_stat=v if v else 0.0,
                                 label=f"V = {v:.3f}" if v else "V = —",
                                 bar_data=grp)
                else:
                    v = _cramers_v(feat_s, t_s)
                    entry.update(method="Cramér's V", stat=v,
                                 abs_stat=v if v else 0.0,
                                 label=f"V = {v:.3f}" if v else "V = —")
        except Exception:
            pass
        results[col] = entry
    return results


# ── correlations ──────────────────────────────────────────────────────────────

def _correlations(df, corr_sample=100_000, threshold=0.75, max_vars=999, target_col=None):
    from scipy.stats import chi2_contingency

    out = dict(
        pearson=pd.DataFrame(), high_corr=[], pair_table=pd.DataFrame(),
        vif=pd.DataFrame(), n_vars=0, sampled=False, sample_size=0,
        total_rows=len(df),
        cat_chi2=pd.DataFrame(),   # categorical chi-square table
    )

    # ── 1. NUMERIC PEARSON ────────────────────────────────────────────────────
    num = df.select_dtypes(include=[np.number]).columns.tolist()
    # Always include all numeric columns — no cap
    out["n_vars"] = len(num)

    if len(num) >= 2:
        df_num  = df[num]
        df_samp = df_num.sample(corr_sample, random_state=42) if len(df_num) > corr_sample else df_num
        out["sampled"]     = len(df_num) > corr_sample
        out["sample_size"] = len(df_samp)

        try:    pearson_mat = df_samp.corr(method="pearson", min_periods=30).round(3)
        except: pearson_mat = df_samp.corr(method="pearson").round(3)
        out["pearson"] = pearson_mat

        # High-corr pairs (exclude target self-pairs)
        cols = pearson_mat.columns.tolist(); C = pearson_mat.values; pairs = []
        for i in range(len(cols)):
            for j in range(i+1, len(cols)):
                v = C[i,j]
                if np.isnan(v): continue
                r = round(float(v), 3)
                if abs(r) >= threshold:
                    pairs.append({"Feature A":cols[i],"Feature B":cols[j],"Pearson r":r,"Abs r":abs(r)})
        out["high_corr"] = sorted(pairs, key=lambda x: x["Abs r"], reverse=True)

        # Pair table
        pair_rows = []
        for i in range(len(cols)):
            for j in range(i+1, len(cols)):
                pv = pearson_mat.iloc[i,j]
                if np.isnan(pv): continue
                pair_rows.append({"Variable A":cols[i],"Variable B":cols[j],
                                   "Pearson r":round(float(pv),3),
                                   "Abs r":abs(round(float(pv),3))})
        if pair_rows:
            out["pair_table"] = (pd.DataFrame(pair_rows)
                                   .sort_values("Abs r", ascending=False)
                                   .drop(columns=["Abs r"])
                                   .reset_index(drop=True))

        # VIF — all numeric features (excluding target)
        try:
            from sklearn.linear_model import LinearRegression
            vif_cols = [c for c in num if c != target_col]
            if len(vif_cols) >= 2:
                X = df[vif_cols].fillna(df[vif_cols].median(numeric_only=True)).values[:20_000].astype(float)
                vifs = []
                for i in range(len(vif_cols)):
                    yi = X[:,i]; Xi = np.delete(X,i,axis=1)
                    try:
                        r2 = LinearRegression().fit(Xi,yi).score(Xi,yi)
                        vifs.append(round(1/(1-r2) if r2 < 0.9999 else 999.0, 1))
                    except: vifs.append(None)
                vdf = pd.DataFrame({"Feature":vif_cols,"VIF":vifs}).dropna()
                vdf["VIF"] = vdf["VIF"].astype(float)
                vdf = vdf.sort_values("VIF",ascending=False).reset_index(drop=True)
                vdf["Flag"] = vdf["VIF"].apply(lambda v: "🔴 HIGH >10" if v>10 else ("🟡 MOD 5–10" if v>5 else "🟢 OK"))
                out["vif"] = vdf
        except Exception: pass

        # Target correlation table (numeric target vs numeric features)
        out["target_col"] = target_col
        target_corr = pd.DataFrame()
        if target_col and target_col in pearson_mat.columns:
            tc = pearson_mat[target_col].drop(target_col, errors="ignore").reset_index()
            tc.columns = ["Feature", "Pearson r"]
            tc["Abs r"] = tc["Pearson r"].abs()
            tc = tc.sort_values("Abs r", ascending=False).drop(columns=["Abs r"]).reset_index(drop=True)
            target_corr = tc
        out["target_corr"] = target_corr
    else:
        out["target_corr"] = pd.DataFrame()
        out["target_col"]  = target_col

    # ── 2. CATEGORICAL CHI-SQUARE ─────────────────────────────────────────────
    # Collect all categorical/object/string columns
    cat_cols = [c for c in df.columns
                if df[c].dtype.name in ("category", "object", "string")
                or str(df[c].dtype).startswith("category")]

    # Also treat low-cardinality numeric columns as categorical for chi-square
    # (catches binary targets like 0/1 and small integer codes)
    for c in df.columns:
        if c not in cat_cols and pd.api.types.is_numeric_dtype(df[c]):
            if 1 < df[c].nunique() <= 20:
                cat_cols.append(c)

    # Make sure target is always included
    if target_col and target_col in df.columns and target_col not in cat_cols:
        cat_cols = [target_col] + cat_cols

    chi_rows = []
    if len(cat_cols) >= 2:
        samp_chi = df.sample(min(50_000, len(df)), random_state=42) if len(df) > 50_000 else df
        for i in range(len(cat_cols)):
            for j in range(i+1, len(cat_cols)):
                ca, cb = cat_cols[i], cat_cols[j]
                if ca not in samp_chi.columns or cb not in samp_chi.columns: continue
                try:
                    ct = pd.crosstab(samp_chi[ca].astype(str), samp_chi[cb].astype(str))
                    if ct.shape[0] < 2 or ct.shape[1] < 2: continue
                    chi2, p, dof, _ = chi2_contingency(ct)
                    n_ct = ct.values.sum()
                    cramers_v = round(np.sqrt(chi2 / (n_ct * (min(ct.shape)-1))), 4) if n_ct > 0 else None
                    sig = "***" if p < 0.001 else ("**" if p < 0.01 else ("*" if p < 0.05 else "ns"))
                    involves_target = (ca == target_col or cb == target_col)
                    chi_rows.append({
                        "Variable A":   ca,
                        "Variable B":   cb,
                        "Chi²":         round(chi2, 2),
                        "p-value":      round(p, 6),
                        "DoF":          int(dof),
                        "Cramér's V":   cramers_v,
                        "Significance": sig,
                        "vs Target":    "🎯" if involves_target else "",
                    })
                except Exception: continue

        if chi_rows:
            chi_df = (pd.DataFrame(chi_rows)
                        .sort_values("Cramér's V", ascending=False)
                        .reset_index(drop=True))
            out["cat_chi2"] = chi_df

    return out


# ── fuzzy category matching ───────────────────────────────────────────────────

def _fuzzy_categories(col_results, threshold=0.85, max_categories=500):
    results = {}
    for col, res in col_results.items():
        if res["dtype"] != "Categorical": continue
        tbl = res.get("category_table", pd.DataFrame())
        nu  = res.get("n_unique", 0)
        if len(tbl) < 2: continue
        if nu > max_categories: results[col] = []; continue
        cats = tbl["Category"].astype(str).tolist()[:max_categories]
        matches = []
        for i in range(len(cats)):
            for j in range(i+1, len(cats)):
                if cats[i].lower() == cats[j].lower():
                    matches.append({"Category A":cats[i],"Category B":cats[j],"Similarity":1.0})
                else:
                    sim = _similarity(cats[i], cats[j])
                    if sim >= threshold:
                        matches.append({"Category A":cats[i],"Category B":cats[j],"Similarity":round(sim,3)})
        if matches: results[col] = sorted(matches, key=lambda x: -x["Similarity"])
    return results


# ── scorecard ─────────────────────────────────────────────────────────────────

def _scorecard(col_results, corr, fuzzy):
    rows = []
    for col, res in col_results.items():
        dtype = res["dtype"]; mp = res["missing_pct"]
        dist  = res.get("dist",{}); outl = res.get("outlier",{})
        zi    = res.get("zero_inflated",False); nu = res.get("n_unique",0)

        hit_rate = res["hit_rate_pct"]
        if hit_rate>=99: hr_score=100
        elif hit_rate>=90: hr_score=80
        elif hit_rate>=75: hr_score=55
        elif hit_rate>=50: hr_score=30
        else: hr_score=5
        hr_label = f"{hit_rate:.1f}%"

        inf_pct = res.get("inf_pct",0.0)
        if dtype in ("Numeric","Boolean"):
            zero_pct = res.get("zero_pct",0)
            if zero_pct>=99 or inf_pct>5: vv_score=10
            elif zero_pct>=50: vv_score=60
            elif zero_pct>=30: vv_score=75
            else: vv_score=100
            vv_label = (f"{inf_pct:.1f}% Inf" if inf_pct>0 and zero_pct==0
                        else f"{zero_pct:.0f}% zeros, {inf_pct:.1f}% Inf" if inf_pct>0
                        else f"{zero_pct:.0f}% zeros" if zero_pct>0 else "OK")
        elif dtype == "Categorical":
            rare=res.get("rare_count",0); tbl=res.get("category_table",pd.DataFrame())
            dom=float(tbl["Share %"].max()) if len(tbl) else 0
            if dom>=99: vv_score=20
            elif dom>=90: vv_score=60
            elif rare>5: vv_score=70
            elif rare>0: vv_score=85
            else: vv_score=100
            vv_label = (f"Dom {dom:.0f}%" if dom>=80 else f"{rare} rare cats" if rare else "OK")
        elif dtype == "Constant": vv_score=0; vv_label="Constant — zero variance"
        else: vv_score=80; vv_label="—"

        sk = float(dist.get("skewness",0) or 0) if dist else 0.0
        if not np.isfinite(sk): sk=0.0
        if dtype=="Numeric":
            ask=abs(sk)
            if ask<0.5: sk_score=100; sk_label=f"Low ({sk:.2f})"
            elif ask<1.0: sk_score=80; sk_label=f"Mod ({sk:.2f})"
            elif ask<2.0: sk_score=55; sk_label=f"High ({sk:.2f})"
            else: sk_score=25; sk_label=f"V.High ({sk:.2f})"
        else: sk_score=100; sk_label="—"

        if dtype=="Categorical":
            fm=fuzzy.get(col,[]); nm=len(fm)
            if nu>50: cc_score=100; cc_label="Skipped (high-card)"
            elif nm==0: cc_score=100; cc_label="Clean"
            elif nm<=2: cc_score=70; cc_label=f"{nm} similar"
            elif nm<=5: cc_score=45; cc_label=f"{nm} similar"
            else: cc_score=20; cc_label=f"{nm} similar"
        else: cc_score=100; cc_label="—"

        iqr_p = outl.get("iqr_pct",0) if dtype in ("Numeric","Boolean") else None
        if iqr_p is None: ol_score=100; ol_label="—"
        elif dtype=="Constant": ol_score=0; ol_label="Constant"
        elif zi: ol_score=50; ol_label="Zero-Inf"
        elif iqr_p<1: ol_score=100; ol_label=f"Low ({iqr_p:.1f}%)"
        elif iqr_p<3: ol_score=80; ol_label=f"Med ({iqr_p:.1f}%)"
        elif iqr_p<8: ol_score=55; ol_label=f"High ({iqr_p:.1f}%)"
        else: ol_score=25; ol_label=f"V.High ({iqr_p:.1f}%)"

        if dtype=="Constant": hr_score=100; vv_score=0; sk_score=0; cc_score=0; ol_score=0

        overall = round(0.30*hr_score + 0.20*vv_score + 0.15*sk_score + 0.15*cc_score + 0.20*ol_score, 1)
        if overall>=80: rag="✅ Good"; pri=2
        elif overall>=55: rag="⚠️ Review"; pri=1
        else: rag="❌ Fix First"; pri=0

        icons = {"Numeric":"🔢","Categorical":"🏷️","Boolean":"☑️","Date":"📅",
                 "ID-like":"🔑","Unknown":"❓","Constant":"🔒"}
        rows.append({"Feature":col,"Type":f"{icons.get(dtype,'❓')} {dtype}",
                     "Hit Rate":hr_label,"Valid Values":vv_label,"Skewness":sk_label,
                     "Cat Consistency":cc_label,"Outlier Score":ol_label,
                     "Overall (0-100)":overall,"Status":rag,
                     "_hr":hr_score,"_vv":vv_score,"_sk":sk_score,"_cc":cc_score,"_ol":ol_score,"_p":pri})

    df_sc = pd.DataFrame(rows)
    if len(df_sc):
        df_sc = (df_sc.sort_values(["_p","Overall (0-100)"])
                      .drop(columns=["_hr","_vv","_sk","_cc","_ol","_p"])
                      .reset_index(drop=True))
    return df_sc


# ── recommendations ───────────────────────────────────────────────────────────

def _recommendations(col_results, scorecard):
    score_map = {r["Feature"]:r["Status"] for _,r in scorecard.iterrows()} if len(scorecard) else {}
    recs = []
    for col, res in col_results.items():
        dtype=res["dtype"]; mp=res["missing_pct"]
        dist=res.get("dist",{}); outl=res.get("outlier",{})
        zi=res.get("zero_inflated",False); nu=res.get("n_unique",0); inf_p=res.get("inf_pct",0.0)
        items=[]
        if mp>=100 or dtype=="Unknown":
            items.append(("Column entirely null","Drop or investigate data pipeline"))
        elif dtype=="Constant":
            items.append(("Zero-variance constant column","Drop before modelling — carries no information"))
        elif dtype=="Numeric":
            sk=dist.get("skewness",0) if dist else 0
            if inf_p>0: items.append((f"{inf_p:.2f}% Inf values","Investigate; replace or cap Inf"))
            if zi: items.append((f"Zero-inflated ({res.get('zero_pct',0):.0f}% zeros)","Two-part model or Tweedie GLM"))
            if dist.get("is_lognormal") and sk>0.5: items.append(("Log-normal","Apply log1p transform"))
            elif abs(sk)>1.5 and not zi: items.append((f"Highly skewed (skew={sk:.1f})","Apply log1p transform"))
            if not zi and outl.get("iqr_pct",0)>5:
                items.append((f"{outl['iqr_pct']:.1f}% outliers",f"Cap at P99 = {outl.get('p99_cap','?')}"))
            if mp>20: items.append((f"High missing ({mp:.0f}%)",f"Add {col}_missing flag + median impute"))
            elif mp>0: items.append((f"Missing {mp:.0f}%","Median imputation"))
            if nu<=5 and nu>0: items.append(("Very few unique values","Treat as categorical / ordinal"))
        elif dtype=="Categorical":
            if res.get("rare_count",0)>0: items.append((f"{res['rare_count']} rare categories (<1%)","Group into 'Other'"))
            if nu>50: items.append((f"High cardinality ({nu} cats)","Target encode or frequency encode"))
            if mp>0: items.append((f"Missing {mp:.0f}%","Create 'Unknown' category"))
        elif dtype=="ID-like": items.append(("ID column","Exclude from modelling"))
        elif dtype=="Date": items.append(("Date column","Extract year, month, quarter, day-of-week"))
        if not items: continue
        recs.append(dict(Feature=col, Type=dtype, Priority=score_map.get(col,"✅ Good"), Items=items))
    order={"❌ Fix First":0,"⚠️ Review":1,"✅ Good":2}
    recs.sort(key=lambda r: order.get(r["Priority"],3))
    return recs


# ── comparison summary ────────────────────────────────────────────────────────

def _df_summary(df, label, agg_cols_list):
    """
    Produce a descriptive summary table for one DataFrame.
    Returns a DataFrame with columns: Column, Count, Missing%, Sum, Mean, Median, Min, Max
    """
    rows = []
    for col in agg_cols_list:
        if col not in df.columns:
            continue
        s = pd.to_numeric(df[col], errors="coerce")
        rows.append({
            "Column":    col,
            "Count":     int(s.notna().sum()),
            "Missing %": round(s.isna().mean() * 100, 2),
            "Sum":       round(s.sum(), 4),
            "Mean":      round(s.mean(), 4),
            "Median":    round(s.median(), 4),
            "Min":       round(s.min(), 4),
            "Max":       round(s.max(), 4),
        })
    return pd.DataFrame(rows)


def _comparison_summary(df_a, df_b, label_a, label_b, groupby_col, agg_cols, agg_config=None):
    """
    Produce:
      - summary_a / summary_b  : descriptive stats per configured column
      - per_col_tables         : dict of {col_fn -> DataFrame} with one row per group,
                                 columns = [group, A_val, B_val, Diff(A-B), Diff%]
                                 plus a TOTAL row at the bottom
    groupby_col : str or list of column names
    agg_cols    : list of columns — default agg = sum
    agg_config  : dict {col: [funcs]}  e.g. {"Premium": ["sum","mean"], "Policy_Number": ["count","nunique"]}
    """
    # Normalise groupby to list
    if isinstance(groupby_col, str):
        grp_cols = [groupby_col] if groupby_col else []
    else:
        grp_cols = [c for c in (groupby_col or []) if c]

    # Build agg dict: col -> list of funcs
    if agg_config:
        final_agg = {c: (f if isinstance(f, list) else [f]) for c, f in agg_config.items()}
    elif agg_cols:
        final_agg = {c: ["sum"] for c in agg_cols}
    else:
        final_agg = {}

    # Flat list of all configured columns for summary
    all_agg_cols = list(final_agg.keys())

    # ── per-DataFrame descriptive summaries ──────────────────────────────────
    summary_a = _df_summary(df_a, label_a, all_agg_cols)
    summary_b = _df_summary(df_b, label_b, all_agg_cols)

    # ── grouped comparison tables ─────────────────────────────────────────────
    def _apply_agg(df, grp, col, fn):
        """Apply a single aggregation function to col grouped by grp."""
        df2 = df.copy()
        df2[col] = pd.to_numeric(df2[col], errors="coerce")
        if fn == "nunique":
            return df2.groupby(grp)[col].nunique()
        elif fn == "count":
            return df2.groupby(grp)[col].count()
        elif fn == "sum":
            return df2.groupby(grp)[col].sum()
        elif fn == "mean":
            return df2.groupby(grp)[col].mean()
        elif fn == "median":
            return df2.groupby(grp)[col].median()
        else:
            return df2.groupby(grp)[col].agg(fn)

    valid_grp = [c for c in grp_cols if c in df_a.columns and c in df_b.columns]

    # One comparison table per (column, function) combination
    per_col_tables = {}   # key = "Premium_sum", value = DataFrame

    if valid_grp:
        grp_label = "_".join(valid_grp)
        for col, fns in final_agg.items():
            if col not in df_a.columns and col not in df_b.columns:
                continue
            for fn in fns:
                key = f"{col}_{fn}"
                try:
                    sa = _apply_agg(df_a, valid_grp, col, fn) if col in df_a.columns else pd.Series(dtype=float)
                    sb = _apply_agg(df_b, valid_grp, col, fn) if col in df_b.columns else pd.Series(dtype=float)

                    # Align on the union of group values
                    all_groups = sa.index.union(sb.index)
                    sa = sa.reindex(all_groups, fill_value=0.0)
                    sb = sb.reindex(all_groups, fill_value=0.0)

                    rows = []
                    for grp_val in all_groups:
                        va = float(sa.loc[grp_val])
                        vb = float(sb.loc[grp_val])
                        diff      = round(va - vb, 6)
                        diff_pct  = round(abs(diff) / abs(va) * 100, 2) if va != 0 else (0.0 if vb == 0 else 100.0)
                        match_pct = max(0.0, round(100.0 - diff_pct, 2))
                        # group label — handle MultiIndex
                        grp_str = " | ".join(str(v) for v in grp_val) if isinstance(grp_val, tuple) else str(grp_val)
                        rows.append({
                            grp_label:           grp_str,
                            f"{label_a}":        round(va, 4),
                            f"{label_b}":        round(vb, 4),
                            "Diff (A−B)":        diff,
                            "Diff %":            round(diff_pct, 2),
                            "Match %":           match_pct,
                        })

                    tbl = pd.DataFrame(rows).sort_values(grp_label).reset_index(drop=True)

                    # TOTAL row
                    tot_a     = round(float(sa.sum()), 4)
                    tot_b     = round(float(sb.sum()), 4)
                    tot_diff  = round(tot_a - tot_b, 6)
                    tot_dpct  = round(abs(tot_diff) / abs(tot_a) * 100, 2) if tot_a != 0 else (0.0 if tot_b == 0 else 100.0)
                    tot_match = max(0.0, round(100.0 - tot_dpct, 2))
                    total_row = pd.DataFrame([{
                        grp_label:    "TOTAL",
                        f"{label_a}": tot_a,
                        f"{label_b}": tot_b,
                        "Diff (A−B)": tot_diff,
                        "Diff %":     round(tot_dpct, 2),
                        "Match %":    tot_match,
                    }])
                    tbl = pd.concat([tbl, total_row], ignore_index=True)
                    per_col_tables[key] = {"table": tbl, "col": col, "fn": fn, "grp_label": grp_label}

                except Exception as e:
                    print(f"  [WARN] Comparison {key}: {e}")

    return dict(
        summary_a=summary_a,
        summary_b=summary_b,
        per_col_tables=per_col_tables,
        label_a=label_a,
        label_b=label_b,
        rows_a=len(df_a),
        rows_b=len(df_b),
        groupby_col=grp_cols,
        agg_config=final_agg,
    )


# ── master ────────────────────────────────────────────────────────────────────

def run_eda(df, config):
    t0 = time.time()
    n  = len(df)
    target      = config.get("target_col")
    feats       = [c for c in df.columns if c != target]
    corr_sample = config.get("corr_sample", 100_000)
    corr_thresh = config.get("corr_threshold", 0.75)
    rare_pct    = config.get("rare_cat_pct", 1.0)
    plot_n      = config.get("plot_sample", 20_000)
    norm_n      = config.get("norm_sample", 5_000)
    id_ratio    = config.get("id_ratio", 0.8)
    max_corr    = config.get("max_corr_vars", 30)
    sections    = config.get("sections", {})  # {} = all on

    def _on(k): return sections.get(k, True)

    _log(f"EDA — {len(feats)} features × {n:,} rows", 0)
    _log("Detecting types...", 5)
    dtype_map = {c: detect_type(df[c], id_ratio) for c in feats}
    for col, ft in config.get("dtype_overrides", {}).items():
        if col in dtype_map: dtype_map[col] = ft

    _log("Analysing columns...", 15)
    col_results = {}
    for i, col in enumerate(feats):
        dtype = dtype_map[col]
        try:
            if dtype in ("Numeric","Boolean"):
                s = df[col]
                if dtype=="Boolean" and s.dtype==object:
                    s = s.map(lambda v: 1.0 if str(v).strip().lower() in
                              {"1","y","yes","true","t","1.0","male","m"} else (0.0 if pd.notna(v) else np.nan))
                col_results[col] = _analyse_numeric(col, s, n, plot_n, norm_n)
            elif dtype=="Unknown":
                col_results[col] = dict(dtype="Unknown",
                    missing_count=int(df[col].isna().sum()),
                    missing_pct=round(df[col].isna().mean()*100,1),
                    hit_rate_pct=round((1-df[col].isna().mean())*100,1),
                    inf_count=0,inf_pct=0.0,n_unique=0,zero_pct=0,
                    dist={},outlier={},plot_sample=[],zero_inflated=False,skewness=None)
            elif dtype=="Constant":
                col_results[col] = dict(dtype="Constant",
                    missing_count=int(df[col].isna().sum()),
                    missing_pct=round(df[col].isna().mean()*100,1),
                    hit_rate_pct=round((1-df[col].isna().mean())*100,1),
                    inf_count=0,inf_pct=0.0,n_unique=1,
                    constant_value=str(df[col].dropna().iloc[0]) if df[col].notna().any() else "NaN",
                    zero_pct=0,dist={},outlier={},plot_sample=[],zero_inflated=False,skewness=None)
            else:
                col_results[col] = _analyse_categorical(col, df[col], n, rare_pct)
        except Exception as e:
            print(f"  [WARN] {col}: {e}")
            col_results[col] = dict(dtype=dtype,missing_count=0,missing_pct=0,
                hit_rate_pct=100,inf_count=0,inf_pct=0.0,n_unique=0,zero_pct=0,
                dist={},outlier={},plot_sample=[],zero_inflated=False,skewness=None)
        pct = 15 + int((i+1)/len(feats)*35)
        if (i+1) % max(1, len(feats)//8) == 0 or i+1==len(feats):
            _log(f"Features {i+1}/{len(feats)}", pct)

    corr={}; fuzzy={}; sc=pd.DataFrame(); recs=[]
    if _on("correlations"):
        _log("Correlations...", 52)
        # Pass full df (all columns including categoricals) so chi-square can use them.
        # _correlations internally separates numeric vs categorical.
        all_cols = list(feats)
        if target and target in df.columns and target not in all_cols:
            all_cols = [target] + all_cols
        corr = _correlations(df[all_cols], corr_sample, corr_thresh, target_col=target)
    if _on("category_quality"):
        _log("Fuzzy category matching...", 62)
        fuzzy = _fuzzy_categories(col_results)
    if _on("scorecard"):
        _log("Scorecard...", 72)
        sc = _scorecard(col_results, corr, fuzzy)
        _log("Recommendations...", 82)
        recs = _recommendations(col_results, sc)

    target_analysis = {}
    if target and _on("target_analysis"):
        _log("Target analysis...", 88)
        target_analysis = _target_analysis(df, col_results, dtype_map, target)

    det = pd.DataFrame()
    if config.get("groupby_col") and config.get("agg_config"):
        _log("Grouped report...", 90)
        gb  = config["groupby_col"]
        agg = {c: f for c,f in config["agg_config"].items() if c in df.columns}
        if gb in df.columns and agg:
            try:
                r = df.groupby(gb).agg(agg)
                r.columns = ["_".join(c) for c in r.columns]
                det = r.reset_index().sort_values(gb)
            except Exception as e:
                print(f"  [WARN] Grouped report: {e}")

    comparison = {}
    cmp_cfg = config.get("comparison")
    if cmp_cfg and isinstance(cmp_cfg, dict):
        _log("Comparison summary...", 93)
        try:
            comparison = _comparison_summary(
                df_a=df, df_b=cmp_cfg["df"],
                label_a=cmp_cfg.get("label_a","Dataset A"),
                label_b=cmp_cfg.get("label_b","Dataset B"),
                groupby_col=cmp_cfg.get("groupby_col", config.get("groupby_col","")),
                agg_cols=cmp_cfg.get("agg_cols",[]),
                agg_config=cmp_cfg.get("agg_config",{}),
            )
            # Store raw DataFrames for side-by-side browsing in the dashboard
            comparison["df_a"] = df
            comparison["df_b"] = cmp_cfg["df"]
        except Exception as e:
            print(f"  [WARN] Comparison: {e}")

    elapsed = round(time.time()-t0, 1)
    _log(f"Done in {elapsed}s", 100)

    return dict(
        df=df, config=config, feature_cols=feats, dtype_map=dtype_map,
        n_rows=n, n_features=len(feats), elapsed_sec=elapsed, target_col=target,
        col_results=col_results, correlations=corr, fuzzy_categories=fuzzy,
        scorecard=sc, recommendations=recs, grouped_report=det,
        target_analysis=target_analysis, comparison=comparison,
    )
