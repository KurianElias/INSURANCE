# Insurance EDA Toolkit — v4

Exploratory data analysis for insurance (and general) datasets. **100% local — no data leaves your machine.**

---

## Quick Start

```python
import sys
sys.path.insert(0, '.')          # folder containing eda_toolkit/
from eda_toolkit import inspect, run_eda, launch_app

plan = inspect(df, target_col="Claim_Flag")
plan.confirm()
df_clean = plan.apply_to_df()
results  = run_eda(df_clean, plan)
launch_app(results)
```

---

## Full Workflow

### Step 1 — Inspect

```python
plan = inspect(df, target_col="Claim_Flag")
```

Prints a pre-flight table: detected type, pandas dtype, unique count, missing %, and sample values for every column. Flags anything suspicious.

### Step 2 — Fix wrong type detections (optional)

```python
plan.fix(
    Policy_Year    = "Categorical",   # was detected as Date
    Inception_Date = "Date",          # fix any column
    Region         = "Categorical",
)
```

Valid types: `Numeric`  `Categorical`  `Boolean`  `Date`  `ID-like`  `Unknown`  `Constant`

### Step 3 — Configure sections (optional — controls analysis time)

Use this to **skip expensive sections** and reduce run time on large datasets.

```python
plan.set_sections(
    correlations     = True,   # Pearson/Spearman/Kendall matrix + VIF
    category_quality = True,   # fuzzy duplicate category detection
    scorecard        = True,   # quality scorecard + recommendations
    target_analysis  = True,   # per-feature association with target
)
```

> **Tip:** On a 1.2M row × 120 column dataset, setting `correlations=False` and `category_quality=False` can cut run time from ~4 minutes to ~45 seconds.

You can also toggle individual tabs **live in the sidebar** after launch — but this only hides/shows the tab, it does not skip the computation. Use `set_sections()` to skip computation before running.

### Step 4 — Key stats config (optional)

Show count, unique count, and duplicate rate for important key columns on the Overview page.

```python
plan.set_key_stats(
    key_cols       = ["Policy_Number", "Risk_ID"],
    composite_keys = [
        ["Policy_Number", "Eff_Date"],       # test if this combo is unique
        ["Policy_Number", "Risk_ID", "Line"] # multi-column composite key
    ],
)
```

### Step 5 — Data comparison config (optional)

Compare your primary dataset against a second DataFrame (e.g. new business vs renewals, current year vs prior year).

**Simple — default aggregation (count / mean / median / sum):**

```python
plan.set_comparison(
    df          = df_renewals,
    label_a     = "New Business",      # label for primary df
    label_b     = "Renewals",          # label for comparison df
    groupby_col = "Region",            # single group column
    agg_cols    = ["Premium", "Claim_Flag", "Exposure"],
)
```

**Advanced — multiple group columns + per-column aggregation methods:**

```python
plan.set_comparison(
    df          = df_prior_year,
    label_a     = "Current Year",
    label_b     = "Prior Year",
    groupby_col = ["Region", "Policy_Year"],   # group by multiple columns
    agg_config  = {
        "Premium":       ["sum", "mean"],
        "Policy_Number": ["count", "nunique"],  # nunique = distinct count
        "Claim_Flag":    ["sum", "mean"],        # mean = claim frequency
        "Exposure":      ["sum"],
        "Claim_Amount":  ["sum", "mean", "median"],
    },
)
```

> **Note:** Both DataFrames must have the group column(s) present. Numeric columns are cast automatically. Results show grouped tables side by side + a delta table (B − A and Delta %).

### Step 6 — Confirm, cast, run

```python
plan.confirm()                   # prints final confirmed table
df_clean = plan.apply_to_df()   # cast columns to confirmed types, drop constants/unknowns
results  = run_eda(df_clean, plan)
launch_app(results)
```

---

## apply_to_df() — what it does per type

| EDA Type    | Cast to        | Notes |
|-------------|----------------|-------|
| Numeric     | `float64`      | pd.to_numeric, errors → NaN |
| Boolean     | `float64`      | 0.0 / 1.0 (Yes/No, M/F, etc.) |
| Categorical | `category`     | memory-efficient |
| Date        | `datetime64`   | pd.to_datetime, errors → NaT |
| Constant    | **DROPPED**    | zero variance, useless for models |
| ID-like     | kept as-is     | use `drop_id_like=True` to drop |
| Unknown     | **DROPPED**    | all-null column |

```python
# Optional flags
df_clean = plan.apply_to_df(
    drop_constants = True,   # default True
    drop_id_like   = False,  # default False — keep IDs for joins
    drop_unknown   = True,   # default True
)
```

---

## One-shot (skip inspect)

```python
from eda_toolkit import run_eda, launch_app

results = run_eda(df, {
    "target_col":       "Claim_Flag",
    "groupby_col":      "Policy_Year",
    "agg_config":       {"Claim_Flag": ["sum","mean"], "Premium": ["sum","mean"]},
    "dtype_overrides":  {"Policy_Year": "Categorical"},
    "sections": {
        "correlations":     True,
        "category_quality": False,   # skip fuzzy matching
        "scorecard":        True,
        "target_analysis":  True,
    },
})
launch_app(results)
```

---

## Dashboard Tabs

| Tab | What it shows |
|-----|---------------|
| **📋 Overview** | Row/col counts, type donut, missing % chart, feature table, key stats panel, composite key builder |
| **🔬 Variable Explorer** | Per-column distribution, stats, skewness alerts |
| **📊 Hit Rate** | % non-null per feature, colour-coded (green ≥95% / orange 75–94% / red <75%) |
| **🏷️ Category Quality** | Fuzzy duplicate detection, rare + dominant category explorer |
| **⚡ Outliers** | Boxplot + P1–P99 clipped histogram, IQR fences, interactive percentile sliders |
| **🔗 Correlations** | Target correlation table, Pearson/Spearman/Kendall heatmap, high-corr pairs, VIF |
| **🎯 Target Analysis** | Feature association ranking (|r| or Cramér's V), per-feature bar/scatter charts |
| **⚖️ Data Comparison** | Side-by-side grouped tables, delta bar chart, download CSVs |
| **🏆 Quality Scorecard** | Per-feature score (0–100), status (Fix/Review/Good), recommended actions |

### Disabling tabs at runtime

After launching, use the **Active Tabs** checkboxes in the sidebar to show/hide any tab instantly. This is cosmetic only — the underlying data was already computed. To skip computation itself, use `plan.set_sections()` before running.

---

## Quality Scorecard — how scores are calculated

Each feature gets an **Overall Score (0–100)** computed as a weighted average of five sub-scores:

```
Overall = 0.30 × Hit Rate
        + 0.20 × Valid Values
        + 0.15 × Skewness
        + 0.15 × Category Consistency
        + 0.20 × Outlier Score
```

### Sub-score breakdown

| Sub-score | What it measures | Score |
|-----------|-----------------|-------|
| **Hit Rate (30%)** | % non-null | 100 if ≥99% · 80 if ≥90% · 55 if ≥75% · 30 if ≥50% · 5 if <50% |
| **Valid Values (20%)** | Zero inflation / Inf / dominant cat | 100 = clean · 75–85 = minor issues · 10–60 = severe |
| **Skewness (15%)** | Numeric skewness (absolute) | 100 if <0.5 · 80 if <1.0 · 55 if <2.0 · 25 if ≥2.0 |
| **Cat Consistency (15%)** | Fuzzy duplicate categories | 100 = clean · 70 = 1–2 similar · 45 = 3–5 · 20 = >5 |
| **Outlier Score (20%)** | % outside IQR fences | 100 if <1% · 80 if <3% · 55 if <8% · 25 if ≥8% |

### RAG status thresholds

| Score | Status |
|-------|--------|
| ≥ 80  | ✅ Good |
| 55–79 | ⚠️ Review |
| < 55  | ❌ Fix First |

> **Constant columns** always score ❌ Fix First (zero variance = no information).

---

## Correlation Methods — when to use each

| Method | Relationship detected | Robustness | Speed | Recommended when |
|--------|-----------------------|------------|-------|------------------|
| **Pearson r** | Linear | Low (outlier-sensitive) | Fast | Normal distributions, no extreme outliers |
| **Spearman ρ** | Monotonic (rank) | High | Medium | Skewed data, any distribution |
| **Kendall τ** | Concordance (rank) | Very high | Slow | Small samples, ordinal data, when Spearman is unstable |

**Strength guide (Pearson / Spearman):** |r| ≥ 0.7 strong · 0.4–0.7 moderate · < 0.4 weak.
**Strength guide (Kendall):** |τ| ≥ 0.5 strong · 0.2–0.5 moderate · < 0.2 weak.

---

## Configuration Reference

| Key | Default | Description |
|-----|---------|-------------|
| `target_col` | `None` | Target/response variable — included in correlation matrix and Target Analysis tab |
| `groupby_col` | `None` | Column for grouped summary on Overview |
| `agg_config` | `{}` | Aggregation dict for grouped report |
| `corr_threshold` | `0.75` | Pearson \|r\| above this → flagged as high correlation |
| `rare_cat_pct` | `1.0` | Categories with share below this % are flagged RARE |
| `id_ratio` | `0.8` | nunique / nrows above this → detected as ID-like |
| `corr_sample` | `100,000` | Max rows for Pearson correlation |
| `plot_sample` | `20,000` | Max rows sampled for histogram/boxplot |
| `max_corr_vars` | `30` | Max variables included in correlation matrix (top by variance) |
| `dtype_overrides` | `{}` | Manual type overrides `{"col": "Type"}` |
| `sections` | all `True` | Dict of bool flags to skip expensive sections |

---

## Requirements

```bash
pip install pandas numpy scipy scikit-learn plotly streamlit
# Optional — faster fuzzy matching:
pip install rapidfuzz
```

---

## File Structure

```
eda_toolkit/
  __init__.py      exports: inspect, run_eda, launch_app, print_summary
  eda_engine.py    all computation — no Streamlit, no external calls
  app.py           Streamlit dashboard (9 tabs)
  launch.py        inspect(), InspectPlan, run_eda(), launch_app(), print_summary()
  README.md        this file
```
