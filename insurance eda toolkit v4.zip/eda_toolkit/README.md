# Insurance EDA Toolkit

Exploratory data analysis for insurance datasets. 100% local — no data leaves your machine.

---

## Recommended workflow — two steps

### Step 1: Inspect your data first

Before running any analysis, call `inspect()`. It detects every column's type, shows you a confirmation table with sample values, and flags anything suspicious.

```python
import sys
sys.path.insert(0, '.')        # folder containing eda_toolkit/

from eda_toolkit import inspect, run_eda, launch_app

plan = inspect(df, target_col="Claim_Flag")
```

**Output looks like this:**

```
══════════════════════════════════════════════════════════
  INSURANCE EDA TOOLKIT — PRE-FLIGHT INSPECTION
  50,000 rows  ×  18 columns  |  Target: Claim_Flag
══════════════════════════════════════════════════════════

  #    Column             Pandas dtype  Detected as    Unique  Missing  Sample values
  ─────────────────────────────────────────────────────────────────────────────────────
  1    Policy_Number      str           🔑 ID-like     50,000    0.0% ⚠️  POL-0000001
  2    Policy_Year        int64         📅 Date              4    0.0%  2021, 2022
  3    Inception_Date     str           📅 Date          8,760    1.2%  2021-03-15
  4    Renewal_Date       str           📅 Date          8,760    0.0%  15/03/2022
  5    Driver_Age         float64       🔢 Numeric          67   10.0%  38.0, 52.0
  6    Gender             str           ☑️ Boolean           2    0.0%  M, F
  7    Is_Commercial      str           ☑️ Boolean           2    0.0%  Yes, No
  8    Region             str           🏷️ Categorical       4    0.0%  North, South
  ...

  ⚠️  WARNINGS:
     Policy_Number  → Will be excluded from EDA analysis
```

### Step 2: Fix any wrong types, confirm, and run

```python
# If anything is wrong, fix it:
plan.fix(
    Policy_Year   = "Categorical",   # was detected as Date — we want it as a category
    Some_Column   = "Numeric",       # fix any other mistakes the same way
)

# Review the final confirmed table:
plan.confirm()

# Run EDA with corrected types:
results = run_eda(df, plan)

# Quick text summary in the notebook:
print_summary(results)

# Open the Streamlit dashboard:
launch_app(results)
```

---

## One-shot (skip inspect)

If you're confident about your types, you can go straight to `run_eda()`:

```python
from eda_toolkit import run_eda, launch_app, print_summary

results = run_eda(df, {
    "target_col":  "Claim_Flag",
    "groupby_col": "Policy_Year",
    "agg_config": {
        "Claim_Flag":   ["sum", "mean"],
        "Claim_Amount": ["sum", "mean"],
        "Premium":      ["sum", "mean"],
    },
    # Optional manual overrides without using inspect():
    "dtype_overrides": {
        "Policy_Year": "Categorical",
    },
})

print_summary(results)
launch_app(results)
```

---

## What inspect() detects automatically

| Column type | Examples |
|-------------|---------|
| 🔢 **Numeric** | Driver_Age, Vehicle_Value, Premium |
| 🏷️ **Categorical** | Region, Cover_Type, Occupation |
| ☑️ **Boolean** | Y/N, Yes/No, True/False, M/F, 0/1, Male/Female |
| 📅 **Date** | YYYY-MM-DD strings, DD/MM/YYYY strings, year integers (2019–2023), actual datetime64 |
| 🔑 **ID-like** | Policy numbers, reference codes, free-text IDs |
| ❓ **Unknown** | All-null columns |

---

## Dashboard tabs

| Tab | Content |
|-----|---------|
| **Overview** | Row/feature counts, type breakdown, missing map, feature table |
| **Feature Drill-Down** | Distribution, key stats, target rate chart per feature |
| **Data Quality** | RAG scorecard (Fix / Review / Clean) + recommended actions |
| **Correlations** | Pearson heatmap, high-correlation pairs, VIF table |

---

## Scorecard logic

Each feature is scored across four dimensions:

| Dimension | Points |
|-----------|--------|
| Missing % | 0 (none) → 1 (<5%) → 2 (<20%) → 3 (>20%) |
| Skewness | 0 (<0.5) → 1 (0.5–1.5) → 2 (>1.5) |
| Outliers (IQR) | 0 (<1%) → 1 (1–5%) → 2 (>5%) |
| Correlation risk | 0 (low) → 1 (medium) → 2 (high) |

**Total → RAG:**  ≤1 = ✅ Clean  |  2–4 = ⚠️ Review  |  ≥5 = ❌ Fix First

---

## Configuration reference

| Key | Default | Description |
|-----|---------|-------------|
| `target_col` | `None` | Target/response variable |
| `groupby_col` | `None` | Column for grouped summary table |
| `agg_config` | `{}` | Aggregation functions for grouped report |
| `corr_threshold` | `0.75` | \|r\| threshold for high-correlation flag |
| `rare_cat_pct` | `1.0` | Categories below this % flagged as RARE |
| `id_ratio` | `0.8` | nunique/nrows above this = ID-like |
| `dtype_overrides` | `{}` | Manual type overrides `{"col": "Type"}` |

---

## Requirements

```
pip install pandas numpy scipy scikit-learn plotly streamlit
```

---

## Files

```
eda_toolkit/
  __init__.py     exports: inspect, run_eda, launch_app, print_summary
  eda_engine.py   all computation — type detection, analysis, scorecard
  app.py          Streamlit dashboard (4 tabs)
  launch.py       inspect(), run_eda(), launch_app(), print_summary()
```
