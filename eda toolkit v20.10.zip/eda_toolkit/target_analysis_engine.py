"""
target_analysis_engine.py -- Insurance EDA Toolkit v5
Pre-aggregates all Target Analysis data at run_eda() time.
No raw data is passed to HTML -- only aggregated tables.

Binning methods
---------------
"equal"    : equal-width intervals
"quantile" : equal row count per bin
"exposure" : equal exposure per bin  (actuarially correct)
              bin_by="amount" -> equal SUM of exposure_col per bin  <- recommended
              bin_by="count"  -> equal row count (same as quantile, baseline)
"""
from __future__ import annotations
import time
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")


def _safe(v, decimals=6):
    try:
        f = float(v)
        if np.isnan(f) or np.isinf(f): return None
        return round(f, decimals)
    except Exception:
        return None


def _safe_stats(arr):
    if len(arr) == 0:
        return {"mean": None, "median": None, "sum": None}
    a = arr[~np.isnan(arr)]
    if len(a) == 0:
        return {"mean": None, "median": None, "sum": None}
    return {
        "mean":   _safe(float(np.mean(a)), 6),
        "median": _safe(float(np.median(a)), 6),
        "sum":    _safe(float(np.sum(a)), 4),
    }


# -- target univariate ---------------------------------------------------------

def _target_univariate(df: pd.DataFrame, target: str, n_bins: int = 50) -> dict:
    """Compute target univariate stats. Handles numeric, object, and category dtypes."""
    raw = df[target]
    # Try to get numeric values -- handles float, int, object-stored-as-string
    if pd.api.types.is_numeric_dtype(raw):
        t = raw.dropna()
    else:
        t = pd.to_numeric(raw, errors="coerce").dropna()
    n = len(t)
    if n == 0:
        # Return empty stats rather than empty dict so the dashboard shows dashes
        return {"stats": {k: None for k in
                ["count","mean","median","std","min","max","p25","p75","p95","p99","skewness","zero_pct"]},
                "hist_raw":{}, "hist_clip":{}, "hist_log":{}}

    stats = {
        "count":    int(n),
        "mean":     _safe(t.mean()),
        "median":   _safe(t.median()),
        "std":      _safe(t.std()),
        "min":      _safe(t.min()),
        "max":      _safe(t.max()),
        "p25":      _safe(t.quantile(0.25)),
        "p75":      _safe(t.quantile(0.75)),
        "p95":      _safe(t.quantile(0.95)),
        "p99":      _safe(t.quantile(0.99)),
        "skewness": _safe(float(t.skew())),
        "zero_pct": _safe(float((t == 0).mean() * 100), 2),
    }

    def _hist(arr, bins=n_bins):
        try:
            counts, edges = np.histogram(arr, bins=bins)
            return {"counts": counts.tolist(), "edges": [_safe(e, 6) for e in edges]}
        except Exception:
            return {}

    p1  = float(t.quantile(0.01))
    p99 = float(t.quantile(0.99))
    t_clip = t[(t >= p1) & (t <= p99)].values
    t_pos  = t[t > 0].values
    hist_log = {}
    if len(t_pos) > 10:
        try:
            hist_log = _hist(np.log1p(t_pos))
            hist_log["note"] = "log1p transformed"
            hist_log["n_zeros_excluded"] = int((t <= 0).sum())
        except Exception:
            pass

    return {
        "stats":     stats,
        "hist_raw":  _hist(t.values),
        "hist_clip": _hist(t_clip),
        "hist_log":  hist_log,
    }


# -- categorical aggregation ---------------------------------------------------

def _aggregate_categorical(df: pd.DataFrame, col: str, target: str,
                            exposure_col: str | None = None) -> list[dict]:
    """Aggregate target vs categorical. Full dataset. No sampling."""
    t = pd.to_numeric(df[target], errors="coerce")
    cat = df[col].astype(str).fillna("(Missing)")
    n_total = len(df)

    tmp = pd.DataFrame({"__cat": cat, "__t": t})
    if exposure_col and exposure_col in df.columns:
        tmp["__exp"] = pd.to_numeric(df[exposure_col], errors="coerce")

    grp = tmp.groupby("__cat", sort=False)
    agg = grp["__t"].agg(["count", "mean", "median", "sum"]).reset_index()
    agg.columns = ["category", "count", "mean", "median", "sum"]

    total_exp = None
    if "__exp" in tmp.columns:
        exp_agg = grp["__exp"].sum().reset_index()
        exp_agg.columns = ["category", "exposure_sum"]
        agg = agg.merge(exp_agg, on="category", how="left")
        total_exp = float(tmp["__exp"].sum())

    agg["pct"] = (agg["count"] / n_total * 100).round(2)
    agg = agg.sort_values("count", ascending=False).reset_index(drop=True)

    rows = []
    for _, r in agg.iterrows():
        row = {
            "category": str(r["category"]),
            "count":    int(r["count"]),
            "pct":      _safe(r["pct"], 2),
            "mean":     _safe(r["mean"], 6),
            "median":   _safe(r["median"], 6),
            "sum":      _safe(r["sum"], 4),
        }
        if "exposure_sum" in agg.columns:
            exp_s = _safe(r.get("exposure_sum"), 4)
            row["exposure_sum"] = exp_s
            row["exposure_pct"] = (
                _safe(float(r["exposure_sum"]) / total_exp * 100, 2)
                if total_exp and total_exp > 0 and not pd.isna(r["exposure_sum"])
                else None
            )
        rows.append(row)
    return rows


# -- bin edge algorithms -------------------------------------------------------

def _edges_equal(x_v: np.ndarray, n_bins: int) -> np.ndarray:
    """Equal-width edges."""
    return np.linspace(x_v.min(), x_v.max(), n_bins + 1)


def _edges_quantile(x_v: np.ndarray, n_bins: int) -> np.ndarray:
    """Equal row-count edges (quantile of feature values)."""
    q = np.linspace(0, 100, n_bins + 1)
    edges = np.unique(np.percentile(x_v, q))
    if len(edges) < 2:
        edges = _edges_equal(x_v, n_bins)
    return edges


def _edges_exposure_amount(x_v: np.ndarray, e_v: np.ndarray,
                            n_bins: int) -> np.ndarray:
    """
    Equal TOTAL EXPOSURE per bin (actuarially correct for insurance).

    Each bin contains the same sum of the exposure column so that:
    - Mean target is equally credible across all bins
    - High-exposure groups don't dominate the chart
    - Thin bins are merged with neighbouring heavy bins automatically

    Algorithm:
      1. Sort records by feature value ascending
      2. Compute cumulative exposure
      3. Find feature-value boundaries at equal steps of cumulative exposure
    """
    sort_idx  = np.argsort(x_v)
    x_sorted  = x_v[sort_idx]
    e_sorted  = np.where(np.isnan(e_v[sort_idx]), 0.0, e_v[sort_idx])

    cum_exp   = np.cumsum(e_sorted)
    total_exp = cum_exp[-1]

    if total_exp <= 0:
        return _edges_quantile(x_v, n_bins)

    target_levels = np.linspace(0, total_exp, n_bins + 1)
    edges = []
    for level in target_levels:
        idx = min(np.searchsorted(cum_exp, level, side="left"), len(x_sorted) - 1)
        edges.append(x_sorted[idx])

    edges = np.array(edges)
    edges = np.unique(edges)
    if len(edges) < 2:
        return _edges_quantile(x_v, n_bins)

    edges[0]  = x_v.min()
    edges[-1] = x_v.max()
    return edges


def _edges_exposure_count(x_v: np.ndarray, e_v: np.ndarray,
                           n_bins: int) -> np.ndarray:
    """
    Equal ROW COUNT per bin (same as quantile, kept as a distinct toggle
    so users can compare it against equal-amount binning).
    """
    return _edges_quantile(x_v, n_bins)


# -- numeric bin aggregation ---------------------------------------------------

def _aggregate_numeric_bins(df: pd.DataFrame, col: str, target: str,
                              n_bins: int,
                              method: str = "equal",
                              exposure_col: str | None = None,
                              bin_by: str = "amount") -> list[dict]:
    """
    Bin a numeric feature and aggregate target per bin. Full dataset.

    method    : "equal" | "quantile" | "exposure"
    bin_by    : "amount" | "count"  (only matters for method="exposure")
    """
    t = pd.to_numeric(df[target], errors="coerce")
    x = pd.to_numeric(df[col],   errors="coerce")

    use_exp = (method == "exposure" and exposure_col and exposure_col in df.columns)
    if use_exp:
        e    = pd.to_numeric(df[exposure_col], errors="coerce")
        mask = x.notna() & t.notna()
        x_v, t_v, e_v = x[mask].values, t[mask].values, e[mask].values
    else:
        mask = x.notna() & t.notna()
        x_v, t_v = x[mask].values, t[mask].values
        e_v = None

    n_total = len(df)
    if len(x_v) < 2:
        return []

    try:
        # Choose edge algorithm
        if method == "equal":
            edges = _edges_equal(x_v, n_bins)
        elif method == "quantile":
            edges = _edges_quantile(x_v, n_bins)
        elif use_exp:
            if bin_by == "amount":
                edges = _edges_exposure_amount(x_v, e_v, n_bins)
            else:
                edges = _edges_exposure_count(x_v, e_v, n_bins)
        else:
            edges = _edges_equal(x_v, n_bins)

        bin_idx = np.digitize(x_v, edges[1:-1])  # 0 .. len(edges)-2

        total_exp = float(e_v[~np.isnan(e_v)].sum()) if e_v is not None else None

        rows = []
        for b in range(len(edges) - 1):
            mb    = bin_idx == b
            if not mb.any():
                continue
            t_bin = t_v[mb]
            cnt   = int(mb.sum())
            lo    = float(edges[b])
            hi    = float(edges[b + 1])

            row = {
                "bin":    f"[{lo:.4g}, {hi:.4g})",
                "bin_lo": _safe(lo, 6),
                "bin_hi": _safe(hi, 6),
                "count":  cnt,
                "pct":    _safe(cnt / n_total * 100, 2),
                **_safe_stats(t_bin),
            }

            if e_v is not None:
                e_bin   = e_v[mb]
                exp_sum = float(np.nansum(e_bin))
                row["exposure_sum"] = _safe(exp_sum, 4)
                row["exposure_pct"] = (
                    _safe(exp_sum / total_exp * 100, 2)
                    if total_exp and total_exp > 0 else None
                )

            rows.append(row)

        return rows
    except Exception:
        return []


# -- master builder ------------------------------------------------------------

def build_target_analysis(df: pd.DataFrame,
                           dtype_map: dict,
                           target: str,
                           n_bins_list: list | None = None,
                           bin_methods: list | None = None,
                           exposure_col: str | None = None,
                           bin_by: str = "amount") -> dict:
    """
    Pre-aggregate all data for the Target Analysis HTML tab.
    No sampling -- uses full dataset throughout.

    Parameters
    ----------
    df           : full DataFrame
    dtype_map    : {col: dtype_string}
    target       : target column name
    n_bins_list  : bin counts to pre-compute  (default [5, 10, 20])
    bin_methods  : methods to pre-compute     (default ["equal","quantile"])
                   Add "exposure" to enable equal-exposure binning
    exposure_col : exposure weight column     (required for "exposure" method)
    bin_by       : "amount" -- equal SUM of exposure_col per bin  (recommended)
                   "count"  -- equal row count per bin
    """
    # Default: pre-compute enough configs that the 1-30 slider has good coverage
    if n_bins_list is None: n_bins_list = [5, 10, 15, 20, 25, 30]
    if bin_methods is None: bin_methods = ["equal", "quantile"]

    # Guard: exposure method needs exposure_col
    if "exposure" in bin_methods and not exposure_col:
        print("[TA] WARN: 'exposure' method needs exposure_col -- skipping")
        bin_methods = [m for m in bin_methods if m != "exposure"]
    if exposure_col and exposure_col not in df.columns:
        print(f"[TA] WARN: exposure_col='{exposure_col}' not in df -- skipping")
        exposure_col = None
        bin_methods  = [m for m in bin_methods if m != "exposure"]
    if target not in df.columns:
        return {}

    cat_cols = [c for c, t in dtype_map.items()
                if t == "Categorical" and c != target and c in df.columns]
    num_cols = [c for c, t in dtype_map.items()
                if t in ("Numeric", "Boolean") and c != target
                and c in df.columns
                and c != exposure_col]

    t0 = time.time()
    n  = len(df)
    print(f"[TA] {n:,} rows . {len(cat_cols)} cat . {len(num_cols)} num . "
          f"methods={bin_methods} . bins={n_bins_list}"
          + (f" . exposure={exposure_col}({bin_by})" if exposure_col else ""))

    # Univariate
    univariate = _target_univariate(df, target)
    print(f"[TA] Univariate done ({time.time()-t0:.1f}s)")

    # Categorical
    categorical = {}
    for i, col in enumerate(cat_cols):
        try:
            categorical[col] = _aggregate_categorical(
                df, col, target, exposure_col=exposure_col)
        except Exception as e:
            print(f"[TA] WARN cat {col}: {e}")
        if (i + 1) % 15 == 0:
            print(f"[TA] Categorical {i+1}/{len(cat_cols)} ({time.time()-t0:.1f}s)")
    print(f"[TA] All categorical done ({time.time()-t0:.1f}s)")

    # Numeric
    numeric = {}
    for i, col in enumerate(num_cols):
        numeric[col] = {}
        for method in bin_methods:
            numeric[col][method] = {}
            for nb in n_bins_list:
                try:
                    numeric[col][method][nb] = _aggregate_numeric_bins(
                        df, col, target, nb,
                        method=method,
                        exposure_col=exposure_col if method == "exposure" else None,
                        bin_by=bin_by,
                    )
                except Exception as e:
                    print(f"[TA] WARN {col} {method} {nb}: {e}")
                    numeric[col][method][nb] = []
        if (i + 1) % 15 == 0:
            print(f"[TA] Numeric {i+1}/{len(num_cols)} ({time.time()-t0:.1f}s)")

    elapsed = round(time.time() - t0, 1)
    print(f"[TA] Done in {elapsed}s")

    return {
        "target_col":   target,
        "n_rows":       n,
        "univariate":   univariate,
        "categorical":  categorical,
        "numeric":      numeric,
        "n_bins_list":  n_bins_list,
        "bin_methods":  bin_methods,
        "exposure_col": exposure_col,
        "bin_by":       bin_by,
        "elapsed_sec":  elapsed,
    }
