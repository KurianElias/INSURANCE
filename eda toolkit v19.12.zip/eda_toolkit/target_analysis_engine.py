"""
target_analysis_engine.py — Insurance EDA Toolkit v5
Pre-aggregates all Target Analysis data at run_eda() time.
No raw data is passed to HTML — only aggregated tables.

Performance model (2.47M rows × 113 features):
  - Target univariate:        ~0.1s
  - 42 categorical features:  ~4s  (groupby + 5 stats)
  - 60 numeric features:      ~12s (2 bin methods × 2 n_bins configs)
  - Total:                    ~16s with no sampling
"""
from __future__ import annotations
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings("ignore")


def _safe(v, decimals=6):
    """Round and make JSON-safe."""
    try:
        f = float(v)
        if np.isnan(f) or np.isinf(f): return None
        return round(f, decimals)
    except Exception:
        return None


def _agg_series(s: pd.Series, t: pd.Series):
    """Return dict of {count, pct, mean, median, sum} for target t within mask s."""
    n_total = len(t)
    n = int(s.sum()) if hasattr(s, 'sum') else len(t)
    t_vals = t[s] if hasattr(s, '__iter__') and not isinstance(s, pd.Series) else t[s.astype(bool)]
    t_clean = pd.to_numeric(t_vals, errors="coerce").dropna()
    return {
        "count":  int(len(t_clean)),
        "pct":    _safe(len(t_clean) / n_total * 100, 2) if n_total else 0,
        "mean":   _safe(t_clean.mean(), 6),
        "median": _safe(t_clean.median(), 6),
        "sum":    _safe(t_clean.sum(), 4),
    }


def _target_univariate(df: pd.DataFrame, target: str, n_bins: int = 50,
                        cap_p99: bool = True) -> dict:
    """
    Compute target univariate distribution.
    Returns histogram bins, summary stats, and capped variant.
    """
    t = pd.to_numeric(df[target], errors="coerce").dropna()
    n = len(t)
    if n == 0:
        return {}

    stats = {
        "count":    int(n),
        "mean":     _safe(t.mean()),
        "median":   _safe(t.median()),
        "std":      _safe(t.std()),
        "min":      _safe(t.min()),
        "max":      _safe(t.max()),
        "p25":      _safe(t.quantile(0.25)),
        "p75":      _safe(t.quantile(0.75)),
        "p95":      _safe(t.quantile(0.95)),
        "p99":      _safe(t.quantile(0.99)),
        "skewness": _safe(float(t.skew())),
        "zero_pct": _safe(float((t == 0).mean() * 100), 2),
    }

    # Equal-width histogram (full range)
    try:
        counts_raw, edges_raw = np.histogram(t.values, bins=n_bins)
        hist_raw = {
            "counts": counts_raw.tolist(),
            "edges":  [_safe(e, 4) for e in edges_raw],
        }
    except Exception:
        hist_raw = {}

    # P1-P99 clipped histogram
    p1  = float(t.quantile(0.01))
    p99 = float(t.quantile(0.99))
    t_clip = t[(t >= p1) & (t <= p99)]
    try:
        counts_clip, edges_clip = np.histogram(t_clip.values, bins=n_bins)
        hist_clip = {
            "counts": counts_clip.tolist(),
            "edges":  [_safe(e, 4) for e in edges_clip],
        }
    except Exception:
        hist_clip = {}

    # Log-transformed histogram (values > 0 only)
    t_pos = t[t > 0]
    hist_log = {}
    if len(t_pos) > 10:
        try:
            t_log = np.log1p(t_pos.values)
            counts_log, edges_log = np.histogram(t_log, bins=n_bins)
            hist_log = {
                "counts": counts_log.tolist(),
                "edges":  [_safe(e, 4) for e in edges_log],
                "note":   "log1p transformed",
                "n_zeros_excluded": int((t <= 0).sum()),
            }
        except Exception:
            pass

    return {
        "stats":     stats,
        "hist_raw":  hist_raw,
        "hist_clip": hist_clip,
        "hist_log":  hist_log,
    }


def _aggregate_categorical(df: pd.DataFrame, col: str, target: str,
                            min_count: int = 0) -> list[dict]:
    """
    Aggregate target vs categorical feature.
    Returns list of dicts: {category, count, pct, mean, median, sum}
    Sorts by count descending.
    No sampling — uses full dataset.
    """
    t = pd.to_numeric(df[target], errors="coerce")
    g = df[[col]].copy()
    g["__t"] = t
    g[col] = g[col].astype(str).fillna("(Missing)")

    grouped = g.groupby(col, sort=False)["__t"]
    agg = grouped.agg(["count","mean","median","sum"]).reset_index()
    agg.columns = ["category","count","mean","median","sum"]

    n_total = len(df)
    agg["pct"]    = (agg["count"] / n_total * 100).round(2)
    agg["mean"]   = agg["mean"].round(6)
    agg["median"] = agg["median"].round(6)
    agg["sum"]    = agg["sum"].round(4)
    agg = agg.sort_values("count", ascending=False).reset_index(drop=True)

    rows = []
    for _, r in agg.iterrows():
        rows.append({
            "category": str(r["category"]),
            "count":    int(r["count"]),
            "pct":      _safe(r["pct"], 2),
            "mean":     _safe(r["mean"], 6),
            "median":   _safe(r["median"], 6),
            "sum":      _safe(r["sum"], 4),
        })
    return rows


def _aggregate_numeric_bins(df: pd.DataFrame, col: str, target: str,
                              n_bins: int, method: str = "equal") -> list[dict]:
    """
    Bin a numeric feature and aggregate target per bin.
    method: "equal" (equal-width) or "quantile" (equal-frequency)
    Returns list of dicts: {bin_label, bin_lo, bin_hi, count, pct, mean, median, sum}
    No sampling — uses full dataset.
    """
    t = pd.to_numeric(df[target], errors="coerce")
    x = pd.to_numeric(df[col],    errors="coerce")

    mask = x.notna() & t.notna()
    x_v  = x[mask].values
    t_v  = t[mask].values
    n_total = len(df)

    if len(x_v) < 2:
        return []

    try:
        if method == "quantile":
            quantiles = np.linspace(0, 100, n_bins + 1)
            edges = np.unique(np.percentile(x_v, quantiles))
            if len(edges) < 2:
                edges = np.linspace(x_v.min(), x_v.max(), n_bins + 1)
        else:
            edges = np.linspace(x_v.min(), x_v.max(), n_bins + 1)

        # Assign bins
        bin_idx = np.digitize(x_v, edges[1:-1])  # 0..n_bins-1

        rows = []
        for b in range(len(edges) - 1):
            mask_b = bin_idx == b
            t_bin  = t_v[mask_b]
            cnt    = int(mask_b.sum())
            if cnt == 0:
                continue
            lo = float(edges[b])
            hi = float(edges[b + 1])
            lbl = f"[{lo:.4g}, {hi:.4g})"
            rows.append({
                "bin":    lbl,
                "bin_lo": _safe(lo, 6),
                "bin_hi": _safe(hi, 6),
                "count":  cnt,
                "pct":    _safe(cnt / n_total * 100, 2),
                "mean":   _safe(float(np.nanmean(t_bin)), 6),
                "median": _safe(float(np.nanmedian(t_bin)), 6),
                "sum":    _safe(float(np.nansum(t_bin)), 4),
            })
        return rows
    except Exception as e:
        return []


def build_target_analysis(df: pd.DataFrame, dtype_map: dict,
                           target: str, n_bins_list: list[int] | None = None,
                           bin_methods: list[str] | None = None) -> dict:
    """
    Pre-aggregate all data needed for Target Analysis tab.

    Parameters
    ----------
    df           : full DataFrame (no sampling)
    dtype_map    : {col: dtype_string}
    target       : target column name
    n_bins_list  : list of bin counts to pre-compute (default [10, 20])
    bin_methods  : list of methods: "equal", "quantile" (default both)

    Returns
    -------
    dict with keys:
      - target_col     : str
      - univariate     : dict (histogram + stats)
      - categorical    : {col: [row dicts]}
      - numeric        : {col: {"equal": {10: [...], 20: [...]}, "quantile": {...}}}
    """
    if n_bins_list  is None: n_bins_list  = [10, 20]
    if bin_methods  is None: bin_methods  = ["equal", "quantile"]

    if target not in df.columns:
        return {}

    cat_cols = [c for c, t in dtype_map.items()
                if t == "Categorical" and c != target and c in df.columns]
    num_cols = [c for c, t in dtype_map.items()
                if t in ("Numeric", "Boolean") and c != target and c in df.columns]

    import time
    t0 = time.time()
    n  = len(df)
    print(f"[TA] Target Analysis: {n:,} rows × {len(cat_cols)} cat + {len(num_cols)} num features")

    # ── Target univariate ─────────────────────────────────────────────────────
    univariate = _target_univariate(df, target)
    print(f"[TA] Univariate done ({time.time()-t0:.1f}s)")

    # ── Categorical features ──────────────────────────────────────────────────
    categorical = {}
    for i, col in enumerate(cat_cols):
        try:
            categorical[col] = _aggregate_categorical(df, col, target)
        except Exception as e:
            print(f"[TA] WARN cat {col}: {e}")
        if (i+1) % 10 == 0:
            print(f"[TA] Categorical {i+1}/{len(cat_cols)} ({time.time()-t0:.1f}s)")

    print(f"[TA] All categorical done ({time.time()-t0:.1f}s)")

    # ── Numeric features ──────────────────────────────────────────────────────
    numeric = {}
    for i, col in enumerate(num_cols):
        numeric[col] = {}
        for method in bin_methods:
            numeric[col][method] = {}
            for nb in n_bins_list:
                try:
                    numeric[col][method][nb] = _aggregate_numeric_bins(
                        df, col, target, nb, method)
                except Exception as e:
                    print(f"[TA] WARN num {col} {method} {nb}: {e}")
                    numeric[col][method][nb] = []
        if (i+1) % 10 == 0:
            print(f"[TA] Numeric {i+1}/{len(num_cols)} ({time.time()-t0:.1f}s)")

    elapsed = round(time.time() - t0, 1)
    print(f"[TA] Target Analysis complete in {elapsed}s")

    return {
        "target_col":   target,
        "n_rows":       n,
        "univariate":   univariate,
        "categorical":  categorical,
        "numeric":      numeric,
        "n_bins_list":  n_bins_list,
        "bin_methods":  bin_methods,
        "elapsed_sec":  elapsed,
    }
