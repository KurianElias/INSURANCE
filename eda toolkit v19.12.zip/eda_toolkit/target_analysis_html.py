"""
target_analysis_html.py — Insurance EDA Toolkit v5
Generates the Target Analysis HTML tab section.

All interactivity is pure JS — no server needed.
Data is pre-aggregated Python-side; the browser does:
  - metric toggle (mean / median / sum)
  - log-scale toggle
  - sort (by count / metric / alphabetical)
  - "Other" grouping for low-frequency categories
  - bin-count slider (switches between pre-computed configs)
  - show/hide exposure bars
  - outlier cap toggle
"""
from __future__ import annotations
import json, math
import numpy as np
import pandas as pd

# ── JSON encoder ──────────────────────────────────────────────────────────────
class _Enc(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (np.integer,)):   return int(o)
        if isinstance(o, (np.floating,)):  return float(o)
        if isinstance(o, np.ndarray):      return o.tolist()
        try:
            if pd.isna(o): return None
        except Exception:
            pass
        return super().default(o)

def _j(v): return json.dumps(v, cls=_Enc, separators=(",", ":"))

def _esc(s):
    return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"','&quot;')

def _safe(v, d=0.0):
    try:    return float(v)
    except: return d

# ── CSS for Target Analysis tab ───────────────────────────────────────────────
TA_CSS = """
/* Target Analysis tab */
.ta-ctrl-bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;
             background:#fff;border:1px solid var(--bdr);border-left:4px solid var(--acc);
             border-radius:var(--r);padding:12px 16px;margin-bottom:16px;
             box-shadow:var(--sh)}
.ta-ctrl-grp{display:flex;flex-direction:column;gap:4px}
.ta-ctrl-lbl{font-size:.72rem;font-weight:600;text-transform:uppercase;
             letter-spacing:.06em;color:var(--txt2)}
.ta-btn-row{display:flex;gap:3px}
.ta-btn{padding:5px 12px;border:1px solid var(--bdr);border-radius:5px;
        font-size:.79rem;font-weight:500;cursor:pointer;background:#fff;
        color:var(--txt2);font-family:inherit;transition:all .12s}
.ta-btn:hover{border-color:var(--navy2);color:var(--navy2)}
.ta-btn.on{background:var(--navy);color:#fff;border-color:var(--navy);font-weight:600}
.ta-toggle{display:flex;align-items:center;gap:6px;font-size:.82rem;
           cursor:pointer;user-select:none;padding:5px 10px;
           border:1px solid var(--bdr);border-radius:5px;background:#fff;
           transition:all .12s}
.ta-toggle input{accent-color:var(--acc);width:14px;height:14px}
.ta-toggle:has(input:checked){background:var(--acc-l);border-color:var(--acc);color:var(--acc)}
.ta-slider-wrap{display:flex;flex-direction:column;gap:4px;min-width:160px}
.ta-slider-lbl{font-size:.72rem;font-weight:600;text-transform:uppercase;
               letter-spacing:.06em;color:var(--txt2)}
.ta-slider{width:100%;accent-color:var(--acc)}

.ta-feat-bar{display:flex;align-items:center;gap:12px;margin-bottom:14px;
             background:#fff;border:1px solid var(--bdr);
             border-left:4px solid var(--navy2);
             border-radius:var(--r);padding:11px 16px;box-shadow:var(--sh)}
.ta-feat-lbl{font-size:.82rem;font-weight:600;color:var(--navy);white-space:nowrap}
.ta-feat-sel{padding:7px 12px;border:1px solid var(--bdr);border-radius:7px;
             font-size:.87rem;font-family:inherit;background:#fff;color:var(--txt);
             min-width:240px;flex:1;outline:none;cursor:pointer}
.ta-feat-sel:focus{border-color:var(--navy2)}

.ta-method-row{display:flex;gap:6px;margin-bottom:10px}
.ta-method-btn{padding:4px 12px;border:1px solid var(--bdr);border-radius:5px;
               font-size:.78rem;font-weight:500;cursor:pointer;background:#fff;
               color:var(--txt2);font-family:inherit;transition:all .12s}
.ta-method-btn.on{background:var(--navy2);color:#fff;border-color:var(--navy2)}

.ta-panel{display:none}
.ta-panel.on{display:block}

.ta-stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));
              gap:10px;margin:12px 0 16px}
.ta-stat{background:#fff;border:1px solid var(--bdr);border-top:3px solid var(--acc);
         border-radius:var(--r);padding:.55rem .9rem .45rem;box-shadow:var(--sh)}
.ta-stat-v{font-size:1.1rem;font-weight:700;color:var(--navy);line-height:1.2}
.ta-stat-l{font-size:.67rem;color:var(--txt2);text-transform:uppercase;
           letter-spacing:.05em;margin-top:2px}

.ta-hist-type{display:flex;gap:4px;margin-bottom:10px}

/* univariate sub-tabs */
.ta-sub-tabs{display:flex;gap:0;border-bottom:2px solid var(--bdr);margin-bottom:14px}
.ta-sub-tab{padding:7px 16px;font-size:13px;font-weight:500;cursor:pointer;
            border:none;background:none;color:var(--txt2);
            border-bottom:2px solid transparent;margin-bottom:-2px;
            font-family:inherit;transition:all .13s}
.ta-sub-tab.on{color:var(--navy);border-bottom-color:var(--navy);font-weight:600}
.ta-sub-panel{display:none}
.ta-sub-panel.on{display:block}
"""

# ── JS for Target Analysis ────────────────────────────────────────────────────
TA_JS = r"""
// ════════════════════════════════════════════════════════════════
//  TARGET ANALYSIS — all interactive logic
// ════════════════════════════════════════════════════════════════

// ── global state ──────────────────────────────────────────────
var TA = {
  metric:     'mean',    // mean | median | sum
  logY:       false,
  capP99:     false,
  showExpo:   true,
  catSort:    'count',   // count | metric | alpha
  otherThresh: 0,        // combine cats with pct < this
  numMethod:  'equal',   // equal | quantile
  numBins:    20,
};

// ── helpers ───────────────────────────────────────────────────
function taFmt(v, digits) {
  if (v === null || v === undefined) return '—';
  var d = digits !== undefined ? digits : 4;
  var f = +v;
  if (isNaN(f)) return '—';
  if (Math.abs(f) >= 1e6) return (f/1e6).toFixed(3)+'M';
  if (Math.abs(f) >= 1e3) return f.toLocaleString(undefined,{maximumFractionDigits:2});
  return f.toFixed(d);
}

function taSetMetric(m) {
  TA.metric = m;
  document.querySelectorAll('.ta-metric-btn').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-m') === m);
  });
  taRefreshActive();
}
function taToggleLog(cb)    { TA.logY     = cb.checked; taRefreshActive(); }
function taToggleCap(cb)    { TA.capP99   = cb.checked; taRefreshActive(); }
function taToggleExpo(cb)   { TA.showExpo = cb.checked; taRefreshActive(); }
function taSetSort(s) {
  TA.catSort = s;
  document.querySelectorAll('.ta-sort-btn').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-s') === s);
  });
  taRefreshActive();
}
function taSetOther(v) {
  TA.otherThresh = +v;
  var el = document.getElementById('ta-other-lbl');
  if (el) el.textContent = v > 0 ? 'Group <' + v + '% → Other' : 'Off';
  taRefreshActive();
}
function taSetMethod(m) {
  TA.numMethod = m;
  document.querySelectorAll('.ta-method-btn').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-meth') === m);
  });
  taRefreshNum();
}
function taSetBins(v) {
  TA.numBins = +v;
  var el = document.getElementById('ta-bins-lbl');
  if (el) el.textContent = v + ' bins';
  taRefreshNum();
}

// ── track what's active ───────────────────────────────────────
var TA_ACTIVE = { type: null, col: null }; // 'cat' | 'num' | 'uni'

function taRefreshActive() {
  if (TA_ACTIVE.type === 'cat') taRenderCat(TA_ACTIVE.col);
  else if (TA_ACTIVE.type === 'num') taRenderNum(TA_ACTIVE.col);
  else if (TA_ACTIVE.type === 'uni') taRenderUni();
}
function taRefreshNum() {
  if (TA_ACTIVE.type === 'num') taRenderNum(TA_ACTIVE.col);
}

// ── show sub-tab (Univariate / Categorical / Numerical) ───────
function taShowTab(btn, id) {
  var wrap = document.getElementById('ta-main');
  if (!wrap) return;
  wrap.querySelectorAll('.ta-panel').forEach(function(p){ p.classList.remove('on'); });
  wrap.querySelectorAll('.ta-sub-tab').forEach(function(b){ b.classList.remove('on'); });
  var pane = document.getElementById(id);
  if (pane) pane.classList.add('on');
  btn.classList.add('on');
}

// ════════════════════════════════════════════════════════════════
//  UNIVARIATE
// ════════════════════════════════════════════════════════════════
function taRenderUni() {
  TA_ACTIVE.type = 'uni';
  var D = window.TA_UNI;
  if (!D) return;
  var hist = TA.logY ? D.hist_log : D.hist_clip;
  if (!hist || !hist.counts) return;
  var edges = hist.edges, counts = hist.counts;
  var mids  = [];
  for (var i = 0; i < counts.length; i++) {
    mids.push(((+edges[i]) + (+edges[i+1])) / 2);
  }
  var data = [{
    type: 'bar', x: mids, y: counts,
    marker: { color: 'rgba(0,43,92,0.75)' },
    hovertemplate: 'Range: [%{x:.4g}]<br>Count: %{y:,}<extra></extra>',
    name: 'Count',
  }];
  var layout = {
    title: { text: 'Target Distribution' + (TA.logY ? ' (log1p)' : ''), font:{size:13} },
    xaxis: { title: window.TA_TARGET || 'Target', gridcolor:'#D4DCE8' },
    yaxis: { title: 'Count', type: TA.logY ? 'log' : 'linear', gridcolor:'#D4DCE8' },
    paper_bgcolor:'rgba(0,0,0,0)', plot_bgcolor:'rgba(0,0,0,0)',
    font: { family:'Inter,sans-serif', size:11, color:'#0D1B2E' },
    height: 340, margin:{l:60,r:20,t:40,b:50},
    bargap: 0.04,
  };
  renderTAChart('ta-uni-chart', data, layout);
  // update table
  taBuildUniTable();
}

function taBuildUniTable() {
  var D = window.TA_UNI; if (!D) return;
  var s = D.stats;
  var rows = [
    ['Count', (s.count||0).toLocaleString()],
    ['Mean',   taFmt(s.mean)],
    ['Median', taFmt(s.median)],
    ['Std',    taFmt(s.std)],
    ['Min',    taFmt(s.min)],
    ['Max',    taFmt(s.max)],
    ['P25',    taFmt(s.p25)],
    ['P75',    taFmt(s.p75)],
    ['P95',    taFmt(s.p95)],
    ['P99',    taFmt(s.p99)],
    ['Skewness', taFmt(s.skewness,3)],
    ['Zero %', taFmt(s.zero_pct,2)+'%'],
  ];
  var html = '<table class="dt" style="max-width:380px"><thead><tr><th>Statistic</th><th>Value</th></tr></thead><tbody>';
  rows.forEach(function(r){ html += '<tr><td>'+r[0]+'</td><td style="font-weight:600;color:var(--navy)">'+r[1]+'</td></tr>'; });
  html += '</tbody></table>';
  var el = document.getElementById('ta-uni-stats'); if (el) el.innerHTML = html;
}

// ════════════════════════════════════════════════════════════════
//  CATEGORICAL
// ════════════════════════════════════════════════════════════════
function taSelectCat(col) {
  TA_ACTIVE = { type:'cat', col:col };
  taRenderCat(col);
}

function taRenderCat(col) {
  var allData = window.TA_CAT && window.TA_CAT[col];
  if (!allData || !allData.length) {
    var el=document.getElementById('ta-cat-chart'); if(el) el.innerHTML='<p class="cap">No data.</p>';
    return;
  }
  var m = TA.metric; // mean | median | sum

  // Apply "Other" grouping
  var thresh = TA.otherThresh;
  var data = allData.slice();
  var other = { category:'(Other)', count:0, pct:0, mean:0, median:0, sum:0 };
  var kept = [], grouped = [];
  if (thresh > 0) {
    data.forEach(function(r){ if (+r.pct < thresh) grouped.push(r); else kept.push(r); });
    if (grouped.length > 0) {
      var n = grouped.reduce(function(a,r){ return a + (+r.count||0); }, 0);
      var wsum = grouped.reduce(function(a,r){ return a + (+r.mean||0)*((+r.count)||0); }, 0);
      other.count  = n;
      other.pct    = grouped.reduce(function(a,r){ return a + (+r.pct||0); }, 0);
      other.mean   = n > 0 ? wsum/n : 0;
      other.sum    = grouped.reduce(function(a,r){ return a + (+r.sum||0); }, 0);
      kept.push(other);
    }
    data = kept;
  }

  // Sort
  var sortKey = TA.catSort;
  if (sortKey === 'count') data.sort(function(a,b){ return (+b.count||0)-(+a.count||0); });
  else if (sortKey === 'metric') data.sort(function(a,b){ return (+b[m]||0)-(+a[m]||0); });
  else data.sort(function(a,b){ return a.category.localeCompare(b.category); });

  var cats   = data.map(function(r){ return r.category; });
  var counts = data.map(function(r){ return +r.count||0; });
  var mvals  = data.map(function(r){ return +r[m]||0; });
  var metricLabel = m.charAt(0).toUpperCase()+m.slice(1)+' Target';

  var traces = [];
  // Exposure bars (primary axis, optional)
  if (TA.showExpo) {
    traces.push({
      type:'bar', x:cats, y:counts,
      name:'Count (exposure)', yaxis:'y2',
      marker:{ color:'rgba(0,74,151,0.22)', line:{ color:'rgba(0,74,151,0.5)', width:1 } },
      hovertemplate:'%{x}<br>Count: %{y:,}<extra></extra>',
    });
  }
  // Mean/median/sum line (primary axis)
  var lineColor = '#C8922A';
  traces.push({
    type:'scatter', mode:'lines+markers', x:cats, y:mvals,
    name:metricLabel, yaxis:'y',
    line:{ color:lineColor, width:2.5 },
    marker:{ color:lineColor, size:6, symbol:'circle' },
    hovertemplate:'%{x}<br>'+metricLabel+': %{y:.6g}<extra></extra>',
  });

  var ylog = TA.logY ? 'log' : 'linear';
  var layout = {
    title:{ text:col+' vs '+window.TA_TARGET, font:{size:13} },
    xaxis:{ title:col, type:'category', tickangle:cats.length>8?-35:0, gridcolor:'#D4DCE8' },
    yaxis:{ title:metricLabel, type:ylog, gridcolor:'#D4DCE8', side:'left', color:lineColor },
    yaxis2:{ title:'Count', overlaying:'y', side:'right', showgrid:false, color:'rgba(0,74,151,0.7)' },
    paper_bgcolor:'rgba(0,0,0,0)', plot_bgcolor:'rgba(0,0,0,0)',
    font:{ family:'Inter,sans-serif', size:11, color:'#0D1B2E' },
    height:380, margin:{l:70,r:80,t:42,b:80},
    legend:{ x:1.08, y:1, bgcolor:'rgba(0,0,0,0)' },
    barmode:'overlay',
  };

  renderTAChart('ta-cat-chart', traces, layout);
  taBuildCatTable(data, m, metricLabel);
}

function taBuildCatTable(data, m, metricLabel) {
  var hdr = '<tr><th>Category</th><th>Count</th><th>% of Total</th>'
          + '<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows = data.map(function(r){
    var bold = r.category==='(Other)'?' style="font-style:italic;color:var(--txt2)"':'';
    return '<tr'+bold+'><td>'+r.category+'</td>'
      +'<td style="text-align:right">'+(+r.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+taFmt(r.pct,2)+'%</td>'
      +'<td style="text-align:right;color:var(--acc);font-weight:600">'+taFmt(r.mean,6)+'</td>'
      +'<td style="text-align:right">'+taFmt(r.median,6)+'</td>'
      +'<td style="text-align:right">'+taFmt(r.sum,4)+'</td></tr>';
  }).join('');
  var html = '<div class="tw"><table class="dt sortable" id="ta-cat-tbl"><thead>'+hdr+'</thead><tbody>'+rows+'</tbody></table></div>';
  html += '<div class="tbl-ctrl"><a class="dl-btn" id="ta-cat-dl">⬇ Download CSV</a></div>';
  var el = document.getElementById('ta-cat-table'); if (el) el.innerHTML = html;
  // wire download
  var dlBtn = document.getElementById('ta-cat-dl');
  if (dlBtn) {
    var csv = 'Category,Count,Pct,Mean,Median,Sum\n'
            + data.map(function(r){
                return [r.category,r.count,r.pct,r.mean,r.median,r.sum].join(',');
              }).join('\n');
    var b64 = btoa(unescape(encodeURIComponent(csv)));
    dlBtn.href = 'data:text/csv;base64,'+b64;
    dlBtn.download = (TA_ACTIVE.col||'cat')+'_target.csv';
  }
}

// ════════════════════════════════════════════════════════════════
//  NUMERICAL
// ════════════════════════════════════════════════════════════════
function taSelectNum(col) {
  TA_ACTIVE = { type:'num', col:col };
  taRenderNum(col);
}

function taRenderNum(col) {
  var allData = window.TA_NUM && window.TA_NUM[col];
  if (!allData) { return; }
  var method = TA.numMethod;
  var nb     = TA.numBins;
  var bins   = (allData[method] && allData[method][nb]) ? allData[method][nb] : [];
  if (!bins || !bins.length) {
    var el=document.getElementById('ta-num-chart');
    if(el) el.innerHTML='<p class="cap">No data for '+method+' binning at '+nb+' bins.</p>';
    return;
  }
  var m = TA.metric;
  var labels = bins.map(function(b){ return b.bin; });
  var counts = bins.map(function(b){ return +b.count||0; });
  var mvals  = bins.map(function(b){ return +b[m]||0; });
  var midpoints = bins.map(function(b){ return ((+b.bin_lo||0)+(+b.bin_hi||0))/2; });
  var metricLabel = m.charAt(0).toUpperCase()+m.slice(1)+' Target';
  var ylog = TA.logY ? 'log' : 'linear';

  var traces = [
    {
      type:'bar', x:midpoints, y:counts, name:'Count (exposure)', yaxis:'y2',
      marker:{ color:'rgba(0,74,151,0.22)', line:{ color:'rgba(0,74,151,0.5)', width:1 } },
      hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>',
      text: labels,
    },
    {
      type:'scatter', mode:'lines+markers', x:midpoints, y:mvals,
      name:metricLabel, yaxis:'y',
      line:{ color:'#C8922A', width:2.5 },
      marker:{ color:'#C8922A', size:6 },
      hovertemplate:'%{text}<br>'+metricLabel+': %{y:.6g}<extra></extra>',
      text: labels,
    },
  ];
  var layout = {
    title:{ text:col+' (binned) vs '+window.TA_TARGET+' ['+method+', '+nb+' bins]', font:{size:13} },
    xaxis:{ title:col, gridcolor:'#D4DCE8' },
    yaxis:{ title:metricLabel, type:ylog, side:'left', color:'#C8922A', gridcolor:'#D4DCE8' },
    yaxis2:{ title:'Count', overlaying:'y', side:'right', showgrid:false, color:'rgba(0,74,151,0.7)' },
    paper_bgcolor:'rgba(0,0,0,0)', plot_bgcolor:'rgba(0,0,0,0)',
    font:{ family:'Inter,sans-serif', size:11, color:'#0D1B2E' },
    height:380, margin:{l:70,r:80,t:42,b:60},
    legend:{ x:1.08, y:1, bgcolor:'rgba(0,0,0,0)' },
    barmode:'overlay',
  };
  renderTAChart('ta-num-chart', traces, layout);
  taBuildNumTable(bins, m, metricLabel, col);
}

function taBuildNumTable(bins, m, metricLabel, col) {
  var hdr = '<tr><th>Bin</th><th>Count</th><th>% of Total</th>'
          + '<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows = bins.map(function(b){
    return '<tr><td>'+b.bin+'</td>'
      +'<td style="text-align:right">'+(+b.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+taFmt(b.pct,2)+'%</td>'
      +'<td style="text-align:right;color:var(--acc);font-weight:600">'+taFmt(b.mean,6)+'</td>'
      +'<td style="text-align:right">'+taFmt(b.median,6)+'</td>'
      +'<td style="text-align:right">'+taFmt(b.sum,4)+'</td></tr>';
  }).join('');
  var html = '<div class="tw"><table class="dt sortable" id="ta-num-tbl"><thead>'+hdr+'</thead><tbody>'+rows+'</tbody></table></div>';
  html += '<div class="tbl-ctrl"><a class="dl-btn" id="ta-num-dl">⬇ Download CSV</a></div>';
  var el = document.getElementById('ta-num-table'); if (el) el.innerHTML = html;
  var dlBtn = document.getElementById('ta-num-dl');
  if (dlBtn) {
    var csv = 'Bin,Bin_Lo,Bin_Hi,Count,Pct,Mean,Median,Sum\n'
            + bins.map(function(b){
                return ['"'+b.bin+'"',b.bin_lo,b.bin_hi,b.count,b.pct,b.mean,b.median,b.sum].join(',');
              }).join('\n');
    var b64 = btoa(unescape(encodeURIComponent(csv)));
    dlBtn.href = 'data:text/csv;base64,'+b64;
    dlBtn.download = (col||'num')+'_target_binned.csv';
  }
}

// ── chart renderer (reuse Plotly) ─────────────────────────────
function renderTAChart(id, data, layout) {
  var el = document.getElementById(id);
  if (!el || !window.Plotly) return;
  // show/hide loader
  var wrap = el.closest ? el.closest('.chart-wrap') : null;
  if (wrap) {
    var ldr = wrap.querySelector('.chart-loader');
    if (ldr) ldr.classList.add('done');
  }
  var cfg = { responsive:true, displayModeBar:true, displaylogo:false,
              modeBarButtonsToRemove:['sendDataToCloud','lasso2d','select2d'] };
  if (el._taPlotted) {
    Plotly.react(id, data, layout, cfg);
  } else {
    Plotly.newPlot(id, data, layout, cfg);
    el._taPlotted = true;
  }
}

// ── init target analysis ──────────────────────────────────────
function taInit() {
  // Show univariate first
  taRenderUni();
}
"""


def build_ta_html(R: dict) -> str:
    """
    Build the full Target Analysis tab HTML.
    Returns empty string if no target or no deep_target_analysis.
    """
    target  = R.get("target_col")
    dta     = R.get("deep_target_analysis", {})
    dm      = R.get("dtype_map", {})

    if not target:
        return _alert_html("No target column defined. Pass target_col= to inspect().", "yellow")
    if not dta:
        return _alert_html(
            "Target Analysis not computed. Ensure set_sections(target_analysis=True) "
            "and target_col is set before running run_eda().", "yellow")

    cat_cols = sorted(dta.get("categorical", {}).keys())
    num_cols = sorted(dta.get("numeric", {}).keys())
    uni      = dta.get("univariate", {})
    n_bins_list = dta.get("n_bins_list", [10, 20])
    bin_methods = dta.get("bin_methods", ["equal", "quantile"])

    # ── Inline JSON data ──────────────────────────────────────────────────────
    # Keep file size reasonable: only embed pre-aggregated tables, never raw data
    cat_data = dta.get("categorical", {})
    num_data = dta.get("numeric", {})

    data_script = f"""
<script>
window.TA_TARGET = {_j(target)};
window.TA_UNI    = {_j(uni)};
window.TA_CAT    = {_j(cat_data)};
window.TA_NUM    = {_j(num_data)};
</script>"""

    # ── Target univariate stats display ──────────────────────────────────────
    stats = uni.get("stats", {})
    def _sv(k, fmt=".4g"):
        v = stats.get(k)
        if v is None: return "—"
        try: return format(float(v), fmt)
        except: return str(v)

    uni_stats_html = '<div class="ta-stat-grid">'
    for lbl, key, fmt in [("Count","count",",.0f"),("Mean","mean",".4g"),
                           ("Median","median",".4g"),("Std Dev","std",".4g"),
                           ("Min","min",".4g"),("Max","max",".4g"),
                           ("P95","p95",".4g"),("P99","p99",".4g"),
                           ("Skewness","skewness",".3f"),("Zero %","zero_pct",".2f")]:
        v = stats.get(key)
        disp = "—"
        if v is not None:
            try:
                fv = float(v)
                if key == "count": disp = f"{int(fv):,}"
                elif key == "zero_pct": disp = f"{fv:.2f}%"
                else: disp = format(fv, fmt)
            except: disp = str(v)
        uni_stats_html += f'<div class="ta-stat"><div class="ta-stat-v">{disp}</div><div class="ta-stat-l">{lbl}</div></div>'
    uni_stats_html += '</div>'

    # ── Categorical dropdown ──────────────────────────────────────────────────
    cat_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in cat_cols)
    num_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in num_cols)

    # ── Bin slider ────────────────────────────────────────────────────────────
    n_bins_min  = min(n_bins_list)
    n_bins_max  = max(n_bins_list)
    n_bins_def  = 20 if 20 in n_bins_list else n_bins_list[0]
    # slider steps map to the discrete pre-computed bins
    bins_json   = _j(n_bins_list)

    # ── Method buttons ────────────────────────────────────────────────────────
    method_btns = "".join(
        f'<button class="ta-method-btn{"  on" if m == "equal" else ""}" '
        f'data-meth="{m}" onclick="taSetMethod(\'{m}\')">'
        f'{"Equal Width" if m == "equal" else "Quantile"}</button>'
        for m in bin_methods
    )

    elapsed = dta.get("elapsed_sec", 0)

    html = f"""
{data_script}

<!-- TA global controls bar -->
<div class="ta-ctrl-bar">
  <!-- Metric -->
  <div class="ta-ctrl-grp">
    <div class="ta-ctrl-lbl">Metric</div>
    <div class="ta-btn-row">
      <button class="ta-btn ta-metric-btn on" data-m="mean"   onclick="taSetMetric('mean')">Mean</button>
      <button class="ta-btn ta-metric-btn"    data-m="median" onclick="taSetMetric('median')">Median</button>
      <button class="ta-btn ta-metric-btn"    data-m="sum"    onclick="taSetMetric('sum')">Sum</button>
    </div>
  </div>
  <!-- Toggles -->
  <div class="ta-ctrl-grp">
    <div class="ta-ctrl-lbl">Options</div>
    <div class="ta-btn-row">
      <label class="ta-toggle"><input type="checkbox" onchange="taToggleLog(this)"> Log Y-axis</label>
      <label class="ta-toggle"><input type="checkbox" checked onchange="taToggleExpo(this)"> Show Exposure</label>
    </div>
  </div>
  <!-- Sort (categorical) -->
  <div class="ta-ctrl-grp" id="ta-sort-ctrl">
    <div class="ta-ctrl-lbl">Sort (Categorical)</div>
    <div class="ta-btn-row">
      <button class="ta-btn ta-sort-btn on" data-s="count"  onclick="taSetSort('count')">By Count</button>
      <button class="ta-btn ta-sort-btn"    data-s="metric" onclick="taSetSort('metric')">By Metric</button>
      <button class="ta-btn ta-sort-btn"    data-s="alpha"  onclick="taSetSort('alpha')">A–Z</button>
    </div>
  </div>
  <!-- Other grouping -->
  <div class="ta-ctrl-grp" id="ta-other-ctrl">
    <div class="ta-ctrl-lbl">Group small cats <span id="ta-other-lbl" style="color:var(--acc)">Off</span></div>
    <input type="range" class="ta-slider" min="0" max="5" step="0.5" value="0"
           oninput="taSetOther(this.value)" style="width:140px">
  </div>
  <div class="ta-ctrl-grp" style="margin-left:auto;font-size:.75rem;color:var(--txt3)">
    Pre-computed in {elapsed:.1f}s · No sampling
  </div>
</div>

<!-- Main sub-tabs -->
<div class="ta-sub-tabs">
  <button class="ta-sub-tab on" onclick="taShowTab(this,'ta-uni')">🎯 Target Overview</button>
  <button class="ta-sub-tab" onclick="taShowTab(this,'ta-cat')">🏷️ Categorical vs Target</button>
  <button class="ta-sub-tab" onclick="taShowTab(this,'ta-num')">🔢 Numerical vs Target</button>
</div>

<div id="ta-main">

<!-- ═══════════════════════════════════════════════════════
     UNIVARIATE
═══════════════════════════════════════════════════════ -->
<div id="ta-uni" class="ta-panel on">
  <h3 class="sh">Target Overview — {_esc(target)}</h3>
  <p class="cap">Full dataset · {dta.get("n_rows",0):,} rows · No sampling</p>
  {uni_stats_html}
  <div class="chart-wrap">
    <div class="chart-loader"><div class="spinner"></div><span>Rendering…</span></div>
    <div id="ta-uni-chart" style="width:100%;height:340px"></div>
  </div>
  <div id="ta-uni-stats" style="margin-top:14px"></div>
</div>

<!-- ═══════════════════════════════════════════════════════
     CATEGORICAL
═══════════════════════════════════════════════════════ -->
<div id="ta-cat" class="ta-panel">
  <h3 class="sh">Categorical Features vs {_esc(target)}</h3>
  <p class="cap">{len(cat_cols)} categorical features · Exposure bars = count · Line = selected metric · Use controls above to sort/group</p>
  {"" if cat_cols else '<div class="al" style="background:#eff6ff;color:#1e3a5f;border-left:3px solid #3b82f6">No categorical features found.</div>'}
  {"" if not cat_cols else f'''
  <div class="ta-feat-bar">
    <label class="ta-feat-lbl">Select Feature</label>
    <select class="ta-feat-sel" onchange="taSelectCat(this.value)">{cat_opts}</select>
  </div>
  <div class="chart-wrap">
    <div class="chart-loader"><div class="spinner"></div><span>Rendering…</span></div>
    <div id="ta-cat-chart" style="width:100%;height:380px"></div>
  </div>
  <div id="ta-cat-table" style="margin-top:14px"></div>
  '''}
</div>

<!-- ═══════════════════════════════════════════════════════
     NUMERICAL
═══════════════════════════════════════════════════════ -->
<div id="ta-num" class="ta-panel">
  <h3 class="sh">Numerical Features vs {_esc(target)}</h3>
  <p class="cap">{len(num_cols)} numeric features · Bars = count per bin · Line = selected metric · Adjust bins &amp; method below</p>
  {"" if num_cols else '<div class="al" style="background:#eff6ff;color:#1e3a5f;border-left:3px solid #3b82f6">No numeric features found.</div>'}
  {"" if not num_cols else f'''
  <div class="ta-feat-bar" style="flex-wrap:wrap;gap:10px">
    <div style="display:flex;align-items:center;gap:10px;flex:1;min-width:240px">
      <label class="ta-feat-lbl">Feature</label>
      <select class="ta-feat-sel" onchange="taSelectNum(this.value)">{num_opts}</select>
    </div>
    <div style="display:flex;align-items:center;gap:10px">
      <label class="ta-feat-lbl">Binning</label>
      {method_btns}
    </div>
    <div class="ta-slider-wrap">
      <div class="ta-slider-lbl">Bins: <strong id="ta-bins-lbl">{n_bins_def}</strong></div>
      <input type="range" class="ta-slider"
             min="0" max="{len(n_bins_list)-1}" step="1"
             value="{n_bins_list.index(n_bins_def) if n_bins_def in n_bins_list else 0}"
             oninput="taSetBinsByIdx(this.value,{bins_json})"
             style="width:140px">
    </div>
  </div>
  <div class="chart-wrap">
    <div class="chart-loader"><div class="spinner"></div><span>Rendering…</span></div>
    <div id="ta-num-chart" style="width:100%;height:380px"></div>
  </div>
  <div id="ta-num-table" style="margin-top:14px"></div>
  '''}
</div>

</div><!-- #ta-main -->

<script>
// bin slider maps index → actual n_bins value
function taSetBinsByIdx(idx, bins) {{
  var nb = bins[+idx] || bins[0];
  TA.numBins = nb;
  var el = document.getElementById('ta-bins-lbl');
  if (el) el.textContent = nb + ' bins';
  taRefreshNum();
}}
// initialise first selections
(function(){{
  var firstCat = {_j(cat_cols[0] if cat_cols else "")};
  var firstNum = {_j(num_cols[0] if num_cols else "")};
  window.addEventListener('load', function(){{
    taRenderUni();
    if (firstCat) taSelectCat(firstCat);
    if (firstNum) taSelectNum(firstNum);
  }});
}})();
</script>
"""
    return html


def _alert_html(msg, kind="yellow"):
    m = {"red":("#fef2f2","#b91c1c","#ef4444"),
         "yellow":("#fffbeb","#78350f","#f59e0b"),
         "blue":("#eff6ff","#1e3a5f","#3b82f6"),
         "green":("#f0fdf4","#14532d","#22c55e")}
    bg, fg, bd = m.get(kind, m["yellow"])
    return f'<div class="al" style="background:{bg};color:{fg};border-left:3px solid {bd}">{msg}</div>'
