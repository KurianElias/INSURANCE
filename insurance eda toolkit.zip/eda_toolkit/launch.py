"""
launch.py — Insurance EDA Toolkit

TWO-PHASE WORKFLOW (recommended):
──────────────────────────────────
Step 1 — Inspect and confirm types:

    from eda_toolkit import inspect, run_eda, launch_app

    plan = inspect(df, target_col="Claim_Flag")
    # Prints a table: column, pandas dtype, detected type, unique count,
    # missing %, and sample values. Plus any warnings.

    # If anything is wrong, fix it:
    plan.fix(
        Policy_Year    = "Categorical",   # was detected as Date
        Inception_Date = "Date",          # was detected as Categorical
    )

    plan.confirm()          # prints final confirmed table
    results = run_eda(df, plan)
    launch_app(results)

ONE-SHOT (skip inspect):

    results = run_eda(df, {
        "target_col":  "Claim_Flag",
        "groupby_col": "Policy_Year",
        "agg_config":  {"Claim_Flag": ["sum","mean"], "Premium": ["sum","mean"]},
    })
    launch_app(results)
"""

import sys, os, pickle, subprocess, threading, time, webbrowser
from pathlib import Path
import pandas as pd
import numpy as np

_DIR = Path(__file__).parent
sys.path.insert(0, str(_DIR))

from eda_engine import detect_type, run_eda as _run_eda


# ── constants ─────────────────────────────────────────────────────────────────

VALID_TYPES = {"Numeric", "Categorical", "Boolean", "Date", "ID-like", "Unknown"}

_ICON = {
    "Numeric":     "🔢",
    "Categorical": "🏷️",
    "Boolean":     "☑️",
    "Date":        "📅",
    "ID-like":     "🔑",
    "Unknown":     "❓",
}

_MEANING = {
    "Numeric":     "Continuous number — histogram, stats, IQR outlier check",
    "Categorical": "Discrete labels — frequency table, target rate per category",
    "Boolean":     "Binary flag (0/1) — treated as Numeric",
    "Date":        "Date/time — extract year, month, quarter for modelling",
    "ID-like":     "Identifier — too many unique values, excluded from analysis",
    "Unknown":     "Entirely null or unreadable — excluded from analysis",
}


# ── helpers ───────────────────────────────────────────────────────────────────

def _sample_vals(s: pd.Series, n=5) -> str:
    vals = s.dropna().head(n).tolist()
    return ", ".join(str(v)[:18] for v in vals) if vals else "—"


def _col_warnings(col: str, s: pd.Series, detected: str) -> list:
    warns = []
    nu = int(s.dropna().nunique())
    mp = float(s.isna().mean() * 100)

    if mp == 100:
        warns.append("ALL NULL — will be excluded")
    elif mp > 20:
        warns.append(f"{mp:.0f}% missing")

    if detected == "Numeric":
        try:
            clean = s.dropna().astype(float)
            if nu <= 150 and ((clean >= 1900) & (clean <= 2100)).mean() > 0.90:
                warns.append("Looks like a YEAR — consider 'Date' or 'Categorical'")
        except Exception:
            pass
        if 2 < nu <= 8:
            warns.append(f"Only {nu} unique values — consider 'Categorical'")

    if detected == "Categorical":
        if nu > 100:
            warns.append(f"High cardinality ({nu} unique) — is this an ID column?")
        try:
            sample = s.dropna().astype(str).head(50)
            date_like = sum(
                1 for v in sample
                if any(sep in v for sep in ["-", "/"]) and any(c.isdigit() for c in v)
            )
            if date_like / max(len(sample), 1) > 0.7:
                warns.append("Values look like dates — consider 'Date'")
        except Exception:
            pass

    if detected == "ID-like":
        warns.append("Will be excluded from EDA analysis")

    return warns


# ─────────────────────────────────────────────────────────────────────────────
# InspectPlan
# ─────────────────────────────────────────────────────────────────────────────

class InspectPlan:
    """
    Holds the confirmed column type map + EDA config.
    Returned by inspect(). Pass directly to run_eda().

    Methods
    -------
    plan.fix(Col="NewType", ...)    — correct one or more detected types
    plan.confirm()                  — print final table, mark as ready
    plan.set(key, value)            — set a config value
    """

    def __init__(self, df: pd.DataFrame, dtype_map: dict, config: dict):
        self._df        = df
        self._dtype_map = dict(dtype_map)
        self._overrides = {}
        self._config    = dict(config)
        self._confirmed = False

    def fix(self, **kwargs):
        """
        Override auto-detected types.

        Examples:
            plan.fix(Policy_Year="Categorical")
            plan.fix(Start_Date="Date", Gender="Boolean")

        Valid types: Numeric, Categorical, Boolean, Date, ID-like, Unknown
        """
        for col, new_type in kwargs.items():
            if col not in self._dtype_map:
                print(f"  ⚠️  '{col}' not found in dataset. Available columns:")
                for c in list(self._dtype_map.keys())[:10]:
                    print(f"      - {c}")
                continue
            if new_type not in VALID_TYPES:
                print(f"  ⚠️  '{new_type}' is not a valid type.")
                print(f"       Valid options: {', '.join(sorted(VALID_TYPES))}")
                continue
            old = self._dtype_map[col]
            self._dtype_map[col] = new_type
            self._overrides[col] = new_type
            print(f"  ✔  {col}: {old} → {new_type}")

        self._confirmed = False
        if kwargs:
            print("\n  Call plan.confirm() to review and proceed.")
        return self

    def set(self, key: str, value):
        """Set a config parameter (e.g. target_col, groupby_col)."""
        self._config[key] = value
        return self

    def confirm(self):
        """Print the final confirmed table and mark the plan as ready."""
        print("\n" + "═" * 68)
        print("  ✅  CONFIRMED COLUMN TYPES")
        print("═" * 68)
        print(f"  {'#':<4} {'Column':<28} {'Type':<16} {'Changed?'}")
        print("  " + "─" * 60)
        for i, (col, dtype) in enumerate(self._dtype_map.items(), 1):
            icon    = _ICON.get(dtype, "❓")
            changed = "  ← overridden" if col in self._overrides else ""
            print(f"  {i:<4} {col:<28} {icon} {dtype:<14}{changed}")
        print("─" * 68)

        tc = self._config.get("target_col")
        if tc:
            print(f"  Target column : {tc}")
        if self._overrides:
            print(f"  Manual overrides: {len(self._overrides)} column(s)")
        print("\n  Ready. Call:  results = run_eda(df, plan)\n")
        self._confirmed = True
        return self

    def _as_config(self) -> dict:
        cfg = dict(self._config)
        cfg["dtype_overrides"] = dict(self._overrides)
        return cfg

    # Allow plan to be used like a dict in run_eda
    def get(self, key, default=None):
        return self._config.get(key, default)

    def __repr__(self):
        st = "confirmed ✅" if self._confirmed else "not confirmed ⚠️"
        return (f"<InspectPlan {len(self._dtype_map)} columns, "
                f"{len(self._overrides)} override(s), {st}>")


# ─────────────────────────────────────────────────────────────────────────────
# inspect() — Step 1
# ─────────────────────────────────────────────────────────────────────────────

def inspect(df: pd.DataFrame,
            target_col: str = None,
            id_ratio:   float = 0.8,
            **config_kwargs) -> InspectPlan:
    """
    Detect column types and show a pre-flight confirmation table.

    Parameters
    ----------
    df         : pd.DataFrame
    target_col : str, optional — name of your target/response variable
    id_ratio   : float — unique/rows above which = ID-like (default 0.8)
    **config_kwargs — forwarded to run_eda() (e.g. groupby_col=, agg_config=)

    Returns
    -------
    InspectPlan — fix errors with .fix(), confirm with .confirm(),
                  then call run_eda(df, plan)
    """
    n_rows, n_cols = df.shape
    feats = [c for c in df.columns if c != target_col]

    print(f"\n{'═'*70}")
    print(f"  INSURANCE EDA TOOLKIT — PRE-FLIGHT INSPECTION")
    print(f"  {n_rows:,} rows  ×  {n_cols} columns", end="")
    if target_col:
        print(f"  |  Target: {target_col}", end="")
    print(f"\n{'═'*70}\n")

    # detect
    dtype_map    = {c: detect_type(df[c], id_ratio) for c in feats}
    warnings_map = {c: _col_warnings(c, df[c], dtype_map[c]) for c in feats}

    # ── column table ──────────────────────────────────────────────────────────
    print(f"  {'#':<4} {'Column':<28} {'Pandas dtype':<14} {'Detected as':<18}"
          f"{'Unique':>8} {'Missing':>8}  Sample values")
    print("  " + "─" * 108)

    for i, col in enumerate(feats, 1):
        dt      = dtype_map[col]
        icon    = _ICON.get(dt, "❓")
        pd_type = str(df[col].dtype)
        nu      = int(df[col].nunique())
        mp      = float(df[col].isna().mean() * 100)
        sample  = _sample_vals(df[col])
        warn    = " ⚠️" if warnings_map[col] else ""

        print(f"  {i:<4} {col:<28} {pd_type:<14} "
              f"{icon} {dt:<16} {nu:>8,} {mp:>6.1f}%{warn}  {sample}")

    print("  " + "─" * 108)

    # ── warnings section ──────────────────────────────────────────────────────
    all_warnings = [(col, w) for col, ws in warnings_map.items() for w in ws]
    if all_warnings:
        print(f"\n  ⚠️  WARNINGS ({len(all_warnings)} total) — review these:\n")
        for col, w in all_warnings:
            print(f"     {col:<28} → {w}")
    else:
        print(f"\n  ✅  No warnings detected — all types look reasonable.")

    # ── type key ──────────────────────────────────────────────────────────────
    print(f"\n  TYPE KEY:")
    for t, m in _MEANING.items():
        print(f"    {_ICON[t]} {t:<14}  {m}")

    # ── instructions ─────────────────────────────────────────────────────────
    print(f"""
  {'─'*68}
  If any types are wrong, fix them before running EDA:

    plan.fix(
        ColumnName  = "CorrectType",
        OtherColumn = "Date",
    )
    plan.confirm()             # shows final confirmed types
    results = run_eda(df, plan)

  Valid types: Numeric  Categorical  Boolean  Date  ID-like  Unknown

  If everything looks correct:
    plan.confirm()
    results = run_eda(df, plan)
  {'─'*68}
""")

    config = {"target_col": target_col, "id_ratio": id_ratio}
    config.update(config_kwargs)
    return InspectPlan(df, dtype_map, config)


# ─────────────────────────────────────────────────────────────────────────────
# run_eda()
# ─────────────────────────────────────────────────────────────────────────────

def run_eda(df: pd.DataFrame, config) -> dict:
    """
    Run EDA. Accepts InspectPlan (from inspect()) or a plain dict.

    Returns dict — pass to launch_app() or print_summary().
    """
    if isinstance(config, InspectPlan):
        if not config._confirmed:
            print("  ⚠️  plan.confirm() not called — proceeding with current types.\n")
        cfg = config._as_config()
    elif isinstance(config, dict):
        cfg = config
    else:
        cfg = {}

    return _run_eda(df, cfg)


# ─────────────────────────────────────────────────────────────────────────────
# launch_app()
# ─────────────────────────────────────────────────────────────────────────────

def launch_app(results: dict, port: int = 8501):
    """Launch Streamlit dashboard. Opens browser automatically."""
    pkl_path = _DIR / "_results.pkl"
    with open(pkl_path, "wb") as f:
        pickle.dump(results, f)

    shim = _DIR / "_entry.py"
    shim.write_text(f"""\
import sys, pickle
from pathlib import Path
_d = Path(r"{_DIR}")
sys.path.insert(0, str(_d))
import streamlit as st
from app import main
if "eda_results" not in st.session_state:
    with open(_d / "_results.pkl", "rb") as f:
        st.session_state["eda_results"] = pickle.load(f)
main()
""")

    url = f"http://localhost:{port}"
    print(f"\n{'─'*50}")
    print(f"  Insurance EDA Toolkit")
    print(f"  Dashboard: {url}")
    print(f"  Stop: Ctrl+C")
    print(f"{'─'*50}\n")

    def _open(): time.sleep(2.5); webbrowser.open(url)
    threading.Thread(target=_open, daemon=True).start()

    cmd = [sys.executable, "-m", "streamlit", "run", str(shim),
           f"--server.port={port}", "--server.headless=true",
           "--theme.base=light"]
    try:
        subprocess.run(cmd, cwd=str(_DIR))
    except KeyboardInterrupt:
        print("\n[EDA] Stopped.")


# ─────────────────────────────────────────────────────────────────────────────
# print_summary()
# ─────────────────────────────────────────────────────────────────────────────

def print_summary(results: dict):
    """Print a quick text summary to the notebook."""
    print(f"\n{'═'*55}")
    print(f"  EDA SUMMARY — {results['n_rows']:,} rows × {results['n_features']} features")
    print(f"  Runtime: {results['elapsed_sec']:.1f}s")
    print(f"{'═'*55}")

    print("\n  FEATURE TYPES:")
    for dtype, cnt in pd.Series(results["dtype_map"]).value_counts().items():
        print(f"    {_ICON.get(dtype,'❓')} {dtype:<15}: {cnt}")

    sc = results.get("scorecard", pd.DataFrame())
    if len(sc):
        print(f"\n  SCORECARD:")
        print(f"    🔴 Fix First : {(sc['Score'] == '❌ Fix First').sum()}")
        print(f"    🟡 Review    : {(sc['Score'] == '⚠️ Review').sum()}")
        print(f"    🟢 Clean     : {(sc['Score'] == '✅ Clean').sum()}")
        fix_feats = sc[sc['Score'] == '❌ Fix First']['Feature'].tolist()
        if fix_feats:
            print(f"\n  FIX FIRST: {', '.join(fix_feats)}")

    recs = results.get("recommendations", [])
    critical = [r for r in recs if "Fix" in r["Priority"]]
    if critical:
        print(f"\n  TOP ACTIONS:")
        for r in critical[:5]:
            for finding, action in r["Items"][:1]:
                print(f"    • {r['Feature']}: {action}")
    print(f"\n{'═'*55}\n")
