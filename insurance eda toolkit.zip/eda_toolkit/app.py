"""
app.py — Insurance EDA Toolkit dashboard
4 tabs: Overview · Feature Drill-Down · Data Quality · Correlations
Launched via launch.py. Results passed through st.session_state.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px

st.set_page_config(
    page_title="Insurance EDA Toolkit",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ── helpers ───────────────────────────────────────────────────────────────────

def _R() -> dict:
    return st.session_state.get("eda_results", {})

def _dl(df: pd.DataFrame, label: str, fname: str):
    st.download_button(f"⬇ Download {label}", df.to_csv(index=False).encode(),
                       fname, "text/csv", use_container_width=True)

def _score_color(val: str) -> str:
    if "Fix"    in str(val): return "🔴"
    if "Review" in str(val): return "🟡"
    if "Clean"  in str(val): return "🟢"
    return ""


# ── sidebar ───────────────────────────────────────────────────────────────────

def _sidebar(R):
    st.sidebar.title("📊 EDA Toolkit")
    st.sidebar.caption("Insurance EDA — 100% local, no data leaves your machine")
    st.sidebar.divider()

    st.sidebar.metric("Rows",     f"{R.get('n_rows', 0):,}")
    st.sidebar.metric("Features", R.get('n_features', 0))
    tc = R.get("config", {}).get("target_col")
    st.sidebar.metric("Target",   tc if tc else "None")
    st.sidebar.metric("Runtime",  f"{R.get('elapsed_sec', 0):.1f}s")

    sc = R.get("scorecard", pd.DataFrame())
    if len(sc):
        st.sidebar.divider()
        st.sidebar.write("**Scorecard summary**")
        st.sidebar.write(f"🔴 Fix First: **{(sc['Score'] == '❌ Fix First').sum()}**")
        st.sidebar.write(f"🟡 Review:    **{(sc['Score'] == '⚠️ Review').sum()}**")
        st.sidebar.write(f"🟢 Clean:     **{(sc['Score'] == '✅ Clean').sum()}**")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════

def tab_overview(R):
    st.header("Dataset Overview")
    cfg = R.get("config", {})
    cr  = R.get("col_results", {})
    dm  = R.get("dtype_map", {})

    # KPIs
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Rows",    f"{R['n_rows']:,}")
    c2.metric("Features",      R['n_features'])
    c3.metric("Target",        cfg.get("target_col") or "—")
    sc = R.get("scorecard", pd.DataFrame())
    issues = int((sc["Score"].str.contains("Fix|Review")).sum()) if len(sc) else 0
    c4.metric("Features Needing Attention", issues)

    st.divider()

    # Feature types donut + missing bar side by side
    left, right = st.columns(2)

    with left:
        st.subheader("Feature Types")
        type_counts = pd.Series(dm).value_counts().reset_index()
        type_counts.columns = ["Type", "Count"]
        fig = px.pie(type_counts, names="Type", values="Count", hole=0.5,
                     color_discrete_sequence=px.colors.qualitative.Set2)
        fig.update_layout(margin=dict(l=20, r=20, t=20, b=20), height=280,
                          showlegend=True, paper_bgcolor="rgba(0,0,0,0)",
                          plot_bgcolor="rgba(0,0,0,0)")
        fig.update_traces(textposition="inside", textinfo="percent+label")
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Missing Values by Feature")
        miss_data = [(col, res["missing_pct"]) for col, res in cr.items() if res["missing_pct"] > 0]
        if miss_data:
            miss_df = pd.DataFrame(miss_data, columns=["Feature", "Missing %"]).sort_values("Missing %", ascending=True)
            fig2 = px.bar(miss_df, x="Missing %", y="Feature", orientation="h",
                          color="Missing %", color_continuous_scale="Reds",
                          range_color=[0, 100])
            fig2.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=280,
                                paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                                coloraxis_showscale=False, yaxis_title="")
            st.plotly_chart(fig2, use_container_width=True)
        else:
            st.success("✅ No missing values in any feature")

    st.divider()

    # Full feature table
    st.subheader("All Features at a Glance")
    rows = []
    for col, res in cr.items():
        dtype = res["dtype"]
        dist  = res.get("dist", {})
        rows.append({
            "Feature":    col,
            "Type":       dtype,
            "Missing %":  res["missing_pct"],
            "Unique":     res["n_unique"],
            "Mean / Top": (f"{dist['mean']:.4g}" if dist and dtype == "Numeric" else
                           (str(res.get("category_table", pd.DataFrame()).iloc[0]["Category"])[:20]
                            if dtype == "Categorical" and len(res.get("category_table", pd.DataFrame())) else "—")),
            "Shape":      dist.get("shape", "—") if dist else "—",
            "Zero %":     res.get("zero_pct", 0),
        })
    feat_df = pd.DataFrame(rows)
    st.dataframe(feat_df, use_container_width=True, height=380,
                 column_config={
                     "Missing %": st.column_config.ProgressColumn("Missing %", min_value=0, max_value=100),
                     "Zero %":    st.column_config.ProgressColumn("Zero %",    min_value=0, max_value=100),
                 })
    _dl(feat_df, "Feature Overview", "feature_overview.csv")

    # Optional grouped report
    det = R.get("grouped_report", pd.DataFrame())
    if len(det):
        st.divider()
        st.subheader(f"Grouped Report — by {cfg.get('groupby_col', '')}")
        st.dataframe(det, use_container_width=True)
        _dl(det, "Grouped Report", "grouped_report.csv")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — FEATURE DRILL-DOWN
# ══════════════════════════════════════════════════════════════════════════════

def tab_features(R):
    st.header("Feature Drill-Down")
    cr     = R.get("col_results", {})
    biv    = R.get("bivariate", {})
    target = R.get("target_col")

    if not cr:
        st.info("No features analysed.")
        return

    selected = st.selectbox("Select a feature", list(cr.keys()))
    if not selected:
        return

    res   = cr[selected]
    dtype = res["dtype"]
    dist  = res.get("dist", {})
    outl  = res.get("outlier", {})
    bdata = biv.get(selected, {})

    st.divider()

    if dtype == "Numeric":
        # stats row
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Missing",  f"{res['missing_pct']:.1f}%")
        c2.metric("Mean",     f"{dist.get('mean', 0):.4g}" if dist else "—")
        c3.metric("Median",   f"{dist.get('median', 0):.4g}" if dist else "—")
        c4.metric("Std Dev",  f"{dist.get('std', 0):.4g}" if dist else "—")
        c5.metric("Skewness", f"{dist.get('skewness', 0):.2f}" if dist else "—")

        c6, c7, c8, c9, c10 = st.columns(5)
        c6.metric("Min",      f"{dist.get('min', 0):.4g}" if dist else "—")
        c7.metric("P25",      f"{dist.get('p25', 0):.4g}" if dist else "—")
        c8.metric("P75",      f"{dist.get('p75', 0):.4g}" if dist else "—")
        c9.metric("P99",      f"{dist.get('p99', 0):.4g}" if dist else "—")
        c10.metric("Zero %",  f"{res.get('zero_pct', 0):.1f}%")

        if dist:
            st.info(f"**Shape:** {dist.get('shape', '—')}   |   "
                    f"**IQR outliers:** {outl.get('iqr_pct', 0):.1f}%   |   "
                    f"**Log-normal:** {'Yes' if dist.get('is_lognormal') else 'No'}")

        # Histogram
        sample = res.get("plot_sample", [])
        if sample:
            arr = np.array(sample)
            fig = go.Figure()
            fig.add_trace(go.Histogram(x=arr, nbinsx=50, name="Distribution",
                                       marker_color="#4F8EF7", opacity=0.8))
            if dist:
                fig.add_vline(x=dist["mean"],   line_dash="dash", line_color="orange",
                              annotation_text="Mean")
                fig.add_vline(x=dist["median"], line_dash="dot",  line_color="green",
                              annotation_text="Median")
            fig.update_layout(title=f"Distribution of {selected}",
                               xaxis_title=selected, yaxis_title="Count",
                               height=320, margin=dict(l=40, r=20, t=40, b=40),
                               paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
            st.plotly_chart(fig, use_container_width=True)

        # Target rate chart
        if target and bdata.get("table"):
            st.subheader(f"Rate by {selected} band")
            tbl = pd.DataFrame(bdata["table"])
            gm  = bdata.get("grand_mean", None)
            fig2 = go.Figure()
            fig2.add_trace(go.Bar(x=tbl["Band"].astype(str), y=tbl["Rate"],
                                  name="Rate", marker_color="#4F8EF7"))
            if gm is not None:
                fig2.add_hline(y=gm, line_dash="dash", line_color="orange",
                               annotation_text=f"Grand mean {gm:.4f}")
            fig2.update_layout(title=f"{target} rate by {selected}",
                               xaxis_title=selected, yaxis_title="Rate",
                               height=300, margin=dict(l=40, r=20, t=40, b=60),
                               paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)")
            fig2.update_xaxes(tickangle=30)
            st.plotly_chart(fig2, use_container_width=True)

    elif dtype == "Categorical":
        c1, c2, c3 = st.columns(3)
        c1.metric("Missing",     f"{res['missing_pct']:.1f}%")
        c2.metric("Categories",  res["n_unique"])
        c3.metric("Rare (<1%)", res.get("rare_count", 0))

        tbl = res.get("category_table", pd.DataFrame())
        if len(tbl):
            st.subheader("Category breakdown")
            # Bar chart
            fig = px.bar(tbl.head(20), x="Category", y="Share %",
                         color="Share %", color_continuous_scale="Blues",
                         text="Count")
            fig.update_layout(height=320, xaxis_title="", yaxis_title="Share %",
                               paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                               margin=dict(l=20, r=20, t=20, b=60),
                               coloraxis_showscale=False)
            fig.update_xaxes(tickangle=30)
            st.plotly_chart(fig, use_container_width=True)
            st.dataframe(tbl, use_container_width=True, height=250)

        if target and bdata.get("table"):
            st.subheader(f"Rate by {selected}")
            tbl2 = pd.DataFrame(bdata["table"])
            gm   = bdata.get("grand_mean", None)
            fig2 = go.Figure()
            fig2.add_trace(go.Bar(x=tbl2["Category"].astype(str), y=tbl2["Rate"],
                                  name="Rate", marker_color="#4F8EF7"))
            if gm is not None:
                fig2.add_hline(y=gm, line_dash="dash", line_color="orange",
                               annotation_text=f"Grand mean {gm:.4f}")
            fig2.update_layout(height=300, xaxis_title="", yaxis_title="Rate",
                               paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                               margin=dict(l=40, r=20, t=20, b=60))
            fig2.update_xaxes(tickangle=30)
            st.plotly_chart(fig2, use_container_width=True)

    else:
        st.metric("Missing",   f"{res['missing_pct']:.1f}%")
        st.metric("Hit Rate",  f"{res['hit_rate_pct']:.1f}%")
        st.info(f"Type: **{dtype}**")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — DATA QUALITY
# ══════════════════════════════════════════════════════════════════════════════

def tab_quality(R):
    st.header("Data Quality — Scorecard & Recommendations")

    sc = R.get("scorecard", pd.DataFrame())
    if not len(sc):
        st.info("Scorecard not available.")
        return

    # Summary KPIs
    n_fix = int((sc["Score"] == "❌ Fix First").sum())
    n_rev = int((sc["Score"] == "⚠️ Review").sum())
    n_ok  = int((sc["Score"] == "✅ Clean").sum())
    c1, c2, c3 = st.columns(3)
    c1.metric("🔴 Fix First", n_fix)
    c2.metric("🟡 Review",    n_rev)
    c3.metric("🟢 Clean",     n_ok)

    st.divider()

    # Scorecard table with colour styling
    st.subheader("Feature Scorecard")
    st.caption("Scored on: Missing %, Skewness, Outliers, Correlation risk")

    filter_opts = st.multiselect("Filter by score",
                                 ["❌ Fix First", "⚠️ Review", "✅ Clean"],
                                 default=["❌ Fix First", "⚠️ Review", "✅ Clean"])
    df_show = sc[sc["Score"].isin(filter_opts)] if filter_opts else sc

    def _color_score(val):
        if "Fix"    in str(val): return "color: #e74c3c; font-weight:bold"
        if "Review" in str(val): return "color: #f39c12; font-weight:bold"
        if "Clean"  in str(val): return "color: #27ae60; font-weight:bold"
        return ""

    styled = df_show.style.map(_color_score, subset=["Score"])
    st.dataframe(styled, use_container_width=True, height=420)
    _dl(sc, "Scorecard", "scorecard.csv")

    st.divider()

    # Recommendations
    recs = R.get("recommendations", [])
    if recs:
        st.subheader("Recommended Actions")
        prio_filter = st.multiselect("Filter by priority",
                                     ["❌ Fix First", "⚠️ Review", "✅ Clean"],
                                     default=["❌ Fix First", "⚠️ Review"])
        filtered = [r for r in recs if r["Priority"] in prio_filter]
        st.caption(f"Showing {len(filtered)} of {len(recs)} features with actions")

        for rec in filtered:
            icon = "🔴" if "Fix" in rec["Priority"] else "🟡" if "Review" in rec["Priority"] else "🟢"
            with st.expander(f"{icon} **{rec['Feature']}** ({rec['Type']})"):
                for finding, action in rec["Items"]:
                    col_a, col_b = st.columns(2)
                    col_a.markdown(f"**Finding:** {finding}")
                    col_b.markdown(f"**Action:** `{action}`")

        # Flat CSV export
        rows_flat = []
        for r in recs:
            for finding, action in r["Items"]:
                rows_flat.append({"Feature": r["Feature"], "Type": r["Type"],
                                  "Priority": r["Priority"], "Finding": finding, "Action": action})
        if rows_flat:
            _dl(pd.DataFrame(rows_flat), "Recommendations", "recommendations.csv")
    else:
        st.success("✅ No significant issues found.")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — CORRELATIONS
# ══════════════════════════════════════════════════════════════════════════════

def tab_correlations(R):
    st.header("Correlations")
    corr = R.get("correlations", {})
    cfg  = R.get("config", {})

    hm = corr.get("heatmap", pd.DataFrame())
    if len(hm) < 2:
        st.info("Need at least 2 numeric features for correlation analysis.")
        return

    st.subheader("Pearson Correlation Heatmap")
    st.caption(f"Based on up to {cfg.get('corr_sample', 100_000):,} rows. "
               f"High correlation threshold: |r| ≥ {cfg.get('corr_threshold', 0.75)}")

    fig = px.imshow(hm, text_auto=".2f", aspect="auto",
                    color_continuous_scale="RdBu_r", zmin=-1, zmax=1)
    fig.update_layout(height=max(350, len(hm) * 40),
                      margin=dict(l=10, r=10, t=20, b=10),
                      paper_bgcolor="rgba(0,0,0,0)")
    fig.update_traces(textfont_size=10)
    st.plotly_chart(fig, use_container_width=True)

    st.divider()

    # High-corr pairs
    hcp = corr.get("high_corr", [])
    if hcp:
        st.subheader(f"⚠️ High Correlation Pairs  (|r| ≥ {cfg.get('corr_threshold', 0.75)})")
        st.caption("Highly correlated features → multicollinearity risk in GLMs. Consider dropping one.")
        st.dataframe(pd.DataFrame(hcp), use_container_width=True)
    else:
        st.success(f"✅ No feature pairs with |r| ≥ {cfg.get('corr_threshold', 0.75)}")

    st.divider()

    # VIF
    vif = corr.get("vif", pd.DataFrame())
    if len(vif):
        st.subheader("VIF — Variance Inflation Factor")
        st.caption("VIF > 10 = severe multicollinearity  |  VIF > 5 = moderate  |  < 5 = OK")
        st.dataframe(vif, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    R = _R()
    if not R:
        st.warning("No EDA results loaded. Run `run_eda()` in your notebook then call `launch_app(results)`.")
        st.code("""
from eda_toolkit import run_eda, launch_app

results = run_eda(df, {
    "target_col": "Claim_Flag",        # or None
    "groupby_col": "Policy_Year",      # optional grouped report
    "agg_config": {
        "Claim_Flag": ["sum", "mean"],
        "Premium":    ["sum", "mean"],
    },
})

launch_app(results)
        """, language="python")
        return

    _sidebar(R)

    t1, t2, t3, t4 = st.tabs([
        "📋 Overview",
        "🔬 Feature Drill-Down",
        "🎯 Data Quality",
        "🔗 Correlations",
    ])
    with t1: tab_overview(R)
    with t2: tab_features(R)
    with t3: tab_quality(R)
    with t4: tab_correlations(R)


if __name__ == "__main__":
    main()
