"""
eda_engine.py — Insurance EDA Toolkit
Pure computation. No Streamlit. No external calls. 100% local.
"""

import time, warnings, numpy as np, pandas as pd
from scipy.stats import skew as _skew, normaltest
warnings.filterwarnings("ignore")


# ── helpers ──────────────────────────────────────────────────────────────────

def _samp(arr, n):
    if len(arr) == 0: return arr
    if len(arr) <= n: return arr
    return arr[np.random.choice(len(arr), n, replace=False)]

def _log(msg, pct=0):
    print(f"[EDA {pct:3d}%] {msg}")

def _nunique(s):
    clean = s.dropna()
    n = len(clean)
    if n == 0: return 0
    if n <= 50_000: return int(clean.nunique())
    return int(clean.sample(50_000, random_state=42).nunique())


# ── type detection ────────────────────────────────────────────────────────────

# Boolean-like string pairs (case-insensitive)
_BOOL_STRINGS = [
    {"0","1"}, {"y","n"}, {"yes","no"}, {"true","false"}, {"t","f"},
    {"1.0","0.0"}, {"male","female"}, {"m","f"},
]

def _try_parse_date(s) -> bool:
    """Return True if >= 80% of a sample of non-null string values parse as dates.
    Tries both default and dayfirst=True to handle DD/MM/YYYY formats.
    """
    sample = s.dropna().astype(str).head(300)
    if len(sample) < 5:
        return False
    # Quick pre-screen: values must contain at least one digit and one separator
    has_sep   = sample.str.contains(r'[-/: ]', regex=True)
    has_digit = sample.str.contains(r'\d', regex=True)
    if (has_sep & has_digit).mean() < 0.7:
        return False
    try:
        # Try standard parse first (handles YYYY-MM-DD, MM/DD/YYYY, etc.)
        p1 = pd.to_datetime(sample, errors="coerce")
        if float(p1.notna().mean()) >= 0.80:
            return True
        # Also try dayfirst for DD/MM/YYYY format common in UK/EU insurance
        p2 = pd.to_datetime(sample, errors="coerce", dayfirst=True)
        return float(p2.notna().mean()) >= 0.80
    except Exception:
        return False


def _is_bool_strings(s) -> bool:
    """Return True if column contains only boolean-like string values."""
    unique_vals = set(s.dropna().astype(str).str.strip().str.lower().unique())
    if len(unique_vals) == 0 or len(unique_vals) > 2:
        return False
    return unique_vals in _BOOL_STRINGS


def detect_type(s, id_ratio=0.8) -> str:
    """
    Detect EDA type with strong heuristics. Checks run in priority order.

      1. Actual pandas bool / datetime dtype
      2. All-null -> Unknown
      3. Numeric:  Boolean (<=2 unique), year-integer -> Date, ID-like, Numeric
      4. String:   Boolean strings (Y/N, Yes/No ...)
                   Date strings (YYYY-MM-DD ...) <- checked BEFORE ID-like
                   ID-like (high unique ratio)
                   Categorical (fallback)
    """
    n = len(s)
    if n == 0 or s.isna().all():
        return "Unknown"

    # actual pandas dtypes
    if pd.api.types.is_bool_dtype(s):
        return "Boolean"
    if pd.api.types.is_datetime64_any_dtype(s):
        return "Date"

    # numeric branch
    if pd.api.types.is_numeric_dtype(s):
        nu = _nunique(s)
        if nu == 0: return "Unknown"
        if nu <= 2: return "Boolean"
        clean = s.dropna()
        # year column: integer, values 1900-2100, few unique
        if nu <= 150:
            try:
                vals = clean.astype(float)
                if ((vals >= 1900) & (vals <= 2100)).mean() > 0.95 and \
                   (vals == vals.round(0)).mean() > 0.99:
                    return "Date"
            except Exception:
                pass
        # ID-like: very high unique ratio + integer values
        if nu / n > id_ratio:
            try:
                if (clean.head(200) == clean.head(200).round(0)).mean() > 0.99:
                    return "ID-like"
            except Exception:
                pass
        return "Numeric"

    # string / object branch
    # 1. boolean strings first (unambiguous, always 2 unique values)
    if _is_bool_strings(s):
        return "Boolean"

    nu = _nunique(s)
    if nu == 0: return "Unknown"

    # 2. date strings -- ALWAYS checked before ID-like.
    #    A column of 500 unique date strings has ratio=1.0 but is still a Date.
    if _try_parse_date(s):
        return "Date"

    # 3. high unique ratio -> ID-like (policy numbers, reference codes, free text)
    if nu / n > id_ratio:
        return "ID-like"

    # 4. default: categorical
    return "Categorical"


# ── per-column analysis ───────────────────────────────────────────────────────

def _analyse_numeric(col, s: pd.Series, n_total: int, plot_n=20_000, norm_n=5_000):
    # Handle string-encoded booleans (Y/N, Yes/No, M/F, True/False, etc.)
    if s.dtype == object:
        _TRUE = {"1","y","yes","true","t","1.0","male","m"}
        s = pd.to_numeric(
            s.map(lambda v: 1.0 if str(v).strip().lower() in _TRUE
                  else (0.0 if pd.notna(v) else np.nan)),
            errors="coerce")
    arr = pd.to_numeric(s, errors="coerce").to_numpy(dtype=float, na_value=np.nan)
    missing = int(np.isnan(arr).sum())
    clean   = arr[~np.isnan(arr)]
    nc      = len(clean)

    base = dict(dtype="Numeric", missing_count=missing,
                missing_pct=round(missing/n_total*100, 1),
                hit_rate_pct=round((n_total-missing)/n_total*100, 1),
                n_unique=0, zero_pct=0.0, dist={}, outlier={},
                plot_sample=[], zero_inflated=False)
    if nc == 0:
        return base

    pcts = np.percentile(clean, [1, 5, 10, 25, 50, 75, 90, 95, 99])
    mean = float(clean.mean())
    std  = float(clean.std()) if nc > 1 else 0.0
    zero_pct = round(float((clean == 0).mean()) * 100, 1)
    zero_inf = zero_pct > 30
    nu = int(pd.Series(_samp(clean, 50_000)).nunique())
    base.update(n_unique=nu, zero_pct=zero_pct, zero_inflated=zero_inf)

    sk = round(float(_skew(clean)), 3) if nc > 3 else 0.0
    if not (np.isfinite(sk)): sk = 0.0

    pos = clean[clean > 0]
    is_ln = False
    if len(pos) > 50:
        try:
            _, lp = normaltest(np.log(_samp(pos, norm_n)))
            is_ln = bool(lp > 0.05)
        except Exception:
            pass

    tags = []
    if zero_inf:             tags.append("Zero-Inflated")
    if is_ln and sk > 0.5:  tags.append("Log-Normal")
    elif sk > 1.0:           tags.append("Right-Skewed")
    elif sk < -1.0:          tags.append("Left-Skewed")
    if not tags:             tags.append("Near-Normal")

    base["dist"] = dict(
        mean=round(mean, 4), median=round(float(pcts[4]), 4),
        std=round(std, 4), min=round(float(clean.min()), 4), max=round(float(clean.max()), 4),
        p25=round(float(pcts[3]), 4), p75=round(float(pcts[5]), 4),
        p95=round(float(pcts[7]), 4), p99=round(float(pcts[8]), 4),
        skewness=sk, is_lognormal=is_ln, shape=", ".join(tags),
    )

    # outlier — skip IQR on zero-inflated (IQR=0 is meaningless)
    k = 1.5
    if zero_inf:
        nz = clean[clean > 0]
        q1 = float(np.percentile(nz, 25)) if len(nz) else 0.0
        q3 = float(np.percentile(nz, 75)) if len(nz) else 0.0
        iqr     = q3 - q1
        fence_lo = 0.0
        fence_hi = round(q3 + k * iqr, 4)
        iqr_cnt  = int((clean > fence_hi).sum())
        note     = "IQR on non-zero values (zero-inflated)"
    else:
        q1, q3  = float(pcts[3]), float(pcts[5])
        iqr     = q3 - q1
        fence_lo = round(q1 - k * iqr, 4)
        fence_hi = round(q3 + k * iqr, 4)
        iqr_cnt  = int(((clean < fence_lo) | (clean > fence_hi)).sum())
        note     = ""

    base["outlier"] = dict(
        q1=round(q1, 4), q3=round(q3, 4), iqr=round(iqr, 4),
        fence_lo=fence_lo, fence_hi=fence_hi,
        iqr_count=iqr_cnt, iqr_pct=round(iqr_cnt / nc * 100, 1),
        p99_cap=round(float(pcts[8]), 4), note=note,
    )
    base["plot_sample"] = _samp(clean, plot_n).tolist()
    return base


def _analyse_categorical(col, s: pd.Series, n_total: int, rare_pct=1.0):
    missing = int(s.isna().sum())
    vc  = s.value_counts(dropna=True)
    nu  = len(vc)
    top = round(float(vc.iloc[0]) / n_total * 100, 1) if nu else 0.0

    hr = pd.DataFrame({
        "Category":   vc.index.astype(str),
        "Count":      vc.values,
        "Share %":    (vc.values / n_total * 100).round(1),
    }).head(30)
    hr["Flag"] = hr["Share %"].apply(
        lambda x: "RARE" if x < rare_pct else ("DOMINANT" if x > 80 else ""))

    return dict(
        dtype="Categorical",
        missing_count=missing,
        missing_pct=round(missing / n_total * 100, 1),
        hit_rate_pct=round((n_total - missing) / n_total * 100, 1),
        n_unique=nu, top_val_pct=top,
        category_table=hr,
        rare_count=int((hr["Flag"] == "RARE").sum()),
        dist={}, outlier={}, plot_sample=[], zero_inflated=False,
    )


# ── bivariate vs target ───────────────────────────────────────────────────────

def _bivariate(df: pd.DataFrame, target_col: str, dtype_map: dict) -> dict:
    if not target_col or target_col not in df.columns:
        return {}
    y  = df[target_col]
    gm = float(y.mean())
    out = {}

    for col in [c for c in df.columns if c != target_col]:
        dtype = dtype_map.get(col)
        mask  = df[col].notna() & y.notna()
        if mask.sum() < 20:
            continue
        sc = df.loc[mask, col]
        yc = y[mask]
        tbl = []

        if dtype == "Numeric":
            try:
                cuts = pd.cut(sc, bins=10, duplicates="drop")
                agg  = (pd.DataFrame({"b": cuts, "y": yc})
                        .groupby("b", observed=True)["y"]
                        .agg(["mean", "count"]).reset_index())
                agg.columns = ["Band", "Rate", "Count"]
                agg["Relativity"] = agg["Rate"].apply(
                    lambda v: round(min(v / gm, 10.0), 3) if gm > 1e-9 else 1.0)
                agg["Band"] = agg["Band"].astype(str)
                tbl = agg.to_dict("records")
            except Exception:
                pass

        elif dtype == "Categorical":
            try:
                agg = (pd.DataFrame({"c": sc.fillna("__MISSING__"), "y": yc})
                       .groupby("c")["y"].agg(["mean", "count"]).reset_index())
                agg.columns = ["Category", "Rate", "Count"]
                agg["Relativity"] = agg["Rate"].apply(
                    lambda v: round(min(v / gm, 10.0), 3) if gm > 1e-9 else 1.0)
                agg = agg.sort_values("Rate", ascending=False).head(20)
                tbl = agg.to_dict("records")
            except Exception:
                pass

        if tbl:
            out[col] = {"dtype": dtype, "table": tbl, "grand_mean": gm}
    return out


# ── correlations ──────────────────────────────────────────────────────────────

def _correlations(df: pd.DataFrame, corr_sample=100_000, threshold=0.75) -> dict:
    num = df.select_dtypes(include=[np.number]).columns.tolist()
    out = dict(heatmap=pd.DataFrame(), high_corr=[], vif=pd.DataFrame())
    if len(num) < 2:
        return out

    df_s = df[num].dropna()
    df_s = df_s.sample(min(corr_sample, len(df_s)), random_state=42)
    out["heatmap"] = df_s.corr().round(3)

    # high-corr pairs
    C = out["heatmap"].values
    pairs = []
    for i in range(len(num)):
        for j in range(i + 1, len(num)):
            r = round(float(C[i, j]), 3)
            if abs(r) >= threshold:
                pairs.append({"Feature A": num[i], "Feature B": num[j], "r": r})
    out["high_corr"] = sorted(pairs, key=lambda x: abs(x["r"]), reverse=True)

    # VIF (up to 15 cols)
    try:
        from sklearn.linear_model import LinearRegression
        cols = num[:15]
        X = df[cols].fillna(df[cols].median()).values[:20_000].astype(float)
        vifs = []
        for i in range(len(cols)):
            yi = X[:, i]
            Xi = np.delete(X, i, axis=1)
            r2 = LinearRegression().fit(Xi, yi).score(Xi, yi)
            vifs.append(round(1 / (1 - r2) if r2 < 0.9999 else 999.0, 1))
        vdf = pd.DataFrame({"Feature": cols, "VIF": vifs}).sort_values("VIF", ascending=False)
        vdf["Flag"] = vdf["VIF"].apply(lambda v: "HIGH>10" if v > 10 else ("MOD 5-10" if v > 5 else "OK"))
        out["vif"] = vdf
    except Exception:
        pass

    return out


# ── scorecard ─────────────────────────────────────────────────────────────────

def _scorecard(col_results: dict, corr: dict) -> pd.DataFrame:
    hm = corr.get("heatmap", pd.DataFrame())
    max_r = {}
    if len(hm):
        for c in hm.columns:
            vals = hm[c].drop(c, errors="ignore").abs()
            max_r[c] = round(float(vals.max()), 3) if len(vals) else 0.0

    rows = []
    for col, res in col_results.items():
        dtype = res["dtype"]
        mp    = res["missing_pct"]
        dist  = res.get("dist", {})
        outl  = res.get("outlier", {})
        zi    = res.get("zero_inflated", False)

        # missing score
        ms = 3 if mp >= 100 else (3 if mp > 20 else (2 if mp > 5 else (1 if mp > 0 else 0)))
        ml = f"{mp:.0f}%" if mp > 0 else "None"

        # skew score
        sk = dist.get("skewness", 0) if dist else 0
        if not np.isfinite(sk): sk = 0.0
        ss = 0; sl = "—"
        if dtype == "Numeric":
            if abs(sk) < 0.5:   ss = 0; sl = "Low"
            elif abs(sk) < 1.5: ss = 1; sl = f"Med ({sk:.1f})"
            else:                ss = 2; sl = f"High ({sk:.1f})"

        # outlier score
        iqr_p = outl.get("iqr_pct", 0) if dtype == "Numeric" else None
        os_ = 0; ol = "—"
        if iqr_p is not None:
            if zi:             os_ = 2; ol = f"Zero-Inf ({res.get('zero_pct',0):.0f}% zeros)"
            elif iqr_p < 1:    os_ = 0; ol = "Low"
            elif iqr_p < 5:    os_ = 1; ol = f"Med ({iqr_p:.1f}%)"
            else:               os_ = 2; ol = f"High ({iqr_p:.1f}%)"

        # corr score
        mr = max_r.get(col, 0.0)
        cs = 2 if mr >= 0.8 else (1 if mr >= 0.5 else 0)
        cl = f"High ({mr:.2f})" if mr >= 0.8 else (f"Med ({mr:.2f})" if mr >= 0.5 else "Low")

        total = ms + ss + os_ + cs
        if total <= 1:    score = "✅ Clean";     pri = 2
        elif total <= 4:  score = "⚠️ Review";   pri = 1
        else:             score = "❌ Fix First"; pri = 0

        type_icon = {"Numeric":"🔢","Categorical":"🏷️","Boolean":"☑️",
                     "Date":"📅","ID-like":"🔑","Unknown":"❓"}.get(dtype, "❓")

        rows.append(dict(Feature=col, Type=f"{type_icon} {dtype}",
                         Missing=ml, Skew=sl, Outliers=ol, Corr=cl,
                         Score=score, _p=pri))

    return (pd.DataFrame(rows)
            .sort_values("_p")
            .drop(columns=["_p"])
            .reset_index(drop=True))


# ── recommendations ───────────────────────────────────────────────────────────

def _recommendations(col_results: dict, scorecard: pd.DataFrame) -> list:
    score_map = {r["Feature"]: r["Score"] for _, r in scorecard.iterrows()} if len(scorecard) else {}
    recs = []

    for col, res in col_results.items():
        dtype = res["dtype"]
        mp    = res["missing_pct"]
        dist  = res.get("dist", {})
        outl  = res.get("outlier", {})
        zi    = res.get("zero_inflated", False)
        nu    = res.get("n_unique", 0)
        items = []

        if mp >= 100 or dtype == "Unknown":
            items.append(("Column entirely null", "Drop or investigate data pipeline"))
        elif dtype == "Numeric":
            sk = dist.get("skewness", 0) if dist else 0
            if zi:
                items.append((f"Zero-inflated ({res.get('zero_pct',0):.0f}% zeros)",
                               "Two-part model (logistic + Gamma) or Tweedie GLM"))
            if dist.get("is_lognormal") and sk > 0.5:
                items.append(("Log-normal distribution", "Apply log1p transform before modelling"))
            elif abs(sk) > 1.5 and not zi:
                items.append((f"Highly skewed (skew={sk:.1f})", "Apply log1p transform"))
            if not zi and outl.get("iqr_pct", 0) > 5:
                p99 = outl.get("p99_cap", "?")
                items.append((f"{outl['iqr_pct']:.1f}% outliers by IQR", f"Cap at P99 = {p99}"))
            if mp > 20:
                items.append((f"High missing ({mp:.0f}%)", f"Add {col}_missing flag + median impute"))
            elif mp > 0:
                items.append((f"Missing {mp:.0f}%", "Median imputation"))
            if nu <= 5 and nu > 0:
                items.append(("Very few unique values", "Treat as categorical / ordinal"))
        elif dtype == "Categorical":
            if res.get("rare_count", 0) > 0:
                items.append((f"{res['rare_count']} rare categories (<1%)", "Group into 'Other'"))
            if nu > 50:
                items.append((f"High cardinality ({nu} categories)", "Target encode or frequency encode"))
            if mp > 0:
                items.append((f"Missing {mp:.0f}%", "Create 'Unknown' category, do not drop"))
        elif dtype == "ID-like":
            items.append(("ID column — unique per row", "Exclude from modelling entirely"))
        elif dtype == "Date":
            items.append(("Date column", "Extract year, month, quarter, day-of-week"))

        if not items:
            continue
        recs.append(dict(Feature=col, Type=dtype,
                         Priority=score_map.get(col, "✅ Clean"),
                         Items=items))

    order = {"❌ Fix First": 0, "⚠️ Review": 1, "✅ Clean": 2}
    recs.sort(key=lambda r: order.get(r["Priority"], 3))
    return recs


# ── master ────────────────────────────────────────────────────────────────────

def run_eda(df: pd.DataFrame, config: dict) -> dict:
    t0     = time.time()
    n      = len(df)
    target = config.get("target_col")
    feats  = [c for c in df.columns if c != target]
    corr_sample = config.get("corr_sample", 100_000)
    corr_thresh = config.get("corr_threshold", 0.75)
    rare_pct    = config.get("rare_cat_pct", 1.0)
    plot_n      = config.get("plot_sample", 20_000)
    norm_n      = config.get("norm_sample", 5_000)
    id_ratio    = config.get("id_ratio", 0.8)

    _log(f"EDA — {len(feats)} features × {n:,} rows", 0)

    _log("Detecting types...", 5)
    dtype_map = {c: detect_type(df[c], id_ratio) for c in feats}

    # Apply any manual overrides from inspect() confirmation step
    overrides = config.get("dtype_overrides", {})
    for col, forced_type in overrides.items():
        if col in dtype_map:
            dtype_map[col] = forced_type

    _log("Analysing columns...", 15)
    col_results = {}
    for i, col in enumerate(feats):
        dtype = dtype_map[col]
        try:
            if dtype in ("Numeric", "Boolean"):
                # For string-based booleans (Y/N, Yes/No) encode to 0/1 first
                s = df[col]
                if dtype == "Boolean" and s.dtype == object:
                    s = s.map(lambda v: 1.0 if str(v).strip().lower() in
                              {"1","y","yes","true","t","1.0","male","m"} else
                              (0.0 if pd.notna(v) else np.nan))
                col_results[col] = _analyse_numeric(col, s, n, plot_n, norm_n)
            elif dtype == "Unknown":
                col_results[col] = dict(dtype="Unknown",
                    missing_count=int(df[col].isna().sum()),
                    missing_pct=round(df[col].isna().mean()*100, 1),
                    hit_rate_pct=round((1-df[col].isna().mean())*100, 1),
                    n_unique=0, zero_pct=0, dist={}, outlier={},
                    plot_sample=[], zero_inflated=False)
            else:
                col_results[col] = _analyse_categorical(col, df[col], n, rare_pct)
        except Exception as e:
            print(f"  [WARN] {col}: {e}")
            col_results[col] = dict(dtype=dtype, missing_count=0, missing_pct=0,
                hit_rate_pct=100, n_unique=0, zero_pct=0, dist={}, outlier={},
                plot_sample=[], zero_inflated=False)
        pct = 15 + int((i + 1) / len(feats) * 35)
        if (i + 1) % max(1, len(feats) // 8) == 0 or i + 1 == len(feats):
            _log(f"Features {i+1}/{len(feats)}", pct)

    _log("Correlations...", 52)
    corr = _correlations(df[feats], corr_sample, corr_thresh)

    biv = {}
    if target and target in df.columns:
        _log("Bivariate vs target...", 62)
        biv = _bivariate(df, target, dtype_map)

    _log("Scorecard...", 72)
    sc = _scorecard(col_results, corr)

    _log("Recommendations...", 82)
    recs = _recommendations(col_results, sc)

    # Grouped report
    det = pd.DataFrame()
    if config.get("groupby_col") and config.get("agg_config"):
        _log("Grouped report...", 90)
        gb  = config["groupby_col"]
        agg = {c: f for c, f in config["agg_config"].items() if c in df.columns}
        if gb in df.columns and agg:
            try:
                r = df.groupby(gb).agg(agg)
                r.columns = ["_".join(c) for c in r.columns]
                det = r.reset_index().sort_values(gb)
            except Exception as e:
                print(f"  [WARN] Grouped report: {e}")

    elapsed = round(time.time() - t0, 1)
    _log(f"Done in {elapsed}s", 100)

    return dict(
        df=df, config=config, feature_cols=feats, dtype_map=dtype_map,
        n_rows=n, n_features=len(feats), elapsed_sec=elapsed, target_col=target,
        col_results=col_results, correlations=corr,
        bivariate=biv, scorecard=sc, recommendations=recs, grouped_report=det,
    )
