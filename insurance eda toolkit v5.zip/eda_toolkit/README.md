# Insurance EDA Toolkit v5

A raw-data EDA toolkit. **No data cleaning required.** Results are honest about what they are.

---

## Installation

```bash
pip install pandas numpy scipy scikit-learn streamlit plotly
```

---

## Quick Start — Jupyter Notebook

```python
import pandas as pd
from eda_toolkit.launch import run_eda, launch_app, print_summary

df = pd.read_csv("insurance.csv")

config = {
    # ── Target (optional) ─────────────────────────────────────
    "target_col": "Claim_Flag",      # set None if no target

    # ── Detailed report in Tab 1 ──────────────────────────────
    "detailed_report": True,
    "groupby_col":  "Policy_Year",   # column to group by
    "agg_config": {
        "Policy_Number": ["nunique"],
        "Claim_Amount":  ["sum", "mean"],
        "Premium":       ["sum", "mean"],
        "Claim_Flag":    ["sum", "mean"],
    },

    # ── Toggle steps on/off ───────────────────────────────────
    "STEP_DATA_QUALITY":     True,
    "STEP_DISTRIBUTION":     True,
    "STEP_MISSING_ANALYSIS": True,
    "STEP_CORRELATION":      True,
    "STEP_SCORECARD":        True,

    # ── Thresholds ────────────────────────────────────────────
    "id_threshold":       10_000,   # unique > 10K → ID-like flag
    "corr_threshold":     0.8,      # |r| >= 0.8 → HIGH_CORR flag
    "rare_cat_threshold": 0.01,     # < 1% hit rate → RARE

    # ── Outlier IQR (override per column if needed) ───────────
    "iqr_multiplier": 1.5,
    "outlier_overrides": {
        "Vehicle_Age": {"lower_k": 1.0, "upper_k": 3.0}
    },

    # ── Correlation ───────────────────────────────────────────
    "corr_sample_size": 150_000,    # rows sampled for heatmap
    "corr_full_data":   True,       # also show full-data Pearson table
}

# Step 1: Compute (prints progress)
results = run_eda(df, config)

# Step 2 (optional): Print text summary in notebook
print_summary(results)

# Step 3: Launch Streamlit dashboard in browser
launch_app(results, config)
```

---

## Sections (7 Tabs)

| Tab | What it shows |
|-----|---------------|
| 📋 Data Summary | KPIs, feature type donut, missing heatmap, full feature table, detailed groupby report |
| 🔬 Feature Analysis | Summary table of all features + deep-dive dropdown: stats, hit rate, histogram+KDE, target rate |
| 🚨 Outliers | Interactive IQR sliders per numeric feature + box plot; rare categories + fuzzy dedup for categoricals; syntax check for ID-like columns |
| ❓ Missing Values | Missing % bar chart, co-missing pairs, MAR/MNAR hints |
| 🔗 Correlations | Pearson heatmap (sampled) + full-data Pearson table + VIF + Cramér V for categorical pairs |
| 🎯 Feature Scorecard | One row per feature: Missing / Skew / Outliers / Corr Risk → ✅ ⚠️ ❌ RAG score |
| ✅ Recommendations | Priority-filtered action cards + auto-generated sklearn pipeline code |

---

## Feature Scorecard — Scoring Rules

| Dimension | ✅ 0 pts | ⚠️ 1 pt | ❌ 2 pts | ❌❌ 3 pts |
|---|---|---|---|---|
| Missing % | 0% | 1–5% | 5–20% | >20% |
| Skew | \|skew\| < 0.5 | 0.5–1.5 | > 1.5 | — |
| Outliers (IQR%) | < 1% | 1–5% | > 5% | — |
| Corr Risk (max \|r\|) | < 0.5 | 0.5–0.8 | > 0.8 | — |
| Data quality flags | None | — | +2 per flag | — |

**Total → RAG:** 0–1 = ✅ Clean | 2–4 = ⚠️ Review | 5+ = ❌ Fix First

---

## Bivariate Target Analysis

Target rates (mean target per bin/category) are computed on **complete cases only** — rows where both the feature and the target are non-null, with no imputation. The dashboard shows what % of rows were used.

This is intentional. Feature Importance (IV, correlations vs target after imputation) belongs in a **separate post-cleaning toolkit**.

---

## Files

```
eda_toolkit/
├── launch.py       ← notebook entry point (run_eda + launch_app)
├── eda_engine.py   ← all computation
├── eda_config.py   ← config defaults
├── charts.py       ← 7 plot functions only
├── app.py          ← 7-tab Streamlit dashboard
└── README.md
```
