"""
example_notebook.py
===================
Copy each block into a Jupyter cell, or run as a script.
"""

# ─── CELL 1 — Install (once) ──────────────────────────────────────────────────
# pip install -r requirements.txt

# ─── CELL 2 — Imports ─────────────────────────────────────────────────────────
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pandas as pd
import numpy as np
from launch import run_eda, launch_app

# ─── CELL 3 — Load data ───────────────────────────────────────────────────────
# df = pd.read_csv("your_data.csv")
# df = pd.read_parquet("your_data.parquet")

# DEMO: synthetic insurance data
np.random.seed(42)
N = 200_000

df = pd.DataFrame({
    "Policy_Number":  [f"POL-{i:07d}" for i in range(N)],
    "Policy_Year":    np.random.choice([2020, 2021, 2022, 2023], N),
    "Driver_Age":     np.clip(np.random.normal(40, 12, N), 17, 90).round(),
    "Vehicle_Value":  np.random.lognormal(9.5, 0.7, N).round(2),
    "Annual_Mileage": np.random.lognormal(9.0, 0.5, N).round(),
    "NCD_Years":      np.random.choice(range(11), N),
    "Vehicle_Age":    np.random.choice(range(21), N),
    "Region":         np.random.choice(["North","South","East","West","Central"], N),
    "Vehicle_Type":   np.random.choice(["Sedan","SUV","Hatchback","Van","Truck"], N,
                                        p=[0.4, 0.25, 0.2, 0.1, 0.05]),
    "Fuel_Type":      np.random.choice(["Petrol","Diesel","Electric","Hybrid"], N,
                                        p=[0.5, 0.35, 0.08, 0.07]),
    "Gender":         np.random.choice(["Male","Female"], N),
    "Claim_Flag":     np.random.binomial(1, 0.12, N),
    "Claim_Amount":   np.where(np.random.binomial(1, 0.12, N),
                               np.random.lognormal(7.5, 1.0, N), 0).round(2),
    "Premium":        np.random.lognormal(6.5, 0.4, N).round(2),
})
# Add 10% missing
for col in ["Driver_Age", "Vehicle_Value", "Annual_Mileage", "NCD_Years"]:
    idx = np.random.choice(N, int(N * 0.10), replace=False)
    df.loc[idx, col] = np.nan

print(f"Shape: {df.shape}")

# ─── CELL 4 — Config ──────────────────────────────────────────────────────────
config = {

    # Core
    "target_col":      "Claim_Flag",   # None if no target

    # Detailed grouped report shown in Tab 1
    "detailed_report": True,
    "groupby_col":     "Policy_Year",
    "agg_config": {
        "Policy_Number": ["nunique"],
        "Claim_Flag":    ["sum", "mean"],
        "Claim_Amount":  ["sum", "mean"],
        "Premium":       ["sum", "mean"],
    },

    # Step toggles
    "STEP_DATA_QUALITY":     True,
    "STEP_DISTRIBUTION":     True,
    "STEP_MISSING_ANALYSIS": True,
    "STEP_CORRELATION":      True,
    "STEP_BIVARIATE":        True,   # requires target_col
    "STEP_SCORECARD":        True,

    # Thresholds
    "id_threshold":        10_000,
    "corr_threshold":      0.75,
    "rare_cat_threshold":  0.01,

    # Outlier fences (symmetric or asymmetric per column)
    "iqr_multiplier":  1.5,
    "outlier_overrides": {
        "Claim_Amount": {"lower_k": 1.5, "upper_k": 3.0},
    },

    # Correlation
    "corr_sample_size": 150_000,
    "corr_full_data":   True,

    # Performance
    "max_workers": 4,
}

# ─── CELL 5 — Run EDA ─────────────────────────────────────────────────────────
results = run_eda(df, config)

# Inspect in notebook:
print("\n── SCORECARD ──")
print(results["scorecard"][["Feature","Type","Missing","Skew","Score"]].to_string(index=False))

print("\n── HIGH CORR PAIRS ──")
for p in results["correlations"].get("high_corr_pairs", []):
    print(f"  {p['Feature A']} × {p['Feature B']}: r={p['Pearson r']}")

print("\n── RECOMMENDATIONS (first 5) ──")
for r in results["recommendations"][:5]:
    print(f"  {r['Priority']}  {r['Feature']}")
    for f, a in zip(r["Findings"], r["Actions"]):
        print(f"    • {f} → {a}")

# ─── CELL 6 — Launch dashboard ────────────────────────────────────────────────
launch_app(results, config, port=8501, open_browser=True)
# Opens http://localhost:8501
# Ctrl+C to stop
