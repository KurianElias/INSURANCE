"""
eda_config.py — All configuration in one place.
Pass overrides via dict to run_eda().
"""

DEFAULT_CONFIG = {
    # ── Target ────────────────────────────────────────────────────────────────
    "target_col": None,            # str or None. If None, Tab 6 hidden.

    # ── Detailed report (Tab 1 bottom) ────────────────────────────────────────
    "detailed_report": False,
    "groupby_col": None,           # e.g. "Policy_Year"
    "agg_config": {},
    # Example:
    # "agg_config": {
    #     "Policy_Number": ["nunique"],
    #     "Claim_Amount":  ["sum", "mean"],
    #     "Premium":       ["sum", "mean"],
    # }

    # ── Step toggles ──────────────────────────────────────────────────────────
    "STEP_DATA_QUALITY":     True,
    "STEP_DISTRIBUTION":     True,
    "STEP_MISSING_ANALYSIS": True,
    "STEP_CORRELATION":      True,
    "STEP_SCORECARD":        True,

    # ── Thresholds ────────────────────────────────────────────────────────────
    "id_threshold":        10_000,   # unique > this → ID-like
    "corr_threshold":      0.8,      # |r| >= this → HIGH_CORR
    "rare_cat_threshold":  0.01,     # < 1% → RARE category

    # ── Outlier IQR ───────────────────────────────────────────────────────────
    "iqr_multiplier": 1.5,
    "outlier_overrides": {},
    # e.g. {"Vehicle_Age": {"lower_k": 1.0, "upper_k": 3.0}}

    # ── Correlation ───────────────────────────────────────────────────────────
    "corr_sample_size": 150_000,
    "corr_full_data":   True,        # also compute full-data vectorized Pearson

    # ── Sampling ──────────────────────────────────────────────────────────────
    "nunique_sample":   50_000,
    "plot_sample":      50_000,
    "cramerv_sample":   300_000,
    "norm_test_sample": 5_000,
    "fit_sample":       10_000,
}


def build_config(user_config: dict = None) -> dict:
    cfg = DEFAULT_CONFIG.copy()
    if user_config:
        cfg.update(user_config)
    return cfg
