"""
eda_engine.py  v5
Pure computation — no Streamlit, no plots.
Results: plain dicts / DataFrames → stored in session_state by launch.py
"""

import pandas as pd
import numpy as np
from scipy import stats as _stats
from scipy.stats import skew as _skew, kurtosis as _kurt, chi2_contingency, normaltest
from concurrent.futures import ThreadPoolExecutor, as_completed
from difflib import SequenceMatcher
import re, time, warnings
from typing import Optional, Callable, Dict, Any
warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────────────────────────────────────
# UTILITIES
# ─────────────────────────────────────────────────────────────────────────────

def detect_type(series: pd.Series, id_threshold: int = 10_000) -> str:
    if pd.api.types.is_bool_dtype(series):           return "Boolean"
    if pd.api.types.is_datetime64_any_dtype(series): return "Date"
    if pd.api.types.is_numeric_dtype(series):
        nu = _fast_nunique(series)
        if nu <= 2:           return "Boolean"
        if nu > id_threshold: return "ID-like"
        return "Numeric"
    nu = _fast_nunique(series)
    if nu > id_threshold: return "ID-like"
    return "Categorical"

def _fast_nunique(s: pd.Series) -> int:
    n = len(s)
    if n <= 50_000: return int(s.nunique(dropna=True))
    return int(s.dropna().sample(50_000, random_state=42).nunique())

def _samp(arr: np.ndarray, n: int) -> np.ndarray:
    return arr if len(arr) <= n else np.random.choice(arr, n, replace=False)

def _log(msg: str, cb: Optional[Callable] = None, pct: int = 0):
    print(f"[EDA {pct:3d}%] {msg}")
    if cb: cb(pct, msg)


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 0 — DATA QUALITY
# ─────────────────────────────────────────────────────────────────────────────

def _data_quality(df: pd.DataFrame, dtype_map: dict) -> dict:
    n = len(df)
    dup_rows = int(df.duplicated().sum())

    # Duplicate columns (hash first 500 rows)
    dup_cols, seen = [], {}
    for col in df.columns:
        try:    h = hash(df[col].values[:500].tobytes())
        except: h = hash(str(df[col].values[:500]))
        if h in seen: dup_cols.append((seen[h], col))
        else:         seen[h] = col

    col_flags = {}
    for col in df.columns:
        dtype  = dtype_map.get(col, "Unknown")
        issues = []
        s      = df[col]

        if dtype in ("Numeric", "Boolean"):
            inf_n = int(np.isinf(pd.to_numeric(s, errors="coerce").fillna(0)).sum())
            if inf_n: issues.append(f"INF_VALUES({inf_n})")

        if dtype == "Numeric":
            neg_n = int((pd.to_numeric(s, errors="coerce") < 0).sum())
            if neg_n: issues.append(f"NEGATIVE_VALUES({neg_n})")

        nu = _fast_nunique(s)
        if nu > 10_000 and dtype not in ("Date",):
            issues.append("ID-LIKE")
        if nu == 1:
            issues.append("CONSTANT")
        if dtype == "Categorical" and nu > 1:
            tp = float(s.value_counts(normalize=True).iloc[0]) * 100
            if tp > 98: issues.append(f"QUASI_CONSTANT({tp:.0f}%)")

        col_flags[col] = ", ".join(issues) if issues else "—"

    return {
        "dup_rows":   dup_rows,
        "dup_cols":   dup_cols,
        "col_flags":  col_flags,
        "n":          n,
    }


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 1 — NUMERIC COLUMN
# ─────────────────────────────────────────────────────────────────────────────

def _analyze_numeric(col, arr, n_total, cfg):
    missing_mask  = np.isnan(arr)
    missing_count = int(missing_mask.sum())
    missing_pct   = round(missing_count / n_total * 100, 2)
    hit_rate_pct  = round((n_total - missing_count) / n_total * 100, 2)
    clean = arr[~missing_mask]
    nc    = len(clean)

    base = dict(
        col=col, dtype="Numeric",
        missing_count=missing_count, missing_pct=missing_pct,
        hit_rate_pct=hit_rate_pct,
        zero_pct=0.0, n_unique=0, top_val_pct=0.0,
        dist={}, outlier={}, plot_sample=[], id_syntax={}
    )
    if nc == 0: return base

    pcts = np.percentile(clean, [1,5,10,25,50,75,90,95,99])
    mn, mx = float(clean.min()), float(clean.max())
    mean   = float(clean.mean())
    std    = float(clean.std()) if nc > 1 else 0.0
    zero_pct = round(float((clean == 0).sum()) / n_total * 100, 2)

    samp50 = _samp(clean, cfg["nunique_sample"])
    n_uniq = int(pd.Series(samp50).nunique())
    vc50   = pd.Series(samp50).value_counts(normalize=True)
    top_pct = round(float(vc50.iloc[0]) * 100, 2) if len(vc50) else 0.0

    base.update(zero_pct=zero_pct, n_unique=n_uniq, top_val_pct=top_pct)

    if cfg.get("STEP_DISTRIBUTION", True):
        sk = float(_skew(clean)) if nc > 3 else 0.0
        ku = float(_kurt(clean)) if nc > 3 else 0.0
        iqr_val = float(pcts[5] - pcts[3])
        cv  = round(std / mean, 4) if mean != 0 else float("nan")
        mad = float(np.abs(clean - mean).mean())

        # Normality
        try:
            sn = _samp(clean, cfg["norm_test_sample"])
            _, norm_p = normaltest(sn)
            is_normal = bool(norm_p > 0.05)
        except Exception:
            norm_p, is_normal = 1.0, True

        # Log-normal
        pos = clean[clean > 0]
        if len(pos) > 50:
            try:
                _, ln_p = normaltest(np.log(_samp(pos, cfg["norm_test_sample"])))
                is_lognormal = bool(ln_p > 0.05)
            except Exception:
                ln_p, is_lognormal = 0.0, False
        else:
            ln_p, is_lognormal = 0.0, False

        # Shape
        shape = []
        if is_lognormal and sk > 0.5: shape.append("Log-Normal")
        elif sk > 1.0:  shape.append("Right Skewed")
        elif sk < -1.0: shape.append("Left Skewed")
        if ku > 3.0:    shape.append("Heavy Tailed")
        if zero_pct > 20: shape.append("Zero Inflated")
        if not shape:     shape.append("Approx Normal")

        base["dist"] = dict(
            mean=mean, median=float(pcts[4]), std=std, variance=std**2,
            min=mn, max=mx, iqr=iqr_val, mad=mad, cv=cv,
            p1=pcts[0], p5=pcts[1], p10=pcts[2], p25=pcts[3], p50=pcts[4],
            p75=pcts[5], p90=pcts[6], p95=pcts[7], p99=pcts[8],
            skewness=sk, kurtosis=ku, zero_pct=zero_pct,
            normality_p=round(float(norm_p), 4), is_normal=is_normal,
            lognormal_p=round(float(ln_p), 4), is_lognormal=is_lognormal,
            shape=", ".join(shape),
        )

    # Outliers
    k_lo = cfg.get("outlier_overrides", {}).get(col, {}).get("lower_k", cfg.get("iqr_multiplier", 1.5))
    k_hi = cfg.get("outlier_overrides", {}).get(col, {}).get("upper_k", cfg.get("iqr_multiplier", 1.5))
    q1, q3 = pcts[3], pcts[5]
    iqr    = q3 - q1
    fence_lo = q1 - k_lo * iqr
    fence_hi = q3 + k_hi * iqr
    iqr_count = int(((clean < fence_lo) | (clean > fence_hi)).sum())
    z_count   = int((np.abs((clean - mean) / std) > 3).sum()) if std > 0 else 0
    base["outlier"] = dict(
        q1=round(q1,4), q3=round(q3,4), iqr=round(iqr,4),
        fence_lo=round(fence_lo,4), fence_hi=round(fence_hi,4),
        iqr_count=iqr_count, iqr_pct=round(iqr_count/n_total*100,2),
        z_count=z_count, z_pct=round(z_count/n_total*100,2),
        p99_cap=round(float(pcts[8]),4),
        k_lo=k_lo, k_hi=k_hi,
    )

    # Plot sample
    base["plot_sample"] = _samp(clean, cfg["plot_sample"]).tolist()
    return base


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 2 — CATEGORICAL COLUMN
# ─────────────────────────────────────────────────────────────────────────────

def _analyze_categorical(col, series, n_total, cfg):
    missing_count = int(series.isna().sum())
    missing_pct   = round(missing_count / n_total * 100, 2)
    hit_rate_pct  = round((n_total - missing_count) / n_total * 100, 2)
    n_unique      = _fast_nunique(series)
    vc = series.value_counts(dropna=False)
    top_pct = round(float(vc.iloc[0]) / n_total * 100, 2) if len(vc) else 0.0

    # Diversity
    probs = (vc.values / n_total).astype(float)
    probs_v = probs[probs > 0]
    entropy = float(-np.sum(probs_v * np.log2(probs_v))) if len(probs_v) else 0.0
    hhi     = float((probs_v**2).sum())

    # Hit rate table (top 30)
    hr = pd.DataFrame({
        "Category":   vc.index.astype(str),
        "Count":      vc.values,
        "Hit Rate %": (vc.values / n_total * 100).round(2),
    }).head(30)
    hr["Flag"] = hr["Hit Rate %"].apply(
        lambda x: "🔴 RARE" if x < 1 else ("⚠️ DOMINANT" if x > 80 else "✅"))

    # Rare categories
    rare_threshold = cfg.get("rare_cat_threshold", 0.01) * 100
    rare = hr[hr["Hit Rate %"] < rare_threshold]

    # Levenshtein near-duplicates (run on list of category names)
    cats = [str(c) for c in vc.index[:200] if pd.notna(c)]
    fuzzy_pairs = []
    for i in range(len(cats)):
        for j in range(i+1, len(cats)):
            sim = SequenceMatcher(None, cats[i].lower(), cats[j].lower()).ratio()
            if sim >= 0.80 and cats[i] != cats[j]:
                fuzzy_pairs.append({
                    "Cat A": cats[i], "Cat B": cats[j],
                    "Similarity": round(sim, 3),
                    "Note": "Possible duplicate (case/typo)"
                })

    return dict(
        col=col, dtype="Categorical",
        missing_count=missing_count, missing_pct=missing_pct,
        hit_rate_pct=hit_rate_pct,
        n_unique=n_unique, top_val_pct=top_pct,
        entropy=round(entropy, 4), hhi=round(hhi, 4),
        hit_rate_table=hr,
        rare_categories=rare,
        fuzzy_pairs=fuzzy_pairs,
        dist={}, outlier={}, plot_sample=[], id_syntax={}
    )


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 3 — ID-LIKE COLUMN SYNTAX CHECK
# ─────────────────────────────────────────────────────────────────────────────

def _syntax_check(col, series, n_total):
    s = series.dropna().astype(str)
    if len(s) == 0:
        return {"col": col, "pattern": "unknown", "violations": [], "dup_ids": 0}

    sample = s.sample(min(5000, len(s)), random_state=42)

    # Detect dominant pattern
    def classify(v):
        if re.fullmatch(r"\d+", v):                return "numeric"
        if re.fullmatch(r"[A-Z0-9\-]+", v):        return "UPPER_ALPHANUM"
        if re.fullmatch(r"[a-z0-9\-]+", v):        return "lower_alphanum"
        if re.fullmatch(r"[A-Za-z0-9\-\_]+", v):   return "mixed"
        return "other"

    patterns = sample.map(classify).value_counts()
    dominant = patterns.index[0] if len(patterns) else "unknown"
    dominant_pct = float(patterns.iloc[0]) / len(sample) * 100

    # Violations = values that don't match dominant pattern
    violations_mask = sample.map(classify) != dominant
    violations = sample[violations_mask].tolist()[:20]

    # Whitespace
    ws = int(series.dropna().astype(str).str.contains(r"^\s|\s$", regex=True).sum())

    # Duplicates
    dup_ids = int(series.dropna().duplicated().sum())

    # Infer template (e.g. POL-XXXXX)
    template = _infer_template(sample[:50].tolist())

    return dict(
        col=col,
        pattern=dominant,
        pattern_pct=round(dominant_pct, 1),
        template=template,
        violations=violations,
        violation_count=len(violations),
        whitespace_count=ws,
        dup_ids=dup_ids,
    )


def _infer_template(vals):
    """Convert sample values to a regex-like template, e.g. POL-NNNNN"""
    if not vals: return "?"
    def to_tmpl(v):
        v = str(v)
        v = re.sub(r"\d", "N", v)
        v = re.sub(r"[a-z]", "a", v)
        v = re.sub(r"[A-Z]", "A", v)
        return v
    templates = [to_tmpl(v) for v in vals]
    counts    = pd.Series(templates).value_counts()
    return counts.index[0] if len(counts) else "?"


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 4 — MISSING ANALYSIS
# ─────────────────────────────────────────────────────────────────────────────

def _missing_analysis(df: pd.DataFrame) -> dict:
    miss_df = df.isna()
    cols_miss = miss_df.columns[miss_df.any()].tolist()

    miss_corr = pd.DataFrame()
    co_pairs  = []
    if len(cols_miss) >= 2:
        miss_corr = miss_df[cols_miss].corr().round(3)
        mat = miss_corr.values
        for i in range(len(cols_miss)):
            for j in range(i+1, len(cols_miss)):
                if abs(mat[i,j]) > 0.3:
                    co_pairs.append({
                        "Col A": cols_miss[i],
                        "Col B": cols_miss[j],
                        "Corr":  round(float(mat[i,j]), 3),
                        "Note":  "Co-missing — may share root cause",
                    })

    # MCAR hints: compare numeric distributions in complete vs incomplete rows
    mcar_hints = {}
    any_miss = miss_df.any(axis=1)
    if any_miss.sum() > 10 and (~any_miss).sum() > 10:
        for col in df.select_dtypes(include=[np.number]).columns[:20]:
            cv = df.loc[~any_miss, col].dropna().values
            mv = df.loc[ any_miss, col].dropna().values
            if len(cv) > 10 and len(mv) > 10:
                try:
                    _, p = _stats.ttest_ind(
                        cv[:5000], mv[:5000], equal_var=False)
                    if p < 0.05:
                        mcar_hints[col] = {
                            "p": round(float(p),4),
                            "hint": "Distribution differs in missing vs complete rows → likely MAR/MNAR"
                        }
                except Exception:
                    pass

    return {
        "cols_with_missing": cols_miss,
        "miss_corr":  miss_corr,
        "co_pairs":   co_pairs,
        "mcar_hints": mcar_hints,
    }


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 5 — CORRELATIONS
# ─────────────────────────────────────────────────────────────────────────────

def _correlations(df: pd.DataFrame, n_total: int, cfg: dict) -> dict:
    num_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    cat_cols = [c for c in df.columns
                if df[c].dtype == object or str(df[c].dtype) == "category"]

    result = dict(pearson_heatmap=pd.DataFrame(),
                  pearson_full=pd.DataFrame(),
                  vif=pd.DataFrame(),
                  high_corr_pairs=[],
                  cramerv=pd.DataFrame(),
                  numeric_cols=num_cols)

    if len(num_cols) >= 2:
        # Sampled heatmap
        ns = min(cfg["corr_sample_size"], n_total)
        df_s = df[num_cols].dropna()
        df_s = df_s.sample(min(ns, len(df_s)), random_state=42)
        result["pearson_heatmap"] = df_s.corr("pearson").round(4)

        # Full-data vectorized Pearson (upper triangle pairs)
        if cfg.get("corr_full_data", True) and n_total <= 5_000_000:
            try:
                X = df[num_cols].fillna(df[num_cols].median()).values.astype(np.float64)
                Xc = X - X.mean(0); Xs = X.std(0)
                with np.errstate(divide="ignore", invalid="ignore"):
                    corr_mat = np.where(
                        (Xs[:,None] * Xs[None,:]) > 0,
                        (Xc.T @ Xc) / (len(X) * Xs[:,None] * Xs[None,:]),
                        0.0
                    )
                pairs = []
                for i in range(len(num_cols)):
                    for j in range(i+1, len(num_cols)):
                        r = round(float(corr_mat[i,j]), 4)
                        pairs.append({
                            "Feature A": num_cols[i],
                            "Feature B": num_cols[j],
                            "Pearson r": r,
                            "|r|": round(abs(r), 4),
                            "Flag": "HIGH_CORR" if abs(r) >= cfg["corr_threshold"] else "—",
                        })
                full_df = pd.DataFrame(pairs).sort_values("|r|", ascending=False)
                result["pearson_full"] = full_df
                result["high_corr_pairs"] = [p for p in pairs if abs(p["Pearson r"]) >= cfg["corr_threshold"]]
            except Exception:
                pass

        # VIF (capped at 30 cols, 20K rows)
        if len(num_cols) >= 2:
            try:
                from sklearn.linear_model import LinearRegression
                vc = num_cols[:30]
                X_v = df[vc].fillna(df[vc].median()).values[:20_000]
                vifs = []
                for i in range(len(vc)):
                    yi = X_v[:, i]; Xi = np.delete(X_v, i, axis=1)
                    r2 = LinearRegression().fit(Xi, yi).score(Xi, yi)
                    vifs.append(round(1/(1-r2) if r2 < 0.9999 else 999.0, 2))
                vif_df = pd.DataFrame({"Feature": vc, "VIF": vifs}).sort_values("VIF", ascending=False)
                vif_df["Flag"] = vif_df["VIF"].apply(
                    lambda v: "❌ HIGH(>10)" if v > 10 else ("⚠️ MOD(5-10)" if v > 5 else "✅"))
                result["vif"] = vif_df
            except Exception:
                pass

    # Cramér V for categorical pairs (capped 10 cols, 100K rows)
    if len(cat_cols) >= 2:
        try:
            cv_cols = cat_cols[:10]
            ns_cv = min(100_000, n_total)
            df_cv = df[cv_cols].sample(min(ns_cv, len(df)), random_state=42)
            cv_mat = pd.DataFrame(index=cv_cols, columns=cv_cols, dtype=float)
            for i, c1 in enumerate(cv_cols):
                for j, c2 in enumerate(cv_cols):
                    if i == j:
                        cv_mat.loc[c1, c2] = 1.0
                    elif j > i:
                        try:
                            ct = pd.crosstab(df_cv[c1].fillna("__NA__"),
                                              df_cv[c2].fillna("__NA__"))
                            chi2 = chi2_contingency(ct, correction=False)[0]
                            r, k = ct.shape
                            v = float(np.sqrt(chi2 / (len(df_cv) * (min(r,k)-1)))) if min(r,k)>1 else 0.0
                            cv_mat.loc[c1, c2] = round(v, 3)
                            cv_mat.loc[c2, c1] = round(v, 3)
                        except Exception:
                            cv_mat.loc[c1, c2] = 0.0
                            cv_mat.loc[c2, c1] = 0.0
            result["cramerv"] = cv_mat.astype(float)
        except Exception:
            pass

    return result


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 6 — BIVARIATE VS TARGET (raw, on complete cases only)
# ─────────────────────────────────────────────────────────────────────────────

def _bivariate(df: pd.DataFrame, target_col: str, dtype_map: dict) -> dict:
    if not target_col or target_col not in df.columns:
        return {}
    y = df[target_col]
    grand_mean = float(y.mean())
    results = {}
    for col in [c for c in df.columns if c != target_col]:
        dtype = dtype_map.get(col, "Unknown")
        # Complete cases only for this feature + target
        mask = df[col].notna() & y.notna()
        n_complete = int(mask.sum())
        n_total    = len(df)
        pct_used   = round(n_complete / n_total * 100, 1)
        s_c = df.loc[mask, col]
        y_c = y[mask]
        res = {"col": col, "dtype": dtype, "pct_complete_cases": pct_used, "bivariate_table": []}

        if dtype == "Numeric":
            try:
                cuts = pd.cut(s_c, bins=10, duplicates="drop")
                biv  = pd.DataFrame({"bin": cuts, "target": y_c})
                agg  = biv.groupby("bin", observed=True)["target"].agg(["mean","count"]).reset_index()
                agg.columns = ["Bin","Mean Target","Count"]
                agg["Hit Rate %"] = (agg["Count"] / n_total * 100).round(2)
                agg["Relativity"] = (agg["Mean Target"] / grand_mean).round(3) if grand_mean else 1.0
                agg["Bin"] = agg["Bin"].astype(str)
                res["bivariate_table"] = agg.to_dict(orient="records")
            except Exception:
                pass

        elif dtype == "Categorical":
            try:
                s_f = s_c.fillna("__MISSING__")
                biv = pd.DataFrame({"cat": s_f, "target": y_c})
                agg = biv.groupby("cat")["target"].agg(["mean","count"]).reset_index()
                agg.columns = ["Category","Mean Target","Count"]
                agg["Hit Rate %"] = (agg["Count"] / n_total * 100).round(2)
                agg["Relativity"] = (agg["Mean Target"] / grand_mean).round(3) if grand_mean else 1.0
                agg = agg.sort_values("Mean Target", ascending=False).head(30)
                res["bivariate_table"] = agg.to_dict(orient="records")
            except Exception:
                pass

        results[col] = res
    return results


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 7 — FEATURE SCORECARD
# ─────────────────────────────────────────────────────────────────────────────

def _scorecard(col_results: dict, corr_result: dict, dq: dict) -> pd.DataFrame:
    """
    One row per feature. 5 dimensions → RAG score.
    Missing | Skew | Outliers | CorrRisk | Score
    """
    rows = []

    # Max |r| per feature (from full Pearson pairs)
    max_r = {}
    pf = corr_result.get("pearson_full", pd.DataFrame())
    if len(pf) > 0:
        for _, row in pf.iterrows():
            for f in [row["Feature A"], row["Feature B"]]:
                max_r[f] = max(max_r.get(f, 0.0), abs(row["Pearson r"]))

    for col, res in col_results.items():
        dtype = res.get("dtype", "Unknown")
        mp    = res.get("missing_pct", 0.0)
        dist  = res.get("dist", {})
        outl  = res.get("outlier", {})
        q_flag = dq.get("col_flags", {}).get(col, "—")

        # ── Missing score ──────────────────────────────────────────────────
        if mp == 0:        miss_score = 0; miss_label = "0%"
        elif mp < 5:       miss_score = 1; miss_label = f"{mp:.1f}% Low"
        elif mp < 20:      miss_score = 2; miss_label = f"{mp:.1f}% Medium"
        else:              miss_score = 3; miss_label = f"{mp:.1f}% High"

        # ── Skew score ─────────────────────────────────────────────────────
        sk = abs(dist.get("skewness", 0)) if dtype == "Numeric" else None
        if sk is None:         skew_score = 0; skew_label = "—"
        elif sk < 0.5:         skew_score = 0; skew_label = "None"
        elif sk < 1.5:         skew_score = 1; skew_label = f"Low ({sk:.1f})"
        else:                  skew_score = 2; skew_label = f"High ({sk:.1f})"

        # ── Outlier score ──────────────────────────────────────────────────
        iqr_pct = outl.get("iqr_pct", 0) if dtype == "Numeric" else None
        if iqr_pct is None:    out_score = 0; out_label = "—"
        elif iqr_pct < 1:      out_score = 0; out_label = "None"
        elif iqr_pct < 5:      out_score = 1; out_label = f"Low ({iqr_pct:.1f}%)"
        else:                  out_score = 2; out_label = f"High ({iqr_pct:.1f}%)"

        # ── Corr risk ──────────────────────────────────────────────────────
        mr = max_r.get(col, 0.0)
        if mr < 0.5:           corr_score = 0; corr_label = "Low"
        elif mr < 0.8:         corr_score = 1; corr_label = f"Medium ({mr:.2f})"
        else:                  corr_score = 2; corr_label = f"High ({mr:.2f})"

        # ── Quality flag penalty ───────────────────────────────────────────
        flag_score = 0
        for bad in ["ID-LIKE","CONSTANT","QUASI_CONSTANT","INF_VALUES"]:
            if bad in q_flag: flag_score += 2

        # ── Total → RAG ────────────────────────────────────────────────────
        total = miss_score + skew_score + out_score + corr_score + flag_score
        if total <= 1:   rag = "✅ Clean"
        elif total <= 4: rag = "⚠️ Review"
        else:            rag = "❌ Fix First"

        # Type icon
        icons = {"Numeric":"🔢","Categorical":"🏷️","Boolean":"☑️","Date":"📅","ID-like":"🔑"}
        type_icon = f"{icons.get(dtype,'❓')} {dtype}"

        rows.append({
            "Feature":   col,
            "Type":      type_icon,
            "Missing":   miss_label,
            "Skew":      skew_label,
            "Outliers":  out_label,
            "Corr Risk": corr_label,
            "Flags":     q_flag if q_flag != "—" else "",
            "Score":     rag,
            "_total":    total,
        })

    df_sc = pd.DataFrame(rows).sort_values("_total", ascending=False)
    df_sc = df_sc.drop(columns=["_total"])
    return df_sc


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 8 — RECOMMENDATIONS
# ─────────────────────────────────────────────────────────────────────────────

def _recommendations(col_results: dict, scorecard: pd.DataFrame) -> list:
    recs = []
    score_map = {row["Feature"]: row["Score"]
                 for _, row in scorecard.iterrows()}

    for col, res in col_results.items():
        dtype   = res.get("dtype", "Unknown")
        mp      = res.get("missing_pct", 0.0)
        dist    = res.get("dist", {})
        outl    = res.get("outlier", {})
        n_uniq  = res.get("n_unique", 0)
        findings, actions, reasons = [], [], []

        def add(f, a, r):
            findings.append(f); actions.append(a); reasons.append(r)

        if dtype == "Numeric":
            sk = dist.get("skewness", 0)
            is_ln = dist.get("is_lognormal", False)
            zero_pct = dist.get("zero_pct", 0)
            iqr_pct  = outl.get("iqr_pct", 0)
            p99      = outl.get("p99_cap", None)

            if is_ln and sk > 0.5:
                add("Log-normal distribution", "Apply log or log1p transform",
                    "Log-normal is canonical for insurance amounts; log transform linearises for GLMs")
            elif abs(sk) > 1.5:
                add(f"Highly skewed (skew={sk:.2f})", "Apply log1p transform",
                    "Compresses long tail, improves GLM fit")
            elif abs(sk) > 0.5:
                add(f"Moderately skewed (skew={sk:.2f})", "Consider sqrt or log transform",
                    "Moderate skew biases linear coefficients")

            if zero_pct > 30:
                add(f"Zero-inflated ({zero_pct:.1f}% zeros)",
                    "Use two-part model (logistic for zero/non-zero + Gamma for positives)",
                    "Tweedie/hurdle models handle structural zeros natively")

            if iqr_pct > 5:
                add(f"{iqr_pct:.1f}% outliers (IQR)",
                    f"Cap at P99 = {p99}" if p99 else "Cap at P99",
                    "Outliers inflate variance and bias coefficients")

            if mp > 20:
                add(f"High missing ({mp:.1f}%)",
                    f"Create {col}_missing flag + median impute",
                    "High missingness may be informative; indicator preserves signal")
            elif mp > 0:
                add(f"Missing {mp:.1f}%", "Median imputation",
                    "Median is robust to skew")

            if n_uniq <= 5:
                add("Very few unique values", "Re-encode as categorical",
                    "Treating discrete values as continuous violates model assumptions")

        elif dtype == "Categorical":
            rare = res.get("rare_categories", pd.DataFrame())
            fuzzy = res.get("fuzzy_pairs", [])
            if n_uniq > 50:
                add(f"High cardinality ({n_uniq})",
                    "Target encode or frequency encode",
                    "One-hot of high-cardinality causes dimensionality explosion")
            if len(rare) > 0:
                add(f"{len(rare)} rare categories (<1%)",
                    "Group rare categories into 'Other'",
                    "Rare categories produce unstable model relativities")
            if len(fuzzy) > 0:
                add(f"{len(fuzzy)} near-duplicate category names",
                    "Standardise: " + ", ".join(f"{p['Cat A']}→{p['Cat B']}" for p in fuzzy[:3]),
                    "Typos and case differences fragment categories")
            if mp > 0:
                add(f"Missing {mp:.1f}%",
                    "Create explicit 'Unknown' category",
                    "Missing is a distinct risk class in insurance")

        elif dtype == "ID-like":
            syn = res.get("id_syntax", {})
            dup = syn.get("dup_ids", 0) if syn else 0
            add("ID-like column",
                "Exclude from modeling; use only for row identification",
                "ID columns cause severe overfitting")
            if dup > 0:
                add(f"{dup} duplicate IDs", "Investigate and deduplicate",
                    "Duplicate IDs may indicate data join errors")

        elif dtype == "Date":
            add("Date column", "Extract: year, month, quarter, day-of-week",
                "Date components capture seasonality patterns")

        priority = score_map.get(col, "✅ Clean")
        recs.append(dict(
            Feature=col, Type=dtype, Priority=priority,
            Findings=findings, Actions=actions, Reasons=reasons
        ))

    # Sort by priority severity
    order = {"❌ Fix First": 0, "⚠️ Review": 1, "✅ Clean": 2}
    recs.sort(key=lambda r: order.get(r["Priority"], 3))
    return recs


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 9 — DETAILED REPORT
# ─────────────────────────────────────────────────────────────────────────────

def _detailed_report(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    groupby_col = cfg.get("groupby_col")
    agg_config  = cfg.get("agg_config", {})
    if not groupby_col or not agg_config or groupby_col not in df.columns:
        return pd.DataFrame()
    try:
        # Build agg dict with only columns that exist
        agg = {col: funcs for col, funcs in agg_config.items() if col in df.columns}
        if not agg:
            return pd.DataFrame()
        result = df.groupby(groupby_col).agg(agg)
        result.columns = ["_".join(c).strip() for c in result.columns]
        result = result.reset_index()
        return result.sort_values(groupby_col)
    except Exception as e:
        print(f"[WARN] Detailed report failed: {e}")
        return pd.DataFrame()


# ─────────────────────────────────────────────────────────────────────────────
# WORKER
# ─────────────────────────────────────────────────────────────────────────────

def _worker(args):
    col, dtype, series, n, cfg = args
    if dtype in ("Numeric", "Boolean"):
        return col, _analyze_numeric(col, series.to_numpy(dtype=np.float64, na_value=np.nan), n, cfg)
    elif dtype == "ID-like":
        res = _analyze_categorical(col, series, n, cfg)
        res["dtype"] = "ID-like"
        res["id_syntax"] = _syntax_check(col, series, n)
        return col, res
    else:
        return col, _analyze_categorical(col, series, n, cfg)


# ─────────────────────────────────────────────────────────────────────────────
# MASTER — run_eda
# ─────────────────────────────────────────────────────────────────────────────

def run_eda(df: pd.DataFrame, cfg: dict,
            progress_callback=None) -> dict:

    t0 = time.time()
    n  = len(df)
    target_col = cfg.get("target_col")
    feature_cols = [c for c in df.columns if c != target_col]

    _log(f"EDA v5 — {len(feature_cols)} features × {n:,} rows", progress_callback, 0)

    # Type detection
    _log("Detecting feature types...", progress_callback, 2)
    dtype_map = {col: detect_type(df[col], cfg.get("id_threshold", 10_000))
                 for col in feature_cols}

    # Data quality
    dq = {}
    if cfg.get("STEP_DATA_QUALITY", True):
        _log("Data quality checks...", progress_callback, 4)
        dq = _data_quality(df[feature_cols], dtype_map)

    # Per-column analysis (parallel)
    _log("Per-column analysis (parallel)...", progress_callback, 6)
    args_list = [(col, dtype_map[col], df[col], n, cfg) for col in feature_cols]
    col_results = {}
    done = 0
    with ThreadPoolExecutor(max_workers=4) as ex:
        fut_map = {ex.submit(_worker, a): a[0] for a in args_list}
        for fut in as_completed(fut_map):
            col = fut_map[fut]
            try:
                col, res = fut.result()
            except Exception as e:
                col_name = fut_map[fut]
                res = dict(col=col_name, dtype=dtype_map.get(col_name,"Unknown"),
                           missing_count=0, missing_pct=0, hit_rate_pct=100,
                           n_unique=0, top_val_pct=0, zero_pct=0,
                           dist={}, outlier={}, plot_sample=[], id_syntax={})
                col = col_name
                print(f"  [WARN] {col}: {e}")
            col_results[col] = res
            done += 1
            if done % max(1, len(feature_cols)//20) == 0 or done == len(feature_cols):
                _log(f"Features: {done}/{len(feature_cols)}", progress_callback,
                     6 + int(done/len(feature_cols)*38))

    # Missing analysis
    miss_adv = {}
    if cfg.get("STEP_MISSING_ANALYSIS", True):
        _log("Missing value analysis...", progress_callback, 46)
        miss_adv = _missing_analysis(df[feature_cols])

    # Correlations
    corr_result = {}
    if cfg.get("STEP_CORRELATION", True):
        _log(f"Correlations (sample={min(cfg['corr_sample_size'],n):,})...", progress_callback, 54)
        corr_result = _correlations(df[feature_cols], n, cfg)

    # Bivariate (complete cases, with warning label)
    biv_result = {}
    if target_col and target_col in df.columns:
        _log("Bivariate analysis (complete cases only)...", progress_callback, 66)
        biv_result = _bivariate(df, target_col, dtype_map)

    # Scorecard
    scorecard = pd.DataFrame()
    if cfg.get("STEP_SCORECARD", True):
        _log("Computing feature scorecard...", progress_callback, 76)
        scorecard = _scorecard(col_results, corr_result, dq)

    # Recommendations
    _log("Generating recommendations...", progress_callback, 86)
    recs = _recommendations(col_results, scorecard if len(scorecard) else pd.DataFrame())

    # Detailed report
    det_report = pd.DataFrame()
    if cfg.get("detailed_report", False):
        _log("Building detailed report...", progress_callback, 93)
        det_report = _detailed_report(df, cfg)

    elapsed = round(time.time() - t0, 1)
    _log(f"Done in {elapsed}s ({elapsed/60:.1f} min)", progress_callback, 100)

    return {
        # Raw inputs
        "df":             df,
        "cfg":            cfg,
        "feature_cols":   feature_cols,
        "dtype_map":      dtype_map,
        "target_col":     target_col,
        "n_rows":         n,
        "n_features":     len(feature_cols),
        "elapsed_sec":    elapsed,
        # Results
        "col_results":    col_results,
        "data_quality":   dq,
        "missing_adv":    miss_adv,
        "correlations":   corr_result,
        "bivariate":      biv_result,
        "scorecard":      scorecard,
        "recommendations":recs,
        "detailed_report":det_report,
    }
