"""
launch.py — Notebook entry point for the Insurance EDA Toolkit v5.

Usage in Jupyter notebook:
──────────────────────────
    import pandas as pd
    from eda_toolkit.launch import run_eda, launch_app

    df = pd.read_csv("insurance.csv")

    config = {
        # ── Required ─────────────────────────────────────────────────────────
        "target_col":   "Claim_Flag",    # set None if no target
        
        # ── Detailed report (Tab 1 bottom) ───────────────────────────────────
        "detailed_report": True,
        "groupby_col":  "Policy_Year",
        "agg_config": {
            "Policy_Number": ["nunique"],
            "Claim_Amount":  ["sum", "mean"],
            "Premium":       ["sum", "mean"],
            "Claim_Flag":    ["sum", "mean"],
        },
        
        # ── Step toggles (True/False) ─────────────────────────────────────────
        "STEP_DATA_QUALITY":     True,
        "STEP_DISTRIBUTION":     True,
        "STEP_MISSING_ANALYSIS": True,
        "STEP_CORRELATION":      True,
        "STEP_SCORECARD":        True,
        
        # ── Thresholds ────────────────────────────────────────────────────────
        "id_threshold":       10_000,
        "corr_threshold":     0.8,
        "rare_cat_threshold": 0.01,
        
        # ── Outlier IQR ───────────────────────────────────────────────────────
        "iqr_multiplier": 1.5,
        "outlier_overrides": {
            # "Vehicle_Age": {"lower_k": 1.0, "upper_k": 3.0}
        },
        
        # ── Correlation ───────────────────────────────────────────────────────
        "corr_sample_size": 150_000,
        "corr_full_data":   True,
    }

    results = run_eda(df, config)    # compute — prints progress
    launch_app(results, config)      # launch Streamlit in browser
"""

import os
import sys
import json
import pickle
import subprocess
import tempfile
import webbrowser
import time
from pathlib import Path

# Add toolkit directory to path
_TOOLKIT_DIR = Path(__file__).parent
sys.path.insert(0, str(_TOOLKIT_DIR))

from eda_config import build_config
from eda_engine import run_eda as _run_eda


# ── Public API ────────────────────────────────────────────────────────────────

def run_eda(df, user_config: dict = None) -> dict:
    """
    Run the full EDA pipeline on df.

    Parameters
    ----------
    df          : pd.DataFrame  — your raw dataset
    user_config : dict          — overrides for DEFAULT_CONFIG

    Returns
    -------
    dict with keys: col_results, data_quality, missing_adv,
                    correlations, bivariate, scorecard,
                    recommendations, detailed_report, df, cfg, ...
    """
    cfg = build_config(user_config)
    return _run_eda(df, cfg)


def launch_app(results: dict, user_config: dict = None, port: int = 8501):
    """
    Save EDA results to a temp file and launch Streamlit on localhost:{port}.

    Parameters
    ----------
    results     : dict — output of run_eda()
    user_config : dict — same config used for run_eda() (for sidebar display)
    port        : int  — Streamlit port (default 8501)
    """
    import pandas as pd

    # Persist results to a temp pickle so Streamlit can read them
    tmp = _TOOLKIT_DIR / "_eda_results.pkl"
    with open(tmp, "wb") as f:
        pickle.dump(results, f)

    # Write a thin loader shim that Streamlit will execute
    shim = _TOOLKIT_DIR / "_streamlit_entry.py"
    shim.write_text(f"""
import pickle, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

import streamlit as st
from app import main

_pkl = Path(__file__).parent / "_eda_results.pkl"
if "eda_results" not in st.session_state:
    with open(_pkl, "rb") as f:
        st.session_state["eda_results"] = pickle.load(f)

main()
""")

    url = f"http://localhost:{port}"
    print(f"\n{'='*55}")
    print(f"  Launching Insurance EDA Toolkit")
    print(f"  URL:  {url}")
    print(f"  Stop: Ctrl+C in this cell / terminal")
    print(f"{'='*55}\n")

    # Open browser after short delay
    def _open():
        time.sleep(3)
        webbrowser.open(url)

    import threading
    threading.Thread(target=_open, daemon=True).start()

    # Launch Streamlit
    cmd = [
        sys.executable, "-m", "streamlit", "run",
        str(shim),
        f"--server.port={port}",
        "--server.headless=true",
        "--theme.base=dark",
        "--theme.backgroundColor=#0e1117",
        "--theme.secondaryBackgroundColor=#1a1d27",
        "--theme.textColor=#e0e4ef",
        "--theme.font=monospace",
    ]
    try:
        subprocess.run(cmd, cwd=str(_TOOLKIT_DIR))
    except KeyboardInterrupt:
        print("\n[EDA] Streamlit stopped.")


# ── Quick preview (no Streamlit) ──────────────────────────────────────────────
def print_summary(results: dict):
    """Print a text summary of EDA results to the notebook."""
    import pandas as pd

    print(f"\n{'═'*60}")
    print(f"  EDA SUMMARY — {results['n_rows']:,} rows × {results['n_features']} features")
    print(f"  Runtime: {results['elapsed_sec']:.1f}s")
    print(f"{'═'*60}")

    sc = results.get("scorecard", pd.DataFrame())
    if len(sc):
        print(f"\n  SCORECARD:")
        print(f"    ❌ Fix First : {(sc['Score']=='❌ Fix First').sum()}")
        print(f"    ⚠️ Review    : {(sc['Score']=='⚠️ Review').sum()}")
        print(f"    ✅ Clean     : {(sc['Score']=='✅ Clean').sum()}")

        print(f"\n  TOP ISSUES:")
        for _, row in sc[sc["Score"]=="❌ Fix First"].head(5).iterrows():
            print(f"    ❌ {row['Feature']:25s} Missing={row['Missing']}  "
                  f"Skew={row['Skew']}  Outliers={row['Outliers']}")

    recs = results.get("recommendations", [])
    critical = [r for r in recs if "Fix" in r["Priority"]]
    if critical:
        print(f"\n  CRITICAL ACTIONS ({len(critical)} features):")
        for r in critical[:5]:
            for a in r["Actions"]:
                print(f"    • {r['Feature']}: {a}")

    print(f"\n{'═'*60}\n")
