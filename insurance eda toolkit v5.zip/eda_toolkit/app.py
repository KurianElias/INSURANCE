"""
app.py — Insurance EDA Toolkit v5
7 tabs. Launched by launch.py after run_eda() completes.
Data passed via st.session_state["eda_results"].
"""

import streamlit as st
import pandas as pd
import numpy as np
import json, io
from charts import (
    fig_histogram_kde, fig_boxplot,
    fig_target_rate_bins, fig_category_bar,
    fig_target_rate_cat, fig_missing_bar,
    fig_correlation_heatmap, fig_cramerv_heatmap,
    fig_type_donut,
)

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Insurance EDA Toolkit",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600&display=swap');
html, body, [class*="css"] { font-family: 'IBM Plex Sans', sans-serif; }

[data-testid="stSidebar"] {
    background: #0f1117;
    border-right: 1px solid #1e2130;
}
[data-testid="stSidebar"] * { color: #c9d1d9 !important; }

.metric-card {
    background: #1a1d27;
    border: 1px solid #2a2d3e;
    border-radius: 8px;
    padding: 16px 20px;
    text-align: center;
}
.metric-val { font-size: 2rem; font-weight: 600; color: #4F8EF7; font-family: 'IBM Plex Mono'; }
.metric-lbl { font-size: 0.78rem; color: #6b7280; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.08em; }

.score-clean  { color: #4FC97E; font-weight: 600; }
.score-review { color: #F7D94F; font-weight: 600; }
.score-fix    { color: #F74F4F; font-weight: 600; }

.rec-card {
    background: #1a1d27;
    border-left: 4px solid #2a2d3e;
    border-radius: 6px;
    padding: 14px 18px;
    margin-bottom: 12px;
}
.rec-card.critical { border-left-color: #F74F4F; }
.rec-card.review   { border-left-color: #F7D94F; }
.rec-card.clean    { border-left-color: #4FC97E; }

.warn-box {
    background: #2a1f0a;
    border: 1px solid #F7D94F44;
    border-radius: 6px;
    padding: 10px 16px;
    color: #F7D94F;
    font-size: 0.85rem;
    margin-bottom: 12px;
}

.section-header {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.72rem;
    letter-spacing: 0.15em;
    color: #6b7280;
    text-transform: uppercase;
    margin: 18px 0 8px 0;
    padding-bottom: 4px;
    border-bottom: 1px solid #2a2d3e;
}

table { width: 100%; }
thead th { background: #12141e !important; color: #6b7280 !important; font-size: 0.78rem !important; }
</style>
""", unsafe_allow_html=True)


# ── Helpers ────────────────────────────────────────────────────────────────────
def _get() -> dict:
    return st.session_state.get("eda_results", {})

def _kpi(label, value, col):
    col.markdown(
        f'<div class="metric-card">'
        f'<div class="metric-val">{value}</div>'
        f'<div class="metric-lbl">{label}</div>'
        f'</div>',
        unsafe_allow_html=True
    )

def _score_html(score: str) -> str:
    if "Clean"  in score: cls = "score-clean"
    elif "Review" in score: cls = "score-review"
    else:                   cls = "score-fix"
    return f'<span class="{cls}">{score}</span>'

def _style_scorecard(df: pd.DataFrame) -> pd.DataFrame:
    """Return display-safe copy with emoji preserved."""
    return df.copy()

def _dl_csv(df: pd.DataFrame, label: str, filename: str):
    csv = df.to_csv(index=False).encode()
    st.download_button(f"⬇ Download {label}", csv, filename, "text/csv", use_container_width=True)


# ── SIDEBAR ────────────────────────────────────────────────────────────────────
def _sidebar(R: dict):
    st.sidebar.markdown("## 📊 EDA Toolkit v5")
    st.sidebar.markdown("---")
    cfg = R.get("cfg", {})
    st.sidebar.markdown(f"**Rows:** `{R.get('n_rows',0):,}`")
    st.sidebar.markdown(f"**Features:** `{R.get('n_features',0)}`")
    tc = cfg.get("target_col")
    st.sidebar.markdown(f"**Target:** `{tc}`" if tc else "**Target:** _none_")
    st.sidebar.markdown(f"**Runtime:** `{R.get('elapsed_sec',0):.1f}s`")
    st.sidebar.markdown("---")

    sc = R.get("scorecard", pd.DataFrame())
    if len(sc):
        n_fix    = (sc["Score"].str.contains("Fix")).sum()
        n_review = (sc["Score"].str.contains("Review")).sum()
        n_clean  = (sc["Score"].str.contains("Clean")).sum()
        st.sidebar.markdown(f"❌ Fix First: **{n_fix}**")
        st.sidebar.markdown(f"⚠️ Review:    **{n_review}**")
        st.sidebar.markdown(f"✅ Clean:     **{n_clean}**")

    st.sidebar.markdown("---")

    # Download ZIP
    buf = io.BytesIO()
    import zipfile, pickle
    with zipfile.ZipFile(buf, "w") as zf:
        if len(sc):
            zf.writestr("scorecard.csv", sc.to_csv(index=False))
        recs = R.get("recommendations", [])
        if recs:
            rows = []
            for r in recs:
                for f, a, rs in zip(r["Findings"], r["Actions"], r["Reasons"]):
                    rows.append({"Feature": r["Feature"], "Priority": r["Priority"],
                                 "Finding": f, "Action": a, "Reason": rs})
            if rows:
                zf.writestr("recommendations.csv",
                            pd.DataFrame(rows).to_csv(index=False))
        det = R.get("detailed_report", pd.DataFrame())
        if len(det):
            zf.writestr("detailed_report.csv", det.to_csv(index=False))
    buf.seek(0)
    st.sidebar.download_button("⬇ Download All (ZIP)", buf, "eda_results.zip",
                               "application/zip", use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — DATA SUMMARY
# ══════════════════════════════════════════════════════════════════════════════
def tab_summary(R: dict):
    cfg = R.get("cfg", {})
    dq  = R.get("data_quality", {})
    col_results = R.get("col_results", {})
    dtype_map   = R.get("dtype_map", {})

    # ── KPI row ────────────────────────────────────────────────────────────────
    k1, k2, k3, k4, k5 = st.columns(5)
    _kpi("Total Rows",     f"{R.get('n_rows',0):,}",  k1)
    _kpi("Features",       R.get('n_features',0),      k2)
    _kpi("Target",         cfg.get('target_col','—'),  k3)
    _kpi("Duplicate Rows", dq.get('dup_rows', 0),      k4)
    sc = R.get("scorecard", pd.DataFrame())
    n_issues = int((sc["Score"].str.contains("Fix|Review")).sum()) if len(sc) else 0
    _kpi("Issues Found",   n_issues,                   k5)

    st.markdown("")

    # ── Type donut + missing heatmap ───────────────────────────────────────────
    c_left, c_right = st.columns([1, 2])
    with c_left:
        st.plotly_chart(fig_type_donut(dtype_map), use_container_width=True)

    with c_right:
        # Compact missing grid (top 30 cols, top 200 rows)
        st.markdown('<p class="section-header">Missing Value Map (sample)</p>',
                    unsafe_allow_html=True)
        df_raw = R.get("df", pd.DataFrame())
        if len(df_raw):
            cols_with_miss = [c for c, res in col_results.items()
                              if res.get("missing_pct", 0) > 0][:30]
            if cols_with_miss:
                miss_grid = df_raw[cols_with_miss].head(200).isna().astype(int)
                import plotly.graph_objects as go
                fig_grid = go.Figure(go.Heatmap(
                    z=miss_grid.T.values,
                    x=[str(i) for i in range(len(miss_grid))],
                    y=cols_with_miss,
                    colorscale=[[0, "#1a1d27"], [1, "#F74F4F"]],
                    showscale=False,
                ))
                fig_grid.update_layout(
                    paper_bgcolor="#1a1d27", plot_bgcolor="#1a1d27",
                    font=dict(color="#e0e4ef", size=9),
                    margin=dict(l=120, r=10, t=10, b=30),
                    height=250,
                )
                fig_grid.update_xaxes(showticklabels=False)
                st.plotly_chart(fig_grid, use_container_width=True)
            else:
                st.success("✅ No missing values detected")

    # ── Full feature table ─────────────────────────────────────────────────────
    st.markdown('<p class="section-header">Feature Overview</p>',
                unsafe_allow_html=True)

    rows = []
    for col, res in col_results.items():
        dtype = res.get("dtype", "Unknown")
        dist  = res.get("dist", {})
        icons = {"Numeric":"🔢","Categorical":"🏷️","Boolean":"☑️",
                 "Date":"📅","ID-like":"🔑"}
        mean_or_top = ""
        if dtype == "Numeric":
            mean_or_top = f"{dist.get('mean', 0):.3g}" if dist else "—"
        elif dtype == "Categorical":
            vc = res.get("hit_rate_table")
            if vc is not None and len(vc):
                mean_or_top = str(vc.iloc[0]["Category"])[:20]

        rows.append({
            "Feature":      col,
            "Type":         f"{icons.get(dtype,'❓')} {dtype}",
            "Hit Rate %":   res.get("hit_rate_pct", 0),
            "Missing %":    res.get("missing_pct", 0),
            "Unique":       res.get("n_unique", 0),
            "Zero %":       res.get("zero_pct", 0),
            "Mean / Top":   mean_or_top,
            "Skew":         round(dist.get("skewness", 0), 2) if dist and dtype=="Numeric" else "—",
            "Shape":        dist.get("shape", "—") if dist else "—",
            "Flags":        dq.get("col_flags", {}).get(col, "—"),
        })

    feat_df = pd.DataFrame(rows)
    st.dataframe(feat_df, use_container_width=True, height=400,
                 column_config={
                     "Hit Rate %":  st.column_config.ProgressColumn("Hit Rate %", min_value=0, max_value=100),
                     "Missing %":   st.column_config.ProgressColumn("Missing %", min_value=0, max_value=100),
                 })
    _dl_csv(feat_df, "Feature Overview", "feature_overview.csv")

    # ── Detailed report ────────────────────────────────────────────────────────
    det = R.get("detailed_report", pd.DataFrame())
    if len(det):
        st.markdown('<p class="section-header">Detailed Report — '
                    f'GroupBy: {cfg.get("groupby_col","")}</p>',
                    unsafe_allow_html=True)
        st.dataframe(det, use_container_width=True)
        _dl_csv(det, "Detailed Report", "detailed_report.csv")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — FEATURE ANALYSIS
# ══════════════════════════════════════════════════════════════════════════════
def tab_features(R: dict):
    col_results = R.get("col_results", {})
    biv         = R.get("bivariate", {})
    target_col  = R.get("target_col")
    df_raw      = R.get("df", pd.DataFrame())

    # ── Summary table (all features) ──────────────────────────────────────────
    st.markdown('<p class="section-header">All Features — Summary</p>',
                unsafe_allow_html=True)
    rows = []
    for col, res in col_results.items():
        dtype = res.get("dtype", "Unknown")
        dist  = res.get("dist", {})
        nu    = res.get("n_unique", 0)
        rows.append({
            "Feature":   col,
            "Type":      dtype,
            "Missing %": res.get("missing_pct", 0),
            "Hit Rate %":res.get("hit_rate_pct", 0),
            "Unique":    nu,
            "Mean":      round(dist.get("mean", 0), 4) if dist and dtype == "Numeric" else "—",
            "Std":       round(dist.get("std",  0), 4) if dist and dtype == "Numeric" else "—",
            "Skew":      round(dist.get("skewness", 0), 2) if dist and dtype == "Numeric" else "—",
            "Shape":     dist.get("shape", "—") if dist else "—",
            "Entropy":   res.get("entropy", "—") if dtype == "Categorical" else "—",
        })
    st.dataframe(pd.DataFrame(rows), use_container_width=True, height=300)

    st.markdown("---")

    # ── Deep dive dropdown ────────────────────────────────────────────────────
    st.markdown('<p class="section-header">Deep Dive — Select a Feature</p>',
                unsafe_allow_html=True)
    all_cols = list(col_results.keys())
    selected = st.selectbox("Feature", all_cols, label_visibility="collapsed")

    if not selected:
        return
    res   = col_results[selected]
    dtype = res.get("dtype", "Unknown")
    dist  = res.get("dist", {})
    biv_f = biv.get(selected, {})

    if dtype == "Numeric":
        # ── Stats grid ────────────────────────────────────────────────────────
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Hit Rate %", f"{res.get('hit_rate_pct',0):.1f}%")
        c2.metric("Missing %",  f"{res.get('missing_pct',0):.1f}%")
        c3.metric("Mean",       f"{dist.get('mean',0):.4g}" if dist else "—")
        c4.metric("Std",        f"{dist.get('std',0):.4g}"  if dist else "—")
        c5.metric("Skewness",   f"{dist.get('skewness',0):.2f}" if dist else "—")

        c6, c7, c8, c9, c10 = st.columns(5)
        c6.metric("Median",   f"{dist.get('median',0):.4g}"  if dist else "—")
        c7.metric("IQR",      f"{dist.get('iqr',0):.4g}"     if dist else "—")
        c8.metric("CV",       f"{dist.get('cv',0):.3f}"      if dist else "—")
        c9.metric("Zero %",   f"{res.get('zero_pct',0):.1f}%")
        c10.metric("Unique",  f"{res.get('n_unique',0):,}")

        if dist:
            st.markdown(f"**Shape:** `{dist.get('shape','—')}`  |  "
                        f"**Normal:** `{'Yes' if dist.get('is_normal') else 'No'}`  |  "
                        f"**Log-Normal:** `{'Yes' if dist.get('is_lognormal') else 'No'}`")

        # ── Percentile table ──────────────────────────────────────────────────
        if dist:
            pcts = {k: round(dist.get(k,0),4) for k in
                    ["p1","p5","p10","p25","p50","p75","p90","p95","p99"]}
            st.dataframe(pd.DataFrame([pcts]), use_container_width=True,
                         hide_index=True)

        # ── Plots ─────────────────────────────────────────────────────────────
        st.plotly_chart(fig_histogram_kde(
            res.get("plot_sample",[]), selected,
            mean=dist.get("mean"), median=dist.get("median")
        ), use_container_width=True)

        # Target rate
        if target_col and biv_f.get("bivariate_table"):
            pct_used = biv_f.get("pct_complete_cases", 100)
            if pct_used < 100:
                st.markdown(f'<div class="warn-box">⚠️ Target rate computed on {pct_used:.0f}% complete cases '
                            f'(rows where both <code>{selected}</code> and target are non-null)</div>',
                            unsafe_allow_html=True)
            gm = float(R["df"][target_col].mean()) if len(R.get("df",pd.DataFrame())) else None
            st.plotly_chart(fig_target_rate_bins(biv_f["bivariate_table"], selected, gm),
                            use_container_width=True)

    elif dtype in ("Categorical", "ID-like"):
        # ── Stats ─────────────────────────────────────────────────────────────
        c1, c2, c3, c4, c5 = st.columns(5)
        c1.metric("Hit Rate %", f"{res.get('hit_rate_pct',0):.1f}%")
        c2.metric("Missing %",  f"{res.get('missing_pct',0):.1f}%")
        c3.metric("Unique",     f"{res.get('n_unique',0):,}")
        c4.metric("Entropy",    f"{res.get('entropy',0):.3f}")
        c5.metric("HHI",        f"{res.get('hhi',0):.3f}")

        # ── Hit rate table ────────────────────────────────────────────────────
        hr = res.get("hit_rate_table")
        if hr is not None and len(hr):
            st.markdown('<p class="section-header">Category Hit Rate</p>',
                        unsafe_allow_html=True)
            st.dataframe(hr, use_container_width=True, height=300)
            st.plotly_chart(fig_category_bar(hr, selected),
                            use_container_width=True)

        # Fuzzy pairs
        fp = res.get("fuzzy_pairs", [])
        if fp:
            st.warning(f"⚠️ {len(fp)} near-duplicate category names detected")
            st.dataframe(pd.DataFrame(fp), use_container_width=True)

        # Target rate
        if target_col and biv_f.get("bivariate_table"):
            pct_used = biv_f.get("pct_complete_cases", 100)
            if pct_used < 100:
                st.markdown(f'<div class="warn-box">⚠️ Target rate computed on {pct_used:.0f}% complete cases</div>',
                            unsafe_allow_html=True)
            gm = float(R["df"][target_col].mean()) if len(R.get("df",pd.DataFrame())) else None
            st.plotly_chart(fig_target_rate_cat(biv_f["bivariate_table"], selected, gm),
                            use_container_width=True)

    else:
        st.info(f"Feature type: **{dtype}** — basic stats shown in Tab 1.")
        st.metric("Missing %", f"{res.get('missing_pct',0):.1f}%")
        st.metric("Hit Rate %",f"{res.get('hit_rate_pct',0):.1f}%")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — OUTLIERS
# ══════════════════════════════════════════════════════════════════════════════
def tab_outliers(R: dict):
    col_results = R.get("col_results", {})
    cfg         = R.get("cfg", {})

    num_cols = [c for c,r in col_results.items() if r.get("dtype") == "Numeric"]
    cat_cols = [c for c,r in col_results.items() if r.get("dtype") == "Categorical"]
    id_cols  = [c for c,r in col_results.items() if r.get("dtype") == "ID-like"]

    # ── Numeric ───────────────────────────────────────────────────────────────
    st.markdown('<p class="section-header">Numeric Outliers — Interactive IQR</p>',
                unsafe_allow_html=True)

    if num_cols:
        sel_num = st.selectbox("Select numeric feature", num_cols)
        res     = col_results[sel_num]
        outl    = res.get("outlier", {})
        sample  = res.get("plot_sample", [])

        arr = np.array([x for x in sample if x is not None and np.isfinite(x)])

        st.markdown(
            "**Adjust the Lower and Upper percentile bounds** to define what counts as an outlier. "
            "The box plot and outlier count update live."
        )

        c_sl1, c_sl2 = st.columns(2)
        q_lo = c_sl1.slider(
            "Lower percentile (Q1)",
            min_value=1, max_value=49, value=25, step=1,
            help="Values below this percentile are flagged as low outliers. "
                 "Standard IQR = 25th percentile.",
            key="q_lo"
        )
        q_hi = c_sl2.slider(
            "Upper percentile (Q3)",
            min_value=51, max_value=99, value=75, step=1,
            help="Values above this percentile are flagged as high outliers. "
                 "Standard IQR = 75th percentile.",
            key="q_hi"
        )

        # Recompute from sample using the chosen percentiles
        if len(arr) > 0:
            p_lo_val = float(np.percentile(arr, q_lo))
            p_hi_val = float(np.percentile(arr, q_hi))
            iqr_live = p_hi_val - p_lo_val

            # IQR fences (k=1.5 of the selected IQR — or just the raw percentile cut)
            # We use the percentile directly as the cut: below P_lo or above P_hi = outlier
            out_mask  = (arr < p_lo_val) | (arr > p_hi_val)
            out_count = int(out_mask.sum())
            out_pct   = round(out_count / len(arr) * 100, 2)
        else:
            p_lo_val = p_hi_val = iqr_live = 0.0
            out_count = out_pct = 0

        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric(f"P{q_lo} (Lower)",  f"{p_lo_val:.4g}")
        m2.metric(f"P{q_hi} (Upper)",  f"{p_hi_val:.4g}")
        m3.metric("Range (IQR equiv)", f"{iqr_live:.4g}")
        m4.metric("P1",  f"{float(np.percentile(arr, 1)):.4g}"  if len(arr) else "—")
        m5.metric("P99", f"{float(np.percentile(arr, 99)):.4g}" if len(arr) else "—")

        flag_col = st.columns(3)
        flag_col[0].metric(f"Outliers (below P{q_lo} or above P{q_hi})",
                           f"{out_count:,}  ({out_pct:.1f}%)")
        flag_col[1].metric("Z-score Outliers (|z|>3)",
                           f"{outl.get('z_count',0):,}  ({outl.get('z_pct',0):.1f}%)")
        flag_col[2].metric("IQR multiplier (fixed 1.5× of selected range)",
                           f"{p_lo_val:.3g}  /  {p_hi_val:.3g}")

        if out_pct > 5:
            st.error(f"❌ {out_pct:.1f}% of values fall outside P{q_lo}–P{q_hi} bounds. "
                     f"Consider capping at P99 = {float(np.percentile(arr,99)):.4g}" if len(arr) else "")
        elif out_pct > 1:
            st.warning(f"⚠️ Moderate outlier rate ({out_pct:.1f}%) outside P{q_lo}–P{q_hi}")
        else:
            st.success(f"✅ Low outlier rate ({out_pct:.1f}%) outside P{q_lo}–P{q_hi}")

        st.plotly_chart(fig_boxplot(sample, sel_num, p_lo_val, p_hi_val),
                        use_container_width=True)

        # Summary table for all numeric cols
        st.markdown('<p class="section-header">All Numeric Outlier Summary</p>',
                    unsafe_allow_html=True)
        rows = []
        for c in num_cols:
            o = col_results[c].get("outlier", {})
            rows.append({
                "Feature":        c,
                "Q1":             o.get("q1","—"),
                "Q3":             o.get("q3","—"),
                "IQR":            o.get("iqr","—"),
                "Fence Lo":       o.get("fence_lo","—"),
                "Fence Hi":       o.get("fence_hi","—"),
                "IQR Outliers":   o.get("iqr_count",0),
                "IQR %":          o.get("iqr_pct",0),
                "Z Outliers":     o.get("z_count",0),
                "Z %":            o.get("z_pct",0),
                "P99 Cap":        o.get("p99_cap","—"),
            })
        st.dataframe(pd.DataFrame(rows), use_container_width=True)
    else:
        st.info("No numeric features found.")

    # ── Categorical ───────────────────────────────────────────────────────────
    st.markdown('<p class="section-header">Categorical Outliers — Rare Categories</p>',
                unsafe_allow_html=True)
    if cat_cols:
        sel_cat = st.selectbox("Select categorical feature", cat_cols, key="cat_outl")
        res_c   = col_results[sel_cat]
        rare    = res_c.get("rare_categories", pd.DataFrame())
        fp      = res_c.get("fuzzy_pairs", [])

        c_a, c_b = st.columns(2)
        with c_a:
            st.markdown("**Rare Categories (< 1% hit rate)**")
            if len(rare):
                st.dataframe(rare, use_container_width=True)
            else:
                st.success("✅ No rare categories")
        with c_b:
            st.markdown("**Near-Duplicate Category Names**")
            if fp:
                st.dataframe(pd.DataFrame(fp), use_container_width=True)
            else:
                st.success("✅ No near-duplicates detected")
    else:
        st.info("No categorical features found.")

    # ── ID-like syntax ────────────────────────────────────────────────────────
    if id_cols:
        st.markdown('<p class="section-header">ID-like Columns — Syntax Consistency</p>',
                    unsafe_allow_html=True)
        for id_col in id_cols:
            syn = col_results[id_col].get("id_syntax", {})
            if not syn: continue
            with st.expander(f"🔑 {id_col}"):
                c1, c2, c3 = st.columns(3)
                c1.metric("Detected Pattern", syn.get("template","?"))
                c2.metric("Pattern Match",    f"{syn.get('pattern_pct',0):.1f}%")
                c3.metric("Duplicate IDs",    syn.get("dup_ids", 0))

                ws = syn.get("whitespace_count", 0)
                if ws: st.warning(f"⚠️ {ws} values with leading/trailing whitespace")

                viols = syn.get("violations", [])
                if viols:
                    st.error(f"❌ {syn.get('violation_count',0)} non-conforming values (sample below):")
                    st.code("\n".join(str(v) for v in viols[:20]))
                else:
                    st.success("✅ All values match detected pattern")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — MISSING VALUES
# ══════════════════════════════════════════════════════════════════════════════
def tab_missing(R: dict):
    col_results = R.get("col_results", {})
    miss_adv    = R.get("missing_adv", {})

    # Missing bar chart
    st.plotly_chart(fig_missing_bar(col_results), use_container_width=True)

    # Table
    st.markdown('<p class="section-header">Missing Value Detail</p>',
                unsafe_allow_html=True)
    rows = []
    for col, res in col_results.items():
        mp = res.get("missing_pct", 0)
        rows.append({
            "Feature":       col,
            "Type":          res.get("dtype","—"),
            "Missing Count": res.get("missing_count", 0),
            "Missing %":     mp,
            "Hit Rate %":    res.get("hit_rate_pct", 100),
            "Informative?":  "⚠️ Yes" if mp > 5 else ("✅ Low" if mp > 0 else "✅ None"),
            "Suggested":     ("Create missing indicator + impute"
                              if mp > 20 else
                              "Median/mode impute" if mp > 0 else "—"),
        })
    miss_df = pd.DataFrame(rows).sort_values("Missing %", ascending=False)
    st.dataframe(miss_df, use_container_width=True)
    _dl_csv(miss_df, "Missing Analysis", "missing_analysis.csv")

    # Co-missing pairs
    co = miss_adv.get("co_pairs", [])
    if co:
        st.markdown('<p class="section-header">Co-Missing Pairs (|corr| > 0.3)</p>',
                    unsafe_allow_html=True)
        st.dataframe(pd.DataFrame(co), use_container_width=True)

    # MCAR hints
    mcar = miss_adv.get("mcar_hints", {})
    if mcar:
        st.markdown('<p class="section-header">MAR / MNAR Hints</p>',
                    unsafe_allow_html=True)
        rows_m = [{"Feature": col, "t-test p": v["p"], "Note": v["hint"]}
                  for col, v in mcar.items()]
        st.dataframe(pd.DataFrame(rows_m), use_container_width=True)
        st.caption("p < 0.05 → distribution in missing rows differs from complete rows "
                   "→ missingness is not random (MAR/MNAR)")

    cols_miss = miss_adv.get("cols_with_missing", [])
    if not cols_miss:
        st.success("✅ No missing values detected in any feature")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — CORRELATIONS
# ══════════════════════════════════════════════════════════════════════════════
def tab_correlations(R: dict):
    corr = R.get("correlations", {})
    cfg  = R.get("cfg", {})

    # Pearson heatmap (sampled)
    ph = corr.get("pearson_heatmap", pd.DataFrame())
    if len(ph):
        st.markdown(f'<p class="section-header">Pearson Heatmap (sample n={cfg.get("corr_sample_size",150000):,})</p>',
                    unsafe_allow_html=True)
        st.plotly_chart(fig_correlation_heatmap(ph, "Pearson Correlation (Sampled)"),
                        use_container_width=True)

    # Full-data Pearson table
    pf = corr.get("pearson_full", pd.DataFrame())
    if len(pf):
        st.markdown('<p class="section-header">Correlation Scores — Full Data (all pairs)</p>',
                    unsafe_allow_html=True)
        threshold = cfg.get("corr_threshold", 0.8)
        show_all = st.checkbox("Show all pairs (not just high-corr)", value=False)
        df_show = pf if show_all else pf[pf["|r|"] >= threshold]
        st.dataframe(df_show, use_container_width=True, height=350)
        _dl_csv(pf, "Pearson Full Data", "pearson_full.csv")

    # High-corr pairs
    hcp = corr.get("high_corr_pairs", [])
    if hcp:
        st.warning(f"⚠️ {len(hcp)} feature pairs with |r| ≥ {cfg.get('corr_threshold', 0.8)} "
                   f"— multicollinearity risk")

    # VIF
    vif = corr.get("vif", pd.DataFrame())
    if len(vif):
        st.markdown('<p class="section-header">VIF — Variance Inflation Factor</p>',
                    unsafe_allow_html=True)
        st.dataframe(vif, use_container_width=True)
        st.caption("VIF > 10 = severe multicollinearity  |  VIF > 5 = moderate")

    # Cramér V
    cv = corr.get("cramerv", pd.DataFrame())
    if len(cv):
        st.markdown('<p class="section-header">Cramér V — Categorical Pair Associations</p>',
                    unsafe_allow_html=True)
        st.plotly_chart(fig_cramerv_heatmap(cv), use_container_width=True)
        st.caption("Cramér V ≈ 0 = no association  |  ≈ 1 = perfect association")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 6 — FEATURE SCORECARD
# ══════════════════════════════════════════════════════════════════════════════
def tab_scorecard(R: dict):
    sc = R.get("scorecard", pd.DataFrame())
    if len(sc) == 0:
        st.info("Scorecard not computed (STEP_SCORECARD=False)")
        return

    st.markdown("""
    **How to read this:** Each feature is scored across 5 dimensions.
    - ✅ **Clean** — safe to use as-is
    - ⚠️ **Review** — needs attention before modeling
    - ❌ **Fix First** — serious issue, do not use without fixing
    """)

    # Filter
    f1, f2 = st.columns([2, 1])
    score_filter = f1.multiselect(
        "Filter by Score",
        ["✅ Clean", "⚠️ Review", "❌ Fix First"],
        default=["✅ Clean", "⚠️ Review", "❌ Fix First"],
    )
    search = f2.text_input("Search feature name", "")

    df_show = sc.copy()
    if score_filter:
        df_show = df_show[df_show["Score"].isin(score_filter)]
    if search:
        df_show = df_show[df_show["Feature"].str.contains(search, case=False)]

    # Summary KPIs
    k1, k2, k3 = st.columns(3)
    k1.metric("❌ Fix First", int((sc["Score"] == "❌ Fix First").sum()))
    k2.metric("⚠️ Review",   int((sc["Score"] == "⚠️ Review").sum()))
    k3.metric("✅ Clean",    int((sc["Score"] == "✅ Clean").sum()))

    st.markdown("---")

    # Scorecard table with color
    def _color_score(val):
        if "Fix"    in str(val): return "color: #F74F4F; font-weight: 600"
        if "Review" in str(val): return "color: #F7D94F; font-weight: 600"
        if "Clean"  in str(val): return "color: #4FC97E; font-weight: 600"
        return ""

    styled = df_show.style.applymap(_color_score, subset=["Score"])
    st.dataframe(styled, use_container_width=True, height=500)

    _dl_csv(sc, "Feature Scorecard", "feature_scorecard.csv")

    # Scoring legend
    with st.expander("📖 Scoring Rules"):
        st.markdown("""
| Dimension | 0 pts | 1 pt | 2 pts | 3 pts |
|---|---|---|---|---|
| **Missing** | 0% | 1–5% | 5–20% | >20% |
| **Skew** | \|skew\| < 0.5 | 0.5–1.5 | > 1.5 | — |
| **Outliers** | IQR% < 1% | 1–5% | > 5% | — |
| **Corr Risk** | max\|r\| < 0.5 | 0.5–0.8 | > 0.8 | — |
| **Flags** | None | — | +2 per bad flag | — |

**Total → RAG:** 0–1 = ✅ Clean | 2–4 = ⚠️ Review | 5+ = ❌ Fix First
        """)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 7 — RECOMMENDATIONS
# ══════════════════════════════════════════════════════════════════════════════
def tab_recommendations(R: dict):
    recs = R.get("recommendations", [])
    if not recs:
        st.info("No recommendations generated.")
        return

    # Filters
    f1, f2, f3 = st.columns(3)
    prio_filter = f1.multiselect(
        "Priority", ["❌ Fix First", "⚠️ Review", "✅ Clean"],
        default=["❌ Fix First", "⚠️ Review"],
    )
    type_filter = f2.multiselect(
        "Type", list({r["Type"] for r in recs}),
        default=list({r["Type"] for r in recs}),
    )
    search_r = f3.text_input("Search feature", "")

    filtered = [r for r in recs
                if r["Priority"] in prio_filter
                and r["Type"] in type_filter
                and (not search_r or search_r.lower() in r["Feature"].lower())]

    st.caption(f"Showing {len(filtered)} of {len(recs)} features")
    st.markdown("---")

    for rec in filtered:
        p = rec["Priority"]
        css = "critical" if "Fix" in p else "review" if "Review" in p else "clean"
        icon = "🔢" if rec["Type"]=="Numeric" else "🏷️" if rec["Type"]=="Categorical" else "🔑"

        with st.expander(f"{p}  {icon} **{rec['Feature']}** ({rec['Type']})"):
            for f, a, reason in zip(rec["Findings"], rec["Actions"], rec["Reasons"]):
                c1, c2 = st.columns([1, 1])
                c1.markdown(f"**Finding:** {f}")
                c1.markdown(f"**Action:** `{a}`")
                c2.markdown(f"*Why:* {reason}")
                st.markdown("---")

    # Pipeline code
    st.markdown('<p class="section-header">Auto-Generated sklearn Pipeline Skeleton</p>',
                unsafe_allow_html=True)
    col_results = R.get("col_results", {})
    dtype_map   = R.get("dtype_map", {})
    num_cols = [c for c,d in dtype_map.items() if d == "Numeric"][:10]
    cat_cols = [c for c,d in dtype_map.items() if d == "Categorical"][:10]

    code = f"""from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OrdinalEncoder
from sklearn.impute import SimpleImputer

numeric_features     = {num_cols}
categorical_features = {cat_cols}

numeric_transformer = Pipeline([
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler',  StandardScaler()),
])

categorical_transformer = Pipeline([
    ('imputer', SimpleImputer(strategy='constant', fill_value='Unknown')),
    ('encoder', OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)),
])

preprocessor = ColumnTransformer([
    ('num', numeric_transformer, numeric_features),
    ('cat', categorical_transformer, categorical_features),
])

# Then: pipeline = Pipeline([('preprocessor', preprocessor), ('model', YourModel())])
"""
    st.code(code, language="python")

    # Download recs CSV
    rows = []
    for r in recs:
        for f, a, rs in zip(r["Findings"], r["Actions"], r["Reasons"]):
            rows.append({"Feature": r["Feature"], "Priority": r["Priority"],
                         "Type": r["Type"], "Finding": f, "Action": a, "Reason": rs})
    if rows:
        _dl_csv(pd.DataFrame(rows), "Recommendations", "recommendations.csv")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
def main():
    R = _get()
    if not R:
        st.warning("⚠️ No EDA results found. Please run `launch_app(results, config)` from your notebook.")
        st.code("""
# In your Jupyter notebook:
import pandas as pd
from eda_toolkit.launch import run_eda, launch_app

df = pd.read_csv("your_data.csv")

config = {
    "target_col":      "Claim_Flag",   # or None
    "groupby_col":     "Policy_Year",
    "agg_config": {
        "Policy_Number": ["nunique"],
        "Claim_Amount":  ["sum", "mean"],
        "Premium":       ["sum", "mean"],
    },
    "detailed_report": True,
}

results = run_eda(df, config)
launch_app(results, config)
        """, language="python")
        return

    _sidebar(R)

    tabs = st.tabs([
        "📋 Data Summary",
        "🔬 Feature Analysis",
        "🚨 Outliers",
        "❓ Missing Values",
        "🔗 Correlations",
        "🎯 Feature Scorecard",
        "✅ Recommendations",
    ])

    with tabs[0]: tab_summary(R)
    with tabs[1]: tab_features(R)
    with tabs[2]: tab_outliers(R)
    with tabs[3]: tab_missing(R)
    with tabs[4]: tab_correlations(R)
    with tabs[5]: tab_scorecard(R)
    with tabs[6]: tab_recommendations(R)


if __name__ == "__main__":
    main()
