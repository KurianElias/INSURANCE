"""
charts.py — 7 plot types only. No extras.
  1. fig_histogram_kde       numeric distribution
  2. fig_boxplot             numeric outliers + IQR fences
  3. fig_target_rate_bins    numeric vs target
  4. fig_category_bar        categorical hit rate
  5. fig_target_rate_cat     categorical vs target
  6. fig_missing_bar         dataset missing %
  7. fig_correlation_heatmap Pearson / Cramer V heatmap
  +  fig_type_donut          dataset type breakdown (mini)
"""

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from scipy.stats import gaussian_kde

C = {
    "blue":    "#4F8EF7", "orange":  "#F7934F",
    "green":   "#4FC97E", "yellow":  "#F7D94F",
    "red":     "#F74F4F", "purple":  "#A78BFA",
    "bg":      "#0e1117", "surface": "#1a1d27",
    "border":  "#2a2d3e", "text":    "#e0e4ef", "muted": "#6b7280",
}
_BASE = dict(
    paper_bgcolor=C["surface"], plot_bgcolor=C["surface"],
    font=dict(family="IBM Plex Mono, monospace", color=C["text"], size=11),
    margin=dict(l=55, r=25, t=40, b=40),
)


def fig_histogram_kde(sample, col, mean, median):
    arr = np.array(sample, dtype=float); arr = arr[np.isfinite(arr)]
    if not len(arr): return go.Figure()
    fig = go.Figure()
    fig.add_trace(go.Histogram(x=arr, nbinsx=60, name="Freq",
        marker_color=C["blue"], opacity=0.65, histnorm="probability density"))
    try:
        kde = gaussian_kde(arr, bw_method="scott")
        xr  = np.linspace(arr.min(), arr.max(), 400)
        fig.add_trace(go.Scatter(x=xr, y=kde(xr), mode="lines", name="KDE",
            line=dict(color=C["orange"], width=2.5)))
    except Exception: pass
    fig.add_vline(x=mean,   line_dash="dash", line_color=C["green"],
        annotation_text=f"μ {mean:.2f}", annotation_font_color=C["green"])
    fig.add_vline(x=median, line_dash="dot",  line_color=C["yellow"],
        annotation_text=f"M {median:.2f}", annotation_font_color=C["yellow"])
    d = _BASE.copy(); d.update(title=f"{col} — Distribution", height=310)
    fig.update_layout(**d, legend=dict(orientation="h", y=1.08))
    fig.update_xaxes(gridcolor=C["border"], zeroline=False)
    fig.update_yaxes(gridcolor=C["border"], title="Density")
    return fig


def fig_boxplot(sample, col, fence_lo, fence_hi):
    arr = np.array(sample, dtype=float); arr = arr[np.isfinite(arr)]
    if not len(arr): return go.Figure()
    fig = go.Figure()
    fig.add_trace(go.Box(x=arr, name=col, orientation="h",
        marker_color=C["blue"], line_color=C["blue"],
        fillcolor=C["blue"]+"28", boxmean="sd",
        boxpoints="suspectedoutliers",
        marker=dict(outliercolor=C["red"], size=3)))
    for x, label, col_line in [(fence_lo, f"Lo {fence_lo:.2f}", C["yellow"]),
                                 (fence_hi, f"Hi {fence_hi:.2f}", C["red"])]:
        fig.add_vline(x=x, line_dash="dash", line_color=col_line,
            annotation_text=label, annotation_font_color=col_line,
            annotation_position="top")
    d = _BASE.copy(); d.update(title=f"{col} — Box Plot (IQR fences)", height=200)
    fig.update_layout(**d, showlegend=False)
    fig.update_xaxes(gridcolor=C["border"])
    fig.update_yaxes(showgrid=False, showticklabels=False)
    return fig


def fig_target_rate_bins(biv_table, col, grand_mean):
    if not biv_table: return go.Figure()
    df = pd.DataFrame(biv_table)
    if "Bin" not in df.columns: return go.Figure()
    rate_col = "Mean Target" if "Mean Target" in df.columns else df.columns[1]
    yv = (df[rate_col] * 100).round(2)
    colors = [C["red"] if v > grand_mean*100*1.1 else
              (C["green"] if v < grand_mean*100*0.9 else C["blue"]) for v in yv]
    fig = go.Figure()
    fig.add_trace(go.Bar(x=df["Bin"].astype(str), y=yv, name="Target %",
        marker_color=colors, opacity=0.85))
    fig.add_hline(y=grand_mean*100, line_dash="dash", line_color=C["yellow"],
        annotation_text=f"Overall {grand_mean*100:.1f}%", annotation_font_color=C["yellow"])
    d = _BASE.copy(); d.update(title=f"{col} — Target Rate per Bin ⚠ complete cases only", height=300)
    fig.update_layout(**d, showlegend=False)
    fig.update_xaxes(gridcolor=C["border"], tickangle=-30)
    fig.update_yaxes(gridcolor=C["border"], title="Target %")
    return fig


def fig_category_bar(hr_table, col):
    if hr_table is None or not len(hr_table): return go.Figure()
    df = hr_table.head(20).copy().sort_values("Hit Rate %", ascending=True)
    colors = [C["red"] if "RARE" in str(f) else
              (C["orange"] if "DOMINANT" in str(f) else C["blue"])
              for f in df.get("Flag", [""] * len(df))]
    fig = go.Figure()
    fig.add_trace(go.Bar(x=df["Hit Rate %"], y=df["Category"].astype(str),
        orientation="h", marker_color=colors, opacity=0.85,
        text=df["Hit Rate %"].apply(lambda v: f"{v:.1f}%"), textposition="outside"))
    d = _BASE.copy(); d.update(title=f"{col} — Hit Rate % per Category (top 20)",
        height=max(280, len(df)*24))
    fig.update_layout(**d, showlegend=False)
    fig.update_xaxes(gridcolor=C["border"], title="Hit Rate %")
    fig.update_yaxes(gridcolor=C["border"])
    return fig


def fig_target_rate_cat(biv_table, col, grand_mean):
    if not biv_table: return go.Figure()
    df = pd.DataFrame(biv_table)
    if "Category" not in df.columns: return go.Figure()
    rate_col = "Mean Target" if "Mean Target" in df.columns else df.columns[1]
    df = df.sort_values(rate_col, ascending=True).head(20)
    yv = (df[rate_col] * 100).round(2)
    colors = [C["red"] if v > grand_mean*100*1.1 else
              (C["green"] if v < grand_mean*100*0.9 else C["blue"]) for v in yv]
    fig = go.Figure()
    fig.add_trace(go.Bar(x=yv, y=df["Category"].astype(str),
        orientation="h", marker_color=colors, opacity=0.85,
        text=yv.apply(lambda v: f"{v:.1f}%"), textposition="outside"))
    fig.add_vline(x=grand_mean*100, line_dash="dash", line_color=C["yellow"],
        annotation_text=f"Overall {grand_mean*100:.1f}%", annotation_font_color=C["yellow"])
    d = _BASE.copy(); d.update(title=f"{col} — Target Rate per Category ⚠ complete cases only", height=300)
    fig.update_layout(**d, showlegend=False)
    fig.update_xaxes(gridcolor=C["border"], title="Target %")
    fig.update_yaxes(gridcolor=C["border"])
    return fig


def fig_missing_bar(col_results):
    rows = [(c, r.get("missing_pct", 0)) for c, r in col_results.items() if r.get("missing_pct",0) > 0]
    if not rows: return go.Figure()
    rows = sorted(rows, key=lambda x: x[1], reverse=True)
    cols_l = [r[0] for r in rows]; pcts = [r[1] for r in rows]
    colors = [C["red"] if p > 20 else (C["orange"] if p > 5 else C["yellow"]) for p in pcts]
    fig = go.Figure()
    fig.add_trace(go.Bar(x=cols_l, y=pcts, marker_color=colors, opacity=0.85,
        text=[f"{p:.1f}%" for p in pcts], textposition="outside"))
    fig.add_hline(y=5,  line_dash="dot", line_color=C["orange"],
        annotation_text="5%",  annotation_font_color=C["orange"])
    fig.add_hline(y=20, line_dash="dot", line_color=C["red"],
        annotation_text="20%", annotation_font_color=C["red"])
    d = _BASE.copy(); d.update(title="Missing Values per Feature", height=320)
    fig.update_layout(**d, showlegend=False)
    fig.update_xaxes(gridcolor=C["border"], tickangle=-35)
    fig.update_yaxes(gridcolor=C["border"], title="Missing %")
    return fig


def fig_correlation_heatmap(corr_df, title="Pearson Correlation (sampled)"):
    if corr_df is None or not len(corr_df): return go.Figure()
    mat  = corr_df.values.astype(float); cols = list(corr_df.columns)
    texts = [[f"{mat[i,j]:.2f}" for j in range(len(cols))] for i in range(len(cols))]
    fig = go.Figure(go.Heatmap(z=mat, x=cols, y=cols, text=texts,
        texttemplate="%{text}", colorscale="RdBu", zmid=0, zmin=-1, zmax=1,
        colorbar=dict(title="r", thickness=12)))
    n = len(cols)
    d = _BASE.copy(); d.update(title=title, height=max(350, n*36))
    fig.update_layout(**d)
    fig.update_xaxes(tickangle=-40)
    return fig


def fig_type_donut(dtype_map):
    from collections import Counter
    counts = Counter(dtype_map.values())
    cmap = {"Numeric": C["blue"], "Categorical": C["orange"],
            "Boolean": C["green"], "Date": C["purple"], "ID-like": C["yellow"]}
    labels = list(counts.keys()); values = list(counts.values())
    colors = [cmap.get(l, C["muted"]) for l in labels]
    fig = go.Figure(go.Pie(labels=labels, values=values, hole=0.55,
        marker_colors=colors, textinfo="label+value", textfont_size=12))
    d = _BASE.copy(); d.update(title="Feature Types", height=250,
        margin=dict(l=10,r=10,t=38,b=10))
    fig.update_layout(**d, showlegend=False)
    return fig
