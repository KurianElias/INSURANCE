"""
launch.py — Insurance EDA Toolkit v4

FULL WORKFLOW:
─────────────
    from eda_toolkit import inspect, run_eda, launch_app

    plan = inspect(df, target_col="Claim_Flag")
    plan.fix(Policy_Year="Categorical")     # override wrong detections
    plan.confirm()
    df_clean = plan.apply_to_df()           # cast + drop constants/unknowns

    # Optional: toggle expensive sections off to save time
    plan.set_sections(correlations=True, category_quality=True,
                      scorecard=True, target_analysis=True)

    # Optional: define key columns for overview stats
    plan.set_key_stats(
        key_cols    = ["Policy_Number"],            # count / unique / dup rate
        composite_keys = [["Policy_Number","Eff_Date"]]  # concat + check uniqueness
    )

    # Optional: define a second dataframe for comparison
    plan.set_comparison(
        df          = df_renewals,
        label_a     = "New Business",
        label_b     = "Renewals",
        groupby_col = "Region",
        agg_cols    = ["Premium","Claim_Flag","Exposure"],
    )

    results = run_eda(df_clean, plan)
    launch_app(results)
"""

import sys, os, pickle, subprocess, threading, time, webbrowser
from pathlib import Path
import pandas as pd
import numpy as np

_DIR = Path(__file__).parent
sys.path.insert(0, str(_DIR))

from eda_engine import detect_type, run_eda as _run_eda

VALID_TYPES = {"Numeric","Categorical","Boolean","Date","ID-like","Unknown","Constant"}

_ICON = {"Numeric":"🔢","Categorical":"🏷️","Boolean":"☑️","Date":"📅",
         "ID-like":"🔑","Unknown":"❓","Constant":"🔒"}

_MEANING = {
    "Numeric":     "Continuous number — histogram, stats, IQR outlier check",
    "Categorical": "Discrete labels — frequency table, fuzzy duplicate check",
    "Boolean":     "Binary flag (0/1) — treated as Numeric",
    "Date":        "Date/time — extract year, month, quarter for modelling",
    "ID-like":     "Identifier — too many unique values, excluded from analysis",
    "Unknown":     "Entirely null or unreadable — excluded from analysis",
    "Constant":    "Zero-variance column — single unique value, drop before modelling",
}

_CAST_MAP = {"Numeric":"float64","Boolean":"float64","Categorical":"category",
             "Date":"datetime","ID-like":None,"Unknown":None,"Constant":None}


def _sample_vals(s, n=5):
    vals = s.dropna().head(n).tolist()
    return ", ".join(str(v)[:22] for v in vals) if vals else "—"


def _col_warnings(col, s, detected):
    warns = []; nu = int(s.dropna().nunique()); mp = float(s.isna().mean()*100)
    if mp == 100: warns.append("ALL NULL — will be excluded")
    elif mp > 20: warns.append(f"{mp:.0f}% missing")
    if detected == "Constant":
        warns.append("Zero-variance — single unique value, useless for modelling")
    if detected == "Numeric":
        try:
            clean = s.dropna().astype(float)
            if nu<=150 and ((clean>=1900)&(clean<=2100)).mean()>0.90:
                warns.append("Looks like a YEAR — consider 'Date' or 'Categorical'")
        except Exception: pass
        if 2 < nu <= 8: warns.append(f"Only {nu} unique values — consider 'Categorical'")
    if detected == "Categorical":
        if nu > 100: warns.append(f"High cardinality ({nu} unique) — is this an ID column?")
        try:
            sample = s.dropna().astype(str).head(50)
            dl = sum(1 for v in sample if any(sep in v for sep in ["-","/"]) and any(c.isdigit() for c in v))
            if dl / max(len(sample),1) > 0.7: warns.append("Values look like dates — consider 'Date'")
        except Exception: pass
    if detected == "ID-like": warns.append("Will be excluded from EDA analysis")
    return warns


# ─────────────────────────────────────────────────────────────────────────────
# InspectPlan
# ─────────────────────────────────────────────────────────────────────────────

class InspectPlan:
    """
    Holds confirmed column types + all EDA configuration.

    Methods
    -------
    plan.fix(**kwargs)              — override auto-detected types
    plan.confirm()                  — print confirmed table, mark ready
    plan.apply_to_df(...)           — cast df to confirmed types, drop constants
    plan.set_sections(...)          — toggle which analysis sections run
    plan.set_key_stats(...)         — define key cols + composite keys for overview
    plan.set_comparison(...)        — define second df for side-by-side comparison
    plan.set(key, value)            — set any raw config key
    """

    def __init__(self, df, dtype_map, config):
        self._df        = df
        self._dtype_map = dict(dtype_map)
        self._overrides = {}
        self._config    = dict(config)
        self._confirmed = False

    # ── fix ───────────────────────────────────────────────────────────────────
    def fix(self, **kwargs):
        """Override auto-detected types. Valid: Numeric Categorical Boolean Date ID-like Unknown Constant"""
        for col, new_type in kwargs.items():
            if col not in self._dtype_map:
                print(f"  ⚠️  '{col}' not found. Available: {list(self._dtype_map.keys())[:8]}...")
                continue
            if new_type not in VALID_TYPES:
                print(f"  ⚠️  '{new_type}' invalid. Options: {sorted(VALID_TYPES)}")
                continue
            old = self._dtype_map[col]; self._dtype_map[col] = new_type; self._overrides[col] = new_type
            print(f"  ✔  {col}: {old} → {new_type}")
        self._confirmed = False
        if kwargs: print("\n  Call plan.confirm() to review and proceed.")
        return self

    # ── set ───────────────────────────────────────────────────────────────────
    def set(self, key, value):
        """Set any raw config key."""
        self._config[key] = value
        return self

    # ── set_sections ──────────────────────────────────────────────────────────
    def set_sections(self, correlations=True, category_quality=True,
                     scorecard=True, target_analysis=True):
        """
        Toggle which analysis sections run. Disable to save time on large datasets.

        Parameters
        ----------
        correlations     : bool  (default True)
        category_quality : bool  (default True)  — fuzzy category matching
        scorecard        : bool  (default True)  — quality scorecard + recommendations
        target_analysis  : bool  (default True)  — feature vs target correlations
        """
        self._config["sections"] = {
            "correlations":     correlations,
            "category_quality": category_quality,
            "scorecard":        scorecard,
            "target_analysis":  target_analysis,
        }
        on  = [k for k,v in self._config["sections"].items() if v]
        off = [k for k,v in self._config["sections"].items() if not v]
        print(f"  ✔  Sections ON : {', '.join(on) or 'none'}")
        if off: print(f"  ⏭  Sections OFF: {', '.join(off)}")
        return self

    # ── set_corr_options ──────────────────────────────────────────────────────
    def set_corr_options(self, corr_sample=100_000, chi_sample=20_000,
                         chi_max_cardinality=10_000, corr_threshold=0.75):
        """
        Tune performance and sensitivity of the Correlations section.

        Parameters
        ----------
        corr_sample          : int    Rows sampled for Pearson matrix (default 100,000).
                                      Increase for more accuracy, lower to save time.
        chi_sample           : int    Rows sampled for chi-square tests (default 20,000).
                                      Chi-square is statistically valid at 10k+ rows.
        chi_max_cardinality  : int    Categorical columns with more unique values than
                                      this threshold are SKIPPED in chi-square to avoid
                                      enormous contingency tables (default 10,000).
                                      Raise to 20,000+ if you have near-ID columns you
                                      still want tested.
        corr_threshold       : float  |r| threshold for flagging high Pearson pairs
                                      (default 0.75).

        Examples
        --------
        # Default — fast, suitable for large datasets
        plan.set_corr_options()

        # Increase chi-square cardinality cap for a dataset with many codes
        plan.set_corr_options(chi_max_cardinality=20_000)

        # High-accuracy mode for smaller datasets
        plan.set_corr_options(corr_sample=500_000, chi_sample=100_000)
        """
        self._config["corr_sample"]          = corr_sample
        self._config["chi_sample"]           = chi_sample
        self._config["chi_max_cardinality"]  = chi_max_cardinality
        self._config["corr_threshold"]       = corr_threshold
        print(f"  ✔  Correlation options set:")
        print(f"     Pearson sample        : {corr_sample:,} rows")
        print(f"     Chi-square sample     : {chi_sample:,} rows")
        print(f"     Chi max cardinality   : {chi_max_cardinality:,} unique values (skip above this)")
        print(f"     High-corr threshold   : |r| ≥ {corr_threshold}")
        return self


    def set_key_stats(self, key_cols=None, composite_keys=None):
        """
        Define key columns to show count/unique/duplicate stats on the Overview page.

        Parameters
        ----------
        key_cols       : list[str]       — columns to analyse individually
                         e.g. ["Policy_Number", "Risk_ID"]
        composite_keys : list[list[str]] — groups of columns to concatenate as composite keys
                         e.g. [["Policy_Number","Eff_Date"], ["Risk_ID","Line"]]
        """
        self._config["key_stats"] = {
            "key_cols":       list(key_cols or []),
            "composite_keys": [list(k) for k in (composite_keys or [])],
        }
        print(f"  ✔  Key columns     : {key_cols or []}")
        print(f"  ✔  Composite keys  : {composite_keys or []}")
        return self

    # ── set_comparison ────────────────────────────────────────────────────────
    def set_comparison(self, df, label_a=None, label_b="Dataset B",
                       groupby_col=None, agg_cols=None, agg_config=None):
        """
        Define a second DataFrame to compare side-by-side on the Comparison tab.

        Parameters
        ----------
        df          : pd.DataFrame   — the second dataset to compare against
        label_a     : str            — label for the primary dataset (default: "Primary")
        label_b     : str            — label for the comparison dataset
        groupby_col : str or list    — column(s) to group both datasets by.
                                       Single: "Region"
                                       Multiple: ["Region","Policy_Year"]
        agg_cols    : list[str]      — columns to summarise using default count/mean/median/sum
        agg_config  : dict           — per-column aggregation methods (overrides agg_cols)
                                       e.g. {"Premium": ["sum","mean"],
                                             "Policy_Number": ["count","nunique"],
                                             "Claim_Flag": ["sum","mean"]}

        Examples
        --------
        # Simple — default agg (count/mean/median/sum) on listed columns
        plan.set_comparison(
            df=df_renewals, label_a="New Business", label_b="Renewals",
            groupby_col="Region",
            agg_cols=["Premium","Claim_Flag","Exposure"],
        )

        # Advanced — per-column aggregation methods
        plan.set_comparison(
            df=df_renewals, label_a="New Business", label_b="Renewals",
            groupby_col=["Region","Policy_Year"],
            agg_config={
                "Premium":       ["sum","mean"],
                "Policy_Number": ["count","nunique"],
                "Claim_Flag":    ["sum","mean"],
                "Exposure":      ["sum"],
            },
        )
        """
        # Normalise groupby_col to always be a list internally
        if isinstance(groupby_col, str):
            grp = [groupby_col]
        elif isinstance(groupby_col, list):
            grp = groupby_col
        else:
            grp = [self._config.get("groupby_col","")] if self._config.get("groupby_col") else []

        self._config["comparison"] = {
            "df":         df,
            "label_a":    label_a or "Primary",
            "label_b":    label_b,
            "groupby_col": grp,
            "agg_cols":   list(agg_cols or []),
            "agg_config": dict(agg_config or {}),
        }
        print(f"  ✔  Comparison configured")
        print(f"     Primary   : {label_a or 'Primary'}  ({len(self._df):,} rows)")
        print(f"     Comparison: {label_b}  ({len(df):,} rows)")
        if grp:    print(f"     Group by  : {grp}")
        if agg_config: print(f"     Agg config: {list(agg_config.keys())}")
        elif agg_cols: print(f"     Agg cols  : {agg_cols}")
        return self

    # ── confirm ───────────────────────────────────────────────────────────────
    def confirm(self):
        print("\n" + "═"*72)
        print("  ✅  CONFIRMED COLUMN TYPES")
        print("═"*72)
        print(f"  {'#':<4} {'Column':<30} {'Type':<16} {'Status'}")
        print("  " + "─"*62)
        for i,(col,dtype) in enumerate(self._dtype_map.items(), 1):
            icon    = _ICON.get(dtype,"❓")
            changed = "  ← overridden" if col in self._overrides else ""
            warn    = "  ⚠️ WILL BE DROPPED" if dtype in ("Constant","ID-like","Unknown") else ""
            print(f"  {i:<4} {col:<30} {icon} {dtype:<14}{changed}{warn}")
        print("─"*72)
        tc = self._config.get("target_col")
        if tc: print(f"  Target column : {tc}")
        if self._overrides: print(f"  Manual overrides: {len(self._overrides)} column(s)")
        secs = self._config.get("sections",{})
        if secs:
            off = [k for k,v in secs.items() if not v]
            if off: print(f"  Sections OFF  : {', '.join(off)}")
        cmp = self._config.get("comparison",{})
        if cmp: print(f"  Comparison    : {cmp.get('label_a','A')} vs {cmp.get('label_b','B')}")
        ks = self._config.get("key_stats",{})
        if ks.get("key_cols"): print(f"  Key stats     : {ks['key_cols']}")
        print()
        print("  Next steps:")
        print("    df_clean = plan.apply_to_df()")
        print("    results  = run_eda(df_clean, plan)")
        print()
        self._confirmed = True
        return self

    # ── apply_to_df ───────────────────────────────────────────────────────────
    def apply_to_df(self, drop_constants=True, drop_id_like=False, drop_unknown=True):
        """
        Return a copy of df cast to confirmed EDA types.

        Numeric      → float64
        Boolean      → float64 (0/1)
        Categorical  → category dtype
        Date         → datetime64[ns]
        Constant     → dropped if drop_constants=True (default)
        Unknown      → dropped if drop_unknown=True (default)
        ID-like      → kept by default (useful for joins); drop if drop_id_like=True
        """
        df = self._df.copy(); dropped = []; cast_log = []
        _TRUE = {"1","y","yes","true","t","1.0","male","m"}
        for col, eda_type in self._dtype_map.items():
            if col not in df.columns: continue
            if eda_type=="Constant" and drop_constants:
                df.drop(columns=[col], inplace=True); dropped.append((col,"Constant — dropped")); continue
            if eda_type=="Unknown" and drop_unknown:
                df.drop(columns=[col], inplace=True); dropped.append((col,"Unknown (all-null) — dropped")); continue
            if eda_type=="ID-like" and drop_id_like:
                df.drop(columns=[col], inplace=True); dropped.append((col,"ID-like — dropped")); continue
            orig = str(df[col].dtype)
            try:
                if eda_type=="Numeric":
                    df[col] = pd.to_numeric(df[col], errors="coerce").astype("float64")
                    cast_log.append((col, orig, "float64"))
                elif eda_type=="Boolean":
                    if df[col].dtype==object:
                        df[col] = df[col].map(lambda v: 1.0 if str(v).strip().lower() in _TRUE
                                              else (0.0 if pd.notna(v) else np.nan)).astype("float64")
                    else:
                        df[col] = pd.to_numeric(df[col], errors="coerce").astype("float64")
                    cast_log.append((col, orig, "float64 (boolean)"))
                elif eda_type=="Categorical":
                    df[col] = df[col].astype("category")
                    cast_log.append((col, orig, "category"))
                elif eda_type=="Date":
                    df[col] = pd.to_datetime(df[col], errors="coerce", infer_datetime_format=True)
                    cast_log.append((col, orig, "datetime64[ns]"))
            except Exception as e:
                print(f"  ⚠️  Could not cast '{col}' ({eda_type}): {e}")

        print(f"\n{'═'*60}")
        print(f"  apply_to_df() — {len(df.columns)} columns kept, {len(dropped)} dropped")
        print(f"{'═'*60}")
        if cast_log:
            print(f"\n  CASTS APPLIED ({len(cast_log)}):")
            for col, old, new in cast_log:
                print(f"    {_ICON.get(self._dtype_map.get(col,''),'  ')} {col:<28} {old:<14} → {new}")
        if dropped:
            print(f"\n  DROPPED ({len(dropped)}):")
            for col, reason in dropped: print(f"    🗑  {col:<28} {reason}")
        print(f"\n  Shape: {df.shape}"); print(f"  Call: results = run_eda(df_clean, plan)\n")
        return df

    # ── internal ──────────────────────────────────────────────────────────────
    def _as_config(self):
        cfg = dict(self._config); cfg["dtype_overrides"] = dict(self._overrides)
        return cfg

    def get(self, key, default=None):
        return self._config.get(key, default)

    def __repr__(self):
        st = "confirmed ✅" if self._confirmed else "not confirmed ⚠️"
        return f"<InspectPlan {len(self._dtype_map)} cols, {len(self._overrides)} override(s), {st}>"


# ─────────────────────────────────────────────────────────────────────────────
# inspect()
# ─────────────────────────────────────────────────────────────────────────────

def inspect(df, target_col=None, id_ratio=0.8, **config_kwargs):
    """
    Detect column types and show a pre-flight confirmation table.
    Returns InspectPlan.
    """
    n_rows, n_cols = df.shape
    feats = [c for c in df.columns if c != target_col]

    print(f"\n{'═'*80}")
    print(f"  EDA TOOLKIT — PRE-FLIGHT INSPECTION")
    print(f"  {n_rows:,} rows  ×  {n_cols} columns", end="")
    if target_col: print(f"  |  Target: {target_col}", end="")
    print(f"\n{'═'*80}\n")

    dtype_map    = {c: detect_type(df[c], id_ratio) for c in feats}
    warnings_map = {c: _col_warnings(c, df[c], dtype_map[c]) for c in feats}

    # Print table — wider columns so sample values don't truncate
    print(f"  {'#':<4} {'Column':<30} {'Pandas dtype':<14} {'Detected as':<18}"
          f"{'Unique':>8} {'Missing':>8}  Sample values")
    print("  " + "─"*116)
    for i, col in enumerate(feats, 1):
        dt      = dtype_map[col]; icon = _ICON.get(dt,"❓")
        pd_type = str(df[col].dtype)
        nu      = int(df[col].nunique()); mp = float(df[col].isna().mean()*100)
        sample  = _sample_vals(df[col], n=4)
        warn    = " ⚠️" if warnings_map[col] else ""
        print(f"  {i:<4} {col:<30} {pd_type:<14} {icon} {dt:<16} {nu:>8,} {mp:>6.1f}%{warn}  {sample}")
    print("  " + "─"*116)

    all_warns = [(c,w) for c,ws in warnings_map.items() for w in ws]
    if all_warns:
        print(f"\n  ⚠️  WARNINGS ({len(all_warns)}):\n")
        for c,w in all_warns: print(f"     {c:<30} → {w}")
    else:
        print(f"\n  ✅  No warnings detected.")

    print(f"\n  TYPE KEY:")
    for t,m in _MEANING.items(): print(f"    {_ICON[t]} {t:<14}  {m}")

    print(f"""
  {'─'*78}
  QUICK START:
    plan.fix(ColumnName="CorrectType")        # fix wrong detections
    plan.confirm()                             # review + mark ready
    df_clean = plan.apply_to_df()             # cast types, drop constants/unknowns

  OPTIONAL CONFIGURATION:
    plan.set_sections(correlations=True, category_quality=True,
                      scorecard=True, target_analysis=True)

    plan.set_key_stats(
        key_cols       = ["Policy_Number"],
        composite_keys = [["Policy_Number","Eff_Date"]]
    )

    plan.set_comparison(
        df=df2, label_a="New Business", label_b="Renewals",
        groupby_col="Region", agg_cols=["Premium","Claim_Flag"]
    )

    results = run_eda(df_clean, plan)

  Valid types: Numeric  Categorical  Boolean  Date  ID-like  Unknown  Constant
  {'─'*78}
""")

    config = {"target_col": target_col, "id_ratio": id_ratio}
    config.update(config_kwargs)
    return InspectPlan(df, dtype_map, config)


# ─────────────────────────────────────────────────────────────────────────────
# run_eda()
# ─────────────────────────────────────────────────────────────────────────────

def run_eda(df, config):
    """Run full EDA. Accepts InspectPlan or plain dict."""
    if isinstance(config, InspectPlan):
        if not config._confirmed:
            print("  ⚠️  plan.confirm() not called — proceeding.\n")
        cfg = config._as_config()
    elif isinstance(config, dict):
        cfg = config
    else:
        cfg = {}
    return _run_eda(df, cfg)


# ─────────────────────────────────────────────────────────────────────────────
# launch_app()
# ─────────────────────────────────────────────────────────────────────────────

def launch_app(results, port=8501):
    """Launch Streamlit dashboard."""
    pkl_path = _DIR / "_results.pkl"
    with open(pkl_path, "wb") as f:
        pickle.dump(results, f)

    shim = _DIR / "_entry.py"
    shim.write_text(f"""\
import sys, pickle
from pathlib import Path
_d = Path(r"{_DIR}")
sys.path.insert(0, str(_d))
import streamlit as st
from app import main
if "eda_results" not in st.session_state:
    with open(_d / "_results.pkl", "rb") as f:
        st.session_state["eda_results"] = pickle.load(f)
main()
""")

    url = f"http://localhost:{port}"
    print(f"\n{'─'*50}\n  EDA Toolkit  |  {url}  |  Ctrl+C or ⏹ in sidebar\n{'─'*50}\n")

    def _open(): time.sleep(2.5); webbrowser.open(url)
    threading.Thread(target=_open, daemon=True).start()

    cmd = [sys.executable, "-m", "streamlit", "run", str(shim),
           f"--server.port={port}", "--server.headless=true", "--theme.base=light"]
    try:
        subprocess.run(cmd, cwd=str(_DIR))
    except KeyboardInterrupt:
        print("\n[EDA] Stopped.")


# ─────────────────────────────────────────────────────────────────────────────
# print_summary()
# ─────────────────────────────────────────────────────────────────────────────

def print_summary(results):
    print(f"\n{'═'*55}")
    print(f"  EDA SUMMARY — {results['n_rows']:,} rows × {results['n_features']} features")
    print(f"  Runtime: {results['elapsed_sec']:.1f}s")
    print(f"{'═'*55}")
    print("\n  FEATURE TYPES:")
    for dtype, cnt in pd.Series(results["dtype_map"]).value_counts().items():
        print(f"    {_ICON.get(dtype,'❓')} {dtype:<15}: {cnt}")
    sc = results.get("scorecard", pd.DataFrame())
    if len(sc):
        print(f"\n  SCORECARD:")
        print(f"    🔴 Fix First : {(sc['Status']=='❌ Fix First').sum()}")
        print(f"    🟡 Review    : {(sc['Status']=='⚠️ Review').sum()}")
        print(f"    🟢 Good      : {(sc['Status']=='✅ Good').sum()}")
        fix = sc[sc['Status']=='❌ Fix First']['Feature'].tolist()
        if fix: print(f"\n  FIX FIRST: {', '.join(fix)}")
    recs = results.get("recommendations",[])
    critical = [r for r in recs if "Fix" in r["Priority"]]
    if critical:
        print(f"\n  TOP ACTIONS:")
        for r in critical[:5]:
            for finding, action in r["Items"][:1]:
                print(f"    • {r['Feature']}: {action}")
    print(f"\n{'═'*55}\n")
