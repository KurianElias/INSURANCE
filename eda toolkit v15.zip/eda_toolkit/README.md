# Insurance EDA Toolkit — v4

A self-contained, local Streamlit EDA dashboard purpose-built for insurance/actuarial datasets.
Handles large datasets efficiently (tested up to 2.5M rows × 200 columns).

---

## Table of Contents

1. [Quick Start](#1-quick-start)
2. [Installation](#2-installation)
3. [Full Workflow with All Options](#3-full-workflow-with-all-options)
4. [Column Type System](#4-column-type-system)
5. [Configuration Reference](#5-configuration-reference)
6. [Performance Tuning for Large Data](#6-performance-tuning-for-large-data)
7. [Dashboard Tabs](#7-dashboard-tabs)
8. [Correlation Section — Detailed Guide](#8-correlation-section--detailed-guide)
9. [Comparison Tab Guide](#9-comparison-tab-guide)
10. [Quality Scorecard](#10-quality-scorecard)
11. [Troubleshooting](#11-troubleshooting)

---

## 1. Quick Start

```python
from eda_toolkit import inspect, run_eda, launch_app

plan = inspect(df, target_col="Claim_Flag")
plan.confirm()

df_clean = plan.apply_to_df()
results  = run_eda(df_clean, plan)
launch_app(results)
```

This is the minimum. Everything else is optional configuration layered on top.

---

## 2. Installation

### Requirements

```
pandas >= 1.5
numpy >= 1.23
scipy
scikit-learn
streamlit >= 1.28
plotly >= 5.0
```

Install with:

```bash
pip install pandas numpy scipy scikit-learn streamlit plotly
```

### Running the app

The toolkit launches Streamlit automatically via `launch_app(results)`. It will open your browser at `http://localhost:8501` (or the next available port). To stop the server, click **Stop Server** in the sidebar or press `Ctrl+C` in the terminal.

---

## 3. Full Workflow with All Options

```python
from eda_toolkit import inspect, run_eda, launch_app

# Step 1: Inspect
plan = inspect(df, target_col="Claim_Flag")

# Step 2: Fix wrong detections (optional)
plan.fix(
    Policy_Year = "Categorical",   # was detected as Numeric
    Risk_Score  = "Numeric",       # was detected as Categorical
)

# Step 3: Toggle sections (optional)
plan.set_sections(
    correlations     = True,   # Pearson, chi-square, VIF, target correlation
    category_quality = True,   # Fuzzy category matching (typo/duplicate detection)
    scorecard        = True,   # Quality scorecard with remediation recommendations
    target_analysis  = True,   # Detailed target variable breakdown
)

# Step 4: Tune correlation performance (optional)
plan.set_corr_options(
    corr_sample         = 100_000,  # rows for Pearson matrix (default 100k)
    chi_sample          = 20_000,   # rows for chi-square (default 20k)
    chi_max_cardinality = 10_000,   # skip categoricals with >10k unique values
    corr_threshold      = 0.75,     # |r| threshold for flagging high pairs
)

# Step 5: Key column stats (optional)
plan.set_key_stats(
    key_cols       = ["Policy_Number"],
    composite_keys = [["Policy_Number", "Eff_Date"]],
)

# Step 6: Comparison dataset (optional)
plan.set_comparison(
    df          = df_prior_year,
    label_a     = "Current Year",
    label_b     = "Prior Year",
    groupby_col = "Policy_Year",
    agg_config  = {
        "Premium":       ["sum", "mean"],
        "Claim_Flag":    ["sum", "mean"],
        "Policy_Number": ["count", "nunique"],
        "Exposure":      ["sum"],
    },
)

# Step 7: Confirm and review
plan.confirm()

# Step 8: Apply types and run
df_clean = plan.apply_to_df()
results  = run_eda(df_clean, plan)
launch_app(results)
```

---

## 4. Column Type System

The toolkit auto-detects column types. Override any detection with `plan.fix(col="Type")`.

| Type | Description | How it's analysed |
|---|---|---|
| `Numeric` | Continuous float/int | Histogram, mean/median/std, IQR outliers, skewness, Pearson |
| `Categorical` | Discrete string labels | Frequency table, hit rate, rare categories, chi-square |
| `Boolean` | Binary 0/1 or Yes/No | Treated as Numeric (0.0/1.0) |
| `Date` | Date/datetime | Year/month/quarter extraction |
| `ID-like` | Too many unique values | **Excluded** from analysis |
| `Constant` | Single unique value | **Excluded** — zero variance |
| `Unknown` | Entirely null | **Excluded** |

### apply_to_df() casts

| Source type | Cast to |
|---|---|
| `Numeric` / `Boolean` | `float64` |
| `Categorical` | `category` |
| `Date` | `datetime64` |
| `ID-like` / `Constant` / `Unknown` | Dropped |

---

## 5. Configuration Reference

### set_sections()

```python
plan.set_sections(
    correlations     = True,
    category_quality = True,
    scorecard        = True,
    target_analysis  = True,
)
```

Tip: On datasets > 1M rows disable `category_quality` first (fuzzy matching is slow), then `correlations` if still slow.

### set_corr_options()

```python
plan.set_corr_options(
    corr_sample         = 100_000,
    chi_sample          = 20_000,
    chi_max_cardinality = 10_000,
    corr_threshold      = 0.75,
)
```

| Parameter | Default | When to change |
|---|---|---|
| `corr_sample` | 100,000 | Increase to 500k for accuracy; lower to 20k for speed |
| `chi_sample` | 20,000 | Valid at 10k+ rows; raise to 100k for higher accuracy |
| `chi_max_cardinality` | 10,000 | Raise to 20k+ if you have high-cardinality codes to test |
| `corr_threshold` | 0.75 | Lower to 0.5 to catch moderate pairs; raise to 0.9 for severe only |

### set_key_stats()

```python
plan.set_key_stats(
    key_cols       = ["Policy_Number", "Risk_ID"],
    composite_keys = [["Policy_Number", "Eff_Date"]],
)
```

### set_comparison()

```python
# Simple
plan.set_comparison(
    df=df_prior, label_a="Current", label_b="Prior",
    groupby_col="Region",
    agg_cols=["Premium", "Claim_Flag"],
)

# Advanced
plan.set_comparison(
    df=df_prior, label_a="Current", label_b="Prior",
    groupby_col=["Region", "Policy_Year"],
    agg_config={
        "Premium":       ["sum", "mean"],
        "Claim_Flag":    ["sum", "mean"],
        "Policy_Number": ["count", "nunique"],
        "Exposure":      ["sum"],
    },
)
```

---

## 6. Performance Tuning for Large Data

### Expected runtimes — 2.5M rows × 200 columns

| Section | Time |
|---|---|
| Column analysis | ~60–120s |
| Pearson (150 numeric cols, 100k sample) | ~5s |
| VIF (matrix formula) | ~3s |
| Chi-square (50 cat cols, 20k sample) | ~10–15s |
| **Total correlations** | **~25s** |

### Why the old version was slow (> 20 minutes)

Three bugs caused this:
1. **Low-cardinality numeric promotion** — integer/float cols with ≤20 unique values were added to chi-square, creating thousands of extra pairs run against 2.5M rows each.
2. **Chi-square on 50k rows** — now 20k (statistically equivalent, 2.5× faster).
3. **VIF via regression loop** — 150 `LinearRegression` fits per run. Now replaced with a single matrix inversion (~15× faster).

### Fast mode for 2.5M+ rows

```python
plan.set_sections(correlations=True, category_quality=False,
                  scorecard=True, target_analysis=True)
plan.set_corr_options(
    corr_sample         = 50_000,
    chi_sample          = 10_000,
    chi_max_cardinality = 5_000,
)
```

### High-accuracy mode

```python
plan.set_corr_options(
    corr_sample         = 500_000,
    chi_sample          = 100_000,
    chi_max_cardinality = 20_000,
)
```

### High-cardinality column skipping

Columns with more unique values than `chi_max_cardinality` (default 10,000) are automatically skipped in chi-square. A notice in the dashboard lists all skipped columns. To include them:

```python
plan.set_corr_options(chi_max_cardinality=50_000)
```

---

## 7. Dashboard Tabs

| Tab | What it shows |
|---|---|
| **Overview** | Row/col counts, missing %, hit rate %, skewness, key stats, duplicates |
| **Variable Explorer** | Full profile per column — histogram/freq chart, stats, outliers |
| **Hit Rate** | Bar chart of data completeness sorted worst → best |
| **Category Quality** | Fuzzy matching for near-duplicate category labels |
| **Outliers** | IQR outlier detection, P1–P99 clipped histograms |
| **Correlations** | Pearson matrix, chi-square, VIF, target correlation summary |
| **Target Analysis** | Target distribution, feature-level breakdowns |
| **Data Comparison** | Side-by-side two-dataset comparison with Match % |
| **Quality Scorecard** | Per-column quality score, status, remediation recommendations |

---

## 8. Correlation Section — Detailed Guide

### Tab 1 — Numeric / Pearson

- Pearson correlation matrix for **all** numeric columns (no column cap)
- Target included and highlighted with 🎯
- Target bar chart shown above the heatmap — always visible even for wide matrices
- High-corr pairs: any pair with |r| ≥ threshold (default 0.75)
- VIF per feature using matrix inversion formula

**Pearson r:** |r| ≥ 0.7 strong · 0.4–0.7 moderate · < 0.4 weak

**VIF:** > 10 severe · 5–10 moderate · < 5 OK

### Tab 2 — Categorical / Chi-Square

- Chi-square test for every pair of categorical columns
- Target always included for vs-target testing
- Cramér's V effect size, χ², p-value, DoF, significance
- Performance banner shows sample size and cardinality cap
- Columns above `chi_max_cardinality` unique values are skipped

**Cramér's V:** ≥ 0.3 strong · 0.1–0.3 moderate · < 0.1 weak

### Tab 3 — Target Correlation

**Combined Summary Table** — the key output. Every feature in one table:

| Feature | Type | Metric | Value | Strength |
|---|---|---|---|---|
| Premium | Numeric | Pearson r | 0.4821 | Moderate |
| Region | Categorical | Cramér's V | 0.3102 | Strong |
| Age | Numeric | Pearson r | −0.2341 | Weak |

- Sorted by absolute value — strongest predictors at top
- Numeric → Pearson r, Categorical → Cramér's V
- Downloadable as CSV
- Bar chart for top 40 features

Detailed sub-tables (Pearson and chi-square separately) available in expandable sections below.

---

## 9. Comparison Tab Guide

The comparison tab requires `plan.set_comparison(...)` to be called before `run_eda`.

**Match % colour coding:**
- 🟢 ≥ 95% very close
- 🟡 85–94% moderate
- 🟠 70–84% notable
- 🔴 < 70% large difference

**TOTAL row** at the bottom shows aggregate across all groups.

Multi-group: `groupby_col=["Region", "Policy_Year"]` creates combined group keys.

---

## 10. Quality Scorecard

Per-column score 0–100 based on:

| Issue | Weight |
|---|---|
| Missing data | 30% |
| Outlier rate | 20% |
| Skewness | 15% |
| Cardinality | 15% |
| Rare categories | 10% |
| Zero inflation | 10% |

Status: ✅ Good (≥75) · ⚠️ Review (50–74) · ❌ Fix First (<50)

---

## 11. Troubleshooting

**`StreamlitDuplicateElementId` error** — Replace old `eda_toolkit` folder entirely with the new zip.

**Chi-square shows "No categorical column pairs"** — Ensure you called `plan.confirm()` then `df_clean = plan.apply_to_df()` before `run_eda`.

**Correlations taking > 3 minutes** — Use fast mode:
```python
plan.set_corr_options(corr_sample=20_000, chi_sample=5_000, chi_max_cardinality=1_000)
```

**Target not in Pearson matrix** — Target must be numeric. String targets (e.g. `"Low"/"High"`) appear only in the chi-square section.

**Numbers truncated (`33……`)** — Fixed in v4 via explicit `column_config`. Ensure you are running the latest files.

**App doesn't open** — Navigate manually to `http://localhost:8501`.

**Memory errors** — For 2.5M × 200 cols expect ~4GB RAM. Drop ID cols with `plan.apply_to_df(drop_ids=True)` or sample first:
```python
df_sample = df.sample(500_000, random_state=42)
```
