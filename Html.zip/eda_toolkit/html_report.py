"""
html_report.py — Insurance EDA Toolkit v5
Self-contained interactive HTML dashboard. No server. No Streamlit.

Usage:
    from eda_toolkit import generate_report

    results = run_eda(df_clean, plan)

    generate_report(results, output_path="report.html")          # save + auto-open
    html = generate_report(results)                               # get string
    displayHTML(html)                                             # Databricks
"""
from __future__ import annotations
import json, math, webbrowser
from pathlib import Path
import numpy as np
import pandas as pd

# ── colours ──────────────────────────────────────────────────────────────────
C = dict(accent="#6366f1", cyan="#06b6d4", red="#ef4444",
         orange="#f59e0b", green="#22c55e", purple="#7c3aed",
         grid="#e5e7ef", bg="rgba(0,0,0,0)")

PLOTLY_CDN = "https://cdn.plot.ly/plotly-2.35.0.min.js"

# ── JSON encoder ──────────────────────────────────────────────────────────────
class _Enc(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, np.integer):  return int(o)
        if isinstance(o, np.floating): return float(o)
        if isinstance(o, np.ndarray):  return o.tolist()
        if isinstance(o, pd.Timestamp):return str(o)
        try:
            if pd.isna(o): return None
        except Exception:
            pass
        return super().default(o)

def _j(v):  return json.dumps(v, cls=_Enc, separators=(",",":"))
def _sf(v, d=0.0):
    try:    return float(v)
    except: return d
def _esc(s):
    return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"','&quot;')
def _fmtn(v):
    try:
        f=float(v)
        if abs(f)>=1e6: return f"{f/1e6:.3f}M"
        if abs(f)>=1e3: return f"{f:,.2f}"
        return f"{f:.4g}"
    except: return str(v)

# ── figure helper ─────────────────────────────────────────────────────────────
def _fig(fig, h=320):
    try:
        fig.update_layout(
            height=h, margin=dict(l=30,r=20,t=36,b=40),
            paper_bgcolor=C["bg"], plot_bgcolor=C["bg"],
            font=dict(family="Inter,system-ui,sans-serif",size=11,color="#374151"),
            legend=dict(bgcolor=C["bg"],font_size=10),
        )
        fig.update_xaxes(gridcolor=C["grid"],linecolor=C["grid"],zerolinecolor=C["grid"])
        fig.update_yaxes(gridcolor=C["grid"],linecolor=C["grid"],zerolinecolor=C["grid"])
        return fig.to_json()
    except:
        return "{}"

# ── HTML primitives ───────────────────────────────────────────────────────────
def metric(label, value, sub=""):
    s = f'<div class="ms">{_esc(sub)}</div>' if sub else ""
    return (f'<div class="mc"><div class="mv">{_esc(str(value))}</div>'
            f'<div class="ml">{_esc(label)}</div>{s}</div>')

def alert(msg, kind="yellow"):
    m={"red":("#fef2f2","#b91c1c","#ef4444"),"yellow":("#fffbeb","#78350f","#f59e0b"),
       "blue":("#eff6ff","#1e3a5f","#3b82f6"),"green":("#f0fdf4","#14532d","#22c55e"),
       "purple":("#f5f3ff","#3b0764","#7c3aed")}
    bg,fg,bd=m.get(kind,m["yellow"])
    return f'<div class="alert" style="background:{bg};color:{fg};border-left:3px solid {bd}">{msg}</div>'

def badge(text, bg, fg):
    return f'<span style="background:{bg};color:{fg};padding:2px 9px;border-radius:999px;font-size:.75rem;font-weight:600;display:inline-block;margin:2px">{_esc(text)}</span>'

def sec(t):
    return f'<h3 class="sh">{_esc(t)}</h3>'

def divider():
    return '<hr class="dv">'

def chart(fig_json, cid, h=320):
    """Emit a chart div. Plotly renders it on page load."""
    return (f'<div id="{cid}" class="pc" data-h="{h}" '
            f'data-fig=\'{fig_json}\'></div>')

def collapsible(title, body, open_=False):
    a=" open" if open_ else ""
    return (f'<details class="col"{a}><summary>{_esc(title)}</summary>'
            f'<div class="col-body">{body}</div></details>')

def table(df, style_fn=None, tid="", cls=""):
    if df is None or not len(df): return '<p class="empty">No data.</p>'
    id_attr = f' id="{tid}"' if tid else ""
    heads = "".join(f'<th>{_esc(c)}</th>' for c in df.columns)
    rows = []
    for _,row in df.iterrows():
        cells=[]
        for c in df.columns:
            v=row[c]; st=""
            if style_fn: st=style_fn(c,v,row)
            d=_esc(str(v)) if not (isinstance(v,float) and math.isnan(v)) else "—"
            cells.append(f'<td style="{st}">{d}</td>')
        rows.append(f'<tr>{"".join(cells)}</tr>')
    tc = f'dt{(" "+cls) if cls else ""}'
    return (f'<div class="tw"><table{id_attr} class="{tc}">'
            f'<thead><tr>{heads}</tr></thead>'
            f'<tbody>{"".join(rows)}</tbody></table></div>')

# ── section builders ──────────────────────────────────────────────────────────

def _overview(R):
    import plotly.graph_objects as go
    import plotly.express as px

    cr=R.get("col_results",{}); dm=R.get("dtype_map",{}); cfg=R.get("config",{})
    n_rows=R.get("n_rows",0); n_feat=R.get("n_features",0); target=R.get("target_col")
    n_num=sum(1 for t in dm.values() if t in("Numeric","Boolean"))
    n_cat=sum(1 for t in dm.values() if t=="Categorical")
    t_cells=n_rows*n_feat
    t_miss=sum(v["missing_count"] for v in cr.values())
    miss_pct=round(t_miss/t_cells*100,2) if t_cells else 0

    h=(f'<div class="mr">'
       +metric("Total Rows",f"{n_rows:,}")
       +metric("Columns",n_feat)
       +metric("Numeric/Bool",n_num)
       +metric("Categorical",n_cat)
       +metric("Overall Missing",f"{miss_pct:.1f}%")
       +'</div>')
    if target: h+=f'<p class="cap">🎯 Target: <strong>{_esc(target)}</strong></p>'
    h+=divider()

    # Donut + missing bar side by side
    tc=pd.Series(dm).value_counts().reset_index(); tc.columns=["Type","Count"]
    cm={"Numeric":C["accent"],"Categorical":C["cyan"],"Boolean":C["orange"],
        "Date":"#10b981","ID-like":"#94a3b8","Constant":C["red"],"Unknown":"#e5e7ef"}
    colors=[cm.get(t,"#94a3b8") for t in tc["Type"]]
    fd=go.Figure(go.Pie(labels=tc["Type"],values=tc["Count"],hole=0.55,
        marker=dict(colors=colors),textposition="inside",
        textinfo="percent+label",textfont_size=10))
    fd.update_layout(showlegend=False)

    miss_data=[(c,r["missing_pct"]) for c,r in cr.items() if r["missing_pct"]>0]
    h+='<div class="two-col">'
    h+=f'<div>{sec("Column Type Distribution")}{chart(_fig(fd,280),"c-donut",280)}</div>'
    if miss_data:
        mdf=pd.DataFrame(miss_data,columns=["Feature","Missing %"]).sort_values("Missing %")
        bc=[C["red"] if v>=30 else C["orange"] if v>=10 else C["accent"] for v in mdf["Missing %"]]
        fm=go.Figure(go.Bar(x=mdf["Missing %"],y=mdf["Feature"],orientation="h",
            marker_color=bc,text=mdf["Missing %"].apply(lambda v:f"{v:.1f}%"),
            textposition="inside",textfont_color="white",textfont_size=9))
        fm.update_layout(xaxis=dict(range=[0,100],title="Missing %"),yaxis_title="")
        h+=f'<div>{sec("Missing Value Overview")}{chart(_fig(fm,max(280,len(mdf)*22)),"c-miss",max(280,len(mdf)*22))}</div>'
    else:
        h+=f'<div>{sec("Missing Value Overview")}{alert("✅ No missing values","green")}</div>'
    h+='</div>'+divider()

    # Feature table
    h+=sec("All Features at a Glance")
    rows=[]
    for col,res in cr.items():
        dtype=res["dtype"]; dist=res.get("dist",{}); sk=res.get("skewness"); inf_p=res.get("inf_pct",0.0)
        mt=(f"{dist['mean']:.4g}" if dist and dtype=="Numeric"
            else(str(res.get("category_table",pd.DataFrame()).iloc[0]["Category"])[:20]
                 if dtype=="Categorical" and len(res.get("category_table",pd.DataFrame()))
                 else res.get("constant_value","—") if dtype=="Constant" else "—"))
        rows.append({"Feature":col,"Type":dtype,"Missing %":res["missing_pct"],
                     "Hit Rate %":res["hit_rate_pct"],"Unique":res["n_unique"],
                     "Mean/Top":mt,"Skewness":round(sk,3) if sk is not None else "—",
                     "Zero %":res.get("zero_pct",0),"Inf %":round(inf_p,2)})
    fd2=pd.DataFrame(rows)
    def _fts(c,v,row):
        if c=="Missing %":
            x=_sf(v)
            if x>=30: return "background:#fee2e2;color:#991b1b"
            if x>=10: return "background:#fef9c3;color:#a16207"
            if x>0:   return "background:#fffbeb;color:#78350f"
            return "background:#dcfce7;color:#166534"
        if c=="Hit Rate %":
            x=_sf(v)
            if x>=95: return "background:#dcfce7;color:#166534;font-weight:600"
            if x>=75: return "background:#fef9c3;color:#a16207"
            return "background:#fee2e2;color:#991b1b"
        if c=="Type":
            dc={"Numeric":C["accent"],"Categorical":C["cyan"],"Boolean":C["orange"],
                "Date":"#10b981","ID-like":"#94a3b8","Constant":C["red"]}
            co=dc.get(str(v),"#94a3b8")
            return f"color:{co};font-weight:600"
        return ""
    h+=table(fd2,_fts,"feat-tbl","sortable")
    h+='<input class="srch" data-tgt="feat-tbl" placeholder="🔍 Search features…">'
    return h


def _variable_explorer(R):
    import plotly.graph_objects as go
    cr=R.get("col_results",{})
    if not cr: return alert("No features analysed.","yellow")

    opts="".join(f'<option value="vp{i}">{_esc(c)}</option>' for i,c in enumerate(cr.keys()))
    panels=[]

    for i,(col,res) in enumerate(cr.items()):
        dtype=res["dtype"]; dist=res.get("dist",{}); inf_p=res.get("inf_pct",0.0)
        sample=res.get("plot_sample",[])
        p=f'<div id="vp{i}" class="vp" style="display:none">'
        p+=f'<div class="vp-head"><span class="vp-name">{_esc(col)}</span><span class="vp-dtype">{_esc(dtype)}</span></div>'

        if dtype in ("Numeric","Boolean") and dist:
            p+='<div class="mr">'
            for lbl,k in [("Mean","mean"),("Median","median"),("Std","std"),("Min","min"),
                           ("Max","max"),("Skewness","skewness"),("Missing %","__miss"),("Zero %","__zero")]:
                if k=="__miss": v=f"{res['missing_pct']:.1f}%"
                elif k=="__zero": v=f"{res.get('zero_pct',0):.1f}%"
                else: v=f"{dist.get(k,0):.4g}" if dist.get(k) is not None else "—"
                p+=metric(lbl,v)
            p+='</div>'
            sk=dist.get("skewness",0) or 0
            if inf_p>0:    p+=alert(f"🔴 {inf_p:.2f}% Inf values excluded","red")
            if abs(sk)>2:  p+=alert(f"⚠️ Very high skewness ({sk:.2f}) — consider log1p","red")
            elif abs(sk)>1:p+=alert(f"⚠️ High skewness ({sk:.2f})","yellow")
            if res["missing_pct"]>20: p+=alert(f"⚠️ Sparse — {res['missing_pct']:.1f}% missing","red")
            elif res["missing_pct"]>5: p+=alert(f"ℹ️ {res['missing_pct']:.1f}% missing","yellow")
            if res.get("zero_inflated"): p+=alert("ℹ️ Zero-inflated (>30% zeros)","blue")
            if dist: p+=f'<p class="cap">Shape: <strong>{_esc(dist.get("shape","—"))}</strong> · P25={dist.get("p25","—")} · P75={dist.get("p75","—")} · P95={dist.get("p95","—")} · P99={dist.get("p99","—")}</p>'
            if sample:
                arr=[x for x in sample if x is not None and not(isinstance(x,float) and math.isnan(x))]
                # Linear histogram
                fl=go.Figure(); fl.add_trace(go.Histogram(x=arr,nbinsx=60,name="Distribution",
                    marker_color=C["accent"],opacity=0.85,marker_line=dict(width=0.3,color="#fff")))
                if dist:
                    fl.add_vline(x=dist["mean"],line_dash="dash",line_color=C["orange"],
                                 annotation_text="Mean",annotation_font_size=10)
                    fl.add_vline(x=dist["median"],line_dash="dot",line_color=C["green"],
                                 annotation_text="Median",annotation_font_size=10)
                fl.update_layout(title=dict(text=f"Distribution — {col}",font_size=13),
                                 xaxis_title=col,yaxis_title="Count",bargap=0.02)
                # Log histogram
                flog=go.Figure(); flog.add_trace(go.Histogram(x=arr,nbinsx=60,
                    marker_color=C["accent"],opacity=0.85,marker_line=dict(width=0.3,color="#fff")))
                if dist:
                    flog.add_vline(x=dist["mean"],line_dash="dash",line_color=C["orange"])
                    flog.add_vline(x=dist["median"],line_dash="dot",line_color=C["green"])
                flog.update_layout(yaxis_type="log",title=dict(text=f"Distribution (Log Y) — {col}",font_size=13),
                                   xaxis_title=col,yaxis_title="Count (log)",bargap=0.02)
                p+=f'''<div class="stog">
  <button class="stob active" onclick="togScale(this,'vlin{i}','vlog{i}')">Linear</button>
  <button class="stob" onclick="togScale(this,'vlog{i}','vlin{i}')">Log</button>
</div>
<div id="vlin{i}">{chart(_fig(fl),"vc_lin{i}".replace("{i}",str(i)))}</div>
<div id="vlog{i}" style="display:none">{chart(_fig(flog),"vc_log{i}".replace("{i}",str(i)))}</div>'''

        elif dtype=="Categorical":
            nu=res["n_unique"]; rare=res.get("rare_count",0)
            p+='<div class="mr">'
            p+=metric("Unique",nu)+metric("Rare (<1%)",rare)
            p+=metric("Missing %",f"{res['missing_pct']:.1f}%")+metric("Top %",f"{res.get('top_val_pct',0):.1f}%")
            p+='</div>'
            if nu>100: p+=alert(f"⚠️ High cardinality — {nu} unique","yellow")
            if rare>5: p+=alert(f"⚠️ {rare} rare categories","yellow")
            if res["missing_pct"]>10: p+=alert(f"⚠️ {res['missing_pct']:.1f}% missing","red")
            tbl=res.get("category_table",pd.DataFrame())
            if len(tbl):
                t25=tbl.head(25)
                bc=[C["red"] if f=="RARE" else C["cyan"] if f=="DOMINANT" else C["accent"] for f in t25["Flag"]]
                fl=go.Figure(go.Bar(x=t25["Category"].astype(str),y=t25["Share %"],
                    marker_color=bc,text=t25["Count"],textposition="outside",textfont_size=9))
                fl.update_layout(title=dict(text=f"Top Categories — {col}",font_size=13),
                                 xaxis_title="",yaxis_title="Share %",bargap=0.15)
                fl.update_xaxes(tickangle=35)
                flog=go.Figure(go.Bar(x=t25["Category"].astype(str),y=t25["Share %"],
                    marker_color=bc,text=t25["Count"],textposition="outside",textfont_size=9))
                flog.update_layout(yaxis_type="log",title=dict(text=f"Top Categories (Log) — {col}",font_size=13),
                                   xaxis_title="",yaxis_title="Share % (log)",bargap=0.15)
                flog.update_xaxes(tickangle=35)
                p+=f'''<div class="stog">
  <button class="stob active" onclick="togScale(this,'clin{i}','clog{i}')">Linear</button>
  <button class="stob" onclick="togScale(this,'clog{i}','clin{i}')">Log</button>
</div>
<div id="clin{i}">{chart(_fig(fl),"cc_lin{i}".replace("{i}",str(i)))}</div>
<div id="clog{i}" style="display:none">{chart(_fig(flog),"cc_log{i}".replace("{i}",str(i)))}</div>'''
                p+=collapsible("Full category table",table(tbl,tid=f"ctbl{i}"))

        elif dtype=="ID-like":
            p+='<div class="mr">'
            p+=metric("Unique",f"{res['n_unique']:,}")+metric("Missing %",f"{res['missing_pct']:.1f}%")
            p+=metric("Hit Rate %",f"{res['hit_rate_pct']:.1f}%")
            p+='</div>'
            p+=alert("🔑 Identifier column — excluded from all analysis.","blue")
            samps=res.get("sample_values",[])
            if samps: p+=f'<p class="cap"><strong>Sample values:</strong> {", ".join(_esc(str(s)) for s in samps)}</p>'

        elif dtype=="Date":
            p+='<div class="mr">'
            p+=metric("Min Date",res.get("date_min","—"))+metric("Max Date",res.get("date_max","—"))
            p+=metric("Unique",f"{res['n_unique']:,}")+metric("Missing %",f"{res['missing_pct']:.1f}%")
            p+='</div>'
            yc=res.get("year_counts",{}); mc=res.get("month_counts",{})
            if yc or mc:
                p+='<div class="two-col">'
                if yc:
                    yr=sorted(yc.keys())
                    fy=go.Figure(go.Bar(x=yr,y=[yc[y] for y in yr],marker_color=C["accent"]))
                    fy.update_layout(title=dict(text=f"{col} — by Year",font_size=12),xaxis_title="Year",yaxis_title="Count")
                    p+=f'<div>{chart(_fig(fy,240),f"cy{i}",240)}</div>'
                if mc:
                    MN=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
                    mo=sorted(mc.keys())
                    fm_=go.Figure(go.Bar(x=[MN[m-1] for m in mo],y=[mc[m] for m in mo],marker_color=C["purple"]))
                    fm_.update_layout(title=dict(text=f"{col} — by Month",font_size=12),xaxis_title="Month",yaxis_title="Count")
                    p+=f'<div>{chart(_fig(fm_,240),f"cm{i}",240)}</div>'
                p+='</div>'

        elif dtype=="Constant":
            p+=alert(f"🔒 Constant column — value: <strong>{_esc(str(res.get('constant_value','?')))}</strong>. Drop before modelling.","red")
        else:
            p+=metric("Missing %",f"{res['missing_pct']:.1f}%")
            p+=alert(f"Type: {_esc(dtype)}","blue")

        p+='</div>'
        panels.append(p)

    return f'''<div class="vex-bar">
  <label class="vex-label">Select Variable</label>
  <select class="vsel" onchange="showVP(this.value)">{opts}</select>
</div>
<div id="vex-panels">{"".join(panels)}</div>
<script>
(function(){{
  function showVP(id){{
    document.querySelectorAll("#vex-panels .vp").forEach(function(el){{el.style.display="none";}});
    var el=document.getElementById(id);
    if(el){{el.style.display="block";renderCharts(el);}}
  }}
  window.showVP=showVP;
  var first=document.querySelector("#vex-panels .vp");
  if(first) first.style.display="block";
}})();
</script>'''


def _hit_rate(R):
    import plotly.graph_objects as go
    cr=R.get("col_results",{}); target=R.get("target_col")
    if not cr: return alert("No data.","yellow")
    rows=[{"Feature":c,"Hit Rate %":r["hit_rate_pct"],"Missing %":r["missing_pct"],"Type":r["dtype"]} for c,r in cr.items()]
    df_hr=pd.DataFrame(rows).sort_values("Hit Rate %",ascending=True)
    bc=[C["green"] if h>=95 else C["orange"] if h>=75 else C["red"] for h in df_hr["Hit Rate %"]]
    fh=go.Figure(go.Bar(x=df_hr["Hit Rate %"],y=df_hr["Feature"],orientation="h",
        marker_color=bc,text=df_hr["Hit Rate %"].apply(lambda v:f"{v:.1f}%"),
        textposition="inside",textfont_size=9,textfont_color="white"))
    fh.update_layout(title=dict(text="Hit Rate per Feature (% non-null)",font_size=13),
        xaxis=dict(range=[0,100],title="Hit Rate %"),yaxis_title="")
    h=max(350,len(df_hr)*22)
    out=chart(_fig(fh,h),"hr-chart",h)
    out+=f'<div class="pills">'
    out+=badge("● ≥95% Good",C["green"]+"20",C["green"])
    out+=badge("● 75–94% Review",C["orange"]+"20",C["orange"])
    out+=badge("● <75% Problem",C["red"]+"20",C["red"])
    out+='</div>'+divider()+sec("Hit Rate Table")
    def _hs(c,v,row):
        if c=="Hit Rate %":
            x=_sf(v)
            if x>=95: return "background:#dcfce7;color:#166534;font-weight:600"
            if x>=75: return "background:#fef9c3;color:#a16207"
            return "background:#fee2e2;color:#991b1b"
        if c=="Missing %":
            x=_sf(v)
            if x>=30: return "background:#fee2e2;color:#991b1b"
            if x>0:   return "background:#fef9c3;color:#a16207"
            return "background:#dcfce7;color:#166534"
        return ""
    out+=table(df_hr.reset_index(drop=True),_hs,"hr-tbl","sortable")
    out+='<input class="srch" data-tgt="hr-tbl" placeholder="🔍 Search…">'
    return out


def _category_quality(R):
    cr=R.get("col_results",{}); fuzzy=R.get("fuzzy_categories",{})
    cat_cols=[c for c,r in cr.items() if r["dtype"]=="Categorical"]
    if not cat_cols: return alert("No categorical columns.","yellow")
    with_m={c:v for c,v in fuzzy.items() if isinstance(v,list) and len(v)>0}
    skipped=[c for c,v in fuzzy.items() if isinstance(v,list) and len(v)==0]

    out='<div class="mr">'
    out+=metric("Cols with similar cats",len(with_m))
    out+=metric("Total similar pairs",sum(len(v) for v in with_m.values()))
    out+=metric("Skipped (high-card)",len(skipped))
    out+='</div>'+divider()+sec("Similar / Duplicate Category Pairs")

    if not with_m:
        out+=alert("✅ No similar or duplicate categories detected.","green")
    else:
        for col,matches in with_m.items():
            nu=cr[col].get("n_unique",0); rare=cr[col].get("rare_count",0)
            mdf=pd.DataFrame(matches)
            def _ss(c,v,row):
                if c=="Similarity":
                    x=_sf(v)
                    if x==1.0: return "background:#fee2e2;color:#991b1b;font-weight:700"
                    if x>=0.95:return "background:#fef9c3;color:#a16207"
                return ""
            out+=collapsible(f"🏷️ {col} — {len(matches)} pair(s) ({nu} cats, {rare} rare)",
                              table(mdf,_ss),open_=True)
    if skipped:
        sl="".join(f'<li>{_esc(c)} ({cr[c].get("n_unique",0)} cats)</li>' for c in sorted(skipped))
        out+=collapsible(f"ℹ️ {len(skipped)} high-cardinality cols skipped",f"<ul>{sl}</ul>")

    out+=divider()+sec("Rare Categories Explorer")
    opts="".join(f'<option value="rcp{i}">{_esc(c)}</option>' for i,c in enumerate(cat_cols))
    panels=[]
    for i,col in enumerate(cat_cols):
        tbl_=cr[col].get("category_table",pd.DataFrame())
        rare_df=tbl_[tbl_["Flag"]=="RARE"] if len(tbl_) else pd.DataFrame()
        dom_df=tbl_[tbl_["Flag"]=="DOMINANT"] if len(tbl_) else pd.DataFrame()
        p=f'<div id="rcp{i}" class="vp" style="display:none"><div class="two-col">'
        p+='<div>'
        if len(rare_df): p+=alert(f"⚠️ {len(rare_df)} rare categories","yellow")+table(rare_df.reset_index(drop=True))
        else: p+=alert(f"✅ No rare categories in {_esc(col)}","green")
        p+='</div><div>'
        if len(dom_df): p+=alert("⚠️ Dominant category detected","yellow")+table(dom_df.reset_index(drop=True))
        else: p+='<p class="cap">No dominant category.</p>'
        p+='</div></div></div>'
        panels.append(p)

    out+=f'''<div class="vex-bar">
  <label class="vex-label">Select Column</label>
  <select class="vsel" onchange="showRCP(this.value)">{opts}</select>
</div>
<div id="rcp-panels">{"".join(panels)}</div>
<script>
(function(){{
  function showRCP(id){{
    document.querySelectorAll("#rcp-panels .vp").forEach(function(e){{e.style.display="none";}});
    var el=document.getElementById(id); if(el) el.style.display="block";
  }}
  window.showRCP=showRCP;
  var first=document.querySelector("#rcp-panels .vp");
  if(first) first.style.display="block";
}})();
</script>'''
    return out


def _outliers(R):
    import plotly.graph_objects as go
    cr=R.get("col_results",{})
    num_cols=[c for c,r in cr.items() if r["dtype"] in("Numeric","Boolean") and r.get("plot_sample")]
    if not num_cols: return alert("No numeric columns with data.","yellow")

    # pre-compute stats
    stats={}
    for col in num_cols:
        res=cr[col]; outl=res.get("outlier",{}); dist=res.get("dist",{})
        sample=res.get("plot_sample",[])
        arr=sorted([x for x in sample if x is not None and not(isinstance(x,float) and math.isnan(x))])
        if not arr: stats[col]=None; continue
        pcts=[float(np.percentile(arr,p)) for p in range(101)]
        p1=pcts[1]; p99=pcts[99]
        lo5=pcts[5]; hi95=pcts[95]
        iqr_pct=outl.get("iqr_pct",0.0); iqr_cnt=outl.get("iqr_count",outl.get("count",0))
        n_out=sum(1 for v in arr if v<lo5 or v>hi95)
        sev=("🔴 High","#fee2e2","#991b1b") if iqr_pct>=10 else \
            ("🟡 Moderate","#fef9c3","#a16207") if iqr_pct>=5 else \
            ("🟢 Low","#dcfce7","#166534") if iqr_pct>=1 else \
            ("✅ Clean","#f0fdf4","#166534")
        stats[col]=dict(arr=arr,pcts=pcts,p1=p1,p99=p99,lo5=lo5,hi95=hi95,
                        n_out=n_out,n_total=len(arr),iqr_pct=iqr_pct,iqr_cnt=iqr_cnt,
                        fence_lo=outl.get("fence_lo","—"),fence_hi=outl.get("fence_hi","—"),
                        note=outl.get("note",""),inf_p=res.get("inf_pct",0.0),
                        zero_inf=res.get("zero_inflated",False),
                        sk=dist.get("skewness",0) or 0,sev=sev)

    # summary table
    out=sec("Outlier Summary — All Variables")
    out+='<p class="cap">IQR method · Click any row to drill into that variable below</p>'
    sum_rows=[]
    for col in num_cols:
        s=stats.get(col)
        if not s:
            sum_rows.append({"Variable":col,"IQR Outliers":"—","IQR %":"—","P5":"—","P95":"—",
                             "Fence Lo":"—","Fence Hi":"—","Skewness":"—","Severity":"—"})
        else:
            sum_rows.append({"Variable":col,"IQR Outliers":s["iqr_cnt"],"IQR %":round(s["iqr_pct"],2),
                             "P5":round(s["lo5"],4),"P95":round(s["hi95"],4),
                             "Fence Lo":s["fence_lo"],"Fence Hi":s["fence_hi"],
                             "Skewness":round(s["sk"],3),"Severity":s["sev"][0]})
    sum_df=pd.DataFrame(sum_rows)

    # custom table with clickable rows
    heads="".join(f'<th>{_esc(c)}</th>' for c in sum_df.columns)
    tbody=""
    for idx,row in sum_df.iterrows():
        vi=idx
        cells=[]
        for c in sum_df.columns:
            v=row[c]; st=""
            if c=="IQR %":
                x=_sf(v)
                if x>=10:  st="background:#fee2e2;color:#991b1b;font-weight:700"
                elif x>=5: st="background:#fef9c3;color:#a16207;font-weight:600"
                elif x>=1: st="background:#dcfce7;color:#166534"
                else:      st="background:#f0fdf4;color:#166534"
            elif c=="Severity":
                s2=stats.get(row["Variable"])
                if s2: st=f"background:{s2['sev'][1]};color:{s2['sev'][2]};font-weight:600"
            elif c=="Skewness":
                x=abs(_sf(v))
                if x>2: st="color:#b91c1c;font-weight:600"
                elif x>1: st="color:#b45309;font-weight:600"
            d=_esc(str(v)) if not(isinstance(v,float) and math.isnan(v)) else "—"
            cells.append(f'<td style="{st}">{d}</td>')
        tbody+=f'<tr class="ol-row" data-vi="{vi}" style="cursor:pointer">{"".join(cells)}</tr>'

    out+=(f'<div class="tw"><table id="ol-sum-tbl" class="dt sortable">'
          f'<thead><tr>{heads}</tr></thead><tbody>{tbody}</tbody></table></div>')
    out+='<input class="srch" data-tgt="ol-sum-tbl" placeholder="🔍 Search…">'
    out+=f'<div class="pills">'
    out+=badge("🔴 IQR%≥10 High","#fee2e220",C["red"])
    out+=badge("🟡 IQR% 5-9 Moderate","#fef9c320",C["orange"])
    out+=badge("🟢 IQR% 1-4 Low","#dcfce720",C["green"])
    out+=badge("✅ IQR%<1 Clean","#f0fdf420","#166534")
    out+='</div>'+divider()

    # drill-down
    out+=sec("Variable Detail")
    opts="".join(f'<option value="op{i}">{_esc(c)}</option>' for i,c in enumerate(num_cols))
    panels=[]
    for i,col in enumerate(num_cols):
        s=stats.get(col)
        p=f'<div id="op{i}" class="vp" style="display:none">'
        if not s: p+=alert("No sample data.","yellow")+' </div>'; panels.append(p); continue

        arr=s["arr"]; pcts=s["pcts"]; p1=s["p1"]; p99=s["p99"]
        lo5=s["lo5"]; hi95=s["hi95"]; pad=(p99-p1)*0.05
        n_out=s["n_out"]

        if s["inf_p"]>0: p+=alert(f"🔴 {s['inf_p']:.2f}% Inf values excluded","red")
        if s["note"]:    p+=alert(f"ℹ️ {_esc(s['note'])}","blue")
        if s["zero_inf"]:p+=alert("ℹ️ Zero-inflated — IQR computed on non-zero values","blue")

        # sliders
        p+=f'''<div class="ol-ctrl">
  <div class="sl-grp">
    <label>Lower percentile cutoff: <strong id="lo_lbl_{i}">P5 = {lo5:.4g}</strong></label>
    <input type="range" id="lo_sl_{i}" min="0" max="20" value="5" step="1"
           oninput="updOutlier({i},this.value,null)">
  </div>
  <div class="sl-grp">
    <label>Upper percentile cutoff: <strong id="hi_lbl_{i}">P95 = {hi95:.4g}</strong></label>
    <input type="range" id="hi_sl_{i}" min="80" max="100" value="95" step="1"
           oninput="updOutlier({i},null,this.value)">
  </div>
</div>'''

        p+=f'<div class="mr">'
        p+=f'<div class="mc"><div class="mv" id="ol_plo_{i}">{lo5:.4g}</div><div class="ml" id="ol_lbplo_{i}">P5</div></div>'
        p+=f'<div class="mc"><div class="mv" id="ol_phi_{i}">{hi95:.4g}</div><div class="ml" id="ol_lbphi_{i}">P95</div></div>'
        p+=f'<div class="mc"><div class="mv" id="ol_cnt_{i}">{n_out:,}</div><div class="ml">Outside range</div></div>'
        p+=f'<div class="mc"><div class="mv" id="ol_pct_{i}">{round(n_out/len(arr)*100,2):.2f}%</div><div class="ml">% outside</div></div>'
        p+=f'<div class="mc"><div class="mv">{s["iqr_cnt"]:,}</div><div class="ml">IQR outliers</div></div>'
        p+=f'<div class="mc"><div class="mv">{s["iqr_pct"]:.1f}%</div><div class="ml">IQR %</div></div>'
        p+='</div>'
        p+=f'<p class="cap"><strong>IQR fences:</strong> lo={s["fence_lo"]} · hi={s["fence_hi"]}</p>'

        # boxplot
        fb=go.Figure()
        fb.add_trace(go.Box(x=arr,name=col,marker_color=C["accent"],boxmean="sd",
                             fillcolor="rgba(99,102,241,.15)",line_color=C["accent"]))
        fb.add_vline(x=lo5,line_dash="dash",line_color=C["orange"],annotation_text="P5",annotation_font_size=10)
        fb.add_vline(x=hi95,line_dash="dash",line_color=C["red"],annotation_text="P95",annotation_font_size=10)
        fb.update_layout(title=dict(text=f"Boxplot — {col}",font_size=13))

        # histogram
        bin_w=(p99-p1)/60 if p99>p1 else None
        fh_=go.Figure()
        fh_.add_trace(go.Histogram(x=arr,
            xbins=dict(size=bin_w,start=p1-pad,end=p99+pad) if bin_w else {},
            marker_color=C["accent"],opacity=0.82,marker_line=dict(width=0.2,color="#fff")))
        if lo5>p1-pad:
            fh_.add_vrect(x0=p1-pad,x1=lo5,fillcolor=C["orange"],opacity=0.12,line_width=0,
                          annotation_text="Low tail",annotation_font_size=9,annotation_position="top left")
        if hi95<p99+pad:
            fh_.add_vrect(x0=hi95,x1=p99+pad,fillcolor=C["red"],opacity=0.12,line_width=0,
                          annotation_text="High tail",annotation_font_size=9,annotation_position="top right")
        fh_.update_layout(title=dict(text=f"Distribution — {col} (P1–P99)",font_size=13),
            xaxis=dict(title=col,range=[p1-pad,p99+pad]),yaxis_title="Count",bargap=0.02)

        p+=chart(_fig(fb,200),f"ob{i}",200)
        p+=chart(_fig(fh_),f"oh{i}")
        if p1>float(min(arr)) or p99<float(max(arr)):
            p+=f'<p class="cap">ℹ️ X-axis clipped to P1–P99 [{p1:.4g},{p99:.4g}]. Full range: [{float(min(arr)):.4g},{float(max(arr)):.4g}]</p>'

        arr_s=arr[::max(1,len(arr)//10000)]
        p+=f'<div id="od{i}" style="display:none" data-pct=\'{_j(pcts)}\' data-arr=\'{_j(arr_s)}\' data-n="{len(arr)}"></div>'
        p+='</div>'
        panels.append(p)

    out+=f'''<div class="vex-bar">
  <label class="vex-label">Select Variable</label>
  <select class="vsel" onchange="showOP(this.value)">{opts}</select>
</div>
<div id="ol-panels">{"".join(panels)}</div>
<script>
(function(){{
  function showOP(id){{
    document.querySelectorAll("#ol-panels .vp").forEach(function(e){{e.style.display="none";}});
    var el=document.getElementById(id);
    if(el){{el.style.display="block";renderCharts(el);}}
  }}
  window.showOP=showOP;
  // row click → jump to variable
  document.querySelectorAll(".ol-row").forEach(function(row){{
    row.addEventListener("click",function(){{
      var idx=this.getAttribute("data-vi");
      var sel=document.querySelector(".vsel[onchange*=showOP]");
      if(sel){{sel.value="op"+idx; showOP("op"+idx);}}
      document.getElementById("ol-panels").scrollIntoView({{behavior:"smooth",block:"start"}});
    }});
    row.addEventListener("mouseenter",function(){{this.style.background="#ede9fe";}});
    row.addEventListener("mouseleave",function(){{this.style.background="";}});
  }});
  var first=document.querySelector("#ol-panels .vp");
  if(first) first.style.display="block";
}})();
</script>'''
    return out


def _correlations(R):
    import plotly.graph_objects as go
    import plotly.express as px
    corr=R.get("correlations",{}); target=R.get("target_col"); cfg=R.get("config",{})
    thresh=cfg.get("corr_threshold",0.75)
    if not corr: return alert("Correlations disabled. Re-run with set_sections(correlations=True).","yellow")

    def sub_tab_bar():
        return '''<div class="stb">
  <button class="stab active" onclick="showST(this,'st-num')">🔢 Numeric — Pearson</button>
  <button class="stab" onclick="showST(this,'st-cat')">🏷️ Categorical — Cramér\'s V</button>
  <button class="stab" onclick="showST(this,'st-tgt')">🎯 Target Correlation</button>
</div>'''

    out=sub_tab_bar()

    # ── Numeric ────────────────────────────────────────────────────────────────
    out+='<div id="st-num" class="st">'
    hm=corr.get("pearson",pd.DataFrame()); n_vars=corr.get("n_vars",0)
    total=corr.get("total_rows",0); sn=corr.get("sample_size",total)
    pct=round(sn/total*100,1) if total else 100

    out+=collapsible("ℹ️ About Pearson correlation",
        "<p><strong>Pearson r</strong> measures linear relationship. Range −1 to +1.<br>"
        "VIF &gt;10 = severe multicollinearity · 5–10 = moderate · &lt;5 = OK</p>")

    if len(hm)<2:
        out+=alert("Need ≥ 2 numeric features for Pearson correlation.","yellow")
    else:
        out+=f'<p class="cap"><strong>{n_vars} numeric features</strong> · {sn:,} of {total:,} rows ({pct}%){" — sampled" if corr.get("sampled") else ""}</p>'
        if target and target in hm.columns:
            tc=hm[target].drop(target,errors="ignore").dropna().sort_values(key=abs,ascending=True)
            if len(tc):
                bc=[C["purple"] if abs(v)>=0.5 else C["accent"] if abs(v)>=0.3 else C["green"] if abs(v)>=0.1 else C["cyan"] for v in tc]
                fq=go.Figure(go.Bar(x=tc.values,y=tc.index.tolist(),orientation="h",marker_color=bc,
                    text=[f"{v:+.3f}" for v in tc.values],textposition="auto",textfont_size=9))
                fq.update_layout(title=dict(text=f"🎯 Features vs Target: {target} (Pearson r)",font_size=13),
                    xaxis=dict(range=[-1,1],title="Pearson r",zeroline=True,zerolinecolor="#374151",zerolinewidth=1.5),yaxis_title="")
                h_=max(300,len(tc)*22)
                out+=sec(f"Features vs Target: {target}")+chart(_fig(fq,h_),"c-ptgt",h_)
                out+='<div class="pills">'
                out+=badge("|r|≥0.5 Strong","#ede9fe",C["purple"])
                out+=badge("0.3–0.5 Moderate","#dbeafe",C["accent"])
                out+=badge("0.1–0.3 Weak","#dcfce7",C["green"])
                out+=badge("<0.1 Negligible","#f1f5f9","#6b7280")
                out+='</div>'+divider()

        out+=sec("Pearson Correlation Heatmap")
        fhm=px.imshow(hm,color_continuous_scale="RdBu_r",zmin=-1,zmax=1,text_auto=".2f")
        fhm.update_layout(title=dict(text="Pearson Correlation Matrix",font_size=13))
        fhm.update_traces(textfont_size=9)
        h_hm=max(350,len(hm)*45)
        out+=chart(_fig(fhm,h_hm),"c-hm",h_hm)+divider()

        pt=corr.get("pair_table",pd.DataFrame())
        if len(pt):
            out+=sec("High-Correlation Pairs")
            out+=f'''<div class="sl-grp" style="max-width:440px;margin-bottom:14px">
  <label>|r| threshold: <strong id="cth-lbl">{thresh:.2f}</strong></label>
  <input type="range" id="cth-sl" min="0" max="100" value="{int(thresh*100)}" step="1"
         oninput="filtCorr(this.value)">
</div>
<p class="cap" id="cth-cnt"></p>'''
            def _ps(c,v,row):
                if c=="Pearson r":
                    x=abs(_sf(v))
                    if x>=0.7: return "background:#ede9fe;color:#5b21b6;font-weight:700"
                    if x>=0.4: return "background:#dbeafe;color:#1e3a5f;font-weight:600"
                return ""
            out+=table(pt,_ps,"cth-tbl","sortable")+divider()

        vif=corr.get("vif",pd.DataFrame())
        if len(vif):
            out+=sec("VIF — Variance Inflation Factor")
            out+='<p class="cap">VIF &gt;10 = severe · 5–10 = moderate · &lt;5 = OK</p>'
            def _vs(c,v,row):
                if c=="VIF":
                    x=_sf(v)
                    if x>10: return "background:#fee2e2;color:#991b1b;font-weight:700"
                    if x>5:  return "background:#fef9c3;color:#a16207"
                    return "background:#dcfce7;color:#166534"
                return ""
            out+=table(vif,_vs)
    out+='</div>'

    # ── Categorical ────────────────────────────────────────────────────────────
    out+='<div id="st-cat" class="st" style="display:none">'
    cv=corr.get("cat_chi2",pd.DataFrame())
    chi_cap=corr.get("chi_max_cardinality",10_000); skipped=corr.get("chi_skipped",[])
    total_r=corr.get("total_rows",0)

    out+=collapsible("ℹ️ About Cramér's V",
        "<p><strong>Cramér's V</strong> measures association between categorical variables. Range 0–1.<br>"
        "V ≥ 0.3 = Strong · 0.1–0.3 = Moderate · &lt;0.1 = Weak. Computed on full dataset.</p>")
    out+=f'<p class="cap">Full {total_r:,} rows · columns &gt;{chi_cap:,} unique values skipped'
    if skipped: out+=f' · <strong>{len(skipped)} skipped</strong>'
    out+='</p>'

    if not len(cv):
        out+=alert("No categorical column pairs (need ≥ 2 categorical columns).","yellow")
    else:
        n_s=int((cv["Cramér's V"].fillna(0)>=0.3).sum())
        n_m=int(((cv["Cramér's V"].fillna(0)>=0.1)&(cv["Cramér's V"].fillna(0)<0.3)).sum())
        n_t=int((cv["vs Target"]=="🎯").sum())
        out+='<div class="mr">'
        out+=metric("Total pairs",len(cv))+metric("Strong (V≥0.3)",n_s)
        out+=metric("Moderate",n_m)+metric("vs Target",n_t)
        out+='</div>'
        cv_json=_j(cv[["Variable A","Variable B","Cramér's V","Strength","vs Target"]].assign(**{"Cramér's V":cv["Cramér's V"].round(4)}).to_dict(orient="records"))
        bar_h=max(300,min(20,len(cv))*26)
        out+=f'''<div class="cv-bar">
  <label class="checkbox-lbl">
    <input type="checkbox" id="cv-tgt" onchange="filtCV()"> Target pairs only
  </label>
</div>
<div id="cv-tbl-wrap"></div>
<div id="cv-bar-wrap"></div>
<script>
(function(){{
  var CVD={cv_json};
  window.CVD=CVD;
  function renderCVTbl(data){{
    var w=document.getElementById("cv-tbl-wrap"); if(!w) return;
    var rows=data.map(function(r){{
      var v=r["Cramér\'s V"]||0;
      var bg=v>=0.3?"background:#ede9fe;color:#5b21b6;font-weight:700":v>=0.1?"background:#dbeafe;color:#1e3a5f":"";
      var tg=r["vs Target"]==="🎯"?"background:#f5f3ff;font-weight:700":"";
      return "<tr><td>"+r["Variable A"]+"</td><td>"+r["Variable B"]+"</td>"+
        "<td style=\\""+bg+"\\">"+v.toFixed(4)+"</td>"+
        "<td style=\\""+bg+"\\">"+r["Strength"]+"</td>"+
        "<td style=\\""+tg+"\\">"+r["vs Target"]+"</td></tr>";
    }}).join("");
    w.innerHTML='<div class="tw"><table class="dt sortable"><thead><tr><th>Variable A</th><th>Variable B</th><th>Cramér\'s V</th><th>Strength</th><th>vs Target</th></tr></thead><tbody>'+rows+'</tbody></table></div>';
  }}
  function renderCVBar(data){{
    var w=document.getElementById("cv-bar-wrap"); if(!w||!data.length) return;
    var top=data.slice(0,20);
    var pairs=top.map(function(r){{return r["Variable A"]+" × "+r["Variable B"];}});
    var vals=top.map(function(r){{return r["Cramér\'s V"];}});
    var clrs=vals.map(function(v){{return v>=0.3?"{C["purple"]}":v>=0.1?"{C["accent"]}":"{C["cyan"]}";}});
    var lay={{height:{bar_h},margin:{{l:0,r:120,t:36,b:40}},paper_bgcolor:"rgba(0,0,0,0)",
      plot_bgcolor:"rgba(0,0,0,0)",font:{{family:"Inter,sans-serif",size:11,color:"#374151"}},
      xaxis:{{title:"Cramér\'s V",range:[0,Math.min(Math.max.apply(null,vals)*1.4,1.05)]}},
      yaxis:{{title:""}},title:{{text:"Categorical Association Strength (Cramér\'s V)",font:{{size:13}}}}}};
    w.innerHTML='<div id="cv-bar-ch" class="pc" style="width:100%"></div>';
    if(window.Plotly) Plotly.newPlot("cv-bar-ch",[{{type:"bar",x:vals,y:pairs,orientation:"h",
      marker:{{color:clrs}},text:top.map(function(r){{return "V="+r["Cramér\'s V"].toFixed(4)+"  "+r["Strength"]}}),
      textposition:"outside",textfont:{{size:9}}}}],lay,{{responsive:true,displayModeBar:false}});
  }}
  function filtCV(){{
    var tgt=document.getElementById("cv-tgt").checked;
    var data=tgt?CVD.filter(function(r){{return r["vs Target"]==="🎯";}}):CVD;
    renderCVTbl(data); renderCVBar(data);
  }}
  window.filtCV=filtCV;
  renderCVTbl(CVD); renderCVBar(CVD);
}})();
</script>'''
    out+='</div>'

    # ── Target ─────────────────────────────────────────────────────────────────
    out+='<div id="st-tgt" class="st" style="display:none">'
    if not target:
        out+=alert("No target column defined. Pass target_col= to inspect().","yellow")
    else:
        out+=f'<p class="cap">Target: <strong>{_esc(target)}</strong></p>'
        ts=corr.get("target_summary",pd.DataFrame())
        if len(ts):
            out+=sec(f"All Features vs Target: {target}")
            out+='<p class="cap">Numeric → Pearson r · Categorical → Cramér\'s V · Higher absolute = stronger</p>'
            tp=ts.dropna(subset=["Value"]).copy()
            tp=tp.sort_values("Value",key=abs,ascending=True).tail(40)
            bc=[]
            for _,row in tp.iterrows():
                v=abs(_sf(row["Value"]))
                if row["Type"]=="Categorical": bc.append(C["purple"] if v>=0.3 else C["accent"] if v>=0.1 else C["cyan"])
                else: bc.append("#7c3aed" if v>=0.5 else C["accent"] if v>=0.3 else C["green"] if v>=0.1 else C["cyan"])
            fts=go.Figure(go.Bar(x=tp["Value"].abs(),y=tp["Feature"],orientation="h",marker_color=bc,
                text=tp.apply(lambda r:f"{r['Metric']}: {abs(_sf(r['Value'])):.4f}",axis=1),
                textposition="auto",textfont_size=9))
            fts.update_layout(title=dict(text=f"Feature Association with {target} (top 40)",font_size=12),
                xaxis=dict(range=[0,1.05],title="Association Strength (absolute)"),yaxis_title="")
            h_ts=max(320,len(tp)*24)
            out+=chart(_fig(fts,h_ts),"c-ts",h_ts)
            out+='<div class="pills">'
            out+=badge("Strong",C["purple"]+"20",C["purple"])
            out+=badge("Moderate",C["accent"]+"20",C["accent"])
            out+=badge("Weak",C["green"]+"20",C["green"])
            out+=badge("🏷️ Categorical","#fef9c3","#78350f")
            out+=badge("🔢 Numeric","#e0f2fe","#0284c7")
            out+='</div>'+divider()

            def _ts_st(c,v,row):
                if c in("Value","Strength"):
                    s=str(row.get("Strength",""))
                    if s=="Strong":   return "background:#ede9fe;color:#5b21b6;font-weight:700"
                    if s=="Moderate": return "background:#dbeafe;color:#1e3a5f;font-weight:600"
                    if s=="Weak":     return "background:#dcfce7;color:#166534"
                if c=="Type":
                    if str(v)=="Categorical": return "background:#fef9c3;color:#78350f"
                    return "background:#e0f2fe;color:#0369a1"
                return ""
            out+=table(ts.reset_index(drop=True),_ts_st,"ts-tbl","sortable")

        tc2=corr.get("target_corr",pd.DataFrame())
        if len(tc2):
            def _tc_st(c,v,row):
                if c=="Pearson r":
                    x=abs(_sf(v))
                    if x>=0.5: return "background:#ede9fe;color:#5b21b6;font-weight:700"
                    if x>=0.3: return "background:#dbeafe;color:#1e3a5f;font-weight:600"
                    if x>=0.1: return "background:#dcfce7;color:#166534"
                return ""
            out+=collapsible(f"🔢 Numeric detail — Pearson r with {target}",table(tc2,_tc_st))

        if len(cv):
            tgt_cv=cv[cv["vs Target"]=="🎯"].copy()
            if len(tgt_cv):
                def _tcv_st(c,v,row):
                    if c=="Cramér's V":
                        x=_sf(v)
                        if x>=0.3: return "background:#ede9fe;color:#5b21b6;font-weight:700"
                        if x>=0.1: return "background:#dbeafe;color:#1e3a5f"
                    return ""
                out+=collapsible(f"🏷️ Categorical detail — Cramér's V vs {target}",table(tgt_cv.reset_index(drop=True),_tcv_st))
    out+='</div>'
    return out


def _comparison(R):
    import plotly.graph_objects as go
    cmp=R.get("comparison",{})
    if not cmp or not isinstance(cmp,dict) or not cmp.get("per_col_tables"):
        return alert("No comparison configured. Call plan.set_comparison(...) before run_eda().","blue")

    la=cmp["label_a"]; lb=cmp["label_b"]
    ra=cmp.get("rows_a",0); rb=cmp.get("rows_b",0)
    gb=cmp.get("groupby_col",[])
    gb_str=", ".join(gb) if isinstance(gb,list) else str(gb or "—")
    sum_a=cmp.get("summary_a",pd.DataFrame()); sum_b=cmp.get("summary_b",pd.DataFrame())
    per_col=cmp.get("per_col_tables",{})

    out='<div class="mr">'
    out+=metric(f"📁 {la} — Rows",f"{ra:,}")+metric(f"📁 {lb} — Rows",f"{rb:,}")
    out+=metric("Row Δ",f"{rb-ra:+,}")+metric("Grouped by",gb_str)
    out+='</div>'+divider()+sec("📋 Dataset Summaries")+'<div class="two-col">'
    for lbl,df_s in [(la,sum_a),(lb,sum_b)]:
        out+=f'<div><h4 style="font-size:.9rem;color:#374151;margin:0 0 8px">{_esc(lbl)}</h4>'
        if len(df_s):
            def _ss(c,v,row):
                if c=="Missing %":
                    x=_sf(v)
                    if x>=30: return "background:#fee2e2;color:#991b1b"
                    if x>=10: return "background:#fef9c3;color:#a16207"
                    if x>0:   return "background:#fffbeb;color:#78350f"
                    return "background:#dcfce7;color:#166534"
                return ""
            out+=table(df_s,_ss)
        else: out+=alert("No summary.","yellow")
        out+='</div>'
    out+='</div>'+divider()+sec("⚖️ Comparison by Group")
    out+=f'<p class="cap">Groups of <strong>{_esc(gb_str)}</strong> · 🟢 100% · 🟡 ≥95% · 🟠 ≥85% · 🔴 &lt;85%</p>'

    keys=list(per_col.keys())
    if len(keys)>1:
        opts="".join(f'<option value="ct_{_esc(k)}">{_esc(per_col[k]["col"])} ({_esc(per_col[k]["fn"])})</option>' for k in keys)
        out+=f'<select class="vsel" onchange="showCT(this.value)" style="margin-bottom:12px">{opts}</select>'

    for ki,key in enumerate(keys):
        entry=per_col[key]; tbl_=entry["table"].copy()
        grp=entry["grp_label"]; cn=entry["col"]; fn=entry["fn"]
        disp=f'style="display:{"block" if ki==0 else "none"}"'
        out+=f'<div id="ct_{_esc(key)}" {disp}>'
        def _cr(c,v,row):
            is_tot=str(row.get(grp,""))=="TOTAL"; bld="font-weight:700;" if is_tot else ""; ex="border-top:2px solid #374151;" if is_tot else ""
            if c=="Match %":
                x=_sf(v)
                if x>=100: return f"background:#dcfce7;color:#166534;{bld}{ex}"
                if x>=95:  return f"background:#bbf7d0;color:#14532d;{bld}{ex}"
                if x>=85:  return f"background:#fef9c3;color:#a16207;{bld}{ex}"
                if x>=70:  return f"background:#fed7aa;color:#9a3412;{bld}{ex}"
                return f"background:#fee2e2;color:#991b1b;{bld}{ex}"
            if c=="Diff %":
                x=abs(_sf(v))
                if x==0:   return f"background:#dcfce7;color:#166534;{bld}{ex}"
                if x<5:    return f"background:#bbf7d0;color:#14532d;{bld}{ex}"
                if x<15:   return f"background:#fef9c3;color:#a16207;{bld}{ex}"
                if x<30:   return f"background:#fed7aa;color:#9a3412;{bld}{ex}"
                return f"background:#fee2e2;color:#991b1b;{bld}{ex}"
            if c=="Diff (A−B)":
                x=_sf(v)
                if x>0: return f"color:#166534;font-weight:600;{ex}"
                if x<0: return f"color:#b91c1c;font-weight:600;{ex}"
                return f"color:#6b7280;{ex}"
            return bld+ex
        out+=table(tbl_,_cr,"sortable")
        plot=tbl_[tbl_[grp]!="TOTAL"].copy()
        if len(plot):
            fg=go.Figure()
            fg.add_trace(go.Bar(name=la,x=plot[grp].astype(str),y=plot[la],marker_color=C["accent"],
                text=plot[la].apply(_fmtn),textposition="outside",textfont_size=9))
            fg.add_trace(go.Bar(name=lb,x=plot[grp].astype(str),y=plot[lb],marker_color=C["cyan"],
                text=plot[lb].apply(_fmtn),textposition="outside",textfont_size=9))
            fg.update_layout(barmode="group",title=dict(text=f"{cn} ({fn}) — {la} vs {lb}",font_size=13),
                xaxis_title=gb_str,yaxis_title=f"{cn} ({fn})",bargap=0.12)
            out+=chart(_fig(fg,340),f"cg{ki}",340)
            if "Match %" in plot.columns:
                bc=[C["green"] if v>=100 else "#86efac" if v>=95 else C["orange"] if v>=85 else "#f97316" if v>=70 else C["red"] for v in plot["Match %"]]
                fm=go.Figure(go.Bar(x=plot[grp].astype(str),y=plot["Match %"],marker_color=bc,
                    text=plot["Match %"].apply(lambda v:f"{v:.1f}%"),
                    textposition="inside",textfont_color="white",textfont_size=10))
                fm.add_hline(y=95,line_dash="dash",line_color=C["orange"])
                fm.update_layout(title=dict(text=f"Match % — {cn} {fn}",font_size=13),
                    xaxis_title=gb_str,yaxis=dict(title="Match %",range=[0,105]))
                out+=chart(_fig(fm,260),f"cm{ki}",260)
        out+='</div>'

    if len(keys)>1:
        out+=f'<script>(function(){{var K={_j(keys)};window.showCT=function(v){{K.forEach(function(k){{var e=document.getElementById("ct_"+k);if(e)e.style.display=(k===v?"block":"none");}});}};}})()</script>'
    return out


def _scorecard(R):
    import plotly.graph_objects as go
    sc=R.get("scorecard",pd.DataFrame()); recs=R.get("recommendations",[])
    if not len(sc): return alert("Scorecard disabled. Re-run with set_sections(scorecard=True).","yellow")

    n_fix=int((sc["Status"]=="❌ Fix First").sum())
    n_rev=int((sc["Status"]=="⚠️ Review").sum())
    n_ok=int((sc["Status"]=="✅ Good").sum())
    tot=len(sc)

    out='<div class="mr">'
    out+=metric("Total",tot)+metric("🔴 Fix First",n_fix)+metric("🟡 Review",n_rev)+metric("🟢 Good",n_ok)
    out+='</div>'
    wf=round(n_fix/tot*200) if tot else 0; wr=round(n_rev/tot*200) if tot else 0; wo=200-wf-wr
    out+=f'<div style="display:flex;border-radius:6px;overflow:hidden;height:10px;margin:8px 0 18px;max-width:500px"><div style="width:{wf}px;background:#ef4444"></div><div style="width:{wr}px;background:#f59e0b"></div><div style="width:{wo}px;background:#22c55e"></div></div>'
    out+=divider()

    sc_col="Overall (0-100)"
    fh=go.Figure()
    fh.add_trace(go.Histogram(x=sc[sc_col],xbins=dict(start=0,end=100,size=5),
        marker_color=[C["red"] if x<55 else C["orange"] if x<80 else C["green"] for x in sc[sc_col]],opacity=0.88))
    fh.update_layout(title=dict(text="Score Distribution",font_size=13),
        xaxis=dict(title="Score (0–100)",range=[0,103]),yaxis_title="# Features",bargap=0.05,
        shapes=[dict(type="line",x0=55,x1=55,y0=0,y1=1,yref="paper",line=dict(color=C["orange"],dash="dash",width=1.5)),
                dict(type="line",x0=80,x1=80,y0=0,y1=1,yref="paper",line=dict(color=C["green"],dash="dash",width=1.5))])
    out+=sec("Score Distribution")+chart(_fig(fh,220),"sc-hist",220)
    out+='<div class="pills">'
    out+=badge("● <55 Fix First","#fee2e220",C["red"])
    out+=badge("● 55–79 Review","#fef9c320",C["orange"])
    out+=badge("● ≥80 Good","#dcfce720",C["green"])
    out+='</div>'+divider()+sec("Feature Scorecard")
    out+='<p class="cap">Weights: Hit Rate 30% · Valid Values 20% · Outliers 20% · Skewness 15% · Cat Consistency 15%</p>'
    out+='''<div class="sc-flt">
  <label class="checkbox-lbl"><input type="checkbox" class="scf" value="Fix" checked onchange="filtSC()"> ❌ Fix First</label>
  <label class="checkbox-lbl"><input type="checkbox" class="scf" value="Review" checked onchange="filtSC()"> ⚠️ Review</label>
  <label class="checkbox-lbl"><input type="checkbox" class="scf" value="Good" checked onchange="filtSC()"> ✅ Good</label>
</div>'''

    show_cols=["Feature","Type","Hit Rate","Valid Values","Skewness","Cat Consistency","Outlier Score",sc_col,"Status"]
    show_cols=[c for c in show_cols if c in sc.columns]
    sc_show=sc[show_cols].copy()
    def _scs(c,v,row):
        if c=="Status":
            s=str(v)
            if "Fix" in s:    return "color:#b91c1c;font-weight:700"
            if "Review" in s: return "color:#b45309;font-weight:700"
            if "Good" in s:   return "color:#166534;font-weight:700"
        if c==sc_col:
            x=_sf(v)
            if x>=80: return "background:#dcfce7;color:#166534;font-weight:600"
            if x>=55: return "background:#fef9c3;color:#a16207;font-weight:600"
            return "background:#fee2e2;color:#991b1b;font-weight:700"
        return ""
    out+=table(sc_show,_scs,"sc-tbl","sortable")

    if recs:
        out+=divider()+sec("Recommended Actions")
        out+='''<div class="sc-flt">
  <label class="checkbox-lbl"><input type="checkbox" class="rf" value="Fix" checked onchange="filtRecs()"> ❌ Fix First</label>
  <label class="checkbox-lbl"><input type="checkbox" class="rf" value="Review" checked onchange="filtRecs()"> ⚠️ Review</label>
</div><div id="recs">'''
        for rec in recs:
            icon="🔴" if "Fix" in rec["Priority"] else "🟡" if "Review" in rec["Priority"] else "🟢"
            pri_short="Fix" if "Fix" in rec["Priority"] else "Review" if "Review" in rec["Priority"] else "Good"
            items="".join(f'<div class="ri"><span class="rf2">{_esc(f)}</span><span class="ra2">→</span><code class="rc">{_esc(a)}</code></div>' for f,a in rec["Items"])
            out+=f'<div class="rec" data-p="{pri_short}"><div class="rh">{icon} <strong>{_esc(rec["Feature"])}</strong><span class="rt">{_esc(rec["Type"])}</span><span class="rp" style="color:{"#b91c1c" if "Fix" in rec["Priority"] else "#b45309"}">{_esc(rec["Priority"])}</span></div><div class="rb">{items}</div></div>'
        out+='</div>'
    else:
        out+=alert("✅ No significant issues found.","green")
    return out


# ── CSS ───────────────────────────────────────────────────────────────────────
CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
:root{--bg:#f5f6fa;--surf:#fff;--bdr:#e2e8f0;--txt:#0f172a;--txt2:#64748b;--txt3:#94a3b8;
  --acc:#6366f1;--acc-l:#ede9fe;--r:10px;
  --sh:0 1px 3px rgba(0,0,0,.08),0 1px 2px rgba(0,0,0,.05);
  --sh2:0 4px 12px rgba(0,0,0,.08);}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--txt);font-size:14px;line-height:1.6}
/* layout */
.lay{display:flex;min-height:100vh}
.side{width:230px;min-width:230px;background:#0f1117;color:#e2e8f0;
      position:sticky;top:0;height:100vh;overflow-y:auto;
      display:flex;flex-direction:column;flex-shrink:0}
.main{flex:1;min-width:0;padding:24px 32px;overflow-x:hidden}
/* sidebar */
.sh2{padding:20px 20px 14px;border-bottom:1px solid #1e2230}
.sl{font-size:19px;font-weight:700;letter-spacing:-.5px;color:#f1f5f9}
.ss{font-size:11px;color:#64748b;margin-top:2px}
.sn{padding:10px 16px 4px;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:#475569}
.ni{display:flex;align-items:center;gap:8px;padding:8px 20px;font-size:13px;cursor:pointer;
    border-left:3px solid transparent;transition:all .15s;color:#94a3b8;white-space:nowrap}
.ni:hover{background:rgba(255,255,255,.04);color:#e2e8f0}
.ni.on{background:rgba(99,102,241,.15);border-left-color:#6366f1;color:#c4b5fd}
.ni-ic{width:18px;text-align:center;flex-shrink:0}
.sts{padding:14px 20px;border-top:1px solid #1e2230;margin-top:auto}
.sr{display:flex;justify-content:space-between;font-size:12px;padding:3px 0;color:#64748b}
.sr strong{color:#e2e8f0}
.qb{height:6px;border-radius:3px;overflow:hidden;display:flex;margin:6px 0}
/* header */
.ph{background:linear-gradient(135deg,#4f46e5,#7c3aed);border-radius:var(--r);
    padding:20px 24px;margin-bottom:20px;color:#fff}
.ph h1{font-size:21px;font-weight:700;letter-spacing:-.4px}
.ph p{font-size:13px;opacity:.85;margin-top:4px}
/* tabs */
.tp{display:none}
.tp.on{display:block}
/* sub-tabs */
.stb{display:flex;gap:2px;border-bottom:2px solid var(--bdr);margin-bottom:18px;overflow-x:auto;flex-wrap:nowrap}
.stab{padding:8px 16px;font-size:13px;font-weight:600;cursor:pointer;border:none;
      background:none;color:var(--txt2);border-bottom:2px solid transparent;
      margin-bottom:-2px;white-space:nowrap;font-family:inherit;transition:all .15s}
.stab:hover{color:var(--txt)}
.stab.on{color:var(--acc);border-bottom-color:var(--acc)}
.st{display:none}
.st.on{display:block}
/* metrics */
.mr{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0 16px}
.mc{background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);
    padding:.65rem 1.1rem .55rem;min-width:100px;flex:1;max-width:180px;box-shadow:var(--sh)}
.mv{font-size:1.2rem;font-weight:700;color:var(--txt);line-height:1.2}
.ml{font-size:.68rem;color:var(--txt2);text-transform:uppercase;letter-spacing:.04em;margin-top:2px}
.ms{font-size:.7rem;color:var(--txt3);margin-top:1px}
/* section */
.sh{font-size:.92rem;font-weight:700;color:var(--txt);border-bottom:2px solid var(--acc);
    padding-bottom:4px;display:inline-block;margin:16px 0 10px}
.dv{border:none;border-top:1px solid var(--bdr);margin:16px 0}
.cap{font-size:.81rem;color:var(--txt2);margin:4px 0 8px}
.empty{color:var(--txt3);font-style:italic;font-size:.84rem;padding:6px 0}
/* alerts */
.alert{padding:.45rem .85rem;border-radius:7px;margin:.3rem 0 .4rem;font-size:.84rem;line-height:1.5}
/* pills */
.pills{display:flex;flex-wrap:wrap;gap:4px;margin:8px 0}
/* tables */
.tw{overflow-x:auto;margin:8px 0;border-radius:8px;box-shadow:var(--sh);border:1px solid var(--bdr)}
.dt{border-collapse:collapse;width:100%;font-size:.81rem;background:var(--surf)}
.dt th{background:#f8fafc;padding:8px 12px;text-align:left;font-weight:600;font-size:.76rem;
       color:var(--txt2);border-bottom:2px solid var(--bdr);cursor:pointer;user-select:none;white-space:nowrap}
.dt th:hover{background:#f1f5f9}
.dt th.sa::after{content:" ↑";color:var(--acc)}
.dt th.sd::after{content:" ↓";color:var(--acc)}
.dt td{padding:6px 12px;border-bottom:1px solid #f8fafc;vertical-align:middle}
.dt tr:last-child td{border-bottom:none}
.dt tbody tr:hover td{background:#fafbff}
.srch{width:100%;max-width:300px;padding:7px 12px;border:1px solid var(--bdr);border-radius:7px;
      font-size:.81rem;font-family:inherit;background:var(--surf);color:var(--txt);
      outline:none;margin:6px 0 12px;display:block}
.srch:focus{border-color:var(--acc);box-shadow:0 0 0 2px rgba(99,102,241,.15)}
/* variable explorer */
.vex-bar{display:flex;align-items:center;gap:12px;margin-bottom:16px;
         background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);
         padding:12px 16px;box-shadow:var(--sh)}
.vex-label{font-size:.82rem;font-weight:600;color:var(--txt2);white-space:nowrap}
.vsel{padding:7px 12px;border:1px solid var(--bdr);border-radius:7px;
      font-size:.88rem;font-family:inherit;background:var(--surf);color:var(--txt);
      min-width:240px;flex:1;outline:none;cursor:pointer}
.vsel:focus{border-color:var(--acc)}
.vp{background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);
    padding:20px;box-shadow:var(--sh)}
.vp-head{display:flex;align-items:center;gap:10px;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid var(--bdr)}
.vp-name{font-size:1.05rem;font-weight:700;color:var(--txt)}
.vp-dtype{font-size:.75rem;font-weight:600;padding:2px 9px;border-radius:999px;
          background:var(--acc-l);color:var(--acc)}
/* scale toggle */
.stog{display:flex;gap:4px;margin-bottom:10px}
.stob{padding:5px 14px;border:1px solid var(--bdr);border-radius:6px;font-size:.79rem;
      font-weight:600;cursor:pointer;background:var(--surf);color:var(--txt2);
      font-family:inherit;transition:all .15s}
.stob.on{background:var(--acc);color:#fff;border-color:var(--acc)}
/* charts */
.pc{width:100%;margin:10px 0;border-radius:8px;overflow:hidden;min-height:50px}
/* outlier sliders */
.ol-ctrl{display:grid;grid-template-columns:1fr 1fr;gap:16px;background:var(--surf);
         border:1px solid var(--bdr);border-radius:var(--r);padding:14px 18px;margin:12px 0}
.sl-grp{display:flex;flex-direction:column;gap:6px}
.sl-grp label{font-size:.81rem;color:var(--txt2)}
.sl-grp strong{color:var(--txt)}
input[type=range]{width:100%;accent-color:var(--acc);cursor:pointer}
/* cv */
.cv-bar{margin:10px 0}
.checkbox-lbl{display:flex;align-items:center;gap:6px;font-size:.83rem;cursor:pointer}
.checkbox-lbl input{accent-color:var(--acc);width:14px;height:14px}
/* scorecard */
.sc-flt{display:flex;gap:16px;margin:8px 0 12px;flex-wrap:wrap}
/* collapsible */
.col{border:1px solid var(--bdr);border-radius:var(--r);margin:8px 0;overflow:hidden}
.col summary{padding:10px 14px;font-size:.86rem;font-weight:600;cursor:pointer;
             list-style:none;background:var(--surf);color:var(--txt);user-select:none}
.col summary::-webkit-details-marker{display:none}
.col summary::before{content:"▶ ";font-size:.68rem;color:var(--txt3);margin-right:4px;
                      transition:transform .2s;display:inline-block}
.col[open] summary::before{transform:rotate(90deg)}
.col summary:hover{background:#f8fafc}
.col-body{padding:14px;border-top:1px solid var(--bdr);background:var(--bg)}
/* recs */
.rec{background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);margin:8px 0;overflow:hidden}
.rh{padding:10px 14px;display:flex;align-items:center;gap:8px;font-size:.88rem;flex-wrap:wrap;background:#fafafa}
.rt{font-size:.73rem;padding:2px 7px;border-radius:999px;background:var(--acc-l);color:var(--acc)}
.rp{font-size:.76rem;font-weight:700;margin-left:auto}
.rb{padding:10px 14px;display:flex;flex-direction:column;gap:6px}
.ri{display:flex;align-items:baseline;gap:8px;font-size:.81rem}
.rf2{color:var(--txt2)} .ra2{color:var(--txt3)}
.rc{background:#f1f5f9;padding:2px 7px;border-radius:4px;font-family:'JetBrains Mono',monospace;font-size:.76rem;color:var(--txt)}
/* two-col */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px}
@media(max-width:900px){.two-col{grid-template-columns:1fr}.side{display:none}.ol-ctrl{grid-template-columns:1fr}}
"""

# ── JavaScript ────────────────────────────────────────────────────────────────
JS = r"""
// ── chart rendering ───────────────────────────────────────────────────────────
function renderCharts(container) {
  var root = container || document;
  root.querySelectorAll('.pc[data-fig]').forEach(function(el) {
    if (!el.id) { el.id = 'pc_' + Math.random().toString(36).slice(2); }
    try {
      var fig = JSON.parse(el.getAttribute('data-fig'));
      var h = parseInt(el.getAttribute('data-h') || '320');
      if (!fig || !fig.data) return;
      if (fig.layout) fig.layout.height = h;
      Plotly.newPlot(el.id, fig.data, fig.layout || {}, {responsive:true, displayModeBar:false});
      el.removeAttribute('data-fig');
    } catch(e) { console.warn('Chart error', el.id, e); }
  });
}

// ── main tabs ─────────────────────────────────────────────────────────────────
function showTab(id) {
  document.querySelectorAll('.tp').forEach(function(p){ p.classList.remove('on'); });
  document.querySelectorAll('.ni').forEach(function(n){ n.classList.remove('on'); });
  var pane = document.getElementById(id);
  if (pane) { pane.classList.add('on'); renderCharts(pane); }
  var nav = document.querySelector('[data-tab="'+id+'"]');
  if (nav) nav.classList.add('on');
}

// ── sub-tabs ──────────────────────────────────────────────────────────────────
function showST(btn, panelId) {
  var pane = document.getElementById(panelId);
  if (!pane) return;
  // find siblings (all .st in same .tp)
  var tp = btn.closest('.tp') || document;
  tp.querySelectorAll('.st').forEach(function(p){ p.classList.remove('on'); p.style.display='none'; });
  tp.querySelectorAll('.stab').forEach(function(b){ b.classList.remove('on'); });
  pane.classList.add('on'); pane.style.display = 'block';
  btn.classList.add('on');
  renderCharts(pane);
}

// ── scale toggles ─────────────────────────────────────────────────────────────
function togScale(btn, showId, hideId) {
  var s = document.getElementById(showId), h = document.getElementById(hideId);
  if (s) { s.style.display = 'block'; renderCharts(s); }
  if (h) { h.style.display = 'none'; }
  var grp = btn.closest('.stog');
  if (grp) grp.querySelectorAll('.stob').forEach(function(b){ b.classList.remove('on'); });
  btn.classList.add('on');
}

// ── table sort ────────────────────────────────────────────────────────────────
document.addEventListener('click', function(e) {
  var th = e.target.closest('th');
  if (!th) return;
  var tbl = th.closest('table.sortable');
  if (!tbl) return;
  var idx = Array.from(th.parentNode.children).indexOf(th);
  var tbody = tbl.querySelector('tbody');
  var rows = Array.from(tbody.querySelectorAll('tr'));
  var asc = th.classList.contains('sa');
  tbl.querySelectorAll('th').forEach(function(h){ h.classList.remove('sa','sd'); });
  rows.sort(function(a,b){
    var av = a.cells[idx] ? a.cells[idx].textContent.trim() : '';
    var bv = b.cells[idx] ? b.cells[idx].textContent.trim() : '';
    var an = parseFloat(av.replace(/[,%]/g,'')), bn = parseFloat(bv.replace(/[,%]/g,''));
    if (!isNaN(an) && !isNaN(bn)) return asc ? an-bn : bn-an;
    return asc ? av.localeCompare(bv) : bv.localeCompare(av);
  });
  rows.forEach(function(r){ tbody.appendChild(r); });
  th.classList.add(asc ? 'sd' : 'sa');
});

// ── table search ──────────────────────────────────────────────────────────────
document.addEventListener('input', function(e) {
  if (!e.target.classList.contains('srch')) return;
  var q = e.target.value.toLowerCase();
  var id = e.target.getAttribute('data-tgt');
  var tbl = id ? document.getElementById(id) : null;
  if (!tbl) return;
  tbl.querySelectorAll('tbody tr').forEach(function(r){
    r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
});

// ── outlier sliders ───────────────────────────────────────────────────────────
function updOutlier(idx, lo, hi) {
  var lsl = document.getElementById('lo_sl_'+idx);
  var hsl = document.getElementById('hi_sl_'+idx);
  if (!lsl||!hsl) return;
  var lv = lo !== null ? parseInt(lo) : parseInt(lsl.value);
  var hv = hi !== null ? parseInt(hi) : parseInt(hsl.value);
  var od = document.getElementById('od'+idx);
  if (!od) return;
  var pcts = JSON.parse(od.getAttribute('data-pct')||'[]');
  var total = parseInt(od.getAttribute('data-n')||'0');
  if (!pcts.length) return;
  var lp = pcts[lv], hp = pcts[hv];
  var ll = document.getElementById('lo_lbl_'+idx);
  var hl = document.getElementById('hi_lbl_'+idx);
  if (ll) ll.textContent = 'P'+lv+' = '+lp.toPrecision(5);
  if (hl) hl.textContent = 'P'+hv+' = '+hp.toPrecision(5);
  var ep = document.getElementById('ol_plo_'+idx);
  var ep2= document.getElementById('ol_phi_'+idx);
  var elb= document.getElementById('ol_lbplo_'+idx);
  var elb2=document.getElementById('ol_lbphi_'+idx);
  var ec = document.getElementById('ol_cnt_'+idx);
  var epc= document.getElementById('ol_pct_'+idx);
  if (ep) ep.textContent = lp.toPrecision(5);
  if (ep2)ep2.textContent = hp.toPrecision(5);
  if (elb) elb.textContent = 'P'+lv;
  if (elb2)elb2.textContent = 'P'+hv;
  var arr = JSON.parse(od.getAttribute('data-arr')||'[]');
  if (arr.length && total>0) {
    var nOut = arr.filter(function(v){ return v<lp||v>hp; }).length;
    var nEst = Math.round(nOut/arr.length*total);
    var pEst = (nOut/arr.length*100).toFixed(2);
    if (ec) ec.textContent = nEst.toLocaleString()+(arr.length<total?'~':'');
    if (epc)epc.textContent = pEst+'%';
  }
  var bd = document.getElementById('ob'+idx);
  if (bd && window.Plotly) Plotly.relayout(bd,{shapes:[
    {type:'line',x0:lp,x1:lp,y0:0,y1:1,yref:'paper',line:{color:'#f59e0b',dash:'dash',width:2}},
    {type:'line',x0:hp,x1:hp,y0:0,y1:1,yref:'paper',line:{color:'#ef4444',dash:'dash',width:2}}
  ]});
  var hd = document.getElementById('oh'+idx);
  if (hd && window.Plotly) {
    var p1=pcts[1],p99=pcts[99],pad=(p99-p1)*.05;
    var shapes=[];
    if (lp>p1-pad) shapes.push({type:'rect',x0:p1-pad,x1:lp,y0:0,y1:1,yref:'paper',fillcolor:'#f59e0b',opacity:.12,line:{width:0}});
    if (hp<p99+pad) shapes.push({type:'rect',x0:hp,x1:p99+pad,y0:0,y1:1,yref:'paper',fillcolor:'#ef4444',opacity:.12,line:{width:0}});
    Plotly.relayout(hd,{shapes:shapes});
  }
}

// ── corr threshold ────────────────────────────────────────────────────────────
function filtCorr(val) {
  var t = val/100;
  var lbl = document.getElementById('cth-lbl');
  if (lbl) lbl.textContent = t.toFixed(2);
  var tbl = document.getElementById('cth-tbl'), cnt=0;
  if (tbl) tbl.querySelectorAll('tbody tr').forEach(function(row){
    var cell = row.cells[2];
    if (!cell) return;
    var v = Math.abs(parseFloat(cell.textContent));
    var show = !isNaN(v) && v>=t;
    row.style.display = show?'':'none';
    if (show) cnt++;
  });
  var ce = document.getElementById('cth-cnt');
  if (ce) ce.textContent = cnt+' pairs with |r| ≥ '+t.toFixed(2);
}

// ── scorecard filter ──────────────────────────────────────────────────────────
function filtSC() {
  var checked = Array.from(document.querySelectorAll('.scf:checked')).map(function(c){return c.value;});
  var tbl = document.getElementById('sc-tbl');
  if (!tbl) return;
  tbl.querySelectorAll('tbody tr').forEach(function(row){
    var txt = row.textContent;
    var show = checked.some(function(v){return txt.includes(v);});
    row.style.display = show?'':'none';
  });
}

// ── recs filter ───────────────────────────────────────────────────────────────
function filtRecs() {
  var checked = Array.from(document.querySelectorAll('.rf:checked')).map(function(c){return c.value;});
  document.querySelectorAll('.rec').forEach(function(c){
    var p = c.getAttribute('data-p')||'';
    c.style.display = checked.some(function(v){return p===v;})?'':'none';
  });
}

// ── init ──────────────────────────────────────────────────────────────────────
window.addEventListener('load', function() {
  // show first tab
  var firstTab = document.querySelector('.tp');
  if (firstTab) { firstTab.classList.add('on'); renderCharts(firstTab); }
  var firstNav = document.querySelector('.ni');
  if (firstNav) firstNav.classList.add('on');

  // show first sub-tab in each tab
  document.querySelectorAll('.tp').forEach(function(tp){
    var firstST = tp.querySelector('.st');
    if (firstST) { firstST.classList.add('on'); firstST.style.display='block'; }
    var firstBtn = tp.querySelector('.stab');
    if (firstBtn) firstBtn.classList.add('on');
  });

  // show first variable panels
  document.querySelectorAll('#vex-panels .vp, #rcp-panels .vp, #ol-panels .vp').forEach(function(p,i){
    if (i===0) return; // first already shown in inline script
    // keep hidden
  });

  // init corr threshold
  var csl = document.getElementById('cth-sl');
  if (csl) filtCorr(csl.value);
});
"""


def generate_report(results: dict,
                    output_path=None,
                    open_browser: bool = True,
                    offline: bool = False) -> str:
    """
    Generate a fully interactive self-contained HTML EDA dashboard.

    Parameters
    ----------
    results      : dict from run_eda()
    output_path  : str path to save HTML file (optional)
    open_browser : auto-open saved file in browser (local only)
    offline      : embed Plotly.js inline (no internet needed)

    Returns
    -------
    str : complete HTML string

    Examples
    --------
    generate_report(results, output_path="report.html")   # save + open
    html = generate_report(results)                        # get string
    displayHTML(html)                                      # Databricks
    """
    target  = results.get("target_col")
    n_rows  = results.get("n_rows", 0)
    n_feat  = results.get("n_features", 0)
    elapsed = results.get("elapsed_sec", 0)
    dm      = results.get("dtype_map", {})
    sc      = results.get("scorecard", pd.DataFrame())
    n_fix   = int((sc["Status"]=="❌ Fix First").sum()) if len(sc) else 0
    n_rev   = int((sc["Status"]=="⚠️ Review").sum())   if len(sc) else 0
    n_ok    = int((sc["Status"]=="✅ Good").sum())      if len(sc) else 0
    tot_sc  = len(sc)

    TABS = [
        ("tab-ov",  "📋", "Overview"),
        ("tab-vex", "🔬", "Variable Explorer"),
        ("tab-hr",  "💧", "Hit Rate"),
        ("tab-cq",  "🏷️", "Category Quality"),
        ("tab-ol",  "⚡", "Outliers"),
        ("tab-co",  "🔗", "Correlations"),
        ("tab-cp",  "⚖️", "Comparison"),
        ("tab-sc",  "🏆", "Scorecard"),
    ]

    nav = "\n".join(
        f'<div class="ni" data-tab="{tid}" onclick="showTab(\'{tid}\')">'
        f'<span class="ni-ic">{ic}</span>{lbl}</div>'
        for tid,ic,lbl in TABS
    )

    wf=round(n_fix/tot_sc*180) if tot_sc else 0
    wr=round(n_rev/tot_sc*180) if tot_sc else 0
    wo=180-wf-wr
    type_s="  ·  ".join(f"{c} {t}" for t,c in pd.Series(dm).value_counts().items()) if dm else ""

    sidebar = f'''<div class="side">
  <div class="sh2"><div class="sl">📊 EDA Toolkit</div><div class="ss">Insurance Analytics · v5</div></div>
  <div class="sn">Navigation</div>
  {nav}
  <div class="sts">
    <div class="sr"><span>Rows</span><strong>{n_rows:,}</strong></div>
    <div class="sr"><span>Columns</span><strong>{n_feat}</strong></div>
    <div class="sr"><span>Target</span><strong>{_esc(target or "—")}</strong></div>
    <div class="sr"><span>Runtime</span><strong>{elapsed:.1f}s</strong></div>
    {"" if not tot_sc else f'<div class="sr" style="margin-top:8px"><span>Quality</span><span></span></div><div class="qb"><div style="width:{wf}px;background:#ef4444"></div><div style="width:{wr}px;background:#f59e0b"></div><div style="width:{wo}px;background:#22c55e"></div></div><div class="sr"><span>🔴 Fix</span><strong>{n_fix}</strong></div><div class="sr"><span>🟡 Review</span><strong>{n_rev}</strong></div><div class="sr"><span>🟢 Good</span><strong>{n_ok}</strong></div>'}
  </div>
</div>'''

    header = f'''<div class="ph">
  <h1>🔍 Insurance EDA Report</h1>
  <p>{n_rows:,} rows · {n_feat} features · {type_s} · Target: {_esc(target or "—")} · {elapsed:.1f}s</p>
</div>'''

    print("[HTML] Building sections...", end="", flush=True)
    builders = [
        ("tab-ov",  _overview),
        ("tab-vex", _variable_explorer),
        ("tab-hr",  _hit_rate),
        ("tab-cq",  _category_quality),
        ("tab-ol",  _outliers),
        ("tab-co",  _correlations),
        ("tab-cp",  _comparison),
        ("tab-sc",  _scorecard),
    ]
    panes = []
    for tid, fn in builders:
        try:
            content = fn(results)
        except Exception as e:
            content = f'<div style="padding:20px">{alert(f"Error building section: {_esc(str(e))}","red")}</div>'
        panes.append(f'<div id="{tid}" class="tp">{content}</div>')
    print(" done.")

    if offline:
        try:
            import plotly
            js_path = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
            if js_path.exists():
                plotly_tag = f"<script>{js_path.read_text()}</script>"
            else:
                plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'
        except Exception:
            plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'
    else:
        plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'

    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>EDA Report — {_esc(target or "no target")} — {n_rows:,} rows</title>
{plotly_tag}
<style>{CSS}</style>
</head>
<body>
<div class="lay">
  {sidebar}
  <div class="main">
    {header}
    {"".join(panes)}
  </div>
</div>
<script>{JS}</script>
</body>
</html>'''

    if output_path:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
        size = path.stat().st_size / 1024
        print(f"[HTML] Saved → {path}  ({size:.0f} KB)")
        if open_browser and not str(output_path).startswith("/dbfs"):
            try:
                webbrowser.open(path.resolve().as_uri())
            except Exception:
                pass

    return html
