# -*- coding: utf-8 -*-
"""
feature_selection_dashboard.py -- Insurance EDA Toolkit v5

Fixes in this version:
  1. Controls are tab-specific: Target Overview has no controls,
     Categorical shows Sort+Group, Numerical shows Bins only
  2. Chart title no longer overlaps toolbar (margin/title position fixed)
  3. Better chart proportions -- not too tall
  4. Improved color scheme: navy bars, steel-blue count, gold line
  5. Smart axis scaling: log scale auto-suggested for skewed data,
     right axis sized so mean line uses full chart height
  6. Stats explanation for zero-inflated targets (P25/P75/P95 = 0 is correct)
  7. Auto pycache cleanup on import -- no stale cache buildup
  8. Efficient: lazy imports, no top-level heavy code
"""
from __future__ import annotations
import json, time, webbrowser
from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

PLOTLY_CDN = "https://cdn.plot.ly/plotly-2.35.0.min.js"
DEFAULT_BINS = [5, 10, 15, 20, 25, 30]

# ── auto-clean stale pycache on import ────────────────────────
def _clean_pycache():
    """Delete stale .pyc files so VS Code doesn't index them."""
    try:
        import shutil, os
        cache = Path(__file__).parent / "__pycache__"
        if cache.exists():
            # Remove only .pyc files older than the source files
            for pyc in cache.glob("*.pyc"):
                stem = pyc.stem.split(".")[0]
                src  = pyc.parent.parent / (stem + ".py")
                if src.exists() and pyc.stat().st_mtime < src.stat().st_mtime:
                    pyc.unlink()
    except Exception:
        pass

_clean_pycache()


class _Enc(json.JSONEncoder):
    def default(self, o):
        try:
            import numpy as np
            if isinstance(o, np.integer):  return int(o)
            if isinstance(o, np.floating): return float(o)
            if isinstance(o, np.ndarray):  return o.tolist()
        except ImportError:
            pass
        try:
            import pandas as pd
            if pd.isna(o): return None
        except Exception:
            pass
        return super().default(o)


def _j(v):   return json.dumps(v, cls=_Enc, separators=(",", ":"))
def _esc(s): return (str(s).replace("&","&amp;").replace("<","&lt;")
                    .replace(">","&gt;").replace('"','&quot;').replace("'","&#39;"))
def _safe(v, d=6):
    try:
        import math
        f = float(v)
        return None if (math.isnan(f) or math.isinf(f)) else round(f, d)
    except Exception:
        return None


# ==============================================================
#  STANDALONE run_target_analysis()
# ==============================================================
def run_target_analysis(df,
                         target_col: str,
                         exposure_col=None,
                         bin_by: str = "amount",
                         n_bins: int = 20,
                         dtype_map=None) -> dict:
    """
    Run Target Analysis independently of run_eda().

    Parameters
    ----------
    df           : full DataFrame
    target_col   : target column name
    exposure_col : exposure column for equal-exposure binning
    bin_by       : "amount" = equal SUM per bin (recommended)
    n_bins       : max bins; pre-computes [5,10,15,20,25,30] up to n_bins+5
    dtype_map    : optional; auto-detected if None

    Returns
    -------
    dict -- pass as {"deep_target_analysis": ta, ...} to generate_fs_report()

    Example
    -------
    ta = run_target_analysis(df, "frequency", exposure_col="expo_amt")
    generate_fs_report(
        {"deep_target_analysis": ta, "target_col": "frequency", "n_rows": len(df)},
        output_path=r"C:\\path\\output.html"
    )
    """
    try:
        from .target_analysis_engine import build_target_analysis
        from .eda_engine import detect_type
    except ImportError:
        from target_analysis_engine import build_target_analysis
        from eda_engine import detect_type

    if target_col not in df.columns:
        raise ValueError(f"target_col='{target_col}' not in DataFrame")

    if dtype_map is None:
        dtype_map = {}
        for col in df.columns:
            if col == target_col:
                continue
            try:
                dtype_map[col] = detect_type(df[col])
            except Exception:
                dtype_map[col] = "Unknown"

    bins_list = sorted(set([b for b in DEFAULT_BINS if b <= max(n_bins + 5, 10)]))
    if n_bins not in bins_list:
        bins_list.append(n_bins)
    bins_list = sorted(set(bins_list))

    bin_methods = ["exposure"] if exposure_col else ["equal"]

    return build_target_analysis(
        df=df, dtype_map=dtype_map, target=target_col,
        n_bins_list=bins_list,
        bin_methods=bin_methods,
        exposure_col=exposure_col,
        bin_by=bin_by,
    )


# ==============================================================
#  CSS
# ==============================================================
CSS = """
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

:root{
  --bg:#F0F2F7;--surf:#fff;--bdr:#D4DCE8;
  --txt:#0D1B2E;--txt2:#4A5568;--txt3:#8A98AA;
  --acc:#C8922A;--acc-l:#FDF3E3;
  --navy:#002B5C;--navy2:#004A97;
  --r:10px;
  --sh:0 1px 5px rgba(0,43,92,.09);
  --sh2:0 4px 18px rgba(0,43,92,.14);
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);
     color:var(--txt);font-size:14px;line-height:1.5;min-height:100vh}

/* ── Header ── */
.hdr{background:linear-gradient(135deg,var(--navy) 0%,var(--navy2) 100%);
     box-shadow:0 3px 20px rgba(0,43,92,.35);position:sticky;top:0;z-index:100}
.hdr-row{display:flex;align-items:center;gap:14px;padding:11px 26px}
.logo{background:var(--acc);color:#fff;font-size:12px;font-weight:800;
      padding:5px 10px;border-radius:7px;white-space:nowrap;letter-spacing:-.2px}
.hdr-title{color:#fff;font-size:16px;font-weight:700;letter-spacing:-.3px}
.hdr-sub{color:rgba(255,255,255,.5);font-size:11px;margin-top:1px}
.hdr-meta{margin-left:auto;display:flex;gap:16px;font-size:12px;color:rgba(255,255,255,.6)}
.hdr-meta strong{color:#fff}
.nav{background:var(--navy);border-top:1px solid rgba(255,255,255,.1);
     display:flex;padding:0 18px;overflow-x:auto}
.nav-btn{padding:10px 20px;font-size:13px;font-weight:500;cursor:pointer;border:none;
         background:none;color:rgba(255,255,255,.45);border-bottom:3px solid transparent;
         margin-bottom:-1px;font-family:inherit;transition:all .13s;white-space:nowrap}
.nav-btn:hover{color:rgba(255,255,255,.85)}
.nav-btn.on{color:#fff;border-bottom-color:var(--acc);font-weight:600}
.tab{display:none}.tab.on{display:block}

/* ── Layout ── */
.page{max-width:1440px;margin:0 auto;padding:22px 28px 60px}

/* ── Tab-specific controls (inside each tab, not global) ── */
.tab-ctrl{display:flex;flex-wrap:wrap;gap:10px;align-items:center;
          background:var(--surf);border:1px solid var(--bdr);
          border-left:4px solid var(--navy2);
          border-radius:var(--r);padding:10px 16px;margin-bottom:14px;
          box-shadow:var(--sh)}
.cg{display:flex;align-items:center;gap:8px}
.cl{font-size:.71rem;font-weight:700;text-transform:uppercase;
    letter-spacing:.06em;color:var(--txt2);white-space:nowrap}
.br{display:flex;gap:3px;flex-wrap:wrap}
.cb{padding:5px 12px;border:1px solid var(--bdr);border-radius:6px;
    font-size:.80rem;font-weight:500;cursor:pointer;background:var(--surf);
    color:var(--txt2);font-family:inherit;transition:all .11s;white-space:nowrap}
.cb:hover{border-color:var(--navy2);color:var(--navy2)}
.cb.on{background:var(--navy);color:#fff;border-color:var(--navy);font-weight:600}
.tg{display:flex;align-items:center;gap:5px;font-size:.81rem;cursor:pointer;
    padding:5px 10px;border:1px solid var(--bdr);border-radius:6px;
    background:var(--surf);transition:all .11s;user-select:none;white-space:nowrap}
.tg input{accent-color:var(--acc);width:13px;height:13px}
.tg:hover{border-color:var(--acc);background:var(--acc-l)}
.csep{width:1px;height:24px;background:var(--bdr);margin:0 2px}

/* ── Feature row ── */
.fr{display:flex;flex-wrap:wrap;gap:10px;align-items:center;
    background:var(--surf);border:1px solid var(--bdr);
    border-radius:var(--r);padding:10px 16px;margin-bottom:12px;
    box-shadow:var(--sh)}
.fl{font-size:.82rem;font-weight:600;color:var(--navy);white-space:nowrap}
.fsel{padding:7px 10px;border:1px solid var(--bdr);border-radius:6px;
      font-size:.86rem;font-family:inherit;background:var(--surf);
      color:var(--txt);min-width:180px;flex:1;max-width:480px;outline:none}
.fsel:focus{border-color:var(--navy2)}
.bl{font-size:.82rem;color:var(--navy);font-weight:700;min-width:52px}
.rng{accent-color:var(--acc);cursor:pointer;width:120px}

/* ── Chart wrapper ── */
.cw{background:var(--surf);border:1px solid var(--bdr);border-radius:var(--r);
    margin:12px 0;overflow:hidden;position:relative;box-shadow:var(--sh)}
.cl2{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
     gap:10px;background:rgba(255,255,255,.95);z-index:2;font-size:.82rem;
     color:var(--txt2);transition:opacity .3s}
.cl2.done{opacity:0;pointer-events:none}
.sp{width:22px;height:22px;border:2.5px solid var(--bdr);border-top-color:var(--acc);
    border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

/* ── Legend strip ── */
.leg{display:flex;flex-wrap:wrap;gap:12px;align-items:center;
     padding:6px 12px;background:#f4f6fb;border-radius:6px;
     border:1px solid var(--bdr);margin:6px 0 12px;font-size:.78rem;color:var(--txt2)}
.li{display:flex;align-items:center;gap:5px}
.ls{width:13px;height:13px;border-radius:3px;flex-shrink:0}
.lline{display:inline-block;width:22px;height:3px;background:#C8922A;
       vertical-align:middle;margin-right:4px;border-radius:2px}

/* ── Stat grid ── */
.sg{display:grid;grid-template-columns:repeat(auto-fill,minmax(115px,1fr));
    gap:10px;margin:12px 0 20px}
.sc{background:var(--surf);border:1px solid var(--bdr);
    border-top:3px solid var(--acc);border-radius:var(--r);
    padding:.6rem 1rem .5rem;box-shadow:var(--sh)}
.sc.warn-card{border-top-color:#f59e0b}
.sv{font-size:1.05rem;font-weight:700;color:var(--navy);line-height:1.2}
.sl{font-size:.67rem;color:var(--txt2);text-transform:uppercase;
    letter-spacing:.05em;margin-top:2px}

/* ── Tables ── */
.tw{overflow-x:auto;margin:10px 0;border-radius:8px;
    box-shadow:var(--sh);border:1px solid var(--bdr)}
.dt{border-collapse:collapse;width:100%;font-size:.81rem;background:var(--surf)}
.dt th{background:#EEF3FA;padding:7px 11px;text-align:left;font-weight:600;
       font-size:.73rem;color:var(--navy2);border-bottom:2px solid var(--bdr);
       cursor:pointer;user-select:none;white-space:nowrap}
.dt th:hover{background:#E0E8F5}
.dt th.sa::after{content:" ^";color:var(--acc)}.dt th.sd::after{content:" v";color:var(--acc)}
.dt td{padding:6px 11px;border-bottom:1px solid #F0F4FA;vertical-align:middle}
.dt tr:last-child td{border-bottom:none}
.dt tbody tr:hover td{background:#F5F8FF}
.tc{display:flex;align-items:center;gap:8px;margin:5px 0 10px}
.dl{display:inline-flex;align-items:center;gap:4px;padding:5px 12px;
    background:var(--surf);border:1px solid var(--bdr);border-radius:6px;
    font-size:.77rem;font-weight:500;color:var(--txt2);text-decoration:none;
    transition:all .12s}
.dl:hover{background:var(--acc-l);color:var(--acc);border-color:var(--acc)}
.pgc{display:flex;align-items:center;gap:8px;margin:5px 0 10px;
     font-size:.81rem;color:var(--txt2)}
.pgb{padding:4px 11px;border:1px solid var(--bdr);border-radius:5px;font-size:.77rem;
     cursor:pointer;background:var(--surf);color:var(--navy2);transition:all .11s}
.pgb:hover:not(:disabled){background:var(--navy2);color:#fff;border-color:var(--navy2)}
.pgb:disabled{opacity:.38;cursor:not-allowed}
.pgi{font-weight:600;color:var(--navy)}

/* ── Typography ── */
.sh{font-size:.94rem;font-weight:700;color:var(--navy);
    border-bottom:2px solid var(--acc);padding-bottom:4px;
    display:inline-block;margin:14px 0 10px}
.cap{font-size:.79rem;color:var(--txt2);margin:3px 0 7px}
.warn{padding:.5rem 1rem;border-radius:7px;font-size:.83rem;
      background:#fffbeb;color:#78350f;border-left:3px solid #f59e0b;margin:.5rem 0}
.zi-note{background:#f0fdf4;border:1px solid #86efac;border-left:4px solid #22c55e;
         border-radius:8px;padding:12px 16px;margin:10px 0 16px;font-size:.83rem;color:#14532d}
.zi-note strong{color:#166534}
.stat-note{font-size:.74rem;color:var(--txt3);margin-top:4px;
           padding:5px 10px;background:#f8fafc;border-radius:5px;
           border-left:2px solid var(--bdr)}

/* ── Fullscreen ── */
#fso{display:none;position:fixed;inset:0;background:rgba(0,0,0,.82);
     z-index:9999;align-items:center;justify-content:center}
#fso.on{display:flex}
#fsb{background:var(--surf);border-radius:12px;padding:8px;
     width:97vw;max-height:97vh;overflow:auto;position:relative}
#fsc{position:absolute;top:10px;right:14px;font-size:22px;cursor:pointer;
     color:#64748b;background:none;border:none;z-index:10;font-weight:700}
#fsp{width:100%;height:86vh}

@media(max-width:768px){.hdr-meta{display:none}.page{padding:12px 10px 32px}}
"""


# ==============================================================
#  JavaScript
# ==============================================================
JS = r"""
// ──────────────────────────────────────────────────────────────
//  Feature Selection Dashboard
//  Controls are TAB-SPECIFIC not global:
//    Tab 1 (Target Overview): no controls
//    Tab 2 (Categorical):     Sort + Group Small
//    Tab 3 (Numerical):       Bins slider only
//
//  Chart design:
//    Navy bars  = exposure (left axis, primary visual)
//    Steel bars = count    (right axis, toggleable)
//    Gold line  = mean     (right axis 2, own scale -- always readable)
//
//  Auto y-scaling: right axis for mean line always uses full height
//  Transparent backgrounds throughout
// ──────────────────────────────────────────────────────────────

var S = {metric:'mean', showCnt:true, catSort:'count', grp:0,
         catPage:0, catPgSz:20, bins:20};
var ACT = {type:null, col:null};
var FIGS = {};

// ── formatting ─────────────────────────────────────────────────
function F(v, d) {
  if (v === null || v === undefined || v !== v) return '--';
  var f = +v;
  if (!isFinite(f)) return '--';
  d = (d !== undefined) ? d : 4;
  if (Math.abs(f) >= 1e9)  return (f/1e9).toFixed(2)  + 'B';
  if (Math.abs(f) >= 1e6)  return (f/1e6).toFixed(2)  + 'M';
  if (Math.abs(f) >= 1e3)  return f.toLocaleString(undefined,{maximumFractionDigits:2});
  if (f !== 0 && Math.abs(f) < 0.0001) return f.toExponential(3);
  return f.toFixed(d);
}
function trunc(s, n) {
  s = String(s||''); n=n||20;
  return s.length>n ? s.slice(0,n-1)+'..' : s;
}

// ── tab switching ──────────────────────────────────────────────
function showTab(id) {
  document.querySelectorAll('.tab').forEach(function(p){p.classList.remove('on');});
  document.querySelectorAll('.nav-btn').forEach(function(b){b.classList.remove('on');});
  var pane = document.getElementById(id);
  var btn  = document.querySelector('[data-tab="'+id+'"]');
  if (pane) pane.classList.add('on');
  if (btn)  btn.classList.add('on');
  window.scrollTo({top:0, behavior:'smooth'});
  setTimeout(function(){
    if (id==='tab-u') { renderUni(); }
    else if (id==='tab-c') {
      var sel = document.querySelector('[onchange*="selCat"]');
      var col = sel ? sel.value : ACT.col;
      if (col) { ACT={type:'cat',col:col}; renderCat(col); }
    } else if (id==='tab-n') {
      var sel2 = document.getElementById('num-feat-sel');
      var col2 = sel2 ? sel2.value : (ACT.type==='num' ? ACT.col : window._FN);
      if (col2) { ACT={type:'num',col:col2}; renderNum(col2); }
    }
  }, 80);
}

// ── categorical controls ───────────────────────────────────────
function setMetric(m) {
  S.metric = m;
  document.querySelectorAll('.mb2').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-m')===m);
  });
  refresh();
}
function togCnt(cb)  { S.showCnt = cb.checked; refresh(); }
function setSort(s) {
  S.catSort = s; S.catPage = 0;
  document.querySelectorAll('.sb').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-s')===s);
  });
  if (ACT.type==='cat') renderCat(ACT.col);
}
function setGrp(v) {
  S.grp = +v; S.catPage = 0;
  var el = document.getElementById('grp-lbl');
  if (el) el.textContent = v>0 ? '<'+v+'%' : 'Off';
  if (ACT.type==='cat') renderCat(ACT.col);
}

// ── numerical controls ─────────────────────────────────────────
function setBins(v) {
  S.bins = +v;
  var el = document.getElementById('bins-v');
  if (el) el.textContent = v+' bins';
  var sel = document.getElementById('num-feat-sel');
  var col = sel ? sel.value : (ACT.type==='num' ? ACT.col : window._FN);
  if (col) { ACT={type:'num',col:col}; renderNum(col); }
}

function refresh() {
  if      (ACT.type==='cat') renderCat(ACT.col);
  else if (ACT.type==='num') renderNum(ACT.col);
  else if (ACT.type==='uni') renderUni();
}

// ── chart renderer ─────────────────────────────────────────────
function plotChart(id, traces, layout) {
  var el = document.getElementById(id);
  if (!el || !window.Plotly) return;
  var wrap = el.closest('.cw');
  if (wrap) {
    var ldr = wrap.querySelector('.cl2');
    if (ldr) { ldr.style.opacity='0'; setTimeout(function(){ldr.classList.add('done');},350); }
  }
  var cfg = {responsive:true, displayModeBar:true, displaylogo:false,
             modeBarButtonsToRemove:['sendDataToCloud','lasso2d','select2d']};
  FIGS[id] = {data:traces, layout:layout};
  try {
    if (el._p) Plotly.react(id, traces, layout, cfg);
    else { Plotly.newPlot(id, traces, layout, cfg); el._p=true; }
  } catch(e) { console.warn('chart error', id, e); }
}

// fullscreen
function openFS(id) {
  var fig=FIGS[id]; if(!fig||!window.Plotly) return;
  var ov=document.getElementById('fso'), pl=document.getElementById('fsp');
  if(!ov||!pl) return;
  var lay=JSON.parse(JSON.stringify(fig.layout||{}));
  lay.height=Math.floor(window.innerHeight*.87); lay.autosize=true;
  Plotly.newPlot(pl,fig.data,lay,{responsive:true,displayModeBar:true,displaylogo:false});
  ov.classList.add('on');
}
function closeFS() {
  var ov=document.getElementById('fso'); if(ov) ov.classList.remove('on');
  var pl=document.getElementById('fsp'); if(pl&&window.Plotly) Plotly.purge(pl);
}
document.addEventListener('click',function(e){
  if(e.target===document.getElementById('fso')) closeFS();
});

// table sort
document.addEventListener('click',function(e){
  var th=e.target.closest('th'); if(!th) return;
  var tbl=th.closest('table.srt'); if(!tbl) return;
  var idx=Array.from(th.parentNode.children).indexOf(th);
  var tbody=tbl.querySelector('tbody');
  var rows=Array.from(tbody.querySelectorAll('tr'));
  var asc=th.classList.contains('sa');
  tbl.querySelectorAll('th').forEach(function(h){h.classList.remove('sa','sd');});
  rows.sort(function(a,b){
    var av=a.cells[idx]?a.cells[idx].textContent.trim():'';
    var bv=b.cells[idx]?b.cells[idx].textContent.trim():'';
    var an=parseFloat(av.replace(/[,%MBk]/g,'')), bn=parseFloat(bv.replace(/[,%MBk]/g,''));
    if(!isNaN(an)&&!isNaN(bn)) return asc?an-bn:bn-an;
    return asc?av.localeCompare(bv):bv.localeCompare(av);
  });
  rows.forEach(function(r){tbody.appendChild(r);});
  th.classList.add(asc?'sd':'sa');
});

// ──────────────────────────────────────────────────────────────
//  SINGLE-CHART BUILDER
//  Everything in ONE panel -- bars + mean line overlaid.
//
//  Colors:
//    Exposure bars: navy   rgba(0,43,92,0.70)
//    Count bars:    steel  rgba(99,140,185,0.50)
//    Mean line:     gold   #C8922A
//
//  Axes:
//    y  (left):  exposure bars
//    y2 (right): count bars  (own scale, separate from mean line)
//    y3 (right): mean line   (own scale, always fills chart height)
//
//  Mean line scale: auto-set so min->max of mean values spans
//  60-80% of the chart height -- always clearly visible.
// ──────────────────────────────────────────────────────────────
function buildChart(id, xLabels, expos, cnts, mvals, expName, mLbl, title, h) {
  if (!window.Plotly || !xLabels || !xLabels.length) return;

  var ec   = expName || '';
  var hasE = !!(ec && expos && expos.length && expos.some(function(v){return v>0;}));
  var n    = xLabels.length;

  // Smart tick angle
  var maxLbl = xLabels.reduce(function(a,s){return s&&s.length>a?s.length:a;},0);
  var angle  = 0;
  if      (n>20 || maxLbl>14) angle = -60;
  else if (n>14 || maxLbl>9)  angle = -45;
  else if (n>8)                angle = -30;

  var bMgn = angle<-50 ? 150 : angle<-25 ? 118 : 70;
  h = h || 420;

  var gc = 'rgba(210,220,235,0.55)';
  var traces = [];

  // Bar 1: Exposure -- navy
  if (hasE) {
    traces.push({
      type:'bar', x:xLabels, y:expos, name:ec, yaxis:'y',
      marker:{color:'rgba(0,43,92,0.68)', line:{color:'rgba(0,43,92,0.88)',width:0.5}},
      hovertemplate:'<b>%{x}</b><br>'+ec+': %{y:,.2f}<extra></extra>',
    });
  }

  // Bar 2: Count -- steel blue (lighter so bars don't blend)
  if (S.showCnt) {
    traces.push({
      type:'bar', x:xLabels, y:cnts, name:'Count', yaxis:hasE?'y2':'y',
      marker:{color:'rgba(99,140,185,0.48)', line:{color:'rgba(80,120,165,0.65)',width:0.5}},
      hovertemplate:'<b>%{x}</b><br>Count: %{y:,}<extra></extra>',
    });
  }

  // Line: Mean -- gold, own axis y3 (always fills height)
  var validM = mvals.filter(function(v){return v!==null&&isFinite(+v);});
  var mMin   = validM.length ? Math.min.apply(null,validM) : 0;
  var mMax   = validM.length ? Math.max.apply(null,validM) : 1;
  var mSpan  = mMax - mMin;
  // Pad so line uses ~75% of chart height
  var mPad   = mSpan>0 ? mSpan*0.18 : Math.abs(mMax)*0.25 || 0.001;
  var mR0    = (mMin>=0) ? 0 : mMin - mPad;
  var mR1    = mMax + mPad;

  traces.push({
    type:'scatter', mode:'lines+markers',
    x:xLabels, y:mvals, name:mLbl, yaxis:'y3',
    line:{color:'#C8922A', width:2.8},
    marker:{color:'#C8922A', size:9, symbol:'circle', line:{color:'#fff',width:1.8}},
    hovertemplate:'<b>%{x}</b><br>'+mLbl+': %{y:.6g}<extra></extra>',
  });

  var tf = {size: Math.max(9, 12-Math.floor(n/10)), color:'#4A5568'};

  var layout = {
    // Title with extra top margin so it doesn't clash with Plotly toolbar
    title:{
      text: title,
      font:{size:13, color:'#0D1B2E'},
      x:0.5, xanchor:'center',
      pad:{t:10},
    },
    xaxis:{
      type:'category', tickangle:angle, tickfont:tf,
      gridcolor:gc, zeroline:false, showgrid:false, automargin:true,
    },
    // Left: exposure (navy)
    yaxis:{
      title:{text: hasE?ec:'', font:{size:11,color:'rgba(0,43,92,0.80)'}},
      tickfont:{color:'rgba(0,43,92,0.75)', size:10},
      gridcolor:gc, zeroline:true, zerolinecolor:'rgba(0,43,92,0.15)',
      showgrid:true, side:'left',
    },
    // Right 1: count (steel, only when exposure also present)
    yaxis2:{
      title:{text: (hasE&&S.showCnt)?'Count':'', font:{size:10,color:'rgba(99,140,185,0.85)'}},
      tickfont:{color:'rgba(99,140,185,0.85)', size:9},
      overlaying:'y', side:'right',
      showgrid:false, zeroline:false,
      visible: !!(hasE && S.showCnt),
    },
    // Right 2: mean line -- always its own clean scale
    yaxis3:{
      title:{text:mLbl, font:{size:11,color:'#C8922A'}},
      tickfont:{color:'#C8922A', size:10},
      overlaying:'y', side:'right',
      anchor:'free', position:1.0,
      range:[mR0, mR1],
      showgrid:false, zeroline:false,
    },
    paper_bgcolor:'rgba(0,0,0,0)',
    plot_bgcolor:'rgba(0,0,0,0)',
    font:{family:'Inter,sans-serif', size:11, color:'#0D1B2E'},
    height: h,
    margin:{l:80, r:hasE&&S.showCnt?115:90, t:56, b:bMgn},
    barmode:'group', bargap:0.20, bargroupgap:0.06,
    legend:{
      orientation:'h', x:0.5, xanchor:'center', y:-0.02, yanchor:'top',
      bgcolor:'rgba(0,0,0,0)', font:{size:11},
    },
    hovermode:'x unified',
  };

  plotChart(id, traces, layout);
}

// ──────────────────────────────────────────────────────────────
//  UNIVARIATE
// ──────────────────────────────────────────────────────────────
function renderUni() {
  ACT.type='uni';
  var D=window.D_UNI;
  if (!D||!window.Plotly) return;

  var hist    = D.hist_clip;
  var histLog = D.hist_log;
  var stats   = D.stats||{};
  var zeroPct = +(stats.zero_pct||0);
  var isZI    = zeroPct>=50;

  if (!hist||!hist.counts||!hist.counts.length) return;

  var gc = 'rgba(210,220,235,0.55)';

  // Build main histogram trace
  var edges=hist.edges, counts=hist.counts, mids=[], labs=[];
  for (var i=0;i<counts.length;i++){
    var lo=+edges[i], hi=+edges[i+1];
    mids.push((lo+hi)/2);
    labs.push('['+lo.toPrecision(4)+', '+hi.toPrecision(4)+')');
  }

  var hasNZ = isZI && histLog && histLog.counts && histLog.counts.length>0;

  if (hasNZ) {
    // Two panels: full dist (left) | non-zero log (right)
    var eL=histLog.edges, cL=histLog.counts, mL=[], lL=[];
    for (var j=0;j<cL.length;j++){
      var lo2=+eL[j], hi2=+eL[j+1];
      mL.push((lo2+hi2)/2);
      lL.push('['+lo2.toPrecision(3)+', '+hi2.toPrecision(3)+')');
    }
    var traces=[
      {type:'bar',x:mids,y:counts,name:'All values',
       xaxis:'x',yaxis:'y',
       marker:{color:'rgba(0,43,92,0.65)',line:{color:'rgba(0,43,92,0.85)',width:0.3}},
       hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>',text:labs},
      {type:'bar',x:mL,y:cL,name:'Non-zero (log1p)',
       xaxis:'x2',yaxis:'y2',
       marker:{color:'rgba(200,146,42,0.65)',line:{color:'rgba(200,146,42,0.9)',width:0.3}},
       hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>',text:lL},
    ];
    var layout={
      title:{text:(window.D_TGT||'Target')+' -- Distribution ('+zeroPct.toFixed(1)+'% zeros)',
             font:{size:13,color:'#0D1B2E'},x:0.5,xanchor:'center',pad:{t:8}},
      grid:{rows:1,columns:2,pattern:'independent'},
      xaxis:{domain:[0,0.46],anchor:'y',
             title:{text:'Value',font:{size:11}},gridcolor:gc,zeroline:false},
      yaxis:{anchor:'x',title:{text:'Count',font:{size:11}},gridcolor:gc},
      xaxis2:{domain:[0.54,1],anchor:'y2',
              title:{text:'log1p(non-zero)',font:{size:11,color:'#C8922A'}},
              gridcolor:gc,zeroline:false},
      yaxis2:{anchor:'x2',title:{text:'Count',font:{size:11}},gridcolor:gc},
      paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
      font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
      height:380,margin:{l:65,r:20,t:52,b:55},bargap:0.04,
      legend:{orientation:'h',x:0.5,xanchor:'center',y:1.06,font:{size:11}},
      annotations:[
        {text:'Full distribution (incl. zeros)',xref:'paper',yref:'paper',
         x:0.23,y:1.04,showarrow:false,font:{size:10,color:'rgba(0,43,92,0.8)'}},
        {text:'Non-zero only (log1p)',xref:'paper',yref:'paper',
         x:0.77,y:1.04,showarrow:false,font:{size:10,color:'#C8922A'}},
      ],
    };
    plotChart('uni-ch',traces,layout);
  } else {
    var traces1=[{
      type:'bar',x:mids,y:counts,name:'Count',
      marker:{color:'rgba(0,43,92,0.65)',line:{color:'rgba(0,43,92,0.85)',width:0.3}},
      hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>',text:labs,
    }];
    var layout1={
      title:{text:(window.D_TGT||'Target')+' -- Distribution',
             font:{size:13,color:'#0D1B2E'},x:0.5,xanchor:'center',pad:{t:8}},
      xaxis:{title:{text:window.D_TGT||'Target',font:{size:11}},gridcolor:gc,zeroline:false},
      yaxis:{title:{text:'Count',font:{size:11}},gridcolor:gc},
      paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
      font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
      height:380,margin:{l:65,r:20,t:52,b:55},bargap:0.04,
    };
    plotChart('uni-ch',traces1,layout1);
  }
  buildUniTbl();
}

function buildUniTbl() {
  var D=window.D_UNI; if(!D) return;
  var s=D.stats||{};
  var zeroPct=+(s.zero_pct||0);
  var rows=[
    ['Count',    (s.count||0).toLocaleString()],
    ['Mean',     F(s.mean,6)],
    ['Median',   F(s.median,6)],
    ['Std Dev',  F(s.std,4)],
    ['Min',      F(s.min,6)],
    ['Max',      F(s.max,4)],
    ['P25',      F(s.p25,6)],
    ['P75',      F(s.p75,4)],
    ['P95',      F(s.p95,4)],
    ['P99',      F(s.p99,4)],
    ['Skewness', F(s.skewness,3)],
    ['Zero %',   F(s.zero_pct,2)+'%'],
  ];
  var h='<div class="tw" style="max-width:400px"><table class="dt">'
    +'<thead><tr><th>Statistic</th>'
    +'<th style="text-align:right">Value</th></tr></thead><tbody>';
  rows.forEach(function(r){
    var warn=(r[0]==='Zero %'&&zeroPct>=50)?' style="color:#b45309;font-weight:700"':'';
    h+='<tr><td>'+r[0]+'</td>'
      +'<td style="text-align:right;font-weight:600;color:var(--navy)"'+warn+'>'+r[1]+'</td></tr>';
  });
  h+='</tbody></table></div>';
  // Add explanation note for zero-inflated targets
  if (zeroPct>=50){
    h+='<p class="stat-note">P25/P75/P95 show 0 because '
      +zeroPct.toFixed(1)+'% of rows are zero -- percentiles below the '
      +(100-zeroPct).toFixed(1)+'th percentile are all zero. '
      +'P99 and Max show the non-zero distribution. Use Sum as metric for clearer signal.</p>';
  }
  var el=document.getElementById('uni-tbl'); if(el) el.innerHTML=h;
}

// ──────────────────────────────────────────────────────────────
//  CATEGORICAL
// ──────────────────────────────────────────────────────────────
function selCat(col){ACT={type:'cat',col:col};S.catPage=0;renderCat(col);}
function catPg(d){S.catPage=Math.max(0,S.catPage+d);renderCat(ACT.col);}

function renderCat(col){
  var rawData=window.D_CAT&&window.D_CAT[col];
  if (!rawData||!rawData.length||!window.Plotly) return;
  var m=S.metric;
  var ec=window.D_EC||'';
  var hasE=!!(ec&&rawData[0]&&rawData[0].exposure_sum!==undefined);

  // FRESH COPY -- never mutate rawData
  var data=rawData.slice();

  // Group small
  if (S.grp>0){
    var kept=[],grp=[];
    data.forEach(function(r){(+r.pct<S.grp?grp:kept).push(r);});
    if (grp.length){
      var gn=grp.reduce(function(a,r){return a+(+r.count||0);},0);
      var gws=grp.reduce(function(a,r){return a+(+r.mean||0)*(+r.count||0);},0);
      var ges=grp.reduce(function(a,r){return a+(+r.exposure_sum||0);},0);
      kept.push({category:'(Other)',count:gn,
        pct:grp.reduce(function(a,r){return a+(+r.pct||0);},0),
        mean:gn>0?gws/gn:0,median:0,
        sum:grp.reduce(function(a,r){return a+(+r.sum||0);},0),
        exposure_sum:ges,
        exposure_pct:grp.reduce(function(a,r){return a+(+r.exposure_pct||0);},0)});
      data=kept;
    }
  }

  // Sort AFTER grouping
  if      (S.catSort==='metric') data.sort(function(a,b){return(+b[m]||0)-(+a[m]||0);});
  else if (S.catSort==='alpha')  data.sort(function(a,b){return String(a.category).localeCompare(String(b.category));});
  else                            data.sort(function(a,b){return(+b.count||0)-(+a.count||0);});

  var ps=S.catPgSz, tot=Math.max(1,Math.ceil(data.length/ps));
  S.catPage=Math.min(S.catPage,tot-1);
  var page=data.slice(S.catPage*ps,(S.catPage+1)*ps);

  var pgEl=document.getElementById('cat-pi');
  if(pgEl) pgEl.textContent=(S.catPage*ps+1)+'-'+Math.min((S.catPage+1)*ps,data.length)+' of '+data.length;
  ['cat-prev','cat-next'].forEach(function(bid,di){
    var b=document.getElementById(bid);
    if(b) b.disabled=(di===0?S.catPage===0:S.catPage>=tot-1);
  });
  var pgw=document.getElementById('cat-pg');
  if(pgw) pgw.style.display=data.length>ps?'flex':'none';

  var n=page.length;
  var maxLen=n>20?10:n>14?13:n>9?17:22;
  var cats  =page.map(function(r){return trunc(String(r.category),maxLen);});
  var expos =hasE?page.map(function(r){return+(r.exposure_sum)||0;}):[]; 
  var cnts  =page.map(function(r){return+(r.count)||0;});
  var mvals =page.map(function(r){return+(r[m])||0;});
  var mLbl  =({mean:'Mean',median:'Median',sum:'Sum'}[m]||m)+' '+window.D_TGT;

  var h=n>20?480:n>12?440:400;
  var title=col+' vs '+window.D_TGT+(tot>1?' (pg '+(S.catPage+1)+'/'+tot+')':'');
  buildChart('cat-ch',cats,expos,cnts,mvals,ec,mLbl,title,h);
  catTbl(page,data,m,mLbl,hasE,ec,col);
}

function catTbl(page,all,m,mLbl,hasE,ec,col){
  var h='<tr><th>Category</th><th>Count</th><th>%</th>'
    +(hasE?'<th>'+ec+'</th><th>Exp%</th>':'')
    +'<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows=page.map(function(r){
    var it=r.category==='(Other)'?' style="font-style:italic;color:var(--txt2)"':'';
    return '<tr'+it+'><td style="font-weight:500;max-width:220px;word-break:break-word">'+String(r.category)+'</td>'
      +'<td style="text-align:right">'+(+r.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+F(r.pct,1)+'%</td>'
      +(hasE?'<td style="text-align:right">'+F(r.exposure_sum,2)+'</td>'
            +'<td style="text-align:right">'+F(r.exposure_pct,1)+'%</td>':'')
      +'<td style="text-align:right;color:var(--acc);font-weight:700">'+F(r.mean,6)+'</td>'
      +'<td style="text-align:right">'+F(r.median,6)+'</td>'
      +'<td style="text-align:right">'+F(r.sum,2)+'</td></tr>';
  }).join('');
  var csvH='Category,Count,Pct'+(hasE?','+ec+',ExpPct':'')+',Mean,Median,Sum';
  var csv=csvH+'\n'+all.map(function(r){
    var b=['"'+r.category+'"',r.count,r.pct];
    if(hasE) b=b.concat([r.exposure_sum,r.exposure_pct]);
    return b.concat([r.mean,r.median,r.sum]).join(',');
  }).join('\n');
  var b64=btoa(unescape(encodeURIComponent(csv)));
  var tbl='<div class="tw"><table class="dt srt"><thead>'+h+'</thead><tbody>'+rows+'</tbody></table></div>'
    +'<div class="tc"><a class="dl" href="data:text/csv;base64,'+b64
    +'" download="'+(col||'cat')+'_vs_target.csv">Download CSV ('+all.length+' rows)</a></div>';
  var el=document.getElementById('cat-tbl'); if(el) el.innerHTML=tbl;
}

// ──────────────────────────────────────────────────────────────
//  NUMERICAL
// ──────────────────────────────────────────────────────────────
function selNum(col){ACT={type:'num',col:col};renderNum(col);}

function renderNum(col){
  var all=window.D_NUM&&window.D_NUM[col];
  if (!all||!window.Plotly) return;

  // Pick best method
  var methData=null;
  if(window.D_EC) methData=all['exposure'];
  if(!methData) methData=all['equal'];
  if(!methData) methData=all['quantile'];
  if(!methData){ var k=Object.keys(all); if(k.length) methData=all[k[0]]; }
  if(!methData){
    var el=document.getElementById('num-ch');
    if(el) el.innerHTML='<p class="cap" style="padding:26px">No binned data.</p>';
    return;
  }

  // Find closest pre-computed bin count
  var avail=Object.keys(methData).map(Number).filter(function(n){return n>0;});
  if(!avail.length) return;
  avail.sort(function(a,b){return a-b;});
  var closest=avail.reduce(function(best,k){
    return Math.abs(k-S.bins)<Math.abs(best-S.bins)?k:best;
  },avail[0]);

  var bins=methData[closest];
  if(!bins||!bins.length){
    document.getElementById('num-ch').innerHTML='<p class="cap" style="padding:26px">No bins for '+closest+'.</p>';
    return;
  }

  var m=S.metric;
  var ec=window.D_EC||'';
  var hasE=!!(ec&&bins[0]&&bins[0].exposure_sum!==undefined);

  var labs  =bins.map(function(b){return b.bin;});
  var expos =hasE?bins.map(function(b){return+(b.exposure_sum)||0;}):[]; 
  var cnts  =bins.map(function(b){return+(b.count)||0;});
  var mvals =bins.map(function(b){return+(b[m])||0;});
  var mLbl  =({mean:'Mean',median:'Median',sum:'Sum'}[m]||m)+' '+window.D_TGT;

  var bNote=(window.D_EC&&window.D_BY==='amount')?' equal '+ec+'/bin':'';
  var cNote=(closest!==S.bins)?' (closest to '+S.bins+')':'';
  var title=col+' vs '+window.D_TGT+' ['+closest+' bins'+bNote+']'+cNote;

  // Update label
  var bv=document.getElementById('bins-v');
  if(bv) bv.textContent=S.bins+' bins'+(closest!==S.bins?' -> using '+closest:'');

  var n=bins.length;
  var h=n>20?480:n>12?440:400;
  buildChart('num-ch',labs,expos,cnts,mvals,ec,mLbl,title,h);
  numTbl(bins,m,mLbl,hasE,ec,col,closest);
}

function numTbl(bins,m,mLbl,hasE,ec,col,nb){
  var h='<tr><th>Bin Range</th><th>Count</th><th>%</th>'
    +(hasE?'<th>'+ec+'</th><th>Exp%</th>':'')
    +'<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows=bins.map(function(b){
    return '<tr><td style="font-family:monospace;font-size:.77rem;white-space:nowrap">'+b.bin+'</td>'
      +'<td style="text-align:right">'+(+b.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+F(b.pct,1)+'%</td>'
      +(hasE?'<td style="text-align:right">'+F(b.exposure_sum,2)+'</td>'
            +'<td style="text-align:right">'+F(b.exposure_pct,1)+'%</td>':'')
      +'<td style="text-align:right;color:var(--acc);font-weight:700">'+F(b.mean,6)+'</td>'
      +'<td style="text-align:right">'+F(b.median,6)+'</td>'
      +'<td style="text-align:right">'+F(b.sum,2)+'</td></tr>';
  }).join('');
  var csvH='Bin,Bin_Lo,Bin_Hi,Count,Pct'+(hasE?','+ec+',ExpPct':'')+',Mean,Median,Sum';
  var csv=csvH+'\n'+bins.map(function(b){
    var base=['"'+b.bin+'"',b.bin_lo,b.bin_hi,b.count,b.pct];
    if(hasE) base=base.concat([b.exposure_sum,b.exposure_pct]);
    return base.concat([b.mean,b.median,b.sum]).join(',');
  }).join('\n');
  var b64=btoa(unescape(encodeURIComponent(csv)));
  var tbl='<div class="tw"><table class="dt srt"><thead>'+h+'</thead><tbody>'+rows+'</tbody></table></div>'
    +'<div class="tc"><a class="dl" href="data:text/csv;base64,'+b64
    +'" download="'+(col||'num')+'_binned.csv">Download CSV ('+nb+' bins)</a></div>';
  var el=document.getElementById('num-tbl'); if(el) el.innerHTML=tbl;
}

// init
window.addEventListener('load',function(){
  renderUni();
  var fc=window._FC, fn=window._FN;
  if(fc){ ACT={type:'cat',col:fc}; }
  if(fn){ ACT={type:'num',col:fn}; }
  // Pre-render all three so switching tabs is instant
  if(fc) renderCat(fc);
  if(fn) renderNum(fn);
  showTab('tab-u');
});
"""


# ==============================================================
#  generate_fs_report()
# ==============================================================
def generate_fs_report(results: dict,
                        output_path=None,
                        open_browser: bool = True,
                        offline: bool = False) -> str:
    """
    Generate the Feature Selection Dashboard.

    IMPORTANT: Always pass output_path.
    Returns None when output_path is given (prevents VS Code freeze).
    Returns HTML string when no output_path (for Databricks displayHTML).

    Example
    -------
    generate_fs_report(
        {"deep_target_analysis": ta, "target_col": "frequency", "n_rows": len(df)},
        output_path=r"C:\\Users\\you\\Desktop\\output.html"
    )
    """
    import numpy as np
    import pandas as pd

    target = results.get("target_col")
    dta    = results.get("deep_target_analysis", {})
    n_rows = results.get("n_rows", 0)

    if not target:
        return "<html><body><p>No target_col in results.</p></body></html>"
    if not dta:
        return ("<html><body><p>No deep_target_analysis. "
                "Use run_target_analysis() or plan.set_sections(target_analysis=True).</p></body></html>")

    cat_cols    = sorted(dta.get("categorical", {}).keys())
    num_cols    = sorted(dta.get("numeric",     {}).keys())
    uni         = dta.get("univariate", {})
    n_bins_list = dta.get("n_bins_list", DEFAULT_BINS)
    exposure_col= dta.get("exposure_col") or ""
    bin_by      = dta.get("bin_by", "amount")
    ta_elapsed  = dta.get("elapsed_sec", 0)
    n_bins_def  = max(n_bins_list) if n_bins_list else 20

    # ── stat cards ──────────────────────────────────────────────
    stats    = uni.get("stats", {})
    zero_pct = float(stats.get("zero_pct") or 0)

    stat_cards = ""
    for lbl, key, fmt_s in [
        ("Count","count",",.0f"),("Mean","mean",".4g"),("Median","median",".4g"),
        ("Std Dev","std",".4g"),("P95","p95",".4g"),("P99","p99",".4g"),
        ("Skewness","skewness",".3f"),("Zero %","zero_pct",".2f"),
    ]:
        v = stats.get(key); disp = "--"
        if v is not None:
            try:
                fv = float(v)
                disp = (f"{int(fv):,}" if key=="count"
                        else f"{fv:.2f}%" if key=="zero_pct"
                        else format(fv, fmt_s))
            except Exception:
                disp = str(v)
        wc = ' warn-card' if key=='zero_pct' and zero_pct>=50 else ''
        stat_cards += (f'<div class="sc{wc}"><div class="sv">{disp}</div>'
                       f'<div class="sl">{lbl}</div></div>')

    # ── zero-inflation note ─────────────────────────────────────
    zi_notice = ""
    if zero_pct >= 50:
        zi_notice = f"""<div class="zi-note">
<strong>Zero-inflated target ({zero_pct:.1f}% zeros):</strong>
P25, P75, P95 are all 0 -- this is mathematically correct when {zero_pct:.0f}% of values are zero.
Only the top {100-zero_pct:.1f}% of rows have non-zero values.<br>
<strong>Recommendation:</strong> Switch metric to <strong>Sum</strong> for clearer signal.
For modelling, use <strong>Tweedie GLM</strong> or a two-stage frequency x severity approach.
</div>"""

    # ── legend ──────────────────────────────────────────────────
    exp_item = (f'<span class="li"><span class="ls" style="background:rgba(0,43,92,.65)"></span>'
                f'{_esc(exposure_col)} (left axis)</span>'
                if exposure_col else "")
    legend = (f'<div class="leg">'
              f'{exp_item}'
              f'<span class="li"><span class="ls" style="background:rgba(99,140,185,.55)"></span>'
              f'Count (right axis)</span>'
              f'<span class="li"><span class="lline"></span>Mean {_esc(target)} (right axis -- own scale)</span>'
              f'</div>')

    cat_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in cat_cols)
    num_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in num_cols)
    no_cat   = '<div class="warn">No categorical features found.</div>' if not cat_cols else ""
    no_num   = '<div class="warn">No numeric features found.</div>'     if not num_cols else ""

    # ── data script ─────────────────────────────────────────────
    data_script = f"""<script>
window.D_TGT={_j(target)};
window.D_UNI={_j(uni)};
window.D_CAT={_j(dta.get("categorical",{}))};
window.D_NUM={_j(dta.get("numeric",{}))};
window.D_EC ={_j(exposure_col)};
window.D_BY ={_j(bin_by)};
window._FC  ={_j(cat_cols[0] if cat_cols else "")};
window._FN  ={_j(num_cols[0] if num_cols else "")};
</script>"""

    if offline:
        try:
            import plotly
            jp = Path(plotly.__file__).parent / "package_data" / "plotly.min.js"
            plotly_tag = (f"<script>{jp.read_text()}</script>"
                          if jp.exists() else f'<script src="{PLOTLY_CDN}"></script>')
        except Exception:
            plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'
    else:
        plotly_tag = f'<script src="{PLOTLY_CDN}"></script>'

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FS -- {_esc(target)} -- {n_rows:,} rows</title>
{plotly_tag}
<style>{CSS}</style>
</head>
<body>
{data_script}

<div id="fso"><div id="fsb">
  <button id="fsc" onclick="closeFS()">&#10005;</button>
  <div id="fsp"></div>
</div></div>

<div class="hdr">
  <div class="hdr-row">
    <div class="logo">RC</div>
    <div>
      <div class="hdr-title">Feature Selection Dashboard</div>
      <div class="hdr-sub">Chubb Risk Cohorts v5</div>
    </div>
    <div class="hdr-meta">
      <span>Rows <strong>{n_rows:,}</strong></span>
      <span>Target <strong>{_esc(target)}</strong></span>
      <span>Cat <strong>{len(cat_cols)}</strong></span>
      <span>Num <strong>{len(num_cols)}</strong></span>
      {"<span>Exposure <strong>" + _esc(exposure_col) + "</strong></span>" if exposure_col else ""}
      <span>Computed <strong>{ta_elapsed:.1f}s</strong></span>
    </div>
  </div>
  <div class="nav">
    <button class="nav-btn on" data-tab="tab-u" onclick="showTab('tab-u')">Target Overview</button>
    <button class="nav-btn"    data-tab="tab-c" onclick="showTab('tab-c')">Categorical vs Target</button>
    <button class="nav-btn"    data-tab="tab-n" onclick="showTab('tab-n')">Numerical vs Target</button>
  </div>
</div>

<div class="page">

<!-- ═══ TARGET OVERVIEW (no controls) ═══ -->
<div id="tab-u" class="tab on">
  <h3 class="sh">Target Overview -- {_esc(target)}</h3>
  <p class="cap">{n_rows:,} rows &bull; full dataset &bull; no sampling</p>
  {zi_notice}
  <div class="sg">{stat_cards}</div>
  <div class="cw">
    <div class="cl2"><div class="sp"></div><span>Rendering...</span></div>
    <div id="uni-ch" style="width:100%;min-height:380px"></div>
  </div>
  <div id="uni-tbl" style="margin-top:18px"></div>
</div>

<!-- ═══ CATEGORICAL (Sort + Group controls) ═══ -->
<div id="tab-c" class="tab">
  <h3 class="sh">Categorical vs {_esc(target)}</h3>
  <!-- Tab-specific controls -->
  <div class="tab-ctrl">
    <div class="cg">
      <span class="cl">Metric</span>
      <div class="br">
        <button class="cb mb2 on" data-m="mean"   onclick="setMetric('mean')">Mean</button>
        <button class="cb mb2"    data-m="median" onclick="setMetric('median')">Median</button>
        <button class="cb mb2"    data-m="sum"    onclick="setMetric('sum')">Sum</button>
      </div>
    </div>
    <div class="csep"></div>
    <div class="cg">
      <span class="cl">Sort</span>
      <div class="br">
        <button class="cb sb on" data-s="count"  onclick="setSort('count')">By Count</button>
        <button class="cb sb"    data-s="metric" onclick="setSort('metric')">By Metric</button>
        <button class="cb sb"    data-s="alpha"  onclick="setSort('alpha')">A-Z</button>
      </div>
    </div>
    <div class="csep"></div>
    <div class="cg">
      <span class="cl">Group small &lt; <span id="grp-lbl" style="color:var(--acc);font-weight:700">Off</span></span>
      <input type="range" class="rng" min="0" max="5" step="0.5" value="0" oninput="setGrp(this.value)">
    </div>
    <div class="csep"></div>
    <label class="tg"><input type="checkbox" checked onchange="togCnt(this)"> Count bars</label>
    <div style="margin-left:auto;font-size:.71rem;color:var(--txt3)">
      {n_rows:,} rows &bull; {ta_elapsed:.1f}s
    </div>
  </div>
  {legend}
  {no_cat}
  {(f'<div class="fr"><label class="fl">Feature</label>'
    f'<select class="fsel" onchange="selCat(this.value)">{cat_opts}</select>'
    f'<span style="font-size:.77rem;color:var(--txt2)">{len(cat_cols)} features &bull; 20/page</span>'
    f'</div>') if cat_cols else ""}
  {('<div id="cat-pg" class="pgc" style="display:none">'
    '<button class="pgb" id="cat-prev" onclick="catPg(-1)">Prev</button>'
    '<span class="pgi" id="cat-pi"></span>'
    '<button class="pgb" id="cat-next" onclick="catPg(1)">Next</button>'
    '</div>') if cat_cols else ""}
  {('<div class="cw"><div class="cl2"><div class="sp"></div><span>Rendering...</span></div>'
    '<div id="cat-ch" style="width:100%;min-height:400px"></div></div>'
    '<div id="cat-tbl" style="margin-top:14px"></div>') if cat_cols else ""}
</div>

<!-- ═══ NUMERICAL (Bins slider only) ═══ -->
<div id="tab-n" class="tab">
  <h3 class="sh">Numerical vs {_esc(target)}</h3>
  <!-- Tab-specific controls -->
  <div class="tab-ctrl">
    <div class="cg">
      <span class="cl">Metric</span>
      <div class="br">
        <button class="cb mb2 on" data-m="mean"   onclick="setMetric('mean')">Mean</button>
        <button class="cb mb2"    data-m="median" onclick="setMetric('median')">Median</button>
        <button class="cb mb2"    data-m="sum"    onclick="setMetric('sum')">Sum</button>
      </div>
    </div>
    <div class="csep"></div>
    <label class="tg"><input type="checkbox" checked onchange="togCnt(this)"> Count bars</label>
    <div class="csep"></div>
    <div class="cg">
      <span class="cl">Bins</span>
      <span class="bl" id="bins-v">{n_bins_def} bins</span>
      <input type="range" class="rng" min="1" max="30" step="1"
             value="{n_bins_def}" oninput="setBins(this.value)">
      <span style="font-size:.73rem;color:var(--txt3)">1-30</span>
    </div>
    <div style="margin-left:auto;font-size:.71rem;color:var(--txt3)">
      pre-computed: {", ".join(str(b) for b in sorted(n_bins_list))}
    </div>
  </div>
  {legend}
  {no_num}
  {(f'<div class="fr"><label class="fl">Feature</label>'
    f'<select id="num-feat-sel" class="fsel" onchange="selNum(this.value)">{num_opts}</select>'
    f'<span style="font-size:.77rem;color:var(--txt2)">{len(num_cols)} features</span>'
    f'</div>') if num_cols else ""}
  {('<div class="cw"><div class="cl2"><div class="sp"></div><span>Rendering...</span></div>'
    '<div id="num-ch" style="width:100%;min-height:400px"></div></div>'
    '<div id="num-tbl" style="margin-top:14px"></div>') if num_cols else ""}
</div>

</div>

<script>
{JS}
S.bins = {n_bins_def};
</script>
</body>
</html>"""

    if output_path:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(html, encoding="utf-8")
        size = path.stat().st_size / 1024
        print(f"[FS] Saved -> {path}  ({size:.0f} KB)")
        if open_browser and not str(output_path).startswith("/dbfs"):
            try:
                webbrowser.open(path.resolve().as_uri())
            except Exception:
                pass
        return None  # Never return HTML to Jupyter -- prevents VS Code freeze

    return html
