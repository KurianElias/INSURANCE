# -*- coding: utf-8 -*-
"""
eda_toolkit -- Insurance EDA Toolkit v5

Lazy imports: heavy libraries (pandas, numpy, plotly) are only loaded
when you actually call a function, not at import time.
This keeps `from eda_toolkit import ...` fast (<0.1s).

Usage:
    from eda_toolkit import inspect, run_eda, generate_report, generate_fs_report
    from eda_toolkit import run_target_analysis
"""

__version__ = "5.0.0"

__all__ = [
    "inspect", "run_eda", "launch_app", "print_summary",
    "generate_report", "generate_fs_report", "run_target_analysis",
]

# ── lazy loader ───────────────────────────────────────────────────────────────
# Each function is a thin wrapper that imports the real module only on first call.
# After the first call, the real function is cached -- subsequent calls are fast.

def inspect(df, target_col=None, **kwargs):
    """Inspect a DataFrame and return an InspectPlan."""
    from .launch import inspect as _fn
    return _fn(df, target_col=target_col, **kwargs)

def run_eda(df, plan, **kwargs):
    """Run the full EDA pipeline and return a results dict."""
    from .launch import run_eda as _fn
    return _fn(df, plan, **kwargs)

def launch_app(results, output_path=None, open_browser=True, offline=False):
    """Generate and open the EDA Dashboard HTML report (Streamlit removed)."""
    from .launch import launch_app as _fn
    return _fn(results, output_path=output_path,
               open_browser=open_browser, offline=offline)

def print_summary(results, **kwargs):
    """Print a text summary of EDA results."""
    from .launch import print_summary as _fn
    return _fn(results, **kwargs)

def generate_report(results, output_path=None, open_browser=True, offline=False):
    """Generate the EDA Dashboard HTML report."""
    from .html_report import generate_report as _fn
    return _fn(results, output_path=output_path,
               open_browser=open_browser, offline=offline)

def generate_fs_report(results, output_path=None, open_browser=True, offline=False):
    """Generate the Feature Selection Dashboard HTML report."""
    from .feature_selection_dashboard import generate_fs_report as _fn
    return _fn(results, output_path=output_path,
               open_browser=open_browser, offline=offline)

def run_target_analysis(df, target_col, exposure_col=None, bin_by="amount",
                         n_bins=20, dtype_map=None):
    """
    Run Target Analysis independently of run_eda().
    Returns a dict compatible with generate_fs_report().
    """
    from .feature_selection_dashboard import run_target_analysis as _fn
    return _fn(df, target_col=target_col, exposure_col=exposure_col,
               bin_by=bin_by, n_bins=n_bins, dtype_map=dtype_map)
