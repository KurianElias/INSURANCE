# -*- coding: utf-8 -*-
"""
target_analysis_html.py - Insurance EDA Toolkit v5
Generates the Target Analysis HTML tab section.

Chart design (from screenshots feedback):
  - Categorical: grouped bars (Count + Exposure side-by-side) + Mean line on y2
  - Numerical:   grouped bars (Count + Exposure side-by-side) + Mean line on y2
  - Max 30 categories shown, rest paginated via "Load more"
  - X-axis labels: max 20 chars, angle only when >10 items
  - Cramers V chart: rendered on tab activation not on page load
"""
from __future__ import annotations
import json, math
import numpy as np
import pandas as pd

class _Enc(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, (np.integer,)):  return int(o)
        if isinstance(o, (np.floating,)): return float(o)
        if isinstance(o, np.ndarray):     return o.tolist()
        try:
            if pd.isna(o): return None
        except Exception:
            pass
        return super().default(o)

def _j(v):  return json.dumps(v, cls=_Enc, separators=(",", ":"))
def _esc(s):
    return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace('"','&quot;')

# -- CSS -----------------------------------------------------------------------
TA_CSS = """
/* -- Feature Selection / Target Analysis -- */
.ta-page{padding:0}
.ta-ctrl-bar{display:flex;flex-wrap:wrap;gap:12px;align-items:flex-end;
             background:#fff;border:1px solid var(--bdr);
             border-left:4px solid var(--acc);
             border-radius:var(--r);padding:14px 18px;margin-bottom:18px;
             box-shadow:var(--sh)}
.ta-ctrl-grp{display:flex;flex-direction:column;gap:5px;min-width:0}
.ta-ctrl-lbl{font-size:.70rem;font-weight:700;text-transform:uppercase;
             letter-spacing:.07em;color:var(--txt2)}
.ta-btn-row{display:flex;gap:3px;flex-wrap:wrap}
.ta-btn{padding:5px 13px;border:1px solid var(--bdr);border-radius:6px;
        font-size:.79rem;font-weight:500;cursor:pointer;background:#fff;
        color:var(--txt2);font-family:inherit;transition:all .12s;white-space:nowrap}
.ta-btn:hover{border-color:var(--navy2);color:var(--navy2);background:#f0f4fa}
.ta-btn.on{background:var(--navy);color:#fff;border-color:var(--navy);font-weight:600}
.ta-toggle-lbl{display:flex;align-items:center;gap:6px;font-size:.82rem;
               cursor:pointer;user-select:none;padding:5px 11px;
               border:1px solid var(--bdr);border-radius:6px;background:#fff;
               transition:all .12s;white-space:nowrap}
.ta-toggle-lbl input{accent-color:var(--acc);width:14px;height:14px;cursor:pointer}
.ta-toggle-lbl:hover{border-color:var(--acc);background:var(--acc-l)}

/* Feature selector row */
.ta-feat-row{display:flex;flex-wrap:wrap;gap:12px;align-items:center;
             background:#fff;border:1px solid var(--bdr);
             border-left:4px solid var(--navy2);
             border-radius:var(--r);padding:12px 16px;margin-bottom:14px;
             box-shadow:var(--sh)}
.ta-feat-lbl{font-size:.82rem;font-weight:700;color:var(--navy);white-space:nowrap}
.ta-feat-sel{padding:7px 12px;border:1px solid var(--bdr);border-radius:7px;
             font-size:.87rem;font-family:inherit;background:#fff;color:var(--txt);
             min-width:220px;flex:1;outline:none;cursor:pointer;max-width:380px}
.ta-feat-sel:focus{border-color:var(--navy2);box-shadow:0 0 0 2px rgba(0,74,151,.1)}
.ta-method-btn{padding:5px 13px;border:1px solid var(--bdr);border-radius:6px;
               font-size:.79rem;font-weight:500;cursor:pointer;background:#fff;
               color:var(--txt2);font-family:inherit;transition:all .12s}
.ta-method-btn.on{background:var(--navy2);color:#fff;border-color:var(--navy2)}
.ta-bins-lbl{font-size:.79rem;color:var(--navy);font-weight:600;min-width:48px}
.ta-slider{accent-color:var(--acc);cursor:pointer;width:120px}

/* Stat cards */
.ta-stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));
              gap:10px;margin:12px 0 18px}
.ta-stat{background:#fff;border:1px solid var(--bdr);border-top:3px solid var(--acc);
         border-radius:var(--r);padding:.55rem 1rem .45rem;box-shadow:var(--sh)}
.ta-stat-v{font-size:1.05rem;font-weight:700;color:var(--navy);line-height:1.2}
.ta-stat-l{font-size:.67rem;color:var(--txt2);text-transform:uppercase;
           letter-spacing:.05em;margin-top:2px}

/* Sub-tabs inside TA */
.ta-sub-tabs{display:flex;gap:0;border-bottom:2px solid var(--bdr);
             margin-bottom:18px;overflow-x:auto}
.ta-sub-tab{padding:9px 20px;font-size:13px;font-weight:500;cursor:pointer;
            border:none;background:none;color:var(--txt2);
            border-bottom:2px solid transparent;margin-bottom:-2px;
            white-space:nowrap;font-family:inherit;transition:all .13s}
.ta-sub-tab:hover{color:var(--navy);background:#f5f8ff}
.ta-sub-tab.on{color:var(--navy);border-bottom-color:var(--acc);font-weight:700}
.ta-panel{display:none}
.ta-panel.on{display:block}

/* Page controls for large categorical sets */
.ta-page-ctrl{display:flex;align-items:center;gap:10px;margin:8px 0 12px;
              font-size:.82rem;color:var(--txt2)}
.ta-page-btn{padding:4px 12px;border:1px solid var(--bdr);border-radius:5px;
             font-size:.78rem;cursor:pointer;background:#fff;color:var(--navy2);
             transition:all .12s}
.ta-page-btn:hover{background:var(--navy2);color:#fff;border-color:var(--navy2)}
.ta-page-info{font-weight:600;color:var(--navy)}

/* Chart note */
.chart-note{font-size:.75rem;color:var(--txt2);margin:4px 0 10px;
            padding:5px 10px;background:#f5f8ff;border-radius:5px;
            border-left:3px solid var(--navy2)}
"""

# -- JavaScript ----------------------------------------------------------------
TA_JS = r"""
// ================================================================
//  FEATURE SELECTION DASHBOARD -- Target Analysis JS
// ================================================================

var TA = {
  metric:     'mean',
  logY:       false,
  showCount:  true,
  showExpo:   true,
  catSort:    'count',
  otherThresh: 0,
  catPage:    0,
  catPageSize: 30,
  numMethod:  'equal',
  numBins:    20,
};
var TA_ACTIVE = { type: null, col: null };

// -- formatting ------------------------------------------------
function taFmt(v, digits) {
  if (v === null || v === undefined || v === '') return '--';
  var f = +v;
  if (isNaN(f)) return '--';
  var d = digits !== undefined ? digits : 4;
  if (Math.abs(f) >= 1e6)  return (f/1e6).toFixed(3)+'M';
  if (Math.abs(f) >= 1e3)  return f.toLocaleString(undefined,{maximumFractionDigits:2});
  return f.toFixed(d);
}
function taShort(s, n) {
  n = n || 22;
  return s && s.length > n ? s.slice(0,n-2)+'..' : s;
}

// -- global controls -------------------------------------------
function taSetMetric(m) {
  TA.metric = m;
  document.querySelectorAll('.ta-metric-btn').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-m') === m);
  });
  taRefresh();
}
function taToggleLog(cb)   { TA.logY      = cb.checked; taRefresh(); }
function taToggleCount(cb) { TA.showCount = cb.checked; taRefresh(); }
function taToggleExpo(cb)  { TA.showExpo  = cb.checked; taRefresh(); }
function taSetSort(s) {
  TA.catSort = s; TA.catPage = 0;
  document.querySelectorAll('.ta-sort-btn').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-s') === s);
  });
  taRefresh();
}
function taSetOther(v) {
  TA.otherThresh = +v; TA.catPage = 0;
  var el = document.getElementById('ta-other-lbl');
  if (el) el.textContent = v > 0 ? '<'+v+'% grouped' : 'Off';
  taRefresh();
}
function taSetMethod(m) {
  TA.numMethod = m;
  document.querySelectorAll('.ta-method-btn').forEach(function(b){
    b.classList.toggle('on', b.getAttribute('data-meth') === m);
  });
  taRefreshNum();
}
function taSetBinsByIdx(idx, bins) {
  TA.numBins = bins[+idx] || bins[0];
  var el = document.getElementById('ta-bins-lbl');
  if (el) el.textContent = TA.numBins + ' bins';
  taRefreshNum();
}
function taRefresh() {
  if (TA_ACTIVE.type === 'cat') taRenderCat(TA_ACTIVE.col);
  else if (TA_ACTIVE.type === 'num') taRenderNum(TA_ACTIVE.col);
  else if (TA_ACTIVE.type === 'uni') taRenderUni();
}
function taRefreshNum() {
  if (TA_ACTIVE.type === 'num') taRenderNum(TA_ACTIVE.col);
}

// -- sub-tab navigation ----------------------------------------
function taShowTab(btn, id) {
  var wrap = document.getElementById('ta-main');
  if (!wrap) return;
  wrap.querySelectorAll('.ta-panel').forEach(function(p){ p.classList.remove('on'); });
  wrap.querySelectorAll('.ta-sub-tab').forEach(function(b){ b.classList.remove('on'); });
  var pane = document.getElementById(id);
  if (pane) pane.classList.add('on');
  btn.classList.add('on');
  // Trigger render for the activated panel
  setTimeout(function(){
    if (id === 'ta-uni') taRenderUni();
    else if (id === 'ta-cat' && TA_ACTIVE.col) taRenderCat(TA_ACTIVE.col);
    else if (id === 'ta-num' && TA_ACTIVE.col) taRenderNum(TA_ACTIVE.col);
  }, 80);
}

// ================================================================
//  UNIVARIATE
//  Zero-inflated (>=50% zeros): two side-by-side panels
//    Left: full distribution  Right: non-zero log1p
//  Otherwise: single histogram
// ================================================================
function taRenderUni() {
  TA_ACTIVE.type = 'uni';
  var D = window.TA_UNI;
  if (!D || !window.Plotly) return;

  var hist    = D.hist_clip;
  var histLog = D.hist_log;
  var stats   = D.stats || {};
  var zeroPct = +(stats.zero_pct || 0);
  var isZI    = zeroPct >= 50;

  if (!hist || !hist.counts || !hist.counts.length) return;

  var gc = 'rgba(212,220,235,0.55)';
  var edges = hist.edges, counts = hist.counts;
  var mids = [], labs = [];
  for (var i = 0; i < counts.length; i++) {
    var lo = +edges[i], hi = +edges[i+1];
    mids.push((lo+hi)/2);
    labs.push('['+lo.toPrecision(4)+', '+hi.toPrecision(4)+')');
  }

  var hasNZ = isZI && histLog && histLog.counts && histLog.counts.length > 0;

  var traces, layout;
  if (hasNZ) {
    // Two panels: full | non-zero log1p
    var eL=histLog.edges, cL=histLog.counts, mL=[], lL=[];
    for (var j=0; j<cL.length; j++) {
      var lo2=+eL[j], hi2=+eL[j+1];
      mL.push((lo2+hi2)/2);
      lL.push('['+lo2.toPrecision(3)+', '+hi2.toPrecision(3)+')');
    }
    traces = [
      { type:'bar', x:mids, y:counts, name:'All values',
        xaxis:'x', yaxis:'y',
        marker:{color:'rgba(0,43,92,0.68)',line:{color:'rgba(0,43,92,0.88)',width:0.3}},
        hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>', text:labs },
      { type:'bar', x:mL, y:cL, name:'Non-zero (log1p)',
        xaxis:'x2', yaxis:'y2',
        marker:{color:'rgba(200,146,42,0.65)',line:{color:'rgba(200,146,42,0.9)',width:0.3}},
        hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>', text:lL },
    ];
    layout = {
      title:{text:(window.TA_TARGET||'Target')+' -- Distribution ('+zeroPct.toFixed(1)+'% zeros)',
             font:{size:13,color:'#0D1B2E'},x:0.5,xanchor:'center',pad:{t:6}},
      grid:{rows:1,columns:2,pattern:'independent'},
      xaxis:{domain:[0,0.46],anchor:'y',title:{text:'Value',font:{size:11}},
             gridcolor:gc,zeroline:false},
      yaxis:{anchor:'x',title:{text:'Count',font:{size:11}},gridcolor:gc},
      xaxis2:{domain:[0.54,1],anchor:'y2',
              title:{text:'log1p(non-zero)',font:{size:11,color:'#C8922A'}},
              gridcolor:gc,zeroline:false},
      yaxis2:{anchor:'x2',title:{text:'Count',font:{size:11}},gridcolor:gc},
      paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
      font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
      height:340,margin:{l:62,r:20,t:52,b:55},bargap:0.04,
      legend:{orientation:'h',x:0.5,xanchor:'center',y:1.06,font:{size:11}},
      annotations:[
        {text:'Full distribution (incl. zeros)',xref:'paper',yref:'paper',
         x:0.23,y:1.04,showarrow:false,font:{size:10,color:'rgba(0,43,92,0.8)'}},
        {text:'Non-zero only (log1p)',xref:'paper',yref:'paper',
         x:0.77,y:1.04,showarrow:false,font:{size:10,color:'#C8922A'}},
      ],
    };
  } else {
    traces = [{
      type:'bar', x:mids, y:counts, name:'Count',
      marker:{color:'rgba(0,43,92,0.68)',line:{color:'rgba(0,43,92,0.88)',width:0.3}},
      hovertemplate:'%{text}<br>Count: %{y:,}<extra></extra>', text:labs,
    }];
    layout = {
      title:{text:(window.TA_TARGET||'Target')+' -- Distribution',
             font:{size:13,color:'#0D1B2E'},x:0.5,xanchor:'center',pad:{t:6}},
      xaxis:{title:{text:window.TA_TARGET||'Target',font:{size:11}},
             gridcolor:gc,zeroline:false},
      yaxis:{title:{text:'Count',font:{size:11}},gridcolor:gc},
      paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
      font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
      height:340,margin:{l:62,r:20,t:50,b:55},bargap:0.04,
    };
  }
  renderTAChart('ta-uni-chart', traces, layout);
  taBuildUniTable();
}

function taBuildUniTable() {
  var D = window.TA_UNI; if (!D) return;
  var s = D.stats;
  var zeroPct = +(s.zero_pct||0);
  var rows = [['Count',(s.count||0).toLocaleString()],
    ['Mean',taFmt(s.mean,6)],['Median',taFmt(s.median,6)],
    ['Std Dev',taFmt(s.std,4)],['Min',taFmt(s.min,6)],['Max',taFmt(s.max,4)],
    ['P25',taFmt(s.p25,6)],['P75',taFmt(s.p75,4)],
    ['P95',taFmt(s.p95,4)],['P99',taFmt(s.p99,4)],
    ['Skewness',taFmt(s.skewness,3)],['Zero %',taFmt(s.zero_pct,2)+'%']];
  var html='<div class="tw" style="max-width:420px"><table class="dt"><thead>'
    +'<tr><th>Statistic</th><th style="text-align:right">Value</th></tr></thead><tbody>';
  rows.forEach(function(r){
    var warn = (r[0]==='Zero %'&&zeroPct>=50)?' style="color:#b45309;font-weight:700"':'';
    html+='<tr><td>'+r[0]+'</td>'
         +'<td style="text-align:right;font-weight:600;color:var(--navy)"'+warn+'>'+r[1]+'</td></tr>';
  });
  html+='</tbody></table></div>';
  if (zeroPct >= 50) {
    html+='<p style="font-size:.74rem;color:var(--txt3);margin-top:6px;padding:6px 10px;'
         +'background:#f8fafc;border-radius:5px;border-left:2px solid var(--bdr)">'
         +'P25/P75/P95 show 0 because '+zeroPct.toFixed(1)+'% of rows are zero. '
         +'Use <strong>Sum</strong> as metric for clearer signal. '
         +'Consider Tweedie GLM or two-stage modelling.</p>';
  }
  var el=document.getElementById('ta-uni-stats'); if(el) el.innerHTML=html;
}

// ================================================================
//  CATEGORICAL -- grouped bars (Count + Exposure) + Mean line
// ================================================================
function taSelectCat(col) {
  TA_ACTIVE = {type:'cat', col:col};
  TA.catPage = 0;
  taRenderCat(col);
}

function taCatPage(dir) {
  TA.catPage = Math.max(0, TA.catPage + dir);
  taRenderCat(TA_ACTIVE.col);
}

function taRenderCat(col) {
  var allData = window.TA_CAT && window.TA_CAT[col];
  if (!allData || !allData.length || !window.Plotly) return;
  var m = TA.metric;
  var expCol = window.TA_EXPOSURE_COL || '';
  var hasExp = allData.length > 0 && allData[0].exposure_sum !== undefined && expCol;

  // -- 1. Apply Other grouping --------------------------------
  var data = allData.slice();
  if (TA.otherThresh > 0) {
    var kept = [], grp = [];
    data.forEach(function(r){ (+r.pct < TA.otherThresh ? grp : kept).push(r); });
    if (grp.length) {
      var n = grp.reduce(function(a,r){return a+(+r.count||0);},0);
      var ws= grp.reduce(function(a,r){return a+(+r.mean||0)*(+r.count||0);},0);
      var es= grp.reduce(function(a,r){return a+(+r.exposure_sum||0);},0);
      var ep= grp.reduce(function(a,r){return a+(+r.exposure_pct||0);},0);
      kept.push({category:'(Other)',count:n,
        pct:grp.reduce(function(a,r){return a+(+r.pct||0);},0),
        mean:n>0?ws/n:0, median:0,
        sum:grp.reduce(function(a,r){return a+(+r.sum||0);},0),
        exposure_sum:es, exposure_pct:ep});
    }
    data = kept;
  }

  // -- 2. Sort -----------------------------------------------
  if (TA.catSort==='count')  data.sort(function(a,b){return (+b.count||0)-(+a.count||0);});
  else if (TA.catSort==='metric') data.sort(function(a,b){return (+b[m]||0)-(+a[m]||0);});
  else data.sort(function(a,b){return a.category.localeCompare(b.category);});

  // -- 3. Pagination -----------------------------------------
  var ps   = TA.catPageSize;
  var totPg= Math.ceil(data.length / ps);
  TA.catPage = Math.min(TA.catPage, Math.max(0, totPg-1));
  var page = data.slice(TA.catPage*ps, (TA.catPage+1)*ps);

  // Update pagination controls
  var pgEl = document.getElementById('ta-cat-pageinfo');
  if (pgEl) pgEl.textContent = 'Showing '+(TA.catPage*ps+1)+'-'+Math.min((TA.catPage+1)*ps,data.length)+' of '+data.length;
  var prevBtn = document.getElementById('ta-cat-prev');
  var nextBtn = document.getElementById('ta-cat-next');
  if (prevBtn) prevBtn.disabled = TA.catPage === 0;
  if (nextBtn) nextBtn.disabled = TA.catPage >= totPg-1;
  var pageWrap = document.getElementById('ta-cat-paging');
  if (pageWrap) pageWrap.style.display = data.length > ps ? 'flex' : 'none';

  // -- 4. Build traces ---------------------------------------
  var cats   = page.map(function(r){ return taShort(r.category, 24); });
  var counts = page.map(function(r){ return +r.count||0; });
  var expos  = hasExp ? page.map(function(r){ return +r.exposure_sum||0; }) : [];
  var mvals  = page.map(function(r){ return +r[m]||0; });
  var metricLabel = ({mean:'Mean',median:'Median',sum:'Sum'}[m]||m)+' '+window.TA_TARGET;
  var ylog = TA.logY ? 'log' : 'linear';

  var traces = [];
  var gc2 = 'rgba(212,220,235,0.50)';

  // Bar 1 -- Exposure (navy, LEFT axis y -- primary)
  if (hasExp && TA.showExpo) {
    traces.push({
      type:'bar', x:cats, y:expos, name:expCol, yaxis:'y',
      marker:{color:'rgba(0,43,92,0.68)',line:{color:'rgba(0,43,92,0.88)',width:0.4}},
      hovertemplate:'<b>%{x}</b><br>'+expCol+': %{y:,.2f}<extra></extra>',
    });
  }

  // Bar 2 -- Count (steel, LEFT axis y -- when no exposure; RIGHT y2 when exposure present)
  if (TA.showCount) {
    var cntAxis = hasExp && TA.showExpo ? 'y2' : 'y';
    traces.push({
      type:'bar', x:cats, y:counts, name:'Count', yaxis:cntAxis,
      marker:{color:'rgba(99,140,185,0.50)',line:{color:'rgba(80,120,165,0.70)',width:0.4}},
      hovertemplate:'<b>%{x}</b><br>Count: %{y:,}<extra></extra>',
    });
  }

  // Line -- mean/median/sum target (gold, RIGHT axis y3 -- own scale, never distorted)
  var validM = mvals.filter(function(v){return v!==null&&isFinite(+v);});
  var mMin = validM.length ? Math.min.apply(null,validM) : 0;
  var mMax = validM.length ? Math.max.apply(null,validM) : 1;
  var mSpan = mMax - mMin;
  var mPad = mSpan > 0 ? mSpan*0.18 : Math.abs(mMax)*0.20 || 0.001;
  var mR0 = mMin >= 0 ? 0 : mMin - mPad;
  var mR1 = mMax + mPad;

  traces.push({
    type:'scatter', mode:'lines+markers', x:cats, y:mvals,
    name:metricLabel, yaxis:'y3',
    line:{color:'#C8922A',width:2.8},
    marker:{color:'#C8922A',size:9,symbol:'circle',line:{color:'#fff',width:1.8}},
    hovertemplate:'<b>%{x}</b><br>'+metricLabel+': %{y:.6g}<extra></extra>',
  });

  // -- 5. Layout ---------------------------------------------
  var n = cats.length;
  var maxLbl = cats.reduce(function(a,s){return s&&s.length>a?s.length:a;},0);
  var angle = 0;
  if (n>18||maxLbl>14) angle=-55;
  else if (n>12||maxLbl>9) angle=-40;
  else if (n>7) angle=-28;
  var bMgn = angle<-45?145:angle<-20?115:72;
  var h = n>20?500:n>12?450:400;
  var layout = {
    title:{text:col+' vs '+window.TA_TARGET+(totPg>1?'  (pg '+(TA.catPage+1)+'/'+totPg+')':''),
           font:{size:13,color:'#0D1B2E'},x:0.5,xanchor:'center',pad:{t:8}},
    xaxis:{type:'category',tickangle:angle,
           tickfont:{size:Math.max(9,12-Math.floor(n/10)),color:'#4A5568'},
           gridcolor:gc2,zeroline:false,showgrid:false,automargin:true},
    yaxis:{title:{text:hasExp&&TA.showExpo?expCol:'Count',
                  font:{size:11,color:'rgba(0,43,92,0.80)'}},
           tickfont:{color:'rgba(0,43,92,0.75)',size:10},
           gridcolor:gc2,zeroline:true,zerolinecolor:'rgba(0,43,92,0.15)',
           showgrid:true,side:'left'},
    yaxis2:{title:{text:TA.showCount?'Count':'',font:{size:10,color:'rgba(99,140,185,0.85)'}},
            tickfont:{color:'rgba(99,140,185,0.85)',size:9},
            overlaying:'y',side:'right',showgrid:false,zeroline:false,
            visible:!!(hasExp&&TA.showExpo&&TA.showCount)},
    yaxis3:{title:{text:metricLabel,font:{size:11,color:'#C8922A'}},
            tickfont:{color:'#C8922A',size:10},
            overlaying:'y',side:'right',anchor:'free',position:1.0,
            range:[mR0,mR1],showgrid:false,zeroline:false},
    paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
    font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
    height:h,margin:{l:78,r:hasExp&&TA.showExpo&&TA.showCount?115:90,t:52,b:bMgn},
    legend:{orientation:'h',x:0.5,xanchor:'center',y:-0.02,yanchor:'top',
            bgcolor:'rgba(0,0,0,0)',font:{size:11}},
    barmode:'group',bargap:0.20,bargroupgap:0.06,
    hovermode:'x unified',
  };

  renderTAChart('ta-cat-chart', traces, layout);
  taBuildCatTable(page, data, m, metricLabel, hasExp, expCol, col);
}

function taBuildCatTable(page, allSorted, m, metricLabel, hasExp, expCol, col) {
  var hdr = '<tr><th>Category</th><th>Count</th><th>Row %</th>'
    +(hasExp?'<th>'+expCol+'</th><th>Exp %</th>':'')
    +'<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows = page.map(function(r){
    var italic = r.category==='(Other)'?' style="font-style:italic;color:var(--txt2)"':'';
    var row='<tr'+italic+'>'
      +'<td style="font-weight:500">'+r.category+'</td>'
      +'<td style="text-align:right">'+(+r.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+taFmt(r.pct,2)+'%</td>';
    if(hasExp){
      row+='<td style="text-align:right">'+taFmt(r.exposure_sum,2)+'</td>'
          +'<td style="text-align:right">'+taFmt(r.exposure_pct,2)+'%</td>';
    }
    row+='<td style="text-align:right;color:var(--acc);font-weight:700">'+taFmt(r.mean,6)+'</td>'
        +'<td style="text-align:right">'+taFmt(r.median,6)+'</td>'
        +'<td style="text-align:right">'+taFmt(r.sum,4)+'</td></tr>';
    return row;
  }).join('');
  var html='<div class="tw"><table class="dt sortable" id="ta-cat-tbl">'
    +'<thead>'+hdr+'</thead><tbody>'+rows+'</tbody></table></div>';

  // Download button (full dataset, all pages)
  var csvCols='Category,Count,Pct'+(hasExp?','+expCol+',ExposurePct':'')+',Mean,Median,Sum';
  var csv=csvCols+'\n'+allSorted.map(function(r){
    var b=['"'+r.category+'"',r.count,r.pct];
    if(hasExp) b=b.concat([r.exposure_sum,r.exposure_pct]);
    return b.concat([r.mean,r.median,r.sum]).join(',');
  }).join('\n');
  var b64=btoa(unescape(encodeURIComponent(csv)));
  html+='<div class="tbl-ctrl"><a class="dl-btn" href="data:text/csv;base64,'+b64
    +'" download="'+(col||'cat')+'_target.csv">DL Download CSV (all '
    +allSorted.length+' rows)</a></div>';

  var el=document.getElementById('ta-cat-table'); if(el) el.innerHTML=html;
}

// ================================================================
//  NUMERICAL -- grouped bars (Count + Exposure) + Mean line
// ================================================================
function taSelectNum(col) {
  TA_ACTIVE = {type:'num', col:col};
  taRenderNum(col);
}

function taRenderNum(col) {
  var allData = window.TA_NUM && window.TA_NUM[col];
  if (!allData || !window.Plotly) return;
  var method = TA.numMethod;
  var nb     = TA.numBins;
  var bins   = (allData[method] && allData[method][nb]) ? allData[method][nb] : [];
  if (!bins || !bins.length) {
    var el=document.getElementById('ta-num-chart');
    if(el) el.innerHTML='<p class="cap" style="padding:20px">No data for '+method+' / '+nb+' bins.</p>';
    return;
  }
  var m          = TA.metric;
  var expCol     = window.TA_EXPOSURE_COL || '';
  var hasExp     = bins.length > 0 && bins[0].exposure_sum !== undefined && expCol;
  var mvals      = bins.map(function(b){ return +b[m]||0; });
  var counts     = bins.map(function(b){ return +b.count||0; });
  var expos      = hasExp ? bins.map(function(b){ return +b.exposure_sum||0; }) : [];
  var mids       = bins.map(function(b){ return ((+b.bin_lo||0)+(+b.bin_hi||0))/2; });
  var labels     = bins.map(function(b){ return b.bin; });
  var metricLabel= ({mean:'Mean',median:'Median',sum:'Sum'}[m]||m)+' '+window.TA_TARGET;
  var ylog       = TA.logY ? 'log' : 'linear';
  var binNote    = method==='exposure'
    ? (window.TA_BIN_BY==='amount'?' . equal '+expCol+' per bin':' . equal count/bin') : '';

  // ── Use bin range labels as categorical x-axis (not midpoints) ──
  var traces = [];
  var gc3 = 'rgba(212,220,235,0.50)';

  // Bar 1 -- Exposure (navy, LEFT axis y)
  if (hasExp && TA.showExpo) {
    traces.push({
      type:'bar', x:labels, y:expos, name:expCol, yaxis:'y',
      marker:{color:'rgba(0,43,92,0.68)',line:{color:'rgba(0,43,92,0.88)',width:0.4}},
      hovertemplate:'<b>%{x}</b><br>'+expCol+': %{y:,.2f}<extra></extra>',
    });
  }

  // Bar 2 -- Count (steel, RIGHT y2 when exposure shown, else LEFT y)
  if (TA.showCount) {
    var cntAxisN = hasExp && TA.showExpo ? 'y2' : 'y';
    traces.push({
      type:'bar', x:labels, y:counts, name:'Count', yaxis:cntAxisN,
      marker:{color:'rgba(99,140,185,0.50)',line:{color:'rgba(80,120,165,0.70)',width:0.4}},
      hovertemplate:'<b>%{x}</b><br>Count: %{y:,}<extra></extra>',
    });
  }

  // Line -- mean/median/sum (gold, RIGHT axis y3 -- own independent scale)
  var validMN = mvals.filter(function(v){return v!==null&&isFinite(+v);});
  var mMinN = validMN.length?Math.min.apply(null,validMN):0;
  var mMaxN = validMN.length?Math.max.apply(null,validMN):1;
  var mSpanN = mMaxN - mMinN;
  var mPadN = mSpanN>0?mSpanN*0.18:Math.abs(mMaxN)*0.20||0.001;
  var mR0N = mMinN>=0?0:mMinN-mPadN;
  var mR1N = mMaxN+mPadN;

  traces.push({
    type:'scatter', mode:'lines+markers', x:labels, y:mvals,
    name:metricLabel, yaxis:'y3',
    line:{color:'#C8922A',width:2.8},
    marker:{color:'#C8922A',size:9,symbol:'circle',line:{color:'#fff',width:1.8}},
    hovertemplate:'<b>%{x}</b><br>'+metricLabel+': %{y:.6g}<extra></extra>',
  });

  var nLabs = labels.length;
  var maxLblN = labels.reduce(function(a,s){return s&&s.length>a?s.length:a;},0);
  var angleN = 0;
  if (nLabs>18||maxLblN>12) angleN=-55;
  else if (nLabs>12||maxLblN>8) angleN=-40;
  else if (nLabs>7) angleN=-28;
  var bMgnN = angleN<-45?140:angleN<-20?105:65;
  var hN = nLabs>20?500:nLabs>12?440:400;

  var layout = {
    title:{text:col+' vs '+window.TA_TARGET+'  ['+method+', '+nb+' bins'+binNote+']',
           font:{size:13,color:'#0D1B2E'},x:0.5,xanchor:'center',pad:{t:8}},
    xaxis:{type:'category',tickangle:angleN,
           tickfont:{size:Math.max(9,12-Math.floor(nLabs/10)),color:'#4A5568'},
           gridcolor:gc3,zeroline:false,showgrid:false,automargin:true},
    yaxis:{title:{text:hasExp&&TA.showExpo?expCol:'Count',
                  font:{size:11,color:'rgba(0,43,92,0.80)'}},
           tickfont:{color:'rgba(0,43,92,0.75)',size:10},
           gridcolor:gc3,zeroline:true,zerolinecolor:'rgba(0,43,92,0.15)',
           showgrid:true,side:'left'},
    yaxis2:{title:{text:TA.showCount?'Count':'',font:{size:10,color:'rgba(99,140,185,0.85)'}},
            tickfont:{color:'rgba(99,140,185,0.85)',size:9},
            overlaying:'y',side:'right',showgrid:false,zeroline:false,
            visible:!!(hasExp&&TA.showExpo&&TA.showCount)},
    yaxis3:{title:{text:metricLabel,font:{size:11,color:'#C8922A'}},
            tickfont:{color:'#C8922A',size:10},
            overlaying:'y',side:'right',anchor:'free',position:1.0,
            range:[mR0N,mR1N],showgrid:false,zeroline:false},
    paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',
    font:{family:'Inter,sans-serif',size:11,color:'#0D1B2E'},
    height:hN,margin:{l:78,r:hasExp&&TA.showExpo&&TA.showCount?115:90,t:52,b:bMgnN},
    legend:{orientation:'h',x:0.5,xanchor:'center',y:-0.02,yanchor:'top',
            bgcolor:'rgba(0,0,0,0)',font:{size:11}},
    barmode:'group',bargap:0.20,bargroupgap:0.05,
    hovermode:'x unified',
  };

  renderTAChart('ta-num-chart', traces, layout);
  taBuildNumTable(bins, m, metricLabel, hasExp, expCol, col);
}

function taBuildNumTable(bins, m, metricLabel, hasExp, expCol, col) {
  var hdr='<tr><th>Bin</th><th>Count</th><th>Row %</th>'
    +(hasExp?'<th>'+expCol+'</th><th>Exp %</th>':'')
    +'<th>Mean</th><th>Median</th><th>Sum</th></tr>';
  var rows=bins.map(function(b){
    var row='<tr><td style="font-family:monospace;font-size:.8rem">'+b.bin+'</td>'
      +'<td style="text-align:right">'+(+b.count||0).toLocaleString()+'</td>'
      +'<td style="text-align:right">'+taFmt(b.pct,2)+'%</td>';
    if(hasExp){
      row+='<td style="text-align:right">'+taFmt(b.exposure_sum,3)+'</td>'
          +'<td style="text-align:right">'+taFmt(b.exposure_pct,2)+'%</td>';
    }
    row+='<td style="text-align:right;color:var(--acc);font-weight:700">'+taFmt(b.mean,6)+'</td>'
        +'<td style="text-align:right">'+taFmt(b.median,6)+'</td>'
        +'<td style="text-align:right">'+taFmt(b.sum,4)+'</td></tr>';
    return row;
  }).join('');
  var html='<div class="tw"><table class="dt sortable" id="ta-num-tbl">'
    +'<thead>'+hdr+'</thead><tbody>'+rows+'</tbody></table></div>';

  var csvCols='Bin,Bin_Lo,Bin_Hi,Count,Pct'+(hasExp?','+expCol+',ExposurePct':'')+',Mean,Median,Sum';
  var csv=csvCols+'\n'+bins.map(function(b){
    var base=['"'+b.bin+'"',b.bin_lo,b.bin_hi,b.count,b.pct];
    if(hasExp) base=base.concat([b.exposure_sum,b.exposure_pct]);
    return base.concat([b.mean,b.median,b.sum]).join(',');
  }).join('\n');
  var b64=btoa(unescape(encodeURIComponent(csv)));
  html+='<div class="tbl-ctrl"><a class="dl-btn" href="data:text/csv;base64,'+b64
    +'" download="'+(col||'num')+'_target_binned.csv">DL Download CSV</a></div>';
  var el=document.getElementById('ta-num-table'); if(el) el.innerHTML=html;
}

// -- chart renderer --------------------------------------------
function renderTAChart(id, data, layout) {
  var el = document.getElementById(id);
  if (!el || !window.Plotly) return;
  var wrap = el.closest ? el.closest('.chart-wrap') : null;
  if (wrap) { var ldr=wrap.querySelector('.chart-loader'); if(ldr) ldr.classList.add('done'); }
  var cfg = {responsive:true, displayModeBar:true, displaylogo:false,
             modeBarButtonsToRemove:['sendDataToCloud','lasso2d','select2d']};
  try {
    if (el._taPlotted) Plotly.react(id, data, layout, cfg);
    else { Plotly.newPlot(id, data, layout, cfg); el._taPlotted=true; }
  } catch(e) { console.warn('TA chart error', id, e); }
}
"""


def build_ta_html(R: dict) -> str:
    """Build the Target Analysis tab HTML content (embedded in EDA dashboard)."""
    target = R.get("target_col")
    dta    = R.get("deep_target_analysis", {})

    if not target:
        return _alert_html("No target column defined.", "yellow")
    if not dta:
        return _alert_html(
            "Target Analysis not computed. "
            "Call plan.set_sections(target_analysis=True) before run_eda().", "yellow")

    return _build_ta_body(target, dta)


def _build_ta_body(target: str, dta: dict) -> str:
    """Core HTML body for Target Analysis -- shared by tab and standalone app."""
    cat_cols    = sorted(dta.get("categorical", {}).keys())
    num_cols    = sorted(dta.get("numeric", {}).keys())
    uni         = dta.get("univariate", {})
    n_bins_list = dta.get("n_bins_list", [5, 10, 20])
    bin_methods = dta.get("bin_methods", ["equal", "quantile"])
    exposure_col= dta.get("exposure_col") or ""
    bin_by      = dta.get("bin_by", "amount")
    n_rows      = dta.get("n_rows", 0)
    elapsed     = dta.get("elapsed_sec", 0)

    cat_data = dta.get("categorical", {})
    num_data = dta.get("numeric", {})

    data_script = f"""<script>
window.TA_TARGET       = {_j(target)};
window.TA_UNI          = {_j(uni)};
window.TA_CAT          = {_j(cat_data)};
window.TA_NUM          = {_j(num_data)};
window.TA_EXPOSURE_COL = {_j(exposure_col)};
window.TA_BIN_BY       = {_j(bin_by)};
</script>"""

    # -- Univariate stat cards -------------------------------------------------
    stats = uni.get("stats", {})
    stat_cards = ""
    for lbl, key, fmt in [
        ("Count","count",",.0f"), ("Mean","mean",".4g"), ("Median","median",".4g"),
        ("Std Dev","std",".4g"),  ("P95","p95",".4g"),   ("P99","p99",".4g"),
        ("Skewness","skewness",".3f"), ("Zero %","zero_pct",".2f"),
    ]:
        v = stats.get(key)
        disp = "--"
        if v is not None:
            try:
                fv = float(v)
                disp = (f"{int(fv):,}" if key=="count"
                        else f"{fv:.2f}%" if key=="zero_pct"
                        else format(fv, fmt))
            except:
                disp = str(v)
        stat_cards += (f'<div class="ta-stat">'
                       f'<div class="ta-stat-v">{disp}</div>'
                       f'<div class="ta-stat-l">{lbl}</div></div>')

    # -- Dropdowns -------------------------------------------------------------
    cat_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in cat_cols)
    num_opts = "".join(f'<option value="{_esc(c)}">{_esc(c)}</option>' for c in num_cols)

    # -- Bin slider ------------------------------------------------------------
    n_bins_def = 20 if 20 in n_bins_list else n_bins_list[0]
    bins_json  = _j(n_bins_list)

    # -- Method buttons --------------------------------------------------------
    METHOD_LABELS = {
        "equal":    "Equal Width",
        "quantile": "Equal Count",
        "exposure": f"Equal Exposure ({bin_by.title()})" if exposure_col else "Equal Exposure",
    }
    method_btns = "".join(
        f'<button class="ta-method-btn{"  on" if i==0 else ""}" '
        f'data-meth="{m}" onclick="taSetMethod(\'{m}\')">'
        f'{METHOD_LABELS.get(m, m)}</button>'
        for i, m in enumerate(bin_methods)
    )

    # -- Exposure note ---------------------------------------------------------
    exp_note = (f'Exposure column: <strong>{_esc(exposure_col)}</strong> . '
                f'Bin by: <strong>{_esc(bin_by)}</strong>'
                if exposure_col else
                'No exposure column configured -- showing row count only')

    # -- "Show" toggles --------------------------------------------------------
    count_toggle = ('<label class="ta-toggle-lbl">'
                    '<input type="checkbox" checked onchange="taToggleCount(this)"> '
                    'Show Count</label>')
    expo_toggle  = (f'<label class="ta-toggle-lbl">'
                    f'<input type="checkbox" checked onchange="taToggleExpo(this)"> '
                    f'Show {_esc(exposure_col) if exposure_col else "Exposure"}</label>'
                    if exposure_col else "")

    html = f"""
{data_script}

<!-- Global controls -->
<div class="ta-ctrl-bar">
  <div class="ta-ctrl-grp">
    <div class="ta-ctrl-lbl">Target Metric</div>
    <div class="ta-btn-row">
      <button class="ta-btn ta-metric-btn on" data-m="mean"   onclick="taSetMetric('mean')">Mean</button>
      <button class="ta-btn ta-metric-btn"    data-m="median" onclick="taSetMetric('median')">Median</button>
      <button class="ta-btn ta-metric-btn"    data-m="sum"    onclick="taSetMetric('sum')">Sum</button>
    </div>
  </div>
  <div class="ta-ctrl-grp">
    <div class="ta-ctrl-lbl">Display</div>
    <div class="ta-btn-row">
      <label class="ta-toggle-lbl"><input type="checkbox" onchange="taToggleLog(this)"> Log Y</label>
      {count_toggle}
      {expo_toggle}
    </div>
  </div>
  <div class="ta-ctrl-grp">
    <div class="ta-ctrl-lbl">Sort Categories</div>
    <div class="ta-btn-row">
      <button class="ta-btn ta-sort-btn on" data-s="count"  onclick="taSetSort('count')">By Count</button>
      <button class="ta-btn ta-sort-btn"    data-s="metric" onclick="taSetSort('metric')">By Metric</button>
      <button class="ta-btn ta-sort-btn"    data-s="alpha"  onclick="taSetSort('alpha')">A-Z</button>
    </div>
  </div>
  <div class="ta-ctrl-grp">
    <div class="ta-ctrl-lbl">Group small cats
      <span id="ta-other-lbl" style="color:var(--acc);font-weight:600">Off</span>
    </div>
    <input type="range" class="ta-slider" min="0" max="5" step="0.5" value="0"
           oninput="taSetOther(this.value)">
  </div>
  <div class="ta-ctrl-grp" style="margin-left:auto;font-size:.73rem;color:var(--txt3);line-height:1.6">
    {n_rows:,} rows . No sampling<br>
    Pre-computed in {elapsed:.1f}s
  </div>
</div>

<!-- Sub-tabs -->
<div class="ta-sub-tabs">
  <button class="ta-sub-tab on" onclick="taShowTab(this,'ta-uni')">Target Overview</button>
  <button class="ta-sub-tab"   onclick="taShowTab(this,'ta-cat')">Categorical vs Target</button>
  <button class="ta-sub-tab"   onclick="taShowTab(this,'ta-num')">Numerical vs Target</button>
</div>

<div id="ta-main">

<!-- UNIVARIATE ------------------------------------------- -->
<div id="ta-uni" class="ta-panel on">
  <h3 class="sh">Target -- {_esc(target)}</h3>
  <p class="cap">{n_rows:,} rows . Full dataset . No sampling</p>
  <div class="ta-stat-grid">{stat_cards}</div>
  <div class="chart-wrap">
    <div class="chart-loader"><div class="spinner"></div><span>Rendering...</span></div>
    <div id="ta-uni-chart" style="width:100%;min-height:360px"></div>
  </div>
  <div id="ta-uni-stats" style="margin-top:16px"></div>
</div>

<!-- CATEGORICAL ------------------------------------------- -->
<div id="ta-cat" class="ta-panel">
  <h3 class="sh">Categorical Features vs {_esc(target)}</h3>
  <div class="chart-note">
    Navy bars = Row Count &nbsp;|&nbsp;
    Gold bars = {_esc(exposure_col) if exposure_col else "Exposure (not configured)"} &nbsp;|&nbsp;
    Gold line = Mean {_esc(target)} (left axis) &nbsp;|&nbsp;
    {exp_note}
  </div>
  {'<p class="cap" style="color:#b45309">No categorical features found.</p>' if not cat_cols else f"""
  <div class="ta-feat-row">
    <label class="ta-feat-lbl">Feature</label>
    <select class="ta-feat-sel" onchange="taSelectCat(this.value)">{cat_opts}</select>
    <span style="font-size:.78rem;color:var(--txt2)">{len(cat_cols)} features available</span>
  </div>
  <div id="ta-cat-paging" class="ta-page-ctrl" style="display:none">
    <button class="ta-page-btn" id="ta-cat-prev" onclick="taCatPage(-1)">Prev</button>
    <span class="ta-page-info" id="ta-cat-pageinfo"></span>
    <button class="ta-page-btn" id="ta-cat-next" onclick="taCatPage(1)">Next</button>
    <span style="color:var(--txt2);font-size:.75rem">30 categories per page</span>
  </div>
  <div class="chart-wrap">
    <div class="chart-loader"><div class="spinner"></div><span>Rendering...</span></div>
    <div id="ta-cat-chart" style="width:100%;min-height:380px"></div>
  </div>
  <div id="ta-cat-table" style="margin-top:14px"></div>
  """}
</div>

<!-- NUMERICAL ------------------------------------------- -->
<div id="ta-num" class="ta-panel">
  <h3 class="sh">Numerical Features vs {_esc(target)}</h3>
  <div class="chart-note">
    Navy bars = Row Count &nbsp;|&nbsp;
    Gold bars = {_esc(exposure_col) if exposure_col else "Exposure (not configured)"} &nbsp;|&nbsp;
    Gold line = Mean {_esc(target)} (left axis) &nbsp;|&nbsp;
    {exp_note}
  </div>
  {'<p class="cap" style="color:#b45309">No numerical features found.</p>' if not num_cols else f"""
  <div class="ta-feat-row" style="flex-wrap:wrap;gap:10px">
    <div style="display:flex;align-items:center;gap:10px;flex:1;min-width:220px">
      <label class="ta-feat-lbl">Feature</label>
      <select class="ta-feat-sel" onchange="taSelectNum(this.value)">{num_opts}</select>
    </div>
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      <label class="ta-feat-lbl">Binning</label>
      {method_btns}
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      <label class="ta-feat-lbl">Bins</label>
      <span class="ta-bins-lbl" id="ta-bins-lbl">{n_bins_def}</span>
      <input type="range" class="ta-slider"
             min="0" max="{len(n_bins_list)-1}" step="1"
             value="{n_bins_list.index(n_bins_def) if n_bins_def in n_bins_list else 0}"
             oninput="taSetBinsByIdx(this.value,{bins_json})">
    </div>
  </div>
  <div class="chart-wrap">
    <div class="chart-loader"><div class="spinner"></div><span>Rendering...</span></div>
    <div id="ta-num-chart" style="width:100%;min-height:380px"></div>
  </div>
  <div id="ta-num-table" style="margin-top:14px"></div>
  """}
</div>

</div><!-- #ta-main -->

<script>
(function(){{
  var firstCat = {_j(cat_cols[0] if cat_cols else "")};
  var firstNum = {_j(num_cols[0] if num_cols else "")};
  function initTA(){{
    taRenderUni();
    if (firstCat) taSelectCat(firstCat);
    if (firstNum) taSelectNum(firstNum);
  }}
  if (document.readyState === 'complete') initTA();
  else window.addEventListener('load', initTA);
}})();
</script>
"""
    return html


def _alert_html(msg, kind="yellow"):
    m = {"red":("#fef2f2","#b91c1c","#ef4444"),
         "yellow":("#fffbeb","#78350f","#f59e0b"),
         "blue":("#eff6ff","#1e3a5f","#3b82f6"),
         "green":("#f0fdf4","#14532d","#22c55e")}
    bg, fg, bd = m.get(kind, m["yellow"])
    return f'<div class="al" style="background:{bg};color:{fg};border-left:3px solid {bd}">{msg}</div>'
