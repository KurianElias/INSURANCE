# Insurance EDA Toolkit v5

Chubb Risk Cohorts -- Commercial Liability Pure Premium EDA.

**Two independent tools. Both use the full dataset -- no sampling anywhere.**

---

## Quick Start

```python
import sys
sys.path.insert(0, r"C:\Users\KUELIAS\Desktop\POC\RiskCohortsapp")
from eda_toolkit import inspect, run_eda, generate_report
from eda_toolkit import run_target_analysis, generate_fs_report
```

---

## Tool 1 -- EDA Dashboard

Full exploratory analysis across 9 tabs.

```python
# Inspect
plan = inspect(df, target_col="frequency")
plan.fix(policy_no="ID-like")

# Configure
plan.set_sections(correlations=True, category_quality=True,
                  scorecard=True, target_analysis=True)
plan.set_target_analysis(
    n_bins       = [5, 10, 20],
    exposure_col = "expo_amt",
    bin_by       = "amount",
)

# Run
plan.confirm()
df_clean = plan.apply_to_df()
results  = run_eda(df_clean, plan)

# Save HTML -- returns None so VS Code stays fast
generate_report(results, output_path=r"C:\path\to\eda_report.html")
```

**9 tabs:** Overview, Distributions, Outliers, Categories,
Correlations, Fuzzy Dedup, Scorecard, Target Analysis, Comparison.

---

## Tool 2 -- Feature Selection Dashboard

Focused actuarial feature analysis. Faster than full EDA.

```python
ta = run_target_analysis(
    df,
    target_col   = "frequency",
    exposure_col = "expo_amt",
    bin_by       = "amount",
    n_bins       = 20,
)

generate_fs_report(
    {"deep_target_analysis": ta, "target_col": "frequency", "n_rows": len(df)},
    output_path = r"C:\path\to\feature_selection.html",
)
```

**3 tabs:** Target Overview, Categorical vs Target, Numerical vs Target.

---

## The two tools are completely independent

`run_eda` and `run_target_analysis` never call each other.
Both call `build_target_analysis` from `target_analysis_engine.py` independently.

The Feature Selection Dashboard can be generated from either:

```python
# From run_eda results
generate_fs_report(results, output_path="fs.html")

# From run_target_analysis (standalone -- skips all EDA sections)
ta = run_target_analysis(df, "frequency", exposure_col="expo_amt")
generate_fs_report({"deep_target_analysis": ta, "target_col": "frequency",
                    "n_rows": len(df)}, output_path="fs.html")
```

---

## Charts

All charts: Plotly in self-contained HTML. No server needed.

**Feature vs Target:**
- Navy bars = exposure (left axis)
- Steel bars = count (right axis, toggleable)
- Gold line = mean target (right axis, own scale -- never distorted by count toggle)
- Numerical x-axis = bin range labels `[25.0, 34.2)` (not midpoints)

**Target Overview:**
- Zero-inflated (>=50% zeros): full distribution + non-zero log1p side by side
- Stat table explains why P25/P75/P95 = 0 when most values are zero

---

## Binning

| Method | Description |
|---|---|
| `exposure` (default) | Equal sum of `expo_amt` per bin -- actuarially correct |
| `equal` | Equal-width intervals |
| `quantile` | Equal row count per bin |

---

## Zero-Inflated Targets

P25/P75/P95 = 0 is correct when >50% zeros. Use **Sum** as metric.
Model with Tweedie GLM or frequency x severity two-stage approach.

---

## VS Code Performance

```python
# Always use output_path -- prevents VS Code freeze
generate_report(results,    output_path=r"C:\path\eda.html")
generate_fs_report(ta_dict, output_path=r"C:\path\fs.html")
```

Copy `.vscode_settings_to_copy.json` to `.vscode/settings.json` in your project.

---

## Full API

```python
from eda_toolkit import (
    inspect,              # Inspect DataFrame -> InspectPlan
    run_eda,              # Full EDA pipeline -> results dict
    generate_report,      # EDA Dashboard HTML
    run_target_analysis,  # Target analysis standalone -> ta dict
    generate_fs_report,   # Feature Selection Dashboard HTML
    print_summary,        # Print text summary
    launch_app,           # Alias for generate_report
)
```

---

## File Structure

```
eda_toolkit/
  __init__.py                    lazy imports, public API
  launch.py                      InspectPlan, inspect, run_eda, print_summary
  eda_engine.py                  core computation engine (full data, no sampling)
  html_report.py                 EDA Dashboard HTML (9 tabs)
  target_analysis_engine.py      binning and aggregation engine
  target_analysis_html.py        Target Analysis tab HTML/JS
  feature_selection_dashboard.py Feature Selection Dashboard
  README.md                      this file
  .vscode_settings_to_copy.json  VS Code settings
```
