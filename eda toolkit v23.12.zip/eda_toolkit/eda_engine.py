# -*- coding: utf-8 -*-
"""
eda_engine.py -- Insurance EDA Toolkit v4
Pure computation. No Streamlit. No external calls. 100% local.

v4 additions:
  - _target_analysis(): per-feature correlation/association with target
  - _comparison_summary(): grouped side-by-side comparison of two DataFrames
  - sections config key: dict of bool flags to skip expensive sections
"""

import time, warnings
import numpy as np
import pandas as pd
from scipy.stats import skew as _skew, normaltest

warnings.filterwarnings("ignore")

try:
    from rapidfuzz import fuzz as _fuzz
    def _similarity(a, b):
        return _fuzz.token_sort_ratio(a, b) / 100.0
    _FUZZY_LIB = "rapidfuzz"
except ImportError:
    from difflib import SequenceMatcher
    def _similarity(a, b):
        return SequenceMatcher(None, a.lower(), b.lower()).ratio()
    _FUZZY_LIB = "difflib"


# -- helpers -------------------------------------------------------------------

def _samp(arr, n):
    if len(arr) == 0: return arr
    if len(arr) <= n: return arr
    return arr[np.random.choice(len(arr), n, replace=False)]

def _log(msg, pct=0):
    print(f"[EDA {pct:3d}%] {msg}")

def _nunique(s):
    """Exact unique count -- no sampling."""
    clean = s.dropna()
    if len(clean) == 0: return 0
    return int(clean.nunique())


# -- type detection ------------------------------------------------------------

_BOOL_STRINGS = [
    {"0","1"}, {"y","n"}, {"yes","no"}, {"true","false"}, {"t","f"},
    {"1.0","0.0"}, {"male","female"}, {"m","f"},
]

def _try_parse_date(s) -> bool:
    sample = s.dropna().astype(str).head(300)
    if len(sample) < 5: return False
    has_sep   = sample.str.contains(r'[-/: ]', regex=True)
    has_digit = sample.str.contains(r'\d', regex=True)
    if (has_sep & has_digit).mean() < 0.7: return False
    try:
        p1 = pd.to_datetime(sample, errors="coerce")
        if float(p1.notna().mean()) >= 0.80: return True
        p2 = pd.to_datetime(sample, errors="coerce", dayfirst=True)
        return float(p2.notna().mean()) >= 0.80
    except Exception:
        return False

def _is_bool_strings(s) -> bool:
    raw_unique = s.dropna().astype(str).str.strip().unique()
    if len(raw_unique) == 0 or len(raw_unique) > 2: return False
    lower_unique = set(v.lower() for v in raw_unique)
    return lower_unique in _BOOL_STRINGS

def detect_type(s, id_ratio=0.8) -> str:
    n = len(s)
    if n == 0 or s.isna().all(): return "Unknown"
    if pd.api.types.is_bool_dtype(s): return "Boolean"
    if pd.api.types.is_datetime64_any_dtype(s): return "Date"
    if pd.api.types.is_numeric_dtype(s):
        nu = _nunique(s)
        if nu == 0: return "Unknown"
        if nu == 1:
            # Single unique value -> Constant only if column is substantially populated.
            # If 95%+ is null (only 1 non-null survivor), treat as Numeric so missing
            # analysis fires correctly rather than hiding it as a Constant.
            non_null_frac = float(s.notna().mean())
            return "Constant" if non_null_frac >= 0.05 else "Numeric"
        if nu == 2: return "Boolean"
        clean = s.dropna()
        if nu <= 150:
            try:
                vals = clean.astype(float)
                if ((vals >= 1900) & (vals <= 2100)).mean() > 0.95 and \
                   (vals == vals.round(0)).mean() > 0.99:
                    return "Date"
            except Exception:
                pass
        if nu / n > id_ratio:
            try:
                if (clean.head(200) == clean.head(200).round(0)).mean() > 0.99:
                    return "ID-like"
            except Exception:
                pass
        return "Numeric"
    if _is_bool_strings(s): return "Boolean"
    nu = _nunique(s)
    if nu == 0: return "Unknown"
    if nu == 1: return "Constant"
    if _try_parse_date(s): return "Date"
    if nu / n > id_ratio: return "ID-like"
    return "Categorical"


# -- per-column analysis -------------------------------------------------------

def _analyse_numeric(col, s, n_total, plot_n=20_000, norm_n=5_000,
                     stat_sample=100_000):
    """
    stat_sample: rows used for all expensive stats (percentiles, std, skew, nunique).
    Exact min/max and missing/inf counts are always computed on the full column.
    Stats are accurate at 100k rows -- running on 2.5M adds 300ms/col with no benefit.
    """
    if s.dtype == object:
        _TRUE = {"1","y","yes","true","t","1.0","male","m"}
        s = pd.to_numeric(
            s.map(lambda v: 1.0 if str(v).strip().lower() in _TRUE
                  else (0.0 if pd.notna(v) else np.nan)),
            errors="coerce")

    # Convert to float numpy once -- reuse dtype if already float
    if hasattr(s, 'values') and np.issubdtype(s.dtype, np.floating):
        arr = s.values.astype(float, copy=False)
    else:
        arr = pd.to_numeric(s, errors="coerce").to_numpy(dtype=float, na_value=np.nan)

    # Exact counts always on full array (single fast pass each)
    nan_mask  = np.isnan(arr)
    inf_mask  = np.isinf(arr)
    missing   = int(nan_mask.sum())
    inf_count = int(inf_mask.sum())
    valid_mask = ~nan_mask & ~inf_mask
    clean_full = arr[valid_mask]
    nc         = len(clean_full)

    # Exact min/max (cheap -- O(n) single pass)
    true_min = float(clean_full.min()) if nc else np.nan
    true_max = float(clean_full.max()) if nc else np.nan

    base = dict(
        dtype="Numeric", missing_count=missing,
        missing_pct=round(missing / n_total * 100, 1),
        hit_rate_pct=round((n_total - missing) / n_total * 100, 1),
        inf_count=inf_count, inf_pct=round(inf_count / n_total * 100, 2),
        n_unique=0, zero_pct=0.0, dist={}, outlier={},
        plot_sample=[], zero_inflated=False, skewness=None,
    )
    if nc == 0: return base

    # -- Sample once for ALL expensive stat operations -------------------------
    # percentile / std / skew / nunique on 2.5M rows = ~300ms wasted per col
    # Same stats computed on 100k sample are statistically identical
    if nc > stat_sample:
        rng   = np.random.default_rng(42)
        sidx  = rng.choice(nc, stat_sample, replace=False)
        clean = clean_full[sidx]
    else:
        clean = clean_full

    pcts     = np.percentile(clean, [1, 5, 10, 25, 50, 75, 90, 95, 99])
    mean     = float(clean.mean())
    std      = float(clean.std()) if len(clean) > 1 else 0.0
    zero_pct = round(float((clean == 0).mean()) * 100, 1)
    zero_inf = zero_pct > 30
    nu       = int(np.unique(clean).shape[0])  # nunique on already-sampled array
    base.update(n_unique=nu, zero_pct=zero_pct, zero_inflated=zero_inf)

    sk = round(float(_skew(clean)), 3) if len(clean) > 3 else 0.0
    if not np.isfinite(sk): sk = 0.0
    base["skewness"] = sk

    pos = clean[clean > 0]; is_ln = False
    if len(pos) > 50:
        try:
            _, lp = normaltest(np.log(_samp(pos, norm_n))); is_ln = bool(lp > 0.05)
        except Exception: pass

    tags = []
    if zero_inf:            tags.append("Zero-Inflated")
    if is_ln and sk > 0.5:  tags.append("Log-Normal")
    elif sk > 1.0:           tags.append("Right-Skewed")
    elif sk < -1.0:          tags.append("Left-Skewed")
    if not tags:             tags.append("Near-Normal")

    base["dist"] = dict(
        mean=round(mean,4), median=round(float(pcts[4]),4), std=round(std,4),
        min=round(true_min,4), max=round(true_max,4),  # always exact
        p25=round(float(pcts[3]),4), p75=round(float(pcts[5]),4),
        p95=round(float(pcts[7]),4), p99=round(float(pcts[8]),4),
        skewness=sk, is_lognormal=is_ln, shape=", ".join(tags),
    )

    k = 1.5
    if zero_inf:
        nz = clean[clean > 0]
        q1 = float(np.percentile(nz, 25)) if len(nz) else 0.0
        q3 = float(np.percentile(nz, 75)) if len(nz) else 0.0
        iqr = q3 - q1; fence_lo = 0.0; fence_hi = round(q3 + k*iqr, 4)
        iqr_cnt = int((clean > fence_hi).sum()); note = "IQR on non-zero values (zero-inflated)"
    else:
        q1, q3 = float(pcts[3]), float(pcts[5]); iqr = q3 - q1
        fence_lo = round(q1 - k*iqr, 4); fence_hi = round(q3 + k*iqr, 4)
        iqr_cnt = int(((clean < fence_lo) | (clean > fence_hi)).sum()); note = ""

    base["outlier"] = dict(
        q1=round(q1,4), q3=round(q3,4), iqr=round(iqr,4),
        fence_lo=fence_lo, fence_hi=fence_hi,
        iqr_count=iqr_cnt, iqr_pct=round(iqr_cnt/len(clean)*100,1),
        count=iqr_cnt,                              # alias for iqr_count
        pct=round(iqr_cnt/len(clean)*100,1),        # alias for iqr_pct
        lower=fence_lo,                             # alias for fence_lo
        upper=fence_hi,                             # alias for fence_hi
        p99_cap=round(float(pcts[8]),4), note=note,
    )
    # plot_sample: draw from FULL clean array (not the stat sample)
    pidx = np.random.default_rng(43).choice(nc, min(plot_n, nc), replace=False)
    base["plot_sample"] = clean_full[pidx].tolist()
    return base


def _analyse_categorical(col, s, n_total, rare_pct=1.0):
    missing = int(s.isna().sum())
    vc  = s.value_counts(dropna=True)
    nu  = len(vc)
    top = round(float(vc.iloc[0]) / n_total * 100, 1) if nu else 0.0
    hr  = pd.DataFrame({
        "Category": vc.index.astype(str),
        "Count":    vc.values,
        "Share %":  (vc.values / n_total * 100).round(1),
    }).head(30)
    hr["Flag"] = hr["Share %"].apply(
        lambda x: "RARE" if x < rare_pct else ("DOMINANT" if x > 80 else ""))
    return dict(
        dtype="Categorical",
        missing_count=missing, missing_pct=round(missing/n_total*100,1),
        hit_rate_pct=round((n_total-missing)/n_total*100,1),
        inf_count=0, inf_pct=0.0, n_unique=nu, top_val_pct=top,
        category_table=hr, rare_count=int((hr["Flag"]=="RARE").sum()),
        dist={}, outlier={}, plot_sample=[], zero_inflated=False, skewness=None,
    )


# -- target analysis -----------------------------------------------------------

def _cramers_v(x, y):
    try:
        ct   = pd.crosstab(x, y)
        n    = ct.values.sum()
        if n == 0: return 0.0
        exp  = np.outer(ct.sum(axis=1), ct.sum(axis=0)) / n
        chi2 = float(((ct.values - exp)**2 / (exp + 1e-9)).sum())
        r, k = ct.shape
        return round(float(np.sqrt(chi2 / n / max(min(k-1, r-1), 1))), 4)
    except Exception:
        return None

def _target_analysis(df, col_results, dtype_map, target_col):
    if target_col not in df.columns: return {}
    t       = df[target_col].copy()
    t_num   = pd.to_numeric(t, errors="coerce")
    t_clean = t_num.dropna()
    t_nu    = int(t_clean.nunique()) if len(t_clean) else 0
    if t_nu == 0: return {}
    t_flavour = "binary" if t_nu <= 2 else ("categorical" if (t_nu <= 20 or not pd.api.types.is_numeric_dtype(t)) else "numeric")

    results = {}
    for col, res in col_results.items():
        dtype = res["dtype"]
        entry = dict(method="--", stat=None, pvalue=None, abs_stat=0.0,
                     label="--", bar_data=None, scatter_x=None, scatter_y=None,
                     t_flavour=t_flavour)
        try:
            if dtype in ("Numeric", "Boolean"):
                feat_num = pd.to_numeric(df[col], errors="coerce")
                mask     = feat_num.notna() & t_num.notna()
                f_v = feat_num[mask]; t_v = t_num[mask]
                if len(f_v) < 30: results[col] = entry; continue
                from scipy.stats import pearsonr
                r, p = pearsonr(f_v.values, t_v.values)
                method = "Pearson r" if t_flavour == "numeric" else "Point-biserial r"
                # scatter plot: sample down for display only (stats use full data)
                scat_n = min(3000, len(f_v))
                scat_idx = np.random.default_rng(42).choice(len(f_v), scat_n, replace=False)
                entry.update(method=method, stat=round(r,4), pvalue=round(p,6),
                             abs_stat=abs(r), label=f"r = {r:.3f}",
                             scatter_x=f_v.values[scat_idx].tolist(),
                             scatter_y=t_v.values[scat_idx].tolist())

            elif dtype == "Categorical":
                feat_s = df[col].dropna()
                t_s    = t[feat_s.index].dropna()
                feat_s = feat_s.loc[t_s.index]
                if len(feat_s) < 30: results[col] = entry; continue
                if t_flavour in ("binary", "numeric"):
                    t_num_s = pd.to_numeric(t_s, errors="coerce")
                    grp = (pd.DataFrame({"cat": feat_s.values, "target": t_num_s.values})
                             .dropna().groupby("cat")["target"]
                             .agg(["mean","count"]).reset_index())
                    grp.columns = ["Category","Mean Target","Count"]
                    grp = grp.sort_values("Mean Target", ascending=False).head(30)
                    grp["Mean Target"] = grp["Mean Target"].round(4)
                    t_bin = (t_num >= t_num.median()).astype(str)
                    v = _cramers_v(feat_s, t_bin)
                    entry.update(method="Mean Rate / Cramer's V", stat=v,
                                 abs_stat=v if v else 0.0,
                                 label=f"V = {v:.3f}" if v else "V = --",
                                 bar_data=grp)
                else:
                    v = _cramers_v(feat_s, t_s)
                    entry.update(method="Cramer's V", stat=v,
                                 abs_stat=v if v else 0.0,
                                 label=f"V = {v:.3f}" if v else "V = --")
        except Exception:
            pass
        results[col] = entry
    return results


# -- correlations --------------------------------------------------------------

def _correlations(df, corr_sample=100_000, threshold=0.75, max_vars=999,
                  target_col=None, chi_sample=20_000, chi_max_cardinality=10_000):
    """
    Compute correlations efficiently at scale.

    Parameters
    ----------
    corr_sample         : int   rows to sample for Pearson (default 100,000)
    threshold           : float |r| threshold for high-corr pairs (default 0.75)
    chi_sample          : int   rows to sample for chi-square (default 20,000)
    chi_max_cardinality : int   categorical columns with more unique values than
                                this are skipped in chi-square (default 10,000).
                                Change via plan.set('chi_max_cardinality', 20_000).
    """
    out = dict(
        pearson=pd.DataFrame(), high_corr=[], pair_table=pd.DataFrame(),
        vif=pd.DataFrame(), n_vars=0, sampled=False, sample_size=0,
        total_rows=len(df),
        cat_chi2=pd.DataFrame(),
        target_corr=pd.DataFrame(),
        target_summary=pd.DataFrame(),   # combined numeric+cat summary vs target
        target_col=target_col,
        chi_skipped=[],                  # columns skipped due to high cardinality
        chi_max_cardinality=chi_max_cardinality,
        chi_sample=chi_sample,
    )

    # -- 1. NUMERIC PEARSON (full data, no sampling) ---------------------------
    num = df.select_dtypes(include=[np.number]).columns.tolist()
    out["n_vars"] = len(num)

    if len(num) >= 2:
        df_num  = df[num]
        out["sampled"]     = False       # always full data
        out["sample_size"] = len(df_num)

        try:    pearson_mat = df_num.corr(method="pearson", min_periods=30).round(3)
        except: pearson_mat = df_num.corr(method="pearson").round(3)
        out["pearson"] = pearson_mat

        # -- Vectorised high-corr pairs (numpy, no Python loop over pairs) ----
        cols = pearson_mat.columns.tolist()
        C    = pearson_mat.values.copy()
        # Get upper triangle indices in one numpy call
        ii, jj = np.triu_indices(len(cols), k=1)
        vals   = C[ii, jj]
        mask   = ~np.isnan(vals)
        ii, jj, vals = ii[mask], jj[mask], vals[mask]

        # High-corr pairs
        hi = np.abs(vals) >= threshold
        if hi.any():
            hcp = pd.DataFrame({
                "Feature A": [cols[i] for i in ii[hi]],
                "Feature B": [cols[j] for j in jj[hi]],
                "Pearson r": np.round(vals[hi], 3),
                "Abs r":     np.round(np.abs(vals[hi]), 3),
            }).sort_values("Abs r", ascending=False).reset_index(drop=True)
            out["high_corr"] = hcp.drop(columns=["Abs r"]).to_dict("records")
        else:
            out["high_corr"] = []

        # Full pair table -- vectorised, then sort
        pt = pd.DataFrame({
            "Variable A": [cols[i] for i in ii],
            "Variable B": [cols[j] for j in jj],
            "Pearson r":  np.round(vals, 3),
            "_abs":       np.abs(vals),
        }).sort_values("_abs", ascending=False).drop(columns=["_abs"]).reset_index(drop=True)
        out["pair_table"] = pt

        # -- VIF via matrix formula (O(p3) once vs O(p) regressions) ----------
        # Much faster: compute inverse of correlation matrix diagonals
        try:
            vif_cols = [c for c in num if c != target_col]
            if len(vif_cols) >= 2:
                Xv = df[vif_cols].fillna(df[vif_cols].median(numeric_only=True)) \
                                 .values.astype(float)
                # Standardise columns (VIF formula works on correlation matrix)
                std = Xv.std(axis=0, keepdims=True)
                std[std == 0] = 1
                Xv = (Xv - Xv.mean(axis=0)) / std
                R_mat = (Xv.T @ Xv) / max(len(Xv) - 1, 1)
                try:
                    R_inv = np.linalg.inv(R_mat)
                    vifs  = np.diag(R_inv)
                    vifs  = np.clip(vifs, 1.0, 999.0)
                except np.linalg.LinAlgError:
                    # Singular -- fall back to pseudo-inverse
                    R_inv = np.linalg.pinv(R_mat)
                    vifs  = np.abs(np.diag(R_inv))
                    vifs  = np.clip(vifs, 1.0, 999.0)
                vdf = pd.DataFrame({"Feature": vif_cols,
                                    "VIF": np.round(vifs, 2)}) \
                        .sort_values("VIF", ascending=False).reset_index(drop=True)
                vdf["Flag"] = vdf["VIF"].apply(
                    lambda v: "HIGH >10" if v > 10 else ("MOD 5-10" if v > 5 else "OK"))
                out["vif"] = vdf
        except Exception:
            pass

        # -- Target correlation (numeric) --------------------------------------
        if target_col and target_col in pearson_mat.columns:
            tc = (pearson_mat[target_col]
                  .drop(target_col, errors="ignore")
                  .reset_index())
            tc.columns = ["Feature", "Pearson r"]
            tc["Abs r"] = tc["Pearson r"].abs()
            tc = tc.sort_values("Abs r", ascending=False) \
                   .drop(columns=["Abs r"]).reset_index(drop=True)
            out["target_corr"] = tc

    # -- 2. CATEGORICAL CRAMER'S V (full data, no sampling, no chi-square) -------
    # Pure numpy: pre-encode to integer codes, then bincount contingency table.
    # No scipy, no string conversion in loop, no sampling -- exact on full data.
    # IMPORTANT: only include columns that are genuinely categorical dtype.
    # If the target is numeric, do NOT add it here -- it will produce a spurious
    # 1000-level contingency table and Cramer's V will be artificially ~1.0.
    # If the target IS categorical, it is already picked up naturally below.
    cat_cols = [c for c in df.columns
                if df[c].dtype.name in ("category", "object", "string")
                or str(df[c].dtype).startswith("category")]

    # NOTE: do NOT force-add target_col here. If target is categorical, it is
    # already in cat_cols above. If target is numeric, it must NOT be added --
    # doing so would treat it as a 1000-level category and produce V~=1.0.

    # Filter: skip constants and extremely high cardinality (would make a huge matrix)
    skipped  = []
    eligible = []
    for c in cat_cols:
        nu = df[c].nunique()
        if nu > chi_max_cardinality:
            skipped.append({"Column": c, "Unique values": nu,
                            "Reason": f">{chi_max_cardinality:,} unique values -- skipped"})
        elif nu < 2:
            pass
        else:
            eligible.append(c)
    out["chi_skipped"] = skipped

    cv_rows = []
    if len(eligible) >= 2:
        # Pre-encode every eligible column to int32 codes ONCE
        codes = {}
        sizes = {}
        for c in eligible:
            s = df[c]
            if hasattr(s, 'cat'):
                codes[c] = s.cat.codes.values.astype(np.int32)
                sizes[c] = s.cat.categories.shape[0]
            else:
                uniq, inv = np.unique(s.fillna("__NA__").astype(str).values, return_inverse=True)
                codes[c] = inv.astype(np.int32)
                sizes[c] = len(uniq)

        def _cramers_v_fast(ca, cb):
            """Exact Cramer's V via numpy bincount. No sampling, no scipy."""
            a, b  = codes[ca], codes[cb]
            na, nb = sizes[ca], sizes[cb]
            ct = np.bincount(a * nb + b, minlength=na * nb).reshape(na, nb).astype(np.float64)
            # Remove all-zero rows/cols (handles NaN codes)
            ct = ct[ct.sum(1) > 0][:, ct.sum(0) > 0]
            if ct.shape[0] < 2 or ct.shape[1] < 2:
                return None
            n_total  = ct.sum()
            row_sums = ct.sum(axis=1, keepdims=True)
            col_sums = ct.sum(axis=0, keepdims=True)
            expected = row_sums * col_sums / n_total
            chi2     = float(((ct - expected) ** 2 / (expected + 1e-10)).sum())
            k        = min(ct.shape) - 1
            return round(float(np.sqrt(max(chi2 / (n_total * k), 0))), 4) if k > 0 else None

        ii2, jj2 = np.triu_indices(len(eligible), k=1)
        for i_idx, j_idx in zip(ii2, jj2):
            ca, cb = eligible[i_idx], eligible[j_idx]
            try:
                cv = _cramers_v_fast(ca, cb)
                if cv is None:
                    continue
                cv_rows.append({
                    "Variable A": ca,
                    "Variable B": cb,
                    "Cramer's V": cv,
                    "Strength":   ("Strong"   if cv >= 0.3 else
                                   "Moderate" if cv >= 0.1 else "Weak"),
                    "vs Target":  "TARGET" if (ca == target_col or cb == target_col) else "",
                })
            except Exception:
                continue

        if cv_rows:
            out["cat_chi2"] = (pd.DataFrame(cv_rows)
                               .sort_values("Cramer's V", ascending=False)
                               .reset_index(drop=True))

    # -- 3. COMBINED TARGET SUMMARY TABLE -------------------------------------
    # One table: every feature, its type, and its association with the target.
    # Numeric features   -> Pearson r (from pearson matrix)
    # Categorical vs categorical target -> Cramer's V (from cat_chi2)
    # Categorical vs numeric target -> Cramer's V with binarized target
    #   (computed in _target_analysis; we pull those values here if available)
    if target_col:
        summary_rows = []

        # Numeric features -> Pearson r
        tc_df = out.get("target_corr", pd.DataFrame())
        if len(tc_df):
            for _, row in tc_df.iterrows():
                r = row["Pearson r"]
                if pd.isna(r):
                    continue
                summary_rows.append({
                    "Feature":   row["Feature"],
                    "Type":      "Numeric",
                    "Metric":    "Pearson r",
                    "Value":     round(float(r), 4),
                    "Abs Value": round(abs(float(r)), 4),
                    "Strength":  ("Strong"     if abs(r) >= 0.5 else
                                  "Moderate"   if abs(r) >= 0.3 else
                                  "Weak"       if abs(r) >= 0.1 else "Negligible"),
                })

        # Categorical features:
        # Case A -- categorical target: pull from cat_chi2 (vs Target pairs)
        chi_df2 = out.get("cat_chi2", pd.DataFrame())
        if len(chi_df2):
            tgt_rows = chi_df2[chi_df2["vs Target"] == "TARGET"].copy()
            for _, row in tgt_rows.iterrows():
                feat = (row["Variable A"]
                        if row["Variable B"] == target_col
                        else row["Variable B"])
                cv = row["Cramer's V"]
                if cv is None or pd.isna(cv):
                    continue
                summary_rows.append({
                    "Feature":   feat,
                    "Type":      "Categorical",
                    "Metric":    "Cramer's V",
                    "Value":     round(float(cv), 4),
                    "Abs Value": round(float(cv), 4),
                    "Strength":  ("Strong"   if cv >= 0.3 else
                                  "Moderate" if cv >= 0.1 else "Weak"),
                })

        # Case B -- numeric target: cat features get Cramer's V via binarized target
        # _target_analysis computes this; we store it in out["_ta_cat_summary"]
        # for pickup here. We do a lightweight version inline:
        target_is_numeric = target_col in df.columns and pd.api.types.is_numeric_dtype(df[target_col])
        if target_is_numeric and len(cat_cols) > 0:
            t_num = pd.to_numeric(df[target_col], errors="coerce")
            # Smart binarization: >40% zeros -> use zero/nonzero split
            # (median binarization fails when median=0 e.g. 96% zeros)
            zero_pct_t = float((t_num == 0).mean())
            if zero_pct_t > 0.40:
                t_bin = (t_num > 0).astype(str)
            else:
                t_bin = (t_num >= t_num.median()).astype(str)

            # Which cat features are eligible and not already in summary?
            already = {r["Feature"] for r in summary_rows}
            for col in cat_cols:
                if col == target_col or col not in df.columns:
                    continue
                if col in already:
                    continue
                try:
                    feat_s = df[col].dropna()
                    t_s    = t_bin.loc[feat_s.index].dropna()
                    feat_s = feat_s.loc[t_s.index]
                    if len(feat_s) < 30:
                        continue
                    # Use the fast bincount Cramer's V
                    ca_codes, ca_size = codes.get(col), sizes.get(col)
                    # If not pre-encoded (column may not have been eligible above), encode now
                    if ca_codes is None:
                        uniq_a, ca_codes = np.unique(
                            feat_s.astype(str).values, return_inverse=True)
                        ca_size = len(uniq_a)
                    # Encode binarized target
                    uniq_b, cb_codes = np.unique(t_s.values, return_inverse=True)
                    cb_size = len(uniq_b)
                    if cb_size < 2:
                        continue
                    # Align indices
                    common_idx = feat_s.index.intersection(t_s.index)
                    if len(common_idx) < 30:
                        continue
                    a_aligned = pd.Series(feat_s.astype(str).values,
                                          index=feat_s.index).loc[common_idx]
                    b_aligned = t_s.loc[common_idx]
                    uniq_a2, inv_a = np.unique(a_aligned.values, return_inverse=True)
                    uniq_b2, inv_b = np.unique(b_aligned.values, return_inverse=True)
                    na2, nb2 = len(uniq_a2), len(uniq_b2)
                    ct = np.bincount(inv_a * nb2 + inv_b,
                                     minlength=na2 * nb2).reshape(na2, nb2).astype(np.float64)
                    ct = ct[ct.sum(1) > 0][:, ct.sum(0) > 0]
                    if ct.shape[0] < 2 or ct.shape[1] < 2:
                        continue
                    n_t = ct.sum()
                    exp = ct.sum(1, keepdims=True) * ct.sum(0, keepdims=True) / n_t
                    chi2 = float(((ct - exp) ** 2 / (exp + 1e-10)).sum())
                    k = min(ct.shape) - 1
                    if k <= 0:
                        continue
                    cv = round(float(np.sqrt(max(chi2 / (n_t * k), 0))), 4)
                    summary_rows.append({
                        "Feature":   col,
                        "Type":      "Categorical",
                        "Metric":    "Cramer's V*",   # * = vs binarized target
                        "Value":     cv,
                        "Abs Value": cv,
                        "Strength":  ("Strong"   if cv >= 0.3 else
                                      "Moderate" if cv >= 0.1 else "Weak"),
                    })
                except Exception:
                    continue

        if summary_rows:
            out["target_summary"] = (
                pd.DataFrame(summary_rows)
                .sort_values("Abs Value", ascending=False)
                .drop(columns=["Abs Value"])
                .reset_index(drop=True)
            )

    return out


# -- fuzzy category matching ---------------------------------------------------

def _fuzzy_categories(col_results, threshold=0.82, max_categories=500):
    """
    Detect near-duplicate category labels using multiple signals:
    - Exact case-insensitive match
    - Whitespace/punctuation normalisation
    - Token-sorted comparison (catches "New York City" vs "City New York")
    - Digit-stripped comparison (catches "Region 1" vs "Region1")
    - Character-level similarity (SequenceMatcher)
    """
    import re
    from difflib import SequenceMatcher

    def _norm(s):
        """Normalise: lowercase, strip, collapse spaces, remove punctuation."""
        s = s.lower().strip()
        s = re.sub(r"[_\-\.\,\/\\]", " ", s)
        s = re.sub(r"\s+", " ", s)
        return s

    def _token_sort(s):
        return " ".join(sorted(_norm(s).split()))

    def _digit_strip(s):
        return re.sub(r"\d+", "", _norm(s)).strip()

    def _similarity(a, b):
        na, nb = _norm(a), _norm(b)
        # Exact normalised match
        if na == nb:
            return 1.0
        # Token-sorted match
        if _token_sort(a) == _token_sort(b):
            return 0.97
        # Digit-stripped match (e.g. "Region 1" vs "Region1")
        if _digit_strip(a) == _digit_strip(b) and _digit_strip(a) != "":
            return 0.95
        # One is prefix of the other (e.g. "NY" vs "New York")
        if na.startswith(nb) or nb.startswith(na):
            ratio = min(len(na), len(nb)) / max(len(na), len(nb))
            if ratio > 0.5:
                return round(0.88 + ratio * 0.1, 3)
        # Character-level similarity
        return round(SequenceMatcher(None, na, nb).ratio(), 3)

    results = {}
    for col, res in col_results.items():
        if res["dtype"] != "Categorical":
            continue
        tbl = res.get("category_table", pd.DataFrame())
        nu  = res.get("n_unique", 0)
        if len(tbl) < 2:
            continue
        if nu > max_categories:
            results[col] = []
            continue

        cats = tbl["Category"].astype(str).tolist()[:max_categories]
        matches = []
        for i in range(len(cats)):
            for j in range(i + 1, len(cats)):
                sim = _similarity(cats[i], cats[j])
                if sim >= threshold:
                    # Determine reason
                    na, nb = _norm(cats[i]), _norm(cats[j])
                    if na == nb:
                        reason = "Case/spacing difference"
                    elif _token_sort(cats[i]) == _token_sort(cats[j]):
                        reason = "Same words, different order"
                    elif _digit_strip(cats[i]) == _digit_strip(cats[j]):
                        reason = "Same text, different number"
                    elif na.startswith(nb) or nb.startswith(na):
                        reason = "One is prefix of other"
                    else:
                        reason = "Similar spelling"
                    matches.append({
                        "Category A": cats[i],
                        "Category B": cats[j],
                        "Similarity": round(sim, 3),
                        "Reason":     reason,
                    })

        if matches:
            results[col] = sorted(matches, key=lambda x: -x["Similarity"])
    return results


# -- scorecard -----------------------------------------------------------------

def _scorecard(col_results, corr, fuzzy):
    rows = []
    for col, res in col_results.items():
        dtype = res["dtype"]; mp = res["missing_pct"]
        dist  = res.get("dist",{}); outl = res.get("outlier",{})
        zi    = res.get("zero_inflated",False); nu = res.get("n_unique",0)

        hit_rate = res["hit_rate_pct"]
        if hit_rate>=99: hr_score=100
        elif hit_rate>=90: hr_score=80
        elif hit_rate>=75: hr_score=55
        elif hit_rate>=50: hr_score=30
        else: hr_score=5
        hr_label = f"{hit_rate:.1f}%"

        inf_pct = res.get("inf_pct",0.0)
        if dtype in ("Numeric","Boolean"):
            zero_pct = res.get("zero_pct",0)
            if zero_pct>=99 or inf_pct>5: vv_score=10
            elif zero_pct>=50: vv_score=60
            elif zero_pct>=30: vv_score=75
            else: vv_score=100
            vv_label = (f"{inf_pct:.1f}% Inf" if inf_pct>0 and zero_pct==0
                        else f"{zero_pct:.0f}% zeros, {inf_pct:.1f}% Inf" if inf_pct>0
                        else f"{zero_pct:.0f}% zeros" if zero_pct>0 else "OK")
        elif dtype == "Categorical":
            rare=res.get("rare_count",0); tbl=res.get("category_table",pd.DataFrame())
            dom=float(tbl["Share %"].max()) if len(tbl) else 0
            if dom>=99: vv_score=20
            elif dom>=90: vv_score=60
            elif rare>5: vv_score=70
            elif rare>0: vv_score=85
            else: vv_score=100
            vv_label = (f"Dom {dom:.0f}%" if dom>=80 else f"{rare} rare cats" if rare else "OK")
        elif dtype == "Constant": vv_score=0; vv_label="Constant -- zero variance"
        else: vv_score=80; vv_label="--"

        sk = float(dist.get("skewness",0) or 0) if dist else 0.0
        if not np.isfinite(sk): sk=0.0
        if dtype=="Numeric":
            ask=abs(sk)
            if ask<0.5: sk_score=100; sk_label=f"Low ({sk:.2f})"
            elif ask<1.0: sk_score=80; sk_label=f"Mod ({sk:.2f})"
            elif ask<2.0: sk_score=55; sk_label=f"High ({sk:.2f})"
            else: sk_score=25; sk_label=f"V.High ({sk:.2f})"
        else: sk_score=100; sk_label="--"

        if dtype=="Categorical":
            fm=fuzzy.get(col,[]); nm=len(fm)
            if nu>50: cc_score=100; cc_label="Skipped (high-card)"
            elif nm==0: cc_score=100; cc_label="Clean"
            elif nm<=2: cc_score=70; cc_label=f"{nm} similar"
            elif nm<=5: cc_score=45; cc_label=f"{nm} similar"
            else: cc_score=20; cc_label=f"{nm} similar"
        else: cc_score=100; cc_label="--"

        iqr_p = outl.get("iqr_pct",0) if dtype in ("Numeric","Boolean") else None
        if iqr_p is None: ol_score=100; ol_label="--"
        elif dtype=="Constant": ol_score=0; ol_label="Constant"
        elif zi: ol_score=50; ol_label="Zero-Inf"
        elif iqr_p<1: ol_score=100; ol_label=f"Low ({iqr_p:.1f}%)"
        elif iqr_p<3: ol_score=80; ol_label=f"Med ({iqr_p:.1f}%)"
        elif iqr_p<8: ol_score=55; ol_label=f"High ({iqr_p:.1f}%)"
        else: ol_score=25; ol_label=f"V.High ({iqr_p:.1f}%)"

        if dtype=="Constant": hr_score=100; vv_score=0; sk_score=0; cc_score=0; ol_score=0

        overall = round(0.30*hr_score + 0.20*vv_score + 0.15*sk_score + 0.15*cc_score + 0.20*ol_score, 1)

        # Hard overrides -- critical data quality issues always -> Fix First
        if hit_rate < 50:   overall = min(overall, 40)  # <50% populated is always critical
        if hit_rate < 25:   overall = min(overall, 20)  # extremely sparse

        if overall>=80: rag="Good"; pri=2
        elif overall>=55: rag="Review"; pri=1
        else: rag="Fix First"; pri=0

        icons = {"Numeric":"[num]","Categorical":"","Boolean":"[bool]","Date":"",
                 "ID-like":"[id]","Unknown":"?","Constant":"[const]"}
        rows.append({"Feature":col,"Type":f"{icons.get(dtype,'?')} {dtype}",
                     "Hit Rate":hr_label,"Valid Values":vv_label,"Skewness":sk_label,
                     "Cat Consistency":cc_label,"Outlier Score":ol_label,
                     "Overall (0-100)":overall,"Status":rag,
                     "_hr":hr_score,"_vv":vv_score,"_sk":sk_score,"_cc":cc_score,"_ol":ol_score,"_p":pri})

    df_sc = pd.DataFrame(rows)
    if len(df_sc):
        df_sc = (df_sc.sort_values(["_p","Overall (0-100)"])
                      .drop(columns=["_hr","_vv","_sk","_cc","_ol","_p"])
                      .reset_index(drop=True))
    return df_sc


# -- recommendations -----------------------------------------------------------

def _recommendations(col_results, scorecard):
    score_map = {r["Feature"]:r["Status"] for _,r in scorecard.iterrows()} if len(scorecard) else {}
    recs = []
    for col, res in col_results.items():
        dtype=res["dtype"]; mp=res["missing_pct"]
        dist=res.get("dist",{}); outl=res.get("outlier",{})
        zi=res.get("zero_inflated",False); nu=res.get("n_unique",0); inf_p=res.get("inf_pct",0.0)
        items=[]
        if mp>=100 or dtype=="Unknown":
            items.append(("Column entirely null","Drop or investigate data pipeline"))
        elif dtype=="Constant":
            items.append(("Zero-variance constant column","Drop before modelling -- carries no information"))
        elif dtype=="Numeric":
            sk=dist.get("skewness",0) if dist else 0
            if inf_p>0: items.append((f"{inf_p:.2f}% Inf values","Investigate; replace or cap Inf"))
            if zi: items.append((f"Zero-inflated ({res.get('zero_pct',0):.0f}% zeros)","Two-part model or Tweedie GLM"))
            if dist.get("is_lognormal") and sk>0.5: items.append(("Log-normal","Apply log1p transform"))
            elif abs(sk)>1.5 and not zi: items.append((f"Highly skewed (skew={sk:.1f})","Apply log1p transform"))
            if not zi and outl.get("iqr_pct",0)>5:
                items.append((f"{outl['iqr_pct']:.1f}% outliers",f"Cap at P99 = {outl.get('p99_cap','?')}"))
            if mp>20: items.append((f"High missing ({mp:.0f}%)",f"Add {col}_missing flag + median impute"))
            elif mp>0: items.append((f"Missing {mp:.0f}%","Median imputation"))
            if nu<=5 and nu>0: items.append(("Very few unique values","Treat as categorical / ordinal"))
        elif dtype=="Categorical":
            if res.get("rare_count",0)>0: items.append((f"{res['rare_count']} rare categories (<1%)","Group into 'Other'"))
            if nu>50: items.append((f"High cardinality ({nu} cats)","Target encode or frequency encode"))
            if mp>0: items.append((f"Missing {mp:.0f}%","Create 'Unknown' category"))
        elif dtype=="ID-like": items.append(("ID column","Exclude from modelling"))
        elif dtype=="Date": items.append(("Date column","Extract year, month, quarter, day-of-week"))
        if not items: continue
        recs.append(dict(Feature=col, Type=dtype, Priority=score_map.get(col,"Good"), Items=items))
    order={"Fix First":0,"Review":1,"Good":2}
    recs.sort(key=lambda r: order.get(r["Priority"],3))
    return recs


# -- comparison summary --------------------------------------------------------

def _df_summary(df, label, agg_cols_list):
    """
    Produce a descriptive summary table for one DataFrame.
    Returns a DataFrame with columns: Column, Count, Missing%, Sum, Mean, Median, Min, Max
    """
    rows = []
    for col in agg_cols_list:
        if col not in df.columns:
            continue
        s = pd.to_numeric(df[col], errors="coerce")
        rows.append({
            "Column":    col,
            "Count":     int(s.notna().sum()),
            "Missing %": round(s.isna().mean() * 100, 2),
            "Sum":       round(s.sum(), 4),
            "Mean":      round(s.mean(), 4),
            "Median":    round(s.median(), 4),
            "Min":       round(s.min(), 4),
            "Max":       round(s.max(), 4),
        })
    return pd.DataFrame(rows)


def _comparison_summary(df_a, df_b, label_a, label_b, groupby_col, agg_cols, agg_config=None):
    """
    Produce:
      - summary_a / summary_b  : descriptive stats per configured column
      - per_col_tables         : dict of {col_fn -> DataFrame} with one row per group,
                                 columns = [group, A_val, B_val, Diff(A-B), Diff%]
                                 plus a TOTAL row at the bottom
    groupby_col : str or list of column names
    agg_cols    : list of columns -- default agg = sum
    agg_config  : dict {col: [funcs]}  e.g. {"Premium": ["sum","mean"], "Policy_Number": ["count","nunique"]}
    """
    # Normalise groupby to list
    if isinstance(groupby_col, str):
        grp_cols = [groupby_col] if groupby_col else []
    else:
        grp_cols = [c for c in (groupby_col or []) if c]

    # Build agg dict: col -> list of funcs
    if agg_config:
        final_agg = {c: (f if isinstance(f, list) else [f]) for c, f in agg_config.items()}
    elif agg_cols:
        final_agg = {c: ["sum"] for c in agg_cols}
    else:
        final_agg = {}

    # Flat list of all configured columns for summary
    all_agg_cols = list(final_agg.keys())

    # -- per-DataFrame descriptive summaries ----------------------------------
    summary_a = _df_summary(df_a, label_a, all_agg_cols)
    summary_b = _df_summary(df_b, label_b, all_agg_cols)

    # -- grouped comparison tables ---------------------------------------------
    def _apply_agg(df, grp, col, fn):
        """Apply a single aggregation function to col grouped by grp."""
        df2 = df.copy()
        df2[col] = pd.to_numeric(df2[col], errors="coerce")
        if fn == "nunique":
            return df2.groupby(grp)[col].nunique()
        elif fn == "count":
            return df2.groupby(grp)[col].count()
        elif fn == "sum":
            return df2.groupby(grp)[col].sum()
        elif fn == "mean":
            return df2.groupby(grp)[col].mean()
        elif fn == "median":
            return df2.groupby(grp)[col].median()
        else:
            return df2.groupby(grp)[col].agg(fn)

    valid_grp = [c for c in grp_cols if c in df_a.columns and c in df_b.columns]

    # One comparison table per (column, function) combination
    per_col_tables = {}   # key = "Premium_sum", value = DataFrame

    if valid_grp:
        grp_label = "_".join(valid_grp)
        for col, fns in final_agg.items():
            if col not in df_a.columns and col not in df_b.columns:
                continue
            for fn in fns:
                key = f"{col}_{fn}"
                try:
                    sa = _apply_agg(df_a, valid_grp, col, fn) if col in df_a.columns else pd.Series(dtype=float)
                    sb = _apply_agg(df_b, valid_grp, col, fn) if col in df_b.columns else pd.Series(dtype=float)

                    # Align on the union of group values
                    all_groups = sa.index.union(sb.index)
                    sa = sa.reindex(all_groups, fill_value=0.0)
                    sb = sb.reindex(all_groups, fill_value=0.0)

                    rows = []
                    for grp_val in all_groups:
                        va = float(sa.loc[grp_val])
                        vb = float(sb.loc[grp_val])
                        diff      = round(va - vb, 6)
                        diff_pct  = round(abs(diff) / abs(va) * 100, 2) if va != 0 else (0.0 if vb == 0 else 100.0)
                        match_pct = max(0.0, round(100.0 - diff_pct, 2))
                        # group label -- handle MultiIndex
                        grp_str = " | ".join(str(v) for v in grp_val) if isinstance(grp_val, tuple) else str(grp_val)
                        rows.append({
                            grp_label:           grp_str,
                            f"{label_a}":        round(va, 4),
                            f"{label_b}":        round(vb, 4),
                            "Diff (A-B)":        diff,
                            "Diff %":            round(diff_pct, 2),
                            "Match %":           match_pct,
                        })

                    tbl = pd.DataFrame(rows).sort_values(grp_label).reset_index(drop=True)

                    # TOTAL row
                    tot_a     = round(float(sa.sum()), 4)
                    tot_b     = round(float(sb.sum()), 4)
                    tot_diff  = round(tot_a - tot_b, 6)
                    tot_dpct  = round(abs(tot_diff) / abs(tot_a) * 100, 2) if tot_a != 0 else (0.0 if tot_b == 0 else 100.0)
                    tot_match = max(0.0, round(100.0 - tot_dpct, 2))
                    total_row = pd.DataFrame([{
                        grp_label:    "TOTAL",
                        f"{label_a}": tot_a,
                        f"{label_b}": tot_b,
                        "Diff (A-B)": tot_diff,
                        "Diff %":     round(tot_dpct, 2),
                        "Match %":    tot_match,
                    }])
                    tbl = pd.concat([tbl, total_row], ignore_index=True)
                    per_col_tables[key] = {"table": tbl, "col": col, "fn": fn, "grp_label": grp_label}

                except Exception as e:
                    print(f"  [WARN] Comparison {key}: {e}")

    return dict(
        summary_a=summary_a,
        summary_b=summary_b,
        per_col_tables=per_col_tables,
        label_a=label_a,
        label_b=label_b,
        rows_a=len(df_a),
        rows_b=len(df_b),
        groupby_col=grp_cols,
        agg_config=final_agg,
    )


# -- master --------------------------------------------------------------------

def run_eda(df, config):
    t0 = time.time()
    n  = len(df)
    target      = config.get("target_col")
    feats       = [c for c in df.columns if c != target]
    corr_sample = config.get("corr_sample", 100_000)
    corr_thresh = config.get("corr_threshold", 0.75)
    rare_pct    = config.get("rare_cat_pct", 1.0)
    plot_n      = config.get("plot_sample", 20_000)
    norm_n      = config.get("norm_sample", 5_000)
    id_ratio    = config.get("id_ratio", 0.8)
    max_corr    = config.get("max_corr_vars", 30)
    sections    = config.get("sections", {})  # {} = all on

    def _on(k): return sections.get(k, True)

    _log(f"EDA -- {len(feats)} features x {n:,} rows", 0)

    # -- Use pre-confirmed dtype_map from InspectPlan if available -------------
    # If the user ran inspect() + plan.confirm(), dtype_map is already set --
    # no need to re-detect. Fall back to auto-detect only if not provided.
    pre_dtype_map = config.get("dtype_map", {})
    if pre_dtype_map:
        dtype_map = {c: pre_dtype_map.get(c, detect_type(df[c], id_ratio)) for c in feats}
        _log("Using confirmed column types...", 5)
    else:
        _log("Detecting types...", 5)
        dtype_map = {c: detect_type(df[c], id_ratio) for c in feats}

    for col, ft in config.get("dtype_overrides", {}).items():
        if col in dtype_map: dtype_map[col] = ft

    _log("Analysing columns...", 15)
    col_results = {}
    for i, col in enumerate(feats):
        dtype = dtype_map[col]
        try:
            if dtype in ("Numeric","Boolean"):
                s = df[col]
                if dtype=="Boolean" and s.dtype==object:
                    s = s.map(lambda v: 1.0 if str(v).strip().lower() in
                              {"1","y","yes","true","t","1.0","male","m"} else (0.0 if pd.notna(v) else np.nan))
                col_results[col] = _analyse_numeric(col, s, n, plot_n, norm_n)
            elif dtype == "ID-like":
                nu = int(df[col].nunique())
                col_results[col] = dict(
                    dtype="ID-like",
                    missing_count=int(df[col].isna().sum()),
                    missing_pct=round(df[col].isna().mean()*100, 1),
                    hit_rate_pct=round((1-df[col].isna().mean())*100, 1),
                    inf_count=0, inf_pct=0.0, n_unique=nu,
                    zero_pct=0, dist={}, outlier={}, plot_sample=[],
                    zero_inflated=False, skewness=None,
                    sample_values=df[col].dropna().astype(str).head(5).tolist(),
                )
            elif dtype == "Date":
                s_dt = pd.to_datetime(df[col], errors="coerce")
                valid = s_dt.dropna()
                col_results[col] = dict(
                    dtype="Date",
                    missing_count=int(df[col].isna().sum()),
                    missing_pct=round(df[col].isna().mean()*100, 1),
                    hit_rate_pct=round((1-df[col].isna().mean())*100, 1),
                    inf_count=0, inf_pct=0.0,
                    n_unique=int(s_dt.nunique()),
                    zero_pct=0, dist={}, outlier={}, plot_sample=[],
                    zero_inflated=False, skewness=None,
                    date_min=str(valid.min().date()) if len(valid) else "--",
                    date_max=str(valid.max().date()) if len(valid) else "--",
                    year_counts=valid.dt.year.value_counts().sort_index().to_dict() if len(valid) else {},
                    month_counts=valid.dt.month.value_counts().sort_index().to_dict() if len(valid) else {},
                )
            elif dtype=="Unknown":
                col_results[col] = dict(dtype="Unknown",
                    missing_count=int(df[col].isna().sum()),
                    missing_pct=round(df[col].isna().mean()*100,1),
                    hit_rate_pct=round((1-df[col].isna().mean())*100,1),
                    inf_count=0,inf_pct=0.0,n_unique=0,zero_pct=0,
                    dist={},outlier={},plot_sample=[],zero_inflated=False,skewness=None)
            elif dtype=="Constant":
                col_results[col] = dict(dtype="Constant",
                    missing_count=int(df[col].isna().sum()),
                    missing_pct=round(df[col].isna().mean()*100,1),
                    hit_rate_pct=round((1-df[col].isna().mean())*100,1),
                    inf_count=0,inf_pct=0.0,n_unique=1,
                    constant_value=str(df[col].dropna().iloc[0]) if df[col].notna().any() else "NaN",
                    zero_pct=0,dist={},outlier={},plot_sample=[],zero_inflated=False,skewness=None)
            else:
                col_results[col] = _analyse_categorical(col, df[col], n, rare_pct)
        except Exception as e:
            print(f"  [WARN] {col}: {e}")
            col_results[col] = dict(dtype=dtype,missing_count=0,missing_pct=0,
                hit_rate_pct=100,inf_count=0,inf_pct=0.0,n_unique=0,zero_pct=0,
                dist={},outlier={},plot_sample=[],zero_inflated=False,skewness=None)
        pct = 15 + int((i+1)/len(feats)*35)
        if (i+1) % max(1, len(feats)//8) == 0 or i+1==len(feats):
            _log(f"Features {i+1}/{len(feats)}", pct)

    corr={}; fuzzy={}; sc=pd.DataFrame(); recs=[]
    if _on("correlations"):
        _log("Correlations...", 52)
        chi_sample          = config.get("chi_sample",          20_000)
        chi_max_cardinality = config.get("chi_max_cardinality", 10_000)
        all_cols = list(feats)
        if target and target in df.columns and target not in all_cols:
            all_cols = [target] + all_cols
        corr = _correlations(df[all_cols], corr_sample, corr_thresh,
                             target_col=target,
                             chi_sample=chi_sample,
                             chi_max_cardinality=chi_max_cardinality)
    if _on("category_quality"):
        _log("Fuzzy category matching...", 62)
        fuzzy = _fuzzy_categories(col_results)
    if _on("scorecard"):
        _log("Scorecard...", 72)
        sc = _scorecard(col_results, corr, fuzzy)
        _log("Recommendations...", 82)
        recs = _recommendations(col_results, sc)

    target_analysis = {}
    if target and _on("target_analysis"):
        _log("Target analysis (correlations)...", 88)
        target_analysis = _target_analysis(df, col_results, dtype_map, target)

    # -- Deep Target Analysis (full aggregations for Target Analysis tab) ------
    deep_ta = {}
    if target and _on("target_analysis"):
        _log("Deep target analysis (binning + aggregations)...", 91)
        try:
            from .target_analysis_engine import build_target_analysis
        except ImportError:
            try:
                from target_analysis_engine import build_target_analysis
            except ImportError:
                build_target_analysis = None
        if build_target_analysis:
            n_bins_list  = config.get("ta_n_bins",       [5, 10, 20])
            bin_methods  = config.get("ta_methods",       ["equal", "quantile"])
            exposure_col = config.get("ta_exposure_col",  None)
            bin_by       = config.get("ta_bin_by",        "amount")
            try:
                deep_ta = build_target_analysis(
                    df, dtype_map, target,
                    n_bins_list  = n_bins_list,
                    bin_methods  = bin_methods,
                    exposure_col = exposure_col,
                    bin_by       = bin_by,
                )
            except Exception as e:
                print(f"  [WARN] Deep target analysis: {e}")

    det = pd.DataFrame()
    if config.get("groupby_col") and config.get("agg_config"):
        _log("Grouped report...", 90)
        gb  = config["groupby_col"]
        agg = {c: f for c,f in config["agg_config"].items() if c in df.columns}
        if gb in df.columns and agg:
            try:
                r = df.groupby(gb).agg(agg)
                r.columns = ["_".join(c) for c in r.columns]
                det = r.reset_index().sort_values(gb)
            except Exception as e:
                print(f"  [WARN] Grouped report: {e}")

    comparison = {}
    cmp_cfg = config.get("comparison")
    if cmp_cfg and isinstance(cmp_cfg, dict):
        _log("Comparison summary...", 93)
        try:
            comparison = _comparison_summary(
                df_a=df, df_b=cmp_cfg["df"],
                label_a=cmp_cfg.get("label_a","Dataset A"),
                label_b=cmp_cfg.get("label_b","Dataset B"),
                groupby_col=cmp_cfg.get("groupby_col", config.get("groupby_col","")),
                agg_cols=cmp_cfg.get("agg_cols",[]),
                agg_config=cmp_cfg.get("agg_config",{}),
            )
            # Store raw DataFrames for side-by-side browsing in the dashboard
            comparison["df_a"] = df
            comparison["df_b"] = cmp_cfg["df"]
        except Exception as e:
            print(f"  [WARN] Comparison: {e}")

    elapsed = round(time.time()-t0, 1)
    _log(f"Done in {elapsed}s", 100)

    return dict(
        df=df, config=config, feature_cols=feats, dtype_map=dtype_map,
        n_rows=n, n_features=len(feats), elapsed_sec=elapsed, target_col=target,
        col_results=col_results, correlations=corr, fuzzy_categories=fuzzy,
        scorecard=sc, recommendations=recs, grouped_report=det,
        target_analysis=target_analysis, deep_target_analysis=deep_ta,
        comparison=comparison,
    )
